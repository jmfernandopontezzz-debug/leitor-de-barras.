//#region node_modules/docx/dist/index.mjs
var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod, mod.exports), cb = null), mod.exports);
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof(o);
}
function toPrimitive(t, r) {
	if ("object" != _typeof(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function toPropertyKey(t) {
	var i = toPrimitive(t, "string");
	return "symbol" == _typeof(i) ? i : i + "";
}
function _defineProperty(e, r, t) {
	return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
/**
* Abstract base class for all XML components in the library.
*
* BaseXmlComponent defines the minimal interface that all XML components must implement.
* It stores the XML element name (rootKey) and requires subclasses to implement
* the prepForXml method for serialization.
*
* @example
* ```typescript
* class MyElement extends BaseXmlComponent {
*   constructor() {
*     super("w:myElement");
*   }
*
*   prepForXml(context: IContext): IXmlableObject {
*     return { "w:myElement": {} };
*   }
* }
* ```
*/
var BaseXmlComponent = class {
	/**
	* Creates a new BaseXmlComponent with the specified XML element name.
	*
	* @param rootKey - The XML element name (e.g., "w:p", "w:r", "w:t")
	*/
	constructor(rootKey) {
		_defineProperty(
			this,
			/** The XML element name for this component (e.g., "w:p" for paragraph). */
			"rootKey",
			void 0
		);
		this.rootKey = rootKey;
	}
	/**
	* The components written in this one's place, one after another, when it can't be written as a single element,
	* such as a run with another run in its children. Undefined when it is written as itself.
	*
	* @internal
	*/
	get writtenAs() {}
};
/**
* Whether a value is a component, from this copy of docx or from another, such as the copy a plugin or another
* library that builds on docx was bundled with. A component from another copy isn't an instance of this copy's
* classes, so it is known by the method that writes it.
*
* The method is checked, rather than a marker such as a `Symbol.for` brand, because copies of docx that predate any
* marker wouldn't carry it, while every copy's components have `prepForXml`. Overriding `Symbol.hasInstance` on the
* base class isn't an option either: subclasses inherit it, so `instanceof Paragraph` would match any component.
*
* What it doesn't take for a component stays safe: an object to write as XML, such as `{ "w:b": {} }`, has no
* methods, and neither has a component copied without its class (with `Object.assign` or spread), which has lost the
* method that would write it.
*
* @internal
*/
var isXmlComponent = (value) => value instanceof BaseXmlComponent || typeof value === "object" && value !== null && typeof value.prepForXml === "function";
/**
* The element a component writes, such as `w:p` for a paragraph, from this copy of docx or from another. Undefined
* when the value isn't a component.
*
* Checks that need to know what kind of component a child is, such as whether a cell ends with a paragraph, compare
* this rather than the child's class, so they hold for components from another copy too. The element is also what
* those checks are really about, because the rules they enforce are rules of the XML: a cell must end with a `w:p`,
* and a `w:r` can't be inside another.
*
* `rootKey` is protected, so it is read through a cast. That is safe for any copy of docx, because every component
* is constructed with its element as `rootKey`.
*
* @internal
*/
var elementOf = (value) => isXmlComponent(value) ? value.rootKey : void 0;
/**
* XML Component module for the docx library.
*
* This module provides the core XmlComponent class that all WordprocessingML elements
* extend from. XmlComponent manages the conversion of component trees into XML structures
* that can be serialized into DOCX files.
*
* @module
*/
/**
* Empty object singleton used for empty XML elements.
*
* This sealed object is used to generate self-closing XML tags when an element
* has no children or attributes.
*
* @internal
*/
var EMPTY_OBJECT = Object.seal({});
/**
* Base class for all XML components in WordprocessingML documents.
*
* XmlComponent provides the infrastructure for building XML element trees
* that are serialized into document.xml and other parts of the DOCX package.
* It manages a collection of child components and handles the conversion to
* the intermediate object format used by the xml serialization library.
*
* @example
* ```typescript
* // Creating a custom XML component
* class MyElement extends XmlComponent {
*   constructor(text: string) {
*     super("w:myElement");
*     this.root.push(new Attributes({ val: text }));
*   }
* }
*
* const element = new MyElement("Hello");
* // When serialized: <w:myElement w:val="Hello"/>
* ```
*/
var XmlComponent = class extends BaseXmlComponent {
	/**
	* Creates a new XmlComponent.
	*
	* @param rootKey - The XML element name (e.g., "w:p", "w:r", "w:t")
	*/
	constructor(rootKey) {
		super(rootKey);
		_defineProperty(
			this,
			/**
			* Array of child components, text nodes, and attributes.
			*
			* This array forms the content of the XML element. It can contain other
			* XmlComponents, string values (text nodes), or attribute components.
			*/
			"root",
			void 0
		);
		this.root = new Array();
	}
	/**
	* Prepares this component and its children for XML serialization.
	*
	* This method is called by the Formatter to convert the component tree into
	* an object structure compatible with the xml library (https://www.npmjs.com/package/xml).
	* It recursively processes all children and handles special cases like
	* attribute-only elements and empty elements.
	*
	* The method can be overridden by subclasses to customize XML representation
	* or execute side effects during serialization (e.g., creating relationships).
	*
	* @param context - The serialization context containing document state
	* @returns The XML-serializable object, or undefined to exclude from output
	*
	* @example
	* ```typescript
	* // Override to add custom serialization logic
	* prepForXml(context: IContext): IXmlableObject | undefined {
	*   // Custom logic here
	*   return super.prepForXml(context);
	* }
	* ```
	*/
	prepForXml(context) {
		var _children$;
		context.stack.push(this);
		const children = this.root.flatMap((comp) => {
			if (isXmlComponent(comp)) {
				const parts = comp.writtenAs;
				return parts ? parts.map((part) => part.prepForXml(context)) : comp.prepForXml(context);
			}
			return comp;
		}).filter((comp) => comp !== void 0);
		context.stack.pop();
		return { [this.rootKey]: children.length ? children.length === 1 && ((_children$ = children[0]) === null || _children$ === void 0 ? void 0 : _children$._attr) ? children[0] : children : EMPTY_OBJECT };
	}
	/**
	* Adds a child element to this component.
	*
	* @deprecated Do not use this method. It is only used internally by the library. It will be removed in a future version.
	* @param child - The child component or text string to add
	* @returns This component (for chaining)
	*/
	addChildElement(child) {
		this.root.push(child);
		return this;
	}
};
/**
* XML component that is excluded from output if it has no meaningful content.
*
* IgnoreIfEmptyXmlComponent is useful for optional container elements that
* should only appear in the XML if they contain children or attributes.
* If the element would be empty, it returns undefined instead, causing it
* to be excluded from the output.
*
* @example
* ```typescript
* class OptionalContainer extends IgnoreIfEmptyXmlComponent {
*   constructor(items?: Item[]) {
*     super("w:container");
*     if (items) {
*       items.forEach(item => this.root.push(item));
*     }
*   }
* }
*
* const container1 = new OptionalContainer([item1, item2]);
* // Renders: <w:container>...</w:container>
*
* const container2 = new OptionalContainer();
* // Renders: nothing (excluded from output)
* ```
*/
var IgnoreIfEmptyXmlComponent = class extends XmlComponent {
	constructor(rootKey, includeIfEmpty) {
		super(rootKey);
		_defineProperty(this, "includeIfEmpty", void 0);
		this.includeIfEmpty = includeIfEmpty;
	}
	/**
	* Prepares the component for XML serialization, excluding it if empty.
	*
	* @param context - The serialization context
	* @returns The XML-serializable object, or undefined if empty
	*/
	prepForXml(context) {
		const result = super.prepForXml(context);
		if (this.includeIfEmpty) return result;
		return result && (typeof result[this.rootKey] !== "object" || Object.keys(result[this.rootKey]).length) ? result : void 0;
	}
};
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread2(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
			_defineProperty(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
/**
* XML attribute components for the docx library.
*
* This module provides base classes for creating XML element attributes.
* Attributes are represented as special components with the "_attr" key.
*
* @module
*/
/**
* Base class for creating XML attributes with automatic name mapping.
*
* XmlAttributeComponent allows you to define attributes using JavaScript-friendly
* property names that are automatically mapped to XML attribute names. Subclasses
* can define an xmlKeys map to specify the transformation.
*
* @example
* ```typescript
* class MyAttributes extends XmlAttributeComponent<{ fontSize: number }> {
*   protected readonly xmlKeys = { fontSize: "w:sz" };
* }
*
* new MyAttributes({ fontSize: 24 });
* // Generates: _attr: { "w:sz": 24 }
* ```
*/
var XmlAttributeComponent = class extends BaseXmlComponent {
	/**
	* Creates a new attribute component.
	*
	* @param root - The attribute data object
	*/
	constructor(root) {
		super("_attr");
		_defineProperty(this, "root", void 0);
		_defineProperty(
			this,
			/** Optional mapping from property names to XML attribute names. */
			"xmlKeys",
			void 0
		);
		this.root = root;
	}
	/**
	* Converts the attribute data to an XML-serializable object.
	*
	* This method transforms the property names using xmlKeys (if defined)
	* and filters out undefined values.
	*
	* @param _ - Context (unused for attributes)
	* @returns Object with _attr key containing the mapped attributes
	*/
	prepForXml(_) {
		const attrs = {};
		Object.entries(this.root).forEach(([key, value]) => {
			if (value !== void 0) {
				const newKey = this.xmlKeys && this.xmlKeys[key] || key;
				attrs[newKey] = value;
			}
		});
		return { _attr: attrs };
	}
};
/**
* Next-generation attribute component with explicit key-value pairs.
*
* NextAttributeComponent provides an alternative approach to attributes where
* each property explicitly specifies both its XML attribute name and value.
* This gives more control but is more verbose than XmlAttributeComponent.
*
* @example
* ```typescript
* new NextAttributeComponent({
*   fontSize: { key: "w:sz", value: 24 },
*   bold: { key: "w:b", value: true }
* });
* // Generates: _attr: { "w:sz": 24, "w:b": true }
* ```
*/
var NextAttributeComponent = class extends BaseXmlComponent {
	/**
	* Creates a new NextAttributeComponent.
	*
	* @param root - Attribute payload with explicit key-value mappings
	*/
	constructor(root) {
		super("_attr");
		_defineProperty(this, "root", void 0);
		this.root = root;
	}
	/**
	* Converts the attribute payload to an XML-serializable object.
	*
	* Extracts the key and value from each property and filters out
	* undefined values.
	*
	* @param _ - Context (unused for attributes)
	* @returns Object with _attr key containing the attributes
	*/
	prepForXml(_) {
		return { _attr: Object.values(this.root).filter(({ value }) => value !== void 0).reduce((acc, { key, value }) => _objectSpread2(_objectSpread2({}, acc), {}, { [key]: value }), {}) };
	}
};
/**
* Common XML attributes module for WordprocessingML elements.
*
* This module provides a reusable Attributes class with commonly used
* WordprocessingML attribute mappings.
*
* @module
*/
/**
* Common XML attributes used across WordprocessingML elements.
*
* This class provides a convenient way to add common attributes to XML elements.
* It automatically maps JavaScript-friendly property names to their corresponding
* w: (WordprocessingML) namespace prefixed XML attribute names.
*
* @example
* ```typescript
* // Create an element with a value attribute
* new Attributes({ val: "someValue" });
* // Generates: <element w:val="someValue"/>
*
* // Multiple attributes
* new Attributes({ color: "FF0000", sz: "24" });
* // Generates: <element w:color="FF0000" w:sz="24"/>
* ```
*/
var Attributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			val: "w:val",
			color: "w:color",
			fill: "w:fill",
			space: "w:space",
			sz: "w:sz",
			type: "w:type",
			rsidR: "w:rsidR",
			rsidRPr: "w:rsidRPr",
			rsidSect: "w:rsidSect",
			w: "w:w",
			h: "w:h",
			top: "w:top",
			right: "w:right",
			bottom: "w:bottom",
			left: "w:left",
			header: "w:header",
			footer: "w:footer",
			gutter: "w:gutter",
			linePitch: "w:linePitch",
			pos: "w:pos"
		});
	}
};
function _objectWithoutPropertiesLoose(r, e) {
	if (null == r) return {};
	var t = {};
	for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
		if (e.includes(n)) continue;
		t[n] = r[n];
	}
	return t;
}
function _objectWithoutProperties(e, t) {
	if (null == e) return {};
	var o, r, i = _objectWithoutPropertiesLoose(e, t);
	if (Object.getOwnPropertySymbols) {
		var s = Object.getOwnPropertySymbols(e);
		for (r = 0; r < s.length; r++) o = s[r], t.includes(o) || {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
	}
	return i;
}
var _excluded$4 = ["elements"];
var PREDEFINED_ENTITIES = /* @__PURE__ */ new Map([
	["amp", "&"],
	["lt", "<"],
	["gt", ">"],
	["quot", "\""],
	["apos", "'"]
]);
var ENTITY_REFERENCE = /&([^;]*);?/g;
/**
* Decodes the five entities XML predefines and character references, such as `&#xA0;`. XML that declares entities of
* its own in a DTD is not supported, so that no input can expand into more than it holds.
*/
var decodeEntities = (raw) => raw.indexOf("&") === -1 ? raw : raw.replace(ENTITY_REFERENCE, (reference, name) => {
	if (!reference.endsWith(";")) throw new Error(`Invalid XML: "&" that starts no entity, in "${raw}"`);
	const predefined = PREDEFINED_ENTITIES.get(name);
	if (predefined !== void 0) return predefined;
	const codePoint = /^#x[0-9a-f]+$/i.test(name) ? parseInt(name.slice(2), 16) : /^#[0-9]+$/.test(name) ? parseInt(name.slice(1), 10) : NaN;
	if (!(codePoint > 0 && codePoint <= 1114111)) throw new Error(`Invalid XML: unknown entity "${reference}"`);
	return String.fromCodePoint(codePoint);
});
var isWhitespace = (char) => char === " " || char === "\n" || char === "	" || char === "\r";
var DECLARATION_ATTRIBUTE = /([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g;
var parseDeclarationAttributes = (body) => Object.fromEntries([...body.matchAll(DECLARATION_ATTRIBUTE)].map(([, name, doubleQuoted, singleQuoted]) => [name, doubleQuoted !== null && doubleQuoted !== void 0 ? doubleQuoted : singleQuoted]));
/**
* Reads XML into a tree of {@link XmlElement}s, the shape xml-js gave for `xml2js(text)`.
*
* Throws on XML that isn't well formed, such as an element that isn't closed or an entity XML doesn't predefine.
*
* @param text - The XML
* @param options - Whether to keep text that is only whitespace
* @returns The document, with its declaration and the nodes at its top level
*/
var parseXml = (text, { keepWhitespaceText = false } = {}) => {
	const document = {};
	const open = [];
	let position = text.charCodeAt(0) === 65279 ? 1 : 0;
	while (position < text.length && isWhitespace(text[position])) position++;
	const append = (node) => {
		var _parent$elements;
		const parent = open.length === 0 ? document : open[open.length - 1];
		((_parent$elements = parent.elements) !== null && _parent$elements !== void 0 ? _parent$elements : parent.elements = []).push(node);
	};
	const appendText = (raw) => {
		if (raw.trim() === "") {
			if (raw !== "" && keepWhitespaceText) append({
				type: "text",
				text: raw
			});
			return;
		}
		if (open.length === 0) throw new Error(`Invalid XML: text outside of the root element, "${raw.trim()}"`);
		append({
			type: "text",
			text: decodeEntities(raw)
		});
	};
	const indexOfOrThrow = (search, from, what) => {
		const index = text.indexOf(search, from);
		if (index === -1) throw new Error(`Invalid XML: ${what} that isn't closed`);
		return index;
	};
	while (position < text.length) {
		const tagStart = text.indexOf("<", position);
		appendText(text.slice(position, tagStart === -1 ? text.length : tagStart));
		if (tagStart === -1) break;
		if (text.startsWith("<?", tagStart)) {
			const end = indexOfOrThrow("?>", tagStart + 2, "processing instruction");
			const content = text.slice(tagStart + 2, end);
			const nameEnd = content.search(/\s/);
			const name = nameEnd === -1 ? content : content.slice(0, nameEnd);
			const body = nameEnd === -1 ? "" : content.slice(nameEnd).trimStart();
			if (name.toLowerCase() === "xml") {
				const attributes = parseDeclarationAttributes(body);
				document.declaration = Object.keys(attributes).length > 0 ? { attributes } : {};
			} else append({
				type: "instruction",
				name,
				instruction: body
			});
			position = end + 2;
		} else if (text.startsWith("<!--", tagStart)) {
			const end = indexOfOrThrow("-->", tagStart + 4, "comment");
			const comment = text.slice(tagStart + 4, end);
			if (comment !== "") append({
				type: "comment",
				comment
			});
			position = end + 3;
		} else if (text.startsWith("<![CDATA[", tagStart)) {
			const end = indexOfOrThrow("]]>", tagStart + 9, "CDATA section");
			const cdata = text.slice(tagStart + 9, end);
			if (cdata !== "") append({
				type: "cdata",
				cdata
			});
			position = end + 3;
		} else if (text.startsWith("<!DOCTYPE", tagStart)) {
			let end = tagStart + 9;
			let quote;
			let inSubset = false;
			for (; end < text.length; end++) {
				const char = text[end];
				if (quote !== void 0) quote = char === quote ? void 0 : quote;
				else if (char === "\"" || char === "'") quote = char;
				else if (char === "[") inSubset = true;
				else if (char === "]") inSubset = false;
				else if (char === ">" && !inSubset) break;
			}
			if (end === text.length) throw new Error("Invalid XML: DOCTYPE that isn't closed");
			append({
				type: "doctype",
				doctype: text.slice(tagStart + 9, end).replace(/^ /, "")
			});
			position = end + 1;
		} else if (text.startsWith("</", tagStart)) {
			const end = indexOfOrThrow(">", tagStart + 2, "closing tag");
			const name = text.slice(tagStart + 2, end).trimEnd();
			const element = open.pop();
			if ((element === null || element === void 0 ? void 0 : element.name) !== name) {
				var _element$name;
				throw new Error(`Invalid XML: closing tag </${name}> doesn't match <${(_element$name = element === null || element === void 0 ? void 0 : element.name) !== null && _element$name !== void 0 ? _element$name : ""}>`);
			}
			position = end + 1;
		} else position = parseStartTag(text, tagStart + 1, (element, selfClosing) => {
			append(element);
			if (!selfClosing) open.push(element);
		});
	}
	if (open.length > 0) throw new Error(`Invalid XML: <${open[open.length - 1].name}> isn't closed`);
	const { elements } = document, rest = _objectWithoutProperties(document, _excluded$4);
	return elements === void 0 ? rest : _objectSpread2(_objectSpread2({}, rest), {}, { elements });
};
/**
* Reads a start tag from just after its "<", such as `w:p w14:paraId="1A2B3C4D">` or `w:br/>`.
*
* @returns The position just after the tag's ">"
*/
var parseStartTag = (text, from, onElement) => {
	let nameEnd = from;
	while (nameEnd < text.length && !isWhitespace(text[nameEnd]) && text[nameEnd] !== "/" && text[nameEnd] !== ">") nameEnd++;
	const name = text.slice(from, nameEnd);
	if (name === "") throw new Error("Invalid XML: tag without a name");
	const attributes = [];
	let position = nameEnd;
	for (;;) {
		while (position < text.length && isWhitespace(text[position])) position++;
		if (position >= text.length) throw new Error(`Invalid XML: <${name}> that isn't closed`);
		if (text[position] === ">" || text.startsWith("/>", position)) {
			const selfClosing = text[position] === "/";
			onElement(_objectSpread2({
				type: "element",
				name
			}, attributes.length > 0 ? { attributes: Object.fromEntries(attributes) } : {}), selfClosing);
			return position + (selfClosing ? 2 : 1);
		}
		const equals = text.indexOf("=", position);
		const attributeName = text.slice(position, equals === -1 ? text.length : equals).trimEnd();
		if (equals === -1 || attributeName === "" || /[\s/>]/.test(attributeName)) throw new Error(`Invalid XML: attribute of <${name}> without a value`);
		let valueStart = equals + 1;
		while (valueStart < text.length && isWhitespace(text[valueStart])) valueStart++;
		const quote = text[valueStart];
		if (quote !== "\"" && quote !== "'") throw new Error(`Invalid XML: value of ${attributeName} on <${name}> isn't quoted`);
		const valueEnd = text.indexOf(quote, valueStart + 1);
		if (valueEnd === -1) throw new Error(`Invalid XML: value of ${attributeName} on <${name}> isn't closed`);
		if (!attributes.some(([existing]) => existing === attributeName)) attributes.push([attributeName, decodeEntities(text.slice(valueStart + 1, valueEnd))]);
		position = valueEnd + 1;
	}
};
var ESCAPES = /* @__PURE__ */ new Map([
	["&", "&amp;"],
	["\"", "&quot;"],
	["'", "&apos;"],
	["<", "&lt;"],
	[">", "&gt;"]
]);
var escapeAll = (value) => value.replace(/[&"'<>\x00-\x08\x0B\x0C\x0E-\x1F]/g, (char) => {
	var _ESCAPES$get;
	return (_ESCAPES$get = ESCAPES.get(char)) !== null && _ESCAPES$get !== void 0 ? _ESCAPES$get : "";
});
var escapeText = (value) => value.replace(/[&<>\x00-\x08\x0B\x0C\x0E-\x1F]/g, (char) => {
	var _ESCAPES$get2;
	return (_ESCAPES$get2 = ESCAPES.get(char)) !== null && _ESCAPES$get2 !== void 0 ? _ESCAPES$get2 : "";
});
/**
* Escapes a value the way the xml package did, leaving values that aren't strings, such as numbers, as they are.
*/
var escapeValue = (value) => typeof value === "string" ? escapeAll(value) : value;
/**
* Works out an element's tag, attributes and content, as the xml package did, quirks and all, so that docx writes the
* same XML byte for byte.
*/
var resolve = (data, indent, depth) => {
	const name = Object.keys(data)[0];
	const values = name === void 0 ? void 0 : data[name];
	const attributes = [];
	const content = [];
	const addAttributes = (attr) => {
		for (const [key, value] of Object.entries(attr)) attributes.push(`${key}="${String(escapeValue(value))}"`);
	};
	if (typeof values === "object") {
		if (values !== null) {
			const { _attr: attr, _cdata: cdata } = values;
			if (attr) addAttributes(attr);
			if (cdata) content.push(`<![CDATA[${cdata.replace(/\]\]>/g, "]]]]><![CDATA[>")}]]>`);
			if (Array.isArray(values)) {
				let isStringContent = false;
				content.push("");
				for (const value of values) if (typeof value === "object") {
					if (Object.keys(value)[0] === "_attr") addAttributes(value._attr);
					else content.push(resolve(value, indent, depth + 1));
				} else {
					content.pop();
					isStringContent = true;
					content.push(escapeValue(value));
				}
				if (!isStringContent) content.push("");
			}
		}
	} else content.push(escapeValue(values));
	return {
		name,
		attributes,
		content,
		indents: depth > 1 ? indent.repeat(depth - 1) : ""
	};
};
var format = (element, indent, isLast) => {
	if (typeof element !== "object") return String(element);
	const { name, attributes, content, indents } = element;
	const { length } = content;
	const open = indents + (name ? `<${name}` : "") + (attributes.length > 0 ? ` ${attributes.join(" ")}` : "") + (length > 0 ? name ? ">" : "" : "/>") + (indent && length > 1 ? "\n" : "");
	if (length === 0) return open + (indent ? "\n" : "");
	return open + content.map((child) => child === void 0 ? "" : format(child, indent, false)).join("") + (length > 1 ? indents : "") + (name ? `</${name}>` : "") + (indent && !isLast ? "\n" : "");
};
/**
* Writes the XML of an object from docx's `Formatter`, such as `{ "w:b": { _attr: { "w:val": false } } }`,
* as the xml package did.
*
* @param input - The object, or several to write one after another
* @param options - How to indent, and the XML declaration to write first
* @returns The XML
*/
var stringifyXmlable = (input, { indent = "", declaration } = {}) => {
	const items = Array.isArray(input) ? input : [input];
	const startDepth = indent ? 1 : 0;
	const standalone = (declaration === null || declaration === void 0 ? void 0 : declaration.standalone) ? ` standalone="${escapeAll(declaration.standalone)}"` : "";
	return (declaration === void 0 ? "" : `<?xml version="1.0" encoding="${escapeAll(declaration.encoding || "UTF-8")}"${standalone}?>${indent ? "\n" : ""}`) + items.map((item, i) => format(resolve(item, indent, startDepth), indent, i === items.length - 1)).join("");
};
var stringifyAttributes = (attributes) => Object.entries(attributes !== null && attributes !== void 0 ? attributes : {}).flatMap(([key, value]) => value === void 0 || value === null ? [] : [` ${key}="${escapeAll(String(value))}"`]).join("");
var stringifyNode = (node) => {
	switch (node.type) {
		case "element": {
			var _node$elements, _node$attributes;
			const elements = (_node$elements = node.elements) !== null && _node$elements !== void 0 ? _node$elements : [];
			const open = `<${node.name}${stringifyAttributes(node.attributes)}`;
			return elements.length > 0 || ((_node$attributes = node.attributes) === null || _node$attributes === void 0 ? void 0 : _node$attributes["xml:space"]) === "preserve" ? `${open}>${elements.map(stringifyNode).join("")}</${node.name}>` : `${open}/>`;
		}
		case "text": return escapeText(String(node.text));
		case "cdata": return `<![CDATA[${String(node.cdata).replace(/\]\]>/g, "]]]]><![CDATA[>")}]]>`;
		case "comment": return `<!--${node.comment}-->`;
		case "doctype": return `<!DOCTYPE ${node.doctype}>`;
		case "instruction": return `<?${node.name}${node.instruction ? ` ${node.instruction}` : ""}?>`;
		default: return "";
	}
};
/**
* Writes the XML of an {@link XmlElement} tree, such as one from {@link parseXml}.
*
* @param document - The document, with its declaration and the nodes at its top level
* @returns The XML
*/
var stringifyElement = (document) => {
	var _document$elements;
	return (document.declaration ? `<?xml${stringifyAttributes(document.declaration.attributes)}?>` : "") + ((_document$elements = document.elements) !== null && _document$elements !== void 0 ? _document$elements : []).map(stringifyNode).join("");
};
/**
* Imported XML Component module for handling external XML content.
*
* This module provides functionality to import existing XML content and convert it
* into XmlComponent trees. This is useful for incorporating XML from external sources
* or templates into generated documents.
*
* @module
*/
/**
* Converts an XML element, in the shape of xml-js's non-compact `Element`, into an XmlComponent tree.
*
* This function recursively processes the element and creates a tree of
* ImportedXmlComponent objects that match the structure of the original XML.
*
* @param element - The XML element as an {@link XmlElement}
* @returns An ImportedXmlComponent tree, text string, or undefined
*
* @example
* ```typescript
* const component = convertToXmlComponent({
*   type: "element",
*   name: "w:p",
*   elements: [{ type: "element", name: "w:r", elements: [{ type: "element", name: "w:t", elements: [{ type: "text", text: "Hello" }] }] }],
* });
* ```
*/
var convertToXmlComponent = (element) => {
	switch (element.type) {
		case void 0:
		case "element":
			const xmlComponent = new ImportedXmlComponent(element.name, element.attributes);
			const childElements = element.elements || [];
			for (const childElm of childElements) {
				const child = convertToXmlComponent(childElm);
				if (child !== void 0) xmlComponent.push(child);
			}
			return xmlComponent;
		case "text": return element.text;
		default: return;
	}
};
/**
* Internal attribute component for imported XML elements.
* @internal
*/
var ImportedXmlComponentAttributes = class extends XmlAttributeComponent {};
/**
* XML component representing imported XML content.
*
* ImportedXmlComponent allows you to parse XML strings and incorporate them
* into the document structure. This is particularly useful when working with
* templates or when you need to include pre-existing XML fragments.
*
* @example
* ```typescript
* // Parse XML string into component tree
* const component = ImportedXmlComponent.fromXmlString(
*   '<w:p><w:r><w:t>Hello World</w:t></w:r></w:p>'
* );
*
* // Manually create an imported component
* const element = new ImportedXmlComponent("w:customElement", { "w:val": "value" });
* element.push(new ImportedXmlComponent("w:child"));
* ```
*/
var ImportedXmlComponent = class extends XmlComponent {
	/**
	* Parses an XML string and converts it to an ImportedXmlComponent tree.
	*
	* This static method is the primary way to import external XML content.
	* It parses the XML string into an {@link XmlElement} tree,
	* then converts that into a tree of XmlComponent objects.
	*
	* The component is for the parsed document, with the XML's element in it, and is written as that element, with no
	* element of its own around it.
	*
	* @param importedContent - The XML content as a string
	* @returns An ImportedXmlComponent representing the parsed XML
	*
	* @example
	* ```typescript
	* const xml = '<w:p><w:r><w:t>Hello</w:t></w:r></w:p>';
	* const component = ImportedXmlComponent.fromXmlString(xml);
	* ```
	*/
	static fromXmlString(importedContent) {
		return convertToXmlComponent(parseXml(importedContent));
	}
	/**
	* Creates an ImportedXmlComponent.
	*
	* @param rootKey - The XML element name
	* @param _attr - Optional attributes for the root element
	*/
	constructor(rootKey, _attr) {
		super(rootKey);
		if (_attr) this.root.push(new ImportedXmlComponentAttributes(_attr));
	}
	/**
	* Adds a child component or text to this element.
	*
	* @param xmlComponent - The child component or text string to add
	*/
	push(xmlComponent) {
		this.root.push(xmlComponent);
	}
	/**
	* A component of no element, such as the one {@link fromXmlString} gives for the parsed document, is written as the
	* elements in it. Written as itself, it would be an `<undefined>` element, which Word can't open.
	*
	* The component itself is still returned, rather than its element, because code written for earlier versions takes
	* the element from its children.
	*
	* @internal
	*/
	get writtenAs() {
		return this.rootKey === void 0 ? this.root.filter((child) => typeof child !== "string") : void 0;
	}
	/**
	* Prepares this element for XML serialization. A component of no element written by itself, rather than among a
	* parent's children, such as by the formatter or by an earlier copy of docx, is written as the one element in it.
	*
	* @param context - The serialization context
	* @returns The XML-serializable object
	*/
	prepForXml(context) {
		const parts = this.writtenAs;
		return (parts === null || parts === void 0 ? void 0 : parts.length) === 1 ? parts[0].prepForXml(context) : super.prepForXml(context);
	}
};
/**
* Represents attributes for imported root elements.
*
* This class is used internally to handle attributes on root elements
* that are being imported from external XML. It passes through the
* attributes without transformation.
*
* @example
* ```typescript
* const attrs = new ImportedRootElementAttributes({
*   "xmlns:w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
* });
* ```
*/
var ImportedRootElementAttributes = class extends XmlComponent {
	/**
	* Creates an ImportedRootElementAttributes component.
	*
	* @param _attr - The attributes object to pass through
	*/
	constructor(_attr) {
		super("");
		_defineProperty(this, "_attr", void 0);
		this._attr = _attr;
	}
	/**
	* Prepares the attributes for XML serialization.
	*
	* @param _ - Context (unused)
	* @returns Object with _attr key containing the raw attributes
	*/
	prepForXml(_) {
		return { _attr: this._attr };
	}
};
/**
* Initializable XML Component module.
*
* This module provides a base class for XML components that can be initialized
* from another component's state, useful for component reuse and composition.
*
* @module
*/
/**
* XML component that can be initialized from another component.
*
* InitializableXmlComponent extends XmlComponent to support copying the internal
* state (root array) from another component. This is useful when you need to
* create a new component that shares or extends the children of an existing component.
*
* @example
* ```typescript
* class MyElement extends InitializableXmlComponent {
*   constructor(init?: MyElement) {
*     super("w:myElement", init);
*     // If init is provided, this.root is copied from init
*     // Otherwise, this.root is an empty array
*   }
* }
*
* const element1 = new MyElement();
* element1.addChildElement(new TextRun("Hello"));
*
* const element2 = new MyElement(element1);
* // element2 now has the same children as element1
* ```
*/
var InitializableXmlComponent = class extends XmlComponent {
	/**
	* Creates a new InitializableXmlComponent.
	*
	* @param rootKey - The XML element name
	* @param initComponent - Optional component to copy children from
	*/
	constructor(rootKey, initComponent) {
		super(rootKey);
		if (initComponent) this.root = initComponent.root;
	}
};
/**
* Validates and converts a number to an integer (decimal number).
*
* Reference: ST_DecimalNumber in OOXML specification
*
* @param val - The number to validate and convert
* @returns The floored integer value
* @throws Error if the value is NaN or infinite, which no integer can be written as
*
* @example
* ```typescript
* const num = decimalNumber(10.7); // Returns 10
* const negative = decimalNumber(-5.3); // Returns -6
* ```
*/
var decimalNumber = (val) => {
	if (!Number.isFinite(val)) throw new Error(`Invalid value '${val}' specified. Must be an integer.`);
	return Math.floor(val);
};
/**
* Validates and converts a number to a positive integer (unsigned decimal number).
*
* Reference: ST_UnsignedDecimalNumber in OOXML specification
*
* @param val - The number to validate and convert
* @returns The floored positive integer value
* @throws Error if the value is NaN, infinite or negative
*
* @example
* ```typescript
* const num = unsignedDecimalNumber(10.7); // Returns 10
* const invalid = unsignedDecimalNumber(-5); // Throws Error
* ```
*/
var unsignedDecimalNumber = (val) => {
	const value = decimalNumber(val);
	if (value < 0) throw new Error(`Invalid value '${val}' specified. Must be a positive integer.`);
	return value;
};
/**
* Validates and normalizes a hexadecimal binary value.
*
* The xsd:hexBinary type represents binary data as a sequence of binary octets
* using hexadecimal encoding, where each binary octet is a two-character
* hexadecimal number. Both lowercase and uppercase letters A-F are permitted.
*
* @param val - The hexadecimal string to validate
* @param length - The expected length in bytes (not characters)
* @returns The validated hexadecimal string
* @throws Error if the value is not a valid hex string of the expected length
*
* @example
* ```typescript
* hexBinary("0FB8", 2); // Valid: 2 bytes = 4 characters
* hexBinary("ABC", 2); // Invalid: wrong length
* ```
*/
var hexBinary = (val, length) => {
	const expectedLength = length * 2;
	if (val.length !== expectedLength || isNaN(Number(`0x${val}`))) throw new Error(`Invalid hex value '${val}'. Expected ${expectedLength} digit hex value`);
	return val;
};
/**
* Validates a single-byte hexadecimal number (1 byte / 2 characters).
*
* Reference: ST_UcharHexNumber in OOXML specification
*
* @param val - The hexadecimal string to validate
* @returns The validated hexadecimal string
* @throws Error if the value is not a valid 2-character hex string
*
* @example
* ```typescript
* const hex = uCharHexNumber("FF"); // Valid
* ```
*/
var uCharHexNumber = (val) => hexBinary(val, 1);
/**
* Normalizes a universal measure value by parsing and reformatting.
*
* Ensures the numeric portion is properly formatted while preserving the unit.
*
* Reference: ST_UniversalMeasure in OOXML specification
*
* @param val - The universal measure string to normalize
* @returns The normalized universal measure
*
* @example
* ```typescript
* const measure = universalMeasureValue("10.500mm"); // Returns "10.5mm"
* ```
*/
var universalMeasureValue = (val) => {
	const unit = val.slice(-2);
	const amount = val.substring(0, val.length - 2);
	return `${Number(amount)}${unit}`;
};
/**
* Twips per unit for each universal measure suffix.
*
* 1 inch = 72 points = 1440 twips; 1 pica = 12 points.
*/
var TWIPS_PER_UNIT = {
	in: 1440,
	cm: 1440 / 2.54,
	mm: 1440 / 25.4,
	pt: 20,
	pc: 240,
	pi: 240
};
/**
* Converts a universal measure (or a value already in twips) into twips.
*
* Numbers are assumed to already be in twips and are returned unchanged.
* Strings are converted according to their unit suffix.
*
* @param val - A number of twips or a universal measure such as "10mm" or "1.5in"
* @returns The equivalent number of twips (not rounded)
*
* @example
* ```typescript
* universalMeasureToTwips(720); // Returns 720
* universalMeasureToTwips("1in"); // Returns 1440
* universalMeasureToTwips("2.54cm"); // Returns 1440
* ```
*/
var universalMeasureToTwips = (val) => {
	if (typeof val === "number") return val;
	const unit = val.slice(-2);
	const amount = Number(val.substring(0, val.length - 2));
	const twipsPerUnit = TWIPS_PER_UNIT[unit];
	if (twipsPerUnit === void 0 || Number.isNaN(amount)) throw new Error(`Invalid universal measure '${val}'. Expected a number followed by mm, cm, in, pt, pc or pi.`);
	return amount * twipsPerUnit;
};
/**
* Validates and normalizes a positive universal measure value.
*
* Reference: ST_PositiveUniversalMeasure in OOXML specification
*
* @param val - The positive universal measure string to validate
* @returns The normalized positive universal measure
* @throws Error if the value is negative
*
* @example
* ```typescript
* const measure = positiveUniversalMeasureValue("10.5mm"); // Valid
* const invalid = positiveUniversalMeasureValue("-5mm"); // Throws Error
* ```
*/
var positiveUniversalMeasureValue = (val) => {
	const value = universalMeasureValue(val);
	if (parseFloat(value) < 0) throw new Error(`Invalid value '${value}' specified. Expected a positive number.`);
	return value;
};
/**
* Validates and normalizes a hexadecimal color value.
*
* Accepts either "auto" or a 6-character RGB hex value (with or without # prefix).
* The # prefix is commonly used but technically invalid in OOXML, so it is stripped
* for strict compliance.
*
* Reference: ST_HexColor in OOXML specification
*
* @param val - The color value to validate ("auto" or hex color)
* @returns The normalized color value
* @throws Error if the hex color is invalid
*
* @example
* ```typescript
* const color1 = hexColorValue("auto"); // Returns "auto"
* const color2 = hexColorValue("FF0000"); // Returns "FF0000"
* const color3 = hexColorValue("#00FF00"); // Returns "00FF00" (# stripped)
* ```
*/
var hexColorValue = (val) => {
	if (val === "auto") return val;
	return hexBinary(val.charAt(0) === "#" ? val.substring(1) : val, 3);
};
/**
* Validates a signed TWIP measurement value.
*
* Accepts either a universal measure string or a numeric TWIP value.
*
* Reference: ST_SignedTwipsMeasure in OOXML specification
*
* @param val - The measurement value (universal measure or number)
* @returns The normalized measurement value
*
* @example
* ```typescript
* const measure1 = signedTwipsMeasureValue("10mm");
* const measure2 = signedTwipsMeasureValue(1440); // 1 inch in TWIP
* ```
*/
var signedTwipsMeasureValue = (val) => typeof val === "string" ? universalMeasureValue(val) : decimalNumber(val);
/**
* Validates a half-point (HPS) measurement value.
*
* Accepts either a positive universal measure string or a positive number.
* HPS (half-points) are commonly used for font sizes.
*
* Reference: ST_HpsMeasure in OOXML specification
*
* @param val - The measurement value (positive universal measure or number)
* @returns The normalized measurement value
*
* @example
* ```typescript
* const fontSize1 = hpsMeasureValue("12pt");
* const fontSize2 = hpsMeasureValue(24); // 12pt in half-points
* ```
*/
var hpsMeasureValue = (val) => typeof val === "string" ? positiveUniversalMeasureValue(val) : unsignedDecimalNumber(val);
/**
* Validates a positive TWIP measurement value.
*
* Accepts either a positive universal measure string or a positive number.
*
* Reference: ST_TwipsMeasure in OOXML specification
*
* @param val - The measurement value (positive universal measure or number)
* @returns The normalized measurement value
*
* @example
* ```typescript
* const width1 = twipsMeasureValue("25.4mm");
* const width2 = twipsMeasureValue(1440); // 1 inch in TWIP
* ```
*/
var twipsMeasureValue = (val) => typeof val === "string" ? positiveUniversalMeasureValue(val) : unsignedDecimalNumber(val);
/**
* Normalizes a percentage value by parsing and reformatting.
*
* Reference: ST_Percentage in OOXML specification
*
* @param val - The percentage string to normalize
* @returns The normalized percentage
*
* @example
* ```typescript
* const percent = percentageValue("50.000%"); // Returns "50%"
* ```
*/
var percentageValue = (val) => {
	const percent = val.substring(0, val.length - 1);
	return `${Number(percent)}%`;
};
/**
* Validates a measurement value that can be expressed as a number, percentage, or universal measure.
*
* Reference: ST_MeasurementOrPercent in OOXML specification
*
* @param val - The measurement value (number, percentage, or universal measure)
* @returns The normalized measurement value
*
* @example
* ```typescript
* const measure1 = measurementOrPercentValue(100); // Unqualified number
* const measure2 = measurementOrPercentValue("50%"); // Percentage
* const measure3 = measurementOrPercentValue("10mm"); // Universal measure
* ```
*/
var measurementOrPercentValue = (val) => {
	if (typeof val === "number") return decimalNumber(val);
	return val.slice(-1) === "%" ? percentageValue(val) : universalMeasureValue(val);
};
/**
* Validates an eighth-point measurement value.
*
* Eighth-points are used for fine-grained measurements in text formatting.
*
* Reference: ST_EighthPointMeasure in OOXML specification
*
* @param val - The measurement value in eighth-points
* @returns The validated positive integer value
*
* @example
* ```typescript
* const measure = eighthPointMeasureValue(16); // 2 points
* ```
*/
var eighthPointMeasureValue = unsignedDecimalNumber;
/**
* Validates a point measurement value.
*
* Reference: ST_PointMeasure in OOXML specification
*
* @param val - The measurement value in points
* @returns The validated positive integer value
*
* @example
* ```typescript
* const fontSize = pointMeasureValue(12); // 12pt
* ```
*/
var pointMeasureValue = unsignedDecimalNumber;
/**
* Converts a JavaScript Date object to an ISO 8601 date-time string.
*
* The format is CCYY-MM-DDThh:mm:ss.sssZ where T is a literal and Z indicates UTC.
* This matches the xsd:dateTime format required by OOXML.
*
* Reference: ST_DateTime in OOXML specification
*
* @param val - The Date object to convert
* @returns An ISO 8601 formatted date-time string
*
* @example
* ```typescript
* const now = new Date();
* const timestamp = dateTimeValue(now); // Returns "2024-01-15T10:30:00.000Z"
* ```
*/
var dateTimeValue = (val) => val.toISOString();
/**
* Simple XML element types for common WordprocessingML patterns.
*
* This module provides reusable element classes for common XML patterns in OOXML,
* such as boolean elements, string values, number values, and empty elements.
* These are building blocks used throughout the library.
*
* @module
*/
/**
* XML element representing a boolean on/off value (CT_OnOff).
*
* This element type is used throughout WordprocessingML to represent boolean properties.
* A value of true (or 1) means the property is enabled. A value of false (or 0) means
* it is explicitly disabled. When the value is true, the attribute is often omitted.
*
* OOXML Reference:
* ```xml
* <xsd:complexType name="CT_OnOff">
*   <xsd:attribute name="val" type="s:ST_OnOff"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Bold enabled (w:val omitted when true)
* new OnOffElement("w:b", true);
* // Generates: <w:b/>
*
* // Bold explicitly disabled
* new OnOffElement("w:b", false);
* // Generates: <w:b w:val="false"/>
* ```
*/
var OnOffElement = class extends XmlComponent {
	/**
	* Creates an OnOffElement.
	*
	* @param name - The XML element name (e.g., "w:b", "w:i")
	* @param val - The boolean value (defaults to true)
	*/
	constructor(name, val = true) {
		super(name);
		if (val !== true) this.root.push(new Attributes({ val }));
	}
};
/**
* XML element representing a half-point size measurement (CT_HpsMeasure).
*
* HpsMeasure elements are used for font sizes and other measurements in WordprocessingML.
* Values can be specified as numbers (interpreted as half-points) or with explicit units.
*
* OOXML Reference:
* ```xml
* <xsd:complexType name="CT_HpsMeasure">
*   <xsd:attribute name="val" type="ST_HpsMeasure" use="required"/>
* </xsd:complexType>
*
* <xsd:simpleType name="ST_HpsMeasure">
*   <xsd:union memberTypes="s:ST_UnsignedDecimalNumber s:ST_PositiveUniversalMeasure" />
* </xsd:simpleType>
* ```
*
* @example
* ```typescript
* // Font size of 24 half-points (12pt)
* new HpsMeasureElement("w:sz", 24);
* // Generates: <w:sz w:val="24"/>
*
* // Using explicit units
* new HpsMeasureElement("w:sz", "12pt");
* ```
*/
var HpsMeasureElement = class extends XmlComponent {
	/**
	* Creates an HpsMeasureElement.
	*
	* @param name - The XML element name
	* @param val - The measurement value (number in half-points or string with units)
	*/
	constructor(name, val) {
		super(name);
		this.root.push(new Attributes({ val: hpsMeasureValue(val) }));
	}
};
/**
* XML element representing an empty element (CT_Empty).
*
* EmptyElement creates self-closing XML tags with no attributes or content.
*
* OOXML Reference:
* ```xml
* <xsd:complexType name="CT_Empty"/>
* ```
*
* @example
* ```typescript
* new EmptyElement("w:noProof");
* // Generates: <w:noProof/>
* ```
*/
var EmptyElement = class extends XmlComponent {};
/**
* XML element with a string value attribute (CT_String).
*
* StringValueElement creates elements with a single "w:val" attribute
* containing a string value.
*
* OOXML Reference:
* ```xml
* <xsd:complexType name="CT_String">
*   <xsd:attribute name="val" type="s:ST_String" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new StringValueElement("w:style", "Heading1");
* // Generates: <w:style w:val="Heading1"/>
* ```
*/
var StringValueElement = class extends XmlComponent {
	/**
	* Creates a StringValueElement.
	*
	* @param name - The XML element name
	* @param val - The string value
	*/
	constructor(name, val) {
		super(name);
		this.root.push(new Attributes({ val }));
	}
};
/**
* Creates a string element using the builder pattern.
*
* This is an alternative to StringValueElement that uses BuilderElement
* for more explicit attribute naming.
*
* @param name - The XML element name
* @param value - The string value
* @returns An XmlComponent with the string value
*
* @example
* ```typescript
* createStringElement("w:pStyle", "Heading1");
* // Generates: <w:pStyle w:val="Heading1"/>
* ```
*/
var createStringElement = (name, value) => new BuilderElement({
	name,
	attributes: { value: {
		key: "w:val",
		value
	} }
});
/**
* XML element with a numeric value attribute.
*
* NumberValueElement creates elements with a single "w:val" attribute
* containing a numeric value.
*
* @example
* ```typescript
* new NumberValueElement("w:ilvl", 2);
* // Generates: <w:ilvl w:val="2"/>
* ```
*/
var NumberValueElement = class extends XmlComponent {
	/**
	* Creates a NumberValueElement.
	*
	* @param name - The XML element name
	* @param val - The numeric value
	*/
	constructor(name, val) {
		super(name);
		this.root.push(new Attributes({ val }));
	}
};
/**
* XML element containing text content.
*
* StringContainer creates elements with text content (not attributes).
* This is used for elements where the value is the text node content
* rather than an attribute.
*
* @example
* ```typescript
* new StringContainer("w:author", "John Doe");
* // Generates: <w:author>John Doe</w:author>
* ```
*/
var StringContainer = class extends XmlComponent {
	/**
	* Creates a StringContainer.
	*
	* @param name - The XML element name
	* @param val - The text content
	*/
	constructor(name, val) {
		super(name);
		this.root.push(val);
	}
};
/**
* Flexible XML element builder with explicit attribute and child configuration.
*
* BuilderElement provides a structured way to create XML elements with typed
* attributes and children. It uses the NextAttributeComponent pattern for
* explicit attribute key-value mapping.
*
* @example
* ```typescript
* // Element with attributes
* new BuilderElement({
*   name: "w:spacing",
*   attributes: {
*     before: { key: "w:before", value: 240 },
*     after: { key: "w:after", value: 120 }
*   }
* });
* // Generates: <w:spacing w:before="240" w:after="120"/>
*
* // Element with children
* new BuilderElement({
*   name: "w:pPr",
*   children: [
*     new StringValueElement("w:pStyle", "Heading1")
*   ]
* });
* ```
*/
var BuilderElement = class extends XmlComponent {
	/**
	* Creates a BuilderElement with the specified configuration.
	*
	* @param config - Element configuration
	* @param config.name - The XML element name
	* @param config.attributes - Optional attributes with explicit key-value pairs
	* @param config.children - Optional child elements
	*/
	constructor({ name, attributes, children }) {
		super(name);
		if (attributes) this.root.push(new NextAttributeComponent(attributes));
		if (children) this.root.push(...children);
	}
};
/**
* Paragraph and table alignment module for WordprocessingML documents.
*
* This module provides justification (alignment) options for paragraphs and tables.
*
* Reference: http://officeopenxml.com/WPalignment.php
*
* @see http://officeopenxml.com/WPtableAlignment.php
* @see http://www.datypic.com/sc/ooxml/t-w_ST_Jc.html
*
* @module
*/
/**
* Paragraph justification (alignment) types.
*
* Specifies the horizontal alignment of text within a paragraph.
*
* Reference: http://officeopenxml.com/WPalignment.php
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_Jc">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="start"/>
*     <xsd:enumeration value="center"/>
*     <xsd:enumeration value="end"/>
*     <xsd:enumeration value="both"/>
*     <xsd:enumeration value="mediumKashida"/>
*     <xsd:enumeration value="distribute"/>
*     <xsd:enumeration value="numTab"/>
*     <xsd:enumeration value="highKashida"/>
*     <xsd:enumeration value="lowKashida"/>
*     <xsd:enumeration value="thaiDistribute"/>
*     <xsd:enumeration value="left"/>
*     <xsd:enumeration value="right"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var AlignmentType = {
	/** Align Start: the left in a left-to-right paragraph, and the right in a `bidirectional` (right-to-left) paragraph */
	START: "start",
	/** Align Center */
	CENTER: "center",
	/** Align End: the right in a left-to-right paragraph, and the left in a `bidirectional` (right-to-left) paragraph */
	END: "end",
	/** Justified */
	BOTH: "both",
	/** Medium Kashida Length */
	MEDIUM_KASHIDA: "mediumKashida",
	/** Distribute All Characters Equally */
	DISTRIBUTE: "distribute",
	/** Align to List Tab */
	NUM_TAB: "numTab",
	/** Widest Kashida Length */
	HIGH_KASHIDA: "highKashida",
	/** Low Kashida Length */
	LOW_KASHIDA: "lowKashida",
	/** Thai Language Justification */
	THAI_DISTRIBUTE: "thaiDistribute",
	/** Align Left: a paragraph stays on the left of the page even when it is `bidirectional` (right-to-left) */
	LEFT: "left",
	/** Align Right: a paragraph stays on the right of the page even when it is `bidirectional` (right-to-left) */
	RIGHT: "right",
	/** Justified */
	JUSTIFIED: "both"
};
/**
* Creates paragraph alignment (justification) element for a WordprocessingML document.
*
* The jc element specifies the horizontal alignment of all text in the paragraph.
*
* Reference: http://officeopenxml.com/WPalignment.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Jc">
*   <xsd:attribute name="val" type="ST_Jc" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Paragraph({
*   alignment: AlignmentType.CENTER,
*   children: [new TextRun("Centered text")],
* });
* ```
*/
var createAlignment = (type) => new BuilderElement({
	name: "w:jc",
	attributes: { val: {
		key: "w:val",
		value: type
	} }
});
/**
* Color scheme module for DrawingML themes.
*
* The twelve colors of a document's theme: the dark and light colors text and backgrounds use, six accent colors,
* and the colors of hyperlinks.
*
* Reference: http://officeopenxml.com/drwTheme.php
*
* @module
*/
var COLOR_OOXML_NAMES = {
	dark1: "dk1",
	light1: "lt1",
	dark2: "dk2",
	light2: "lt2",
	accent1: "accent1",
	accent2: "accent2",
	accent3: "accent3",
	accent4: "accent4",
	accent5: "accent5",
	accent6: "accent6",
	hyperlink: "hlink",
	followedHyperlink: "folHlink"
};
var OFFICE_COLORS = {
	dark2: "44546A",
	light2: "E7E6E6",
	accent1: "4472C4",
	accent2: "ED7D31",
	accent3: "A5A5A5",
	accent4: "FFC000",
	accent5: "5B9BD5",
	accent6: "70AD47",
	hyperlink: "0563C1",
	followedHyperlink: "954F72"
};
var OFFICE_SYSTEM_COLORS = {
	dark1: {
		value: "windowText",
		lastColor: "000000"
	},
	light1: {
		value: "window",
		lastColor: "FFFFFF"
	}
};
var rgbColorValue = (name, color) => {
	if (color === "auto") throw new Error(`Invalid theme color ${name} 'auto'. Expected 6 digit hex value`);
	return hexColorValue(color);
};
/**
* The hex color of each of a theme's colors, with Office's in place of those not given. The system's window text and
* window colors are black and white.
*
* @throws If a color isn't a 6-digit hex value
*/
var themeColorValues = (colors = {}) => Object.fromEntries(Object.keys(COLOR_OOXML_NAMES).map((name) => {
	const color = colors[name];
	const office = name === "dark1" || name === "light1" ? OFFICE_SYSTEM_COLORS[name].lastColor : OFFICE_COLORS[name];
	return [name, color === void 0 ? office : rgbColorValue(name, color)];
}));
var createRgbColor = (name, color) => new BuilderElement({
	name: "a:srgbClr",
	attributes: { value: {
		key: "val",
		value: rgbColorValue(name, color)
	} }
});
var createColor = (name, colors) => {
	const color = colors[name];
	const system = name === "dark1" || name === "light1" ? OFFICE_SYSTEM_COLORS[name] : void 0;
	return new BuilderElement({
		name: `a:${COLOR_OOXML_NAMES[name]}`,
		children: [color === void 0 && system ? new BuilderElement({
			name: "a:sysClr",
			attributes: {
				value: {
					key: "val",
					value: system.value
				},
				lastColor: {
					key: "lastClr",
					value: system.lastColor
				}
			}
		}) : createRgbColor(name, color !== null && color !== void 0 ? color : OFFICE_COLORS[name])]
	});
};
/**
* Creates a theme's color scheme, with Office's colors in place of those not given.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_ColorScheme">
*   <xsd:sequence>
*     <xsd:element name="dk1" type="CT_Color" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="lt1" type="CT_Color" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="dk2" type="CT_Color" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="lt2" type="CT_Color" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="accent1" type="CT_Color" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="accent2" type="CT_Color" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="accent3" type="CT_Color" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="accent4" type="CT_Color" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="accent5" type="CT_Color" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="accent6" type="CT_Color" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="hlink" type="CT_Color" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="folHlink" type="CT_Color" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="extLst" type="CT_OfficeArtExtensionList" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="name" type="xsd:string" use="required"/>
* </xsd:complexType>
* ```
*
* @throws If a color isn't a 6-digit hex value
*/
var createColorScheme = (name, colors = {}) => new BuilderElement({
	name: "a:clrScheme",
	attributes: { name: {
		key: "name",
		value: name
	} },
	children: Object.keys(COLOR_OOXML_NAMES).map((color) => createColor(color, colors))
});
/**
* Theme color module for WordprocessingML documents.
*
* Text, underlines, borders and shading can be in a color of the document's theme, lighter or darker as Word's color
* menus offer them. Word writes the theme color's name, how much lighter (`themeTint`) or darker (`themeShade`) it
* is, and the color it comes to in hex, for applications that don't read the theme. The hex color is worked out in
* HSL as the standard describes, and is close to Word's but not always the same.
*
* Reference: http://officeopenxml.com/WPtextFormatting.php
*
* @module
*/
var THEME_COLOR_NAMES = /* @__PURE__ */ new Set([
	"dark1",
	"light1",
	"dark2",
	"light2",
	"accent1",
	"accent2",
	"accent3",
	"accent4",
	"accent5",
	"accent6",
	"hyperlink",
	"followedHyperlink"
]);
var THEME_COLOR_SUGGESTIONS = /* @__PURE__ */ new Map([
	["dk1", "dark1"],
	["lt1", "light1"],
	["dk2", "dark2"],
	["lt2", "light2"],
	["hlink", "hyperlink"],
	["folHlink", "followedHyperlink"],
	["text1", "dark1"],
	["background1", "light1"],
	["text2", "dark2"],
	["background2", "light2"]
]);
var changeValue = (value, option) => {
	if (!(value >= 0 && value <= 100)) throw new Error(`Invalid ${option} ${value}. Expected a number from 0 to 100`);
	return Math.round(255 * (1 - value / 100));
};
/**
* Checks a theme color, and works out its tint or shade.
*
* @throws If the color isn't one of the theme's, is both lighter and darker, or a change is outside 0 to 100
*/
var themeColorChange = ({ theme, lighter, darker }) => {
	if (!THEME_COLOR_NAMES.has(theme)) {
		const suggestion = THEME_COLOR_SUGGESTIONS.get(theme);
		throw new Error(`Invalid theme color "${theme}". ${suggestion ? `Did you mean "${suggestion}"?` : `Expected one of ${[...THEME_COLOR_NAMES].join(", ")}`}`);
	}
	if (lighter !== void 0 && darker !== void 0) throw new Error("Invalid theme color. Expected lighter or darker, not both");
	const tint = lighter === void 0 ? void 0 : changeValue(lighter, "lighter");
	const shade = darker === void 0 ? void 0 : changeValue(darker, "darker");
	return {
		tint: tint === 255 ? void 0 : tint,
		shade: shade === 255 ? void 0 : shade
	};
};
var toHsl = (hex) => {
	const [red, green, blue] = [
		0,
		2,
		4
	].map((index) => parseInt(hex.slice(index, index + 2), 16) / 255);
	const max = Math.max(red, green, blue);
	const min = Math.min(red, green, blue);
	const lightness = (max + min) / 2;
	const range = max - min;
	if (range === 0) return {
		hue: 0,
		saturation: 0,
		lightness
	};
	return {
		hue: (max === red ? ((green - blue) / range + 6) % 6 : max === green ? (blue - red) / range + 2 : (red - green) / range + 4) * 60,
		saturation: range / (1 - Math.abs(2 * lightness - 1)),
		lightness
	};
};
var toHex = ({ hue, saturation, lightness }) => {
	const chroma = (1 - Math.abs(2 * lightness - 1)) * saturation;
	const second = chroma * (1 - Math.abs(hue / 60 % 2 - 1));
	const [red, green, blue] = hue < 60 ? [
		chroma,
		second,
		0
	] : hue < 120 ? [
		second,
		chroma,
		0
	] : hue < 180 ? [
		0,
		chroma,
		second
	] : hue < 240 ? [
		0,
		second,
		chroma
	] : hue < 300 ? [
		second,
		0,
		chroma
	] : [
		chroma,
		0,
		second
	];
	const lowest = lightness - chroma / 2;
	return [
		red,
		green,
		blue
	].map((value) => Math.floor((value + lowest) * 255 + 1e-9).toString(16).padStart(2, "0")).join("").toUpperCase();
};
/**
* The color a theme color comes to: its lightness moved towards white by its tint, or towards black by its shade.
*/
var applyChange = (hex, { tint, shade }) => {
	if (tint === void 0 && shade === void 0) return hex;
	const hsl = toHsl(hex);
	const lightness = tint === void 0 ? hsl.lightness * shade / 255 : hsl.lightness * tint / 255 + (1 - tint / 255);
	return toHex(_objectSpread2(_objectSpread2({}, hsl), {}, { lightness }));
};
var hexByte = (value) => value === void 0 ? void 0 : value.toString(16).padStart(2, "0").toUpperCase();
/**
* Checks a color option, so that mistakes throw when an element is created rather than when it is written.
*
* @throws If a hex color isn't 6 hex digits, or a theme color isn't valid
*/
var checkColor = (color) => typeof color === "string" ? {
	type: "hex",
	value: hexColorValue(color)
} : {
	type: "theme",
	color,
	change: themeColorChange(color)
};
var colorValues = (checked, colors) => checked.type === "hex" ? { color: checked.value } : {
	color: applyChange(colors[checked.color.theme], checked.change),
	theme: checked.color.theme,
	tint: hexByte(checked.change.tint),
	shade: hexByte(checked.change.shade)
};
var OFFICE_THEME_COLORS = themeColorValues();
/**
* The attributes of an element with colors, some of which may be the theme's. A theme color is written with the hex
* color it comes to in the document's theme, so that is worked out when the element is written. Attributes are written
* in the order given.
*
* @internal
*/
var ColorAttributeComponent = class extends BaseXmlComponent {
	/**
	* @throws If a color isn't valid
	*/
	constructor(attributes) {
		super("_attr");
		_defineProperty(this, "attributes", void 0);
		this.attributes = attributes.map((attribute) => "keys" in attribute ? {
			keys: attribute.keys,
			color: attribute.color === void 0 ? void 0 : checkColor(attribute.color)
		} : attribute);
	}
	prepForXml(context) {
		var _context$file$Theme$C, _context$file;
		const themeColors = (_context$file$Theme$C = (_context$file = context.file) === null || _context$file === void 0 || (_context$file = _context$file.Theme) === null || _context$file === void 0 ? void 0 : _context$file.Colors) !== null && _context$file$Theme$C !== void 0 ? _context$file$Theme$C : OFFICE_THEME_COLORS;
		const entries = this.attributes.flatMap((attribute) => {
			if (!("keys" in attribute)) return [[attribute.key, attribute.value]];
			if (attribute.color === void 0) return [];
			const { keys } = attribute;
			const values = colorValues(attribute.color, themeColors);
			return [
				[keys.color, values.color],
				[keys.theme, values.theme],
				[keys.tint, values.tint],
				[keys.shade, values.shade]
			];
		});
		return { _attr: Object.fromEntries(entries.filter(([, value]) => value !== void 0)) };
	}
};
var ColorElement = class extends XmlComponent {
	constructor(name, attributes) {
		super(name);
		this.root.push(new ColorAttributeComponent(attributes));
	}
};
/**
* Creates an element whose attributes include colors, some of which may be the theme's.
*
* @throws If a color isn't valid
*/
var createColorElement = (name, attributes) => new ColorElement(name, attributes);
/**
* The attributes most elements write a color with: `w:color`, `w:themeColor`, `w:themeTint` and `w:themeShade`.
*/
var COLOR_ATTRIBUTES = {
	color: "w:color",
	theme: "w:themeColor",
	tint: "w:themeTint",
	shade: "w:themeShade"
};
/**
* Border module for WordprocessingML documents.
*
* Borders are used in multiple contexts (paragraphs, tables, table cells, sections)
* and share the same CT_Border type definition. This module provides the createBorderElement
* factory function and BorderStyle constants used throughout the document structure.
*
* Reference: http://officeopenxml.com/WPborders.php
*
* @see http://officeopenxml.com/WPtableBorders.php
* @see http://officeopenxml.com/WPtableCellProperties-Borders.php
* @see http://officeopenxml.com/WPsectionBorders.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Border">
*   <xsd:attribute name="val" type="ST_Border" use="required"/>
*   <xsd:attribute name="color" type="ST_HexColor" use="optional" default="auto"/>
*   <xsd:attribute name="themeColor" type="ST_ThemeColor" use="optional"/>
*   <xsd:attribute name="themeTint" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="themeShade" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="sz" type="ST_EighthPointMeasure" use="optional"/>
*   <xsd:attribute name="space" type="ST_PointMeasure" use="optional" default="0"/>
*   <xsd:attribute name="shadow" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="frame" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*
* @module
*/
/**
* Creates a border element for a WordprocessingML document.
*
* Used to create border specifications for paragraphs, tables, table cells,
* and sections. The element name is specified to create different border
* types (top, bottom, left, right, etc.).
*
* @example
* ```typescript
* // Create a top border
* createBorderElement("w:top", {
*   style: BorderStyle.SINGLE,
*   color: "FF0000",
*   size: 24,
*   space: 1,
* });
* ```
*/
var createBorderElement = (elementName, { color, size, space, style }) => createColorElement(elementName, [
	{
		key: "w:val",
		value: style
	},
	{
		keys: COLOR_ATTRIBUTES,
		color
	},
	{
		key: "w:sz",
		value: size === void 0 ? void 0 : eighthPointMeasureValue(size)
	},
	{
		key: "w:space",
		value: space === void 0 ? void 0 : pointMeasureValue(space)
	}
]);
/**
* Table borders are defined with the <w:tblBorders> element. Child elements of this element specify the kinds of `border`:
*
* `bottom`, `end` (`right` in the previous version of the standard), `insideH`, `insideV`, `start` (`left` in the previous version of the standard), and `top`.
*
* Reference: http://officeopenxml.com/WPtableBorders.php
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_Border">
*     <xsd:restriction base="xsd:string">
*          <xsd:enumeration value="single"/>
*          <xsd:enumeration value="dashDotStroked"/>
*          <xsd:enumeration value="dashed"/>
*          <xsd:enumeration value="dashSmallGap"/>
*          <xsd:enumeration value="dotDash"/>
*          <xsd:enumeration value="dotDotDash"/>
*          <xsd:enumeration value="dotted"/>
*          <xsd:enumeration value="double"/>
*          <xsd:enumeration value="doubleWave"/>
*          <xsd:enumeration value="inset"/>
*          <xsd:enumeration value="nil"/>
*          <xsd:enumeration value="none"/>
*          <xsd:enumeration value="outset"/>
*          <xsd:enumeration value="thick"/>
*          <xsd:enumeration value="thickThinLargeGap"/>
*          <xsd:enumeration value="thickThinMediumGap"/>
*          <xsd:enumeration value="thickThinSmallGap"/>
*          <xsd:enumeration value="thinThickLargeGap"/>
*          <xsd:enumeration value="thinThickMediumGap"/>
*          <xsd:enumeration value="thinThickSmallGap"/>
*          <xsd:enumeration value="thinThickThinLargeGap"/>
*          <xsd:enumeration value="thinThickThinMediumGap"/>
*          <xsd:enumeration value="thinThickThinSmallGap"/>
*          <xsd:enumeration value="threeDEmboss"/>
*          <xsd:enumeration value="threeDEngrave"/>
*          <xsd:enumeration value="triple"/>
*          <xsd:enumeration value="wave"/>
*     </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var BorderStyle = {
	/** a single line */
	SINGLE: "single",
	/** a line with a series of alternating thin and thick strokes */
	DASH_DOT_STROKED: "dashDotStroked",
	/** a dashed line */
	DASHED: "dashed",
	/** a dashed line with small gaps */
	DASH_SMALL_GAP: "dashSmallGap",
	/** a line with alternating dots and dashes */
	DOT_DASH: "dotDash",
	/** a line with a repeating dot - dot - dash sequence */
	DOT_DOT_DASH: "dotDotDash",
	/** a dotted line */
	DOTTED: "dotted",
	/** a double line */
	DOUBLE: "double",
	/** a double wavy line */
	DOUBLE_WAVE: "doubleWave",
	/** an inset set of lines */
	INSET: "inset",
	/** no border */
	NIL: "nil",
	/** no border */
	NONE: "none",
	/** an outset set of lines */
	OUTSET: "outset",
	/** a single line */
	THICK: "thick",
	/** a thick line contained within a thin line with a large-sized intermediate gap */
	THICK_THIN_LARGE_GAP: "thickThinLargeGap",
	/** a thick line contained within a thin line with a medium-sized intermediate gap */
	THICK_THIN_MEDIUM_GAP: "thickThinMediumGap",
	/** a thick line contained within a thin line with a small intermediate gap */
	THICK_THIN_SMALL_GAP: "thickThinSmallGap",
	/** a thin line contained within a thick line with a large-sized intermediate gap */
	THIN_THICK_LARGE_GAP: "thinThickLargeGap",
	/** a thick line contained within a thin line with a medium-sized intermediate gap */
	THIN_THICK_MEDIUM_GAP: "thinThickMediumGap",
	/** a thick line contained within a thin line with a small intermediate gap */
	THIN_THICK_SMALL_GAP: "thinThickSmallGap",
	/** a thin-thick-thin line with a large gap */
	THIN_THICK_THIN_LARGE_GAP: "thinThickThinLargeGap",
	/** a thin-thick-thin line with a medium gap */
	THIN_THICK_THIN_MEDIUM_GAP: "thinThickThinMediumGap",
	/** a thin-thick-thin line with a small gap */
	THIN_THICK_THIN_SMALL_GAP: "thinThickThinSmallGap",
	/** a three-staged gradient line, getting darker towards the paragraph */
	THREE_D_EMBOSS: "threeDEmboss",
	/** a three-staged gradient like, getting darker away from the paragraph */
	THREE_D_ENGRAVE: "threeDEngrave",
	/** a triple line */
	TRIPLE: "triple",
	/** a wavy line */
	WAVE: "wave"
};
/**
* Paragraph border module for WordprocessingML documents.
*
* This module provides border options for paragraphs.
*
* Reference: http://officeopenxml.com/WPborders.php
*
* @module
*/
/**
* Represents paragraph borders in a WordprocessingML document.
*
* The pBdr element specifies borders that surround the paragraph.
*
* Reference: http://officeopenxml.com/WPborders.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PBdr">
*   <xsd:sequence>
*     <xsd:element name="top" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="left" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="bottom" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="right" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="between" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="bar" type="CT_Border" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Paragraph({
*   border: {
*     top: { style: BorderStyle.SINGLE, size: 6, color: "FF0000" },
*     bottom: { style: BorderStyle.SINGLE, size: 6, color: "FF0000" },
*   },
*   children: [new TextRun("Paragraph with top and bottom borders")],
* });
* ```
*/
var Border = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:pBdr");
		if (options.top) this.root.push(createBorderElement("w:top", options.top));
		if (options.left) this.root.push(createBorderElement("w:left", options.left));
		if (options.bottom) this.root.push(createBorderElement("w:bottom", options.bottom));
		if (options.right) this.root.push(createBorderElement("w:right", options.right));
		if (options.between) this.root.push(createBorderElement("w:between", options.between));
	}
};
/**
* Represents a thematic break (horizontal rule) in a WordprocessingML document.
*
* Creates a horizontal line across the paragraph using a bottom border.
*
* Reference: http://officeopenxml.com/WPborders.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PBdr">
*   <xsd:sequence>
*     <xsd:element name="bottom" type="CT_Border" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Paragraph({
*   thematicBreak: true,
*   children: [new TextRun("Paragraph with horizontal rule below")],
* });
* ```
*/
var ThematicBreak = class extends XmlComponent {
	constructor() {
		super("w:pBdr");
		const bottom = createBorderElement("w:bottom", {
			color: "auto",
			space: 1,
			style: BorderStyle.SINGLE,
			size: 6
		});
		this.root.push(bottom);
	}
};
/**
* Paragraph indentation module for WordprocessingML documents.
*
* This module provides indentation options for paragraphs including left, right,
* hanging, and first line indentation.
*
* Reference: http://officeopenxml.com/WPindentation.php
*
* @module
*/
/**
* Creates paragraph indentation element for a WordprocessingML document.
*
* The ind element specifies the indentation of the paragraph from the margins.
*
* Reference: http://officeopenxml.com/WPindentation.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Ind">
*   <xsd:attribute name="start" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="startChars" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="end" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="endChars" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="left" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="leftChars" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="right" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="rightChars" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="hanging" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="hangingChars" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="firstLine" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="firstLineChars" type="ST_DecimalNumber" use="optional"/>
* </xsd:complexType>
* ```
*/
var createIndent = ({ start, end, left, right, hanging, firstLine, firstLineChars }) => new BuilderElement({
	name: "w:ind",
	attributes: {
		start: {
			key: "w:start",
			value: start === void 0 ? void 0 : signedTwipsMeasureValue(start)
		},
		end: {
			key: "w:end",
			value: end === void 0 ? void 0 : signedTwipsMeasureValue(end)
		},
		left: {
			key: "w:left",
			value: left === void 0 ? void 0 : signedTwipsMeasureValue(left)
		},
		right: {
			key: "w:right",
			value: right === void 0 ? void 0 : signedTwipsMeasureValue(right)
		},
		hanging: {
			key: "w:hanging",
			value: hanging === void 0 ? void 0 : twipsMeasureValue(hanging)
		},
		firstLine: {
			key: "w:firstLine",
			value: firstLine === void 0 ? void 0 : twipsMeasureValue(firstLine)
		},
		firstLineChars: {
			key: "w:firstLineChars",
			value: firstLineChars === void 0 ? void 0 : decimalNumber(firstLineChars)
		}
	}
});
/**
* Break module for WordprocessingML documents.
*
* This module provides support for line breaks within a run. A break element
* represents a line break (line feed) within text content.
*
* Reference: http://officeopenxml.com/WPtextSpecialContent-break.php
* Reference: http://officeopenxml.com/WPrun.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Br">
*   <xsd:attribute name="type" type="ST_BrType" use="optional"/>
*   <xsd:attribute name="clear" type="ST_BrClear" use="optional"/>
* </xsd:complexType>
*
* <xsd:simpleType name="ST_BrType">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="page"/>
*     <xsd:enumeration value="column"/>
*     <xsd:enumeration value="textWrapping"/>
*   </xsd:restriction>
* </xsd:simpleType>
*
* <xsd:simpleType name="ST_BrClear">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="none"/>
*     <xsd:enumeration value="left"/>
*     <xsd:enumeration value="right"/>
*     <xsd:enumeration value="all"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @module
*/
/**
* Creates a line break element for a WordprocessingML document.
*
* The Break element inserts a line break (carriage return/line feed) within a run.
* This forces text to continue on the next line without starting a new paragraph.
*
* Reference: http://officeopenxml.com/WPtextSpecialContent-break.php
*
* @example
* ```typescript
* // Add line breaks in a run
* new Run({
*   children: [
*     "First line",
*     createBreak(),
*     "Second line",
*     createBreak(),
*     "Third line",
*   ],
* });
* ```
*/
var createBreak = () => new BuilderElement({ name: "w:br" });
/**
* Field module for WordprocessingML documents.
*
* This module provides support for complex fields, which are regions of text
* that can contain dynamic content such as page numbers, dates, or mail merge fields.
* Fields are delimited by field character elements (begin, separate, end).
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @module
*/
/**
* Field character types that delimit field regions.
*
* @internal
*/
var FieldCharacterType = {
	BEGIN: "begin",
	END: "end",
	SEPARATE: "separate"
};
/**
* Creates a field character element.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_FldChar">
*   <xsd:sequence>
*     <xsd:element name="fldData" type="CT_Text" minOccurs="0"/>
*     <xsd:element name="ffData" type="CT_FFData" minOccurs="0"/>
*     <xsd:element name="numberingChange" type="CT_TrackChangeNumbering" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="fldCharType" type="ST_FldCharType" use="required"/>
*   <xsd:attribute name="fldLock" type="s:ST_OnOff"/>
*   <xsd:attribute name="dirty" type="s:ST_OnOff"/>
* </xsd:complexType>
* ```
* @internal
*/
var createFieldChar = (type, dirty, locked) => new BuilderElement({
	name: "w:fldChar",
	attributes: {
		type: {
			key: "w:fldCharType",
			value: type
		},
		dirty: {
			key: "w:dirty",
			value: dirty
		},
		locked: {
			key: "w:fldLock",
			value: locked
		}
	}
});
/**
* Creates the beginning of a complex field.
*
* The Begin element marks the start of a field. A field consists of a begin character,
* field instructions, an optional separate character, field result, and an end character.
* A locked field (`w:fldLock`) is not updated by Word.
*/
var createBegin = (dirty, locked) => createFieldChar(FieldCharacterType.BEGIN, dirty, locked);
/** The formatted begin characters of the fields that are dirty only when the document isn't given page numbers */
var dirtyWithoutPageNumbers = /* @__PURE__ */ new WeakSet();
/** The beginning of a field that is dirty, so Word updates it, unless the document is given page numbers */
var BeginDirtyWithoutPageNumbers = class extends BuilderElement {
	constructor() {
		super({
			name: "w:fldChar",
			attributes: {
				type: {
					key: "w:fldCharType",
					value: FieldCharacterType.BEGIN
				},
				dirty: {
					key: "w:dirty",
					value: true
				}
			}
		});
	}
	prepForXml(context) {
		const xml = super.prepForXml(context);
		dirtyWithoutPageNumbers.add(xml);
		return xml;
	}
};
/**
* Creates the beginning of a field whose result is written when the document is given page numbers, such as a page
* reference or a SEQ field. It is written dirty, so Word updates the field when it opens the document, and asks to. When
* the document is given page numbers, it is written clean (see {@link isDirtyWithoutPageNumbers}), so Word shows the
* number written, or nothing when none could be worked out, and doesn't ask.
*/
var createBeginDirtyWithoutPageNumbers = () => new BeginDirtyWithoutPageNumbers();
/** Whether a formatted field character is the beginning of a field that is dirty only without page numbers */
var isDirtyWithoutPageNumbers = (element) => typeof element === "object" && element !== null && dirtyWithoutPageNumbers.has(element);
/**
* Creates the separator between field code and field result in a complex field.
*
* The Separate element divides the field code (instructions) from the field result
* (the computed value).
*/
var createSeparate = (dirty) => createFieldChar(FieldCharacterType.SEPARATE, dirty);
/**
* Creates the end of a complex field.
*
* The End element marks the end of a field. Every field that begins with a Begin
* element must be terminated with an End element.
*/
var createEnd = (dirty) => createFieldChar(FieldCharacterType.END, dirty);
/**
* Space type module for WordprocessingML documents.
*
* This module provides the xml:space attribute values for
* controlling whitespace handling in text elements.
*
* @module
*/
/**
* XML space handling modes.
*
* Controls how whitespace is handled in text elements.
*
* @example
* ```typescript
* // Preserve whitespace (spaces, newlines)
* SpaceType.PRESERVE;
*
* // Default whitespace handling
* SpaceType.DEFAULT;
* ```
*
* @publicApi
*/
var SpaceType = {
	DEFAULT: "default",
	PRESERVE: "preserve"
};
/**
* Represents text element attributes.
*
* Used to set the xml:space attribute which controls
* whitespace preservation in text content.
*
* @example
* ```typescript
* new TextAttributes({ space: SpaceType.PRESERVE });
* ```
*
* @internal
*/
var TextAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { space: "xml:space" });
	}
};
/**
* Page number field instruction module for WordprocessingML documents.
*
* This module provides field instruction elements for displaying
* page numbers, page counts, and section information.
*
* Reference: http://officeopenxml.com/WPfields.php
*
* @module
*/
/**
* Represents a PAGE field instruction.
*
* Displays the current page number in the document.
*
* @example
* ```typescript
* new Run({ children: [new Begin(true), new Page(), new End()] });
* ```
*
* @internal
*/
var Page = class extends XmlComponent {
	constructor() {
		super("w:instrText");
		this.root.push(new TextAttributes({ space: SpaceType.PRESERVE }));
		this.root.push("PAGE");
	}
};
/**
* Represents a NUMPAGES field instruction.
*
* Displays the total number of pages in the document.
*
* @internal
*/
var NumberOfPages = class extends XmlComponent {
	constructor() {
		super("w:instrText");
		this.root.push(new TextAttributes({ space: SpaceType.PRESERVE }));
		this.root.push("NUMPAGES");
	}
};
/**
* Represents a SECTIONPAGES field instruction.
*
* Displays the total number of pages in the current section.
*
* @internal
*/
var NumberOfPagesSection = class extends XmlComponent {
	constructor() {
		super("w:instrText");
		this.root.push(new TextAttributes({ space: SpaceType.PRESERVE }));
		this.root.push("SECTIONPAGES");
	}
};
/**
* Represents a SECTION field instruction.
*
* Displays the current section number.
*
* @internal
*/
var CurrentSection = class extends XmlComponent {
	constructor() {
		super("w:instrText");
		this.root.push(new TextAttributes({ space: SpaceType.PRESERVE }));
		this.root.push("SECTION");
	}
};
/**
* Shading module for WordprocessingML documents.
*
* Shading is used to apply background colors and patterns to paragraphs,
* table cells, and text runs. The shading type is identical in all places.
*
* Reference: http://officeopenxml.com/WPshading.php
*
* @see http://officeopenxml.com/WPtableShading.php
* @see http://officeopenxml.com/WPtableCellProperties-Shading.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Shd">
*   <xsd:attribute name="val" type="ST_Shd" use="required"/>
*   <xsd:attribute name="color" type="ST_HexColor" use="optional"/>
*   <xsd:attribute name="themeColor" type="ST_ThemeColor" use="optional"/>
*   <xsd:attribute name="themeTint" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="themeShade" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="fill" type="ST_HexColor" use="optional"/>
*   <xsd:attribute name="themeFill" type="ST_ThemeColor" use="optional"/>
*   <xsd:attribute name="themeFillTint" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="themeFillShade" type="ST_UcharHexNumber" use="optional"/>
* </xsd:complexType>
* ```
*
* @module
*/
/**
* Creates a shading element for a WordprocessingML document.
*
* The shd element specifies the shading applied to the paragraph,
* table cell, or text run.
*
* Reference: http://officeopenxml.com/WPshading.php
*/
var createShading = ({ fill, color, type }) => createColorElement("w:shd", [
	{
		keys: {
			color: "w:fill",
			theme: "w:themeFill",
			tint: "w:themeFillTint",
			shade: "w:themeFillShade"
		},
		color: fill
	},
	{
		keys: COLOR_ATTRIBUTES,
		color
	},
	{
		key: "w:val",
		value: type !== null && type !== void 0 ? type : ShadingType.CLEAR
	}
]);
/**
* Shading pattern types.
*
* Specifies the pattern used for shading. The pattern combines the fill
* color and the pattern color.
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_Shd">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="nil"/>
*     <xsd:enumeration value="clear"/>
*     <xsd:enumeration value="solid"/>
*     <xsd:enumeration value="horzStripe"/>
*     <xsd:enumeration value="vertStripe"/>
*     <xsd:enumeration value="reverseDiagStripe"/>
*     <xsd:enumeration value="diagStripe"/>
*     <xsd:enumeration value="horzCross"/>
*     <xsd:enumeration value="diagCross"/>
*     <!-- ... percent values ... -->
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var ShadingType = {
	/** Clear shading - no pattern, fill color only */
	CLEAR: "clear",
	DIAGONAL_CROSS: "diagCross",
	DIAGONAL_STRIPE: "diagStripe",
	HORIZONTAL_CROSS: "horzCross",
	HORIZONTAL_STRIPE: "horzStripe",
	NIL: "nil",
	PERCENT_5: "pct5",
	PERCENT_10: "pct10",
	PERCENT_12: "pct12",
	PERCENT_15: "pct15",
	PERCENT_20: "pct20",
	PERCENT_25: "pct25",
	PERCENT_30: "pct30",
	PERCENT_35: "pct35",
	PERCENT_37: "pct37",
	PERCENT_40: "pct40",
	PERCENT_45: "pct45",
	PERCENT_50: "pct50",
	PERCENT_55: "pct55",
	PERCENT_60: "pct60",
	PERCENT_62: "pct62",
	PERCENT_65: "pct65",
	PERCENT_70: "pct70",
	PERCENT_75: "pct75",
	PERCENT_80: "pct80",
	PERCENT_85: "pct85",
	PERCENT_87: "pct87",
	PERCENT_90: "pct90",
	PERCENT_95: "pct95",
	REVERSE_DIAGONAL_STRIPE: "reverseDiagStripe",
	SOLID: "solid",
	THIN_DIAGONAL_CROSS: "thinDiagCross",
	THIN_DIAGONAL_STRIPE: "thinDiagStripe",
	THIN_HORIZONTAL_CROSS: "thinHorzCross",
	THIN_REVERSE_DIAGONAL_STRIPE: "thinReverseDiagStripe",
	THIN_VERTICAL_STRIPE: "thinVertStripe",
	VERTICAL_STRIPE: "vertStripe"
};
/**
* Track Revision module for WordprocessingML documents.
*
* This module provides support for tracking document revisions
* (insertions, deletions, and formatting changes).
*
* Reference: http://officeopenxml.com/WPtrackChanges.php
*
* @module
*/
/**
* Attributes for a tracked change element.
*
* Represents the common attributes (id, author, date) that appear on track change
* elements such as insertions (w:ins) and deletions (w:del). These attributes
* are part of the CT_TrackChange complex type in OOXML.
*
* Reference: http://officeopenxml.com/WPtrackChanges.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TrackChange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_Markup">
*       <xsd:attribute name="author" type="s:ST_String" use="required"/>
*       <xsd:attribute name="date" type="ST_DateTime" use="optional"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_Markup">
*   <xsd:attribute name="id" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*
* @internal
*/
var ChangeAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			id: "w:id",
			author: "w:author",
			date: "w:date"
		});
	}
};
var DeletionTrackChange = class extends XmlComponent {
	constructor(options) {
		super("w:del");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
	}
};
var InsertionTrackChange = class extends XmlComponent {
	constructor(options) {
		super("w:ins");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
	}
};
/**
* Creates the East Asian layout (`w:eastAsianLayout`) of a run's text.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_EastAsianLayout">
*   <xsd:attribute name="id" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="combine" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="combineBrackets" type="ST_CombineBrackets" use="optional"/>
*   <xsd:attribute name="vert" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="vertCompress" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* createEastAsianLayout({ twoLinesInOne: true, brackets: TwoLinesInOneBrackets.ROUND });
* ```
*/
var createEastAsianLayout = ({ twoLinesInOne, brackets, horizontalInVertical, fitToLine, group }) => new BuilderElement({
	name: "w:eastAsianLayout",
	attributes: {
		id: {
			key: "w:id",
			value: group === void 0 ? void 0 : decimalNumber(group)
		},
		combine: {
			key: "w:combine",
			value: twoLinesInOne
		},
		combineBrackets: {
			key: "w:combineBrackets",
			value: brackets
		},
		vert: {
			key: "w:vert",
			value: horizontalInVertical
		},
		vertCompress: {
			key: "w:vertCompress",
			value: fitToLine
		}
	}
});
/**
* Emphasis mark module for WordprocessingML run properties.
*
* This module provides support for East Asian emphasis marks, which are
* characters placed above or below text to emphasize it.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @module
*/
/**
* Emphasis mark types.
*
* Defines the types of emphasis marks that can be applied to text.
* Emphasis marks are commonly used in East Asian typography.
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_Em">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="none"/>
*     <xsd:enumeration value="dot"/>
*     <xsd:enumeration value="comma"/>
*     <xsd:enumeration value="circle"/>
*     <xsd:enumeration value="underDot"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var EmphasisMarkType = { 
/** Dot emphasis mark */
DOT: "dot" };
/**
* Creates an emphasis mark element for a WordprocessingML document.
*
* Emphasis marks are characters (typically dots or circles) placed above or below
* text to emphasize it. This is commonly used in East Asian typography.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Em">
*   <xsd:attribute name="val" type="ST_Em" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Apply dot emphasis mark
* createEmphasisMark(EmphasisMarkType.DOT);
*
* // Default to dot
* createEmphasisMark();
* ```
*/
var createEmphasisMark = (emphasisMarkType = EmphasisMarkType.DOT) => new BuilderElement({
	name: "w:em",
	attributes: { val: {
		key: "w:val",
		value: emphasisMarkType
	} }
});
var urlAlphabet = "57X6y3wQZNzYjJB2L_10pxbackgroundhimselfUTF-8DEMOGRAPHICSVqvt4KW9";
var customAlphabet = (alphabet, defaultSize = 21) => {
	return (size = defaultSize) => {
		let id = "";
		let i = size | 0;
		while (i-- > 0) id += alphabet[Math.random() * alphabet.length | 0];
		return id;
	};
};
var nanoid = (size = 21) => {
	let id = "";
	let i = size | 0;
	while (i-- > 0) id += urlAlphabet[Math.random() * 64 | 0];
	return id;
};
/**
* SHA-1 and SHA-256, for the names of media files and the hashes of passwords that protect a document. They are worked
* out here because documents are written synchronously, and browsers only hash asynchronously.
*
* @module
*/
/**
* The words the bytes come to once padded as SHA-1 and SHA-256 pad them: a 1 bit, then 0 bits up to a multiple of 64
* bytes, the last 8 of which are the length in bits. Words and the length are big-endian.
*/
var paddedWords = (data) => {
	const words = new Int32Array(Math.ceil((data.length + 9) / 64) * 16);
	for (let index = 0; index < data.length; index++) words[index >> 2] |= data[index] << 24 - (index & 3) * 8;
	words[data.length >> 2] |= 128 << 24 - (data.length & 3) * 8;
	words[words.length - 2] = Math.floor(data.length / 536870912);
	words[words.length - 1] = data.length * 8;
	return words;
};
/** The bytes of the words of a hash, big-endian */
var bytesOfWords = (words) => {
	const bytes = new Uint8Array(words.length * 4);
	for (let index = 0; index < bytes.length; index++) bytes[index] = words[index >> 2] >>> 24 - (index & 3) * 8;
	return bytes;
};
var rotateRight = (word, bits) => word >>> bits | word << 32 - bits;
var SHA256_ROUND_CONSTANTS = Int32Array.of(1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298);
var SHA256_INITIAL_HASH = [
	1779033703,
	3144134277,
	1013904242,
	2773480762,
	1359893119,
	2600822924,
	528734635,
	1541459225
];
var sha256Schedule = /* @__PURE__ */ new Int32Array(64);
/** SHA-256 of bytes, as in FIPS 180-4 */
var sha256 = (data) => {
	const words = paddedWords(data);
	const schedule = sha256Schedule;
	let [h0, h1, h2, h3, h4, h5, h6, h7] = SHA256_INITIAL_HASH;
	for (let block = 0; block < words.length; block += 16) {
		schedule.set(words.subarray(block, block + 16));
		for (let t = 16; t < 64; t++) {
			const early = schedule[t - 15];
			const late = schedule[t - 2];
			schedule[t] = schedule[t - 16] + (rotateRight(early, 7) ^ rotateRight(early, 18) ^ early >>> 3) + schedule[t - 7] + (rotateRight(late, 17) ^ rotateRight(late, 19) ^ late >>> 10);
		}
		let [a, b, c, d, e, f, g, h] = [
			h0,
			h1,
			h2,
			h3,
			h4,
			h5,
			h6,
			h7
		];
		for (let t = 0; t < 64; t++) {
			const first = h + (rotateRight(e, 6) ^ rotateRight(e, 11) ^ rotateRight(e, 25)) + (e & f ^ ~e & g) + SHA256_ROUND_CONSTANTS[t] + schedule[t] | 0;
			const second = (rotateRight(a, 2) ^ rotateRight(a, 13) ^ rotateRight(a, 22)) + (a & b ^ a & c ^ b & c) | 0;
			h = g;
			g = f;
			f = e;
			e = d + first | 0;
			d = c;
			c = b;
			b = a;
			a = first + second | 0;
		}
		[h0, h1, h2, h3, h4, h5, h6, h7] = [
			h0 + a | 0,
			h1 + b | 0,
			h2 + c | 0,
			h3 + d | 0,
			h4 + e | 0,
			h5 + f | 0,
			h6 + g | 0,
			h7 + h | 0
		];
	}
	return bytesOfWords([
		h0,
		h1,
		h2,
		h3,
		h4,
		h5,
		h6,
		h7
	]);
};
/**
* Converts inches to TWIP (twentieths of a point).
*
* TWIP is a common unit in Office Open XML where 1 inch = 1440 TWIP.
*
* @param inches - The measurement in inches to convert
* @returns The equivalent measurement in TWIP
*
* @example
* ```typescript
* const width = convertInchesToTwip(1); // Returns 1440
* ```
*
* @publicApi
*/
var convertInchesToTwip = (inches) => Math.floor(inches * 72 * 20);
/**
* Creates a unique numeric ID generator with sequential numbering.
*
* @param initial - The initial value to start counting from (default: 0)
* @returns A function that returns incrementing numbers on each call
*
* @example
* ```typescript
* const idGen = uniqueNumericIdCreator(10);
* console.log(idGen()); // 11
* console.log(idGen()); // 12
* console.log(idGen()); // 13
* ```
*/
var uniqueNumericIdCreator = (initial = 0) => {
	let currentCount = initial;
	return () => ++currentCount;
};
/**
* Creates a unique numeric ID generator for abstract numbering definitions.
*
* Abstract numbering definitions define the appearance and behavior of lists.
*
* @returns A function that generates sequential IDs starting from 1
*
* @example
* ```typescript
* const idGen = abstractNumUniqueNumericIdGen();
* const id = idGen(); // Returns 1
* ```
*/
var abstractNumUniqueNumericIdGen = () => uniqueNumericIdCreator();
/**
* Creates a unique numeric ID generator for concrete numbering instances.
*
* Concrete numbering instances reference abstract numbering definitions and are
* used to apply numbering to paragraphs. Initial value is 1 because ID 1 is
* reserved for "default-bullet-numbering".
*
* @returns A function that generates sequential IDs starting from 2
*
* @example
* ```typescript
* const idGen = concreteNumUniqueNumericIdGen();
* const id = idGen(); // Returns 2 (1 is reserved)
* ```
*/
var concreteNumUniqueNumericIdGen = () => uniqueNumericIdCreator(1);
/**
* Creates a unique numeric ID generator for document properties.
*
* @returns A function that generates sequential IDs starting from 1
*
* @example
* ```typescript
* const idGen = docPropertiesUniqueNumericIdGen();
* const id = idGen(); // Returns 1
* ```
*/
var docPropertiesUniqueNumericIdGen = () => uniqueNumericIdCreator();
docPropertiesUniqueNumericIdGen();
/**
* Creates a unique numeric ID generator for bookmarks.
*
* Bookmarks are used to mark specific locations in a document for navigation
* and cross-referencing.
*
* @returns A function that generates sequential IDs starting from 1
*
* @example
* ```typescript
* const idGen = bookmarkUniqueNumericIdGen();
* const id = idGen(); // Returns 1
* ```
*/
var bookmarkUniqueNumericIdGen = () => uniqueNumericIdCreator();
/**
* Returns the next bookmark ID from a single counter shared by every bookmark.
*
* Bookmark IDs must be unique within a document, but a bookmark is created
* before it belongs to one, so all bookmarks draw from this one counter rather
* than a generator per instance.
*
* @returns A number no earlier call has returned
*
* @example
* ```typescript
* const first = bookmarkUniqueNumericId();
* const second = bookmarkUniqueNumericId(); // first + 1
* ```
*/
var bookmarkUniqueNumericId = bookmarkUniqueNumericIdGen();
var fitTextUniqueNumericIdGen = uniqueNumericIdCreator();
/**
* Returns the next ID for text fitted to a width on its own (`w:fitText`), from a single counter shared by every run.
*
* Word fits runs one after the other with the same ID together, and runs without one unreliably, so a run fitted
* without a group is given an ID no other run has. The IDs count down from -1, as Word's own are negative, so they
* don't meet the groups people give, which count up.
*
* @returns A negative number no earlier call has returned
*
* @example
* ```typescript
* const first = fitTextUniqueNumericId(); // -1
* const second = fitTextUniqueNumericId(); // -2
* ```
*/
var fitTextUniqueNumericId = () => -fitTextUniqueNumericIdGen();
/**
* Generates a unique lowercase alphanumeric ID using nanoid.
*
* The ID is suitable for use as a relationship ID or other unique identifier
* within a document.
*
* @returns A unique lowercase string ID
*/
var uniqueId = () => nanoid().toLowerCase();
/**
* Generates a random hexadecimal string of specified length.
*
* @param count - The number of hexadecimal characters to generate
* @returns A random hexadecimal string
*/
var generateUuidPart = (count) => customAlphabet("1234567890abcdef", count)();
/**
* Generates a UUID v4-style unique identifier.
*
* The UUID follows the format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
*
* @returns A UUID string
*
* @example
* ```typescript
* const uuid = uniqueUuid(); // Returns "a3bb189e-8bf9-3888-9912-ace4e6543002"
* ```
*/
var uniqueUuid = () => `${generateUuidPart(8)}-${generateUuidPart(4)}-${generateUuidPart(4)}-${generateUuidPart(4)}-${generateUuidPart(12)}`;
/**
* Encode a string to UTF-8 bytes.
*
* The copy via `new Uint8Array()` ensures the returned array uses the
* current module's Uint8Array constructor, avoiding cross-realm issues
* in test environments (jsdom) where TextEncoder returns a different
* realm's Uint8Array that fails `instanceof Uint8Array` checks.
*/
var encodeUtf8 = (str) => new Uint8Array(new TextEncoder().encode(str));
/**
* Fit text module for WordprocessingML run properties.
*
* This module provides Word's Fit Text, which squeezes or spreads a run's text so that it takes up a width given for it.
*
* Reference: ISO/IEC 29500-1, 17.3.2.14 fitText
*
* @module
*/
/**
* Creates the fitting of a run's text to a width (`w:fitText`).
*
* Word writes an ID for each piece of fitted text, and fits runs without one unreliably: two of them next to each other
* together, and some not at all. So a run without a group is given an ID of its own.
*
* A width given as a measure is written in twips, as Office's schemas allow only a whole number of them, though the
* standard's allow a measure.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_FitText">
*   <xsd:attribute name="val" type="s:ST_TwipsMeasure" use="required"/>
*   <xsd:attribute name="id" type="ST_DecimalNumber" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* createFitText({ width: 1440, group: 1 });
* ```
*/
var createFitText = ({ width, group }) => new BuilderElement({
	name: "w:fitText",
	attributes: {
		val: {
			key: "w:val",
			value: Math.round(universalMeasureToTwips(twipsMeasureValue(width)))
		},
		id: {
			key: "w:id",
			value: group === void 0 ? fitTextUniqueNumericId() : decimalNumber(group)
		}
	}
});
/**
* Run formatting module for WordprocessingML documents.
*
* This module provides character-level formatting elements including
* spacing, color, and highlighting.
*
* Reference: http://officeopenxml.com/WPtextFormatting.php
*
* @module
*/
/**
* Represents character spacing (tracking) in a run.
*
* Adjusts the space between characters in the text.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SignedTwipsMeasure">
*   <xsd:attribute name="val" type="ST_SignedTwipsMeasure" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new CharacterSpacing(20); // 20 twips (1 point)
* new CharacterSpacing("0.5pt"); // Half point
* ```
*
* @internal
*/
var CharacterSpacing = class extends XmlComponent {
	constructor(value) {
		super("w:spacing");
		this.root.push(new Attributes({ val: signedTwipsMeasureValue(value) }));
	}
};
/**
* Represents text color in a run.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Color">
*   <xsd:attribute name="val" type="ST_HexColor" use="required"/>
*   <xsd:attribute name="themeColor" type="ST_ThemeColor" use="optional"/>
*   <xsd:attribute name="themeTint" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="themeShade" type="ST_UcharHexNumber" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Color("FF0000"); // Red text
* new Color("auto"); // Automatic color
* new Color({ theme: "accent1", darker: 25 }); // The theme's first accent color, 25% darker
* ```
*
* @internal
*/
var Color = class extends XmlComponent {
	constructor(color) {
		super("w:color");
		this.root.push(new ColorAttributeComponent([{
			keys: _objectSpread2(_objectSpread2({}, COLOR_ATTRIBUTES), {}, { color: "w:val" }),
			color
		}]));
	}
};
/**
* Represents text highlighting in a run.
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_HighlightColor">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="black"/>
*     <xsd:enumeration value="blue"/>
*     <xsd:enumeration value="cyan"/>
*     <xsd:enumeration value="green"/>
*     <xsd:enumeration value="magenta"/>
*     <xsd:enumeration value="red"/>
*     <xsd:enumeration value="yellow"/>
*     <xsd:enumeration value="white"/>
*     <xsd:enumeration value="darkBlue"/>
*     <xsd:enumeration value="darkCyan"/>
*     <xsd:enumeration value="darkGreen"/>
*     <xsd:enumeration value="darkMagenta"/>
*     <xsd:enumeration value="darkRed"/>
*     <xsd:enumeration value="darkYellow"/>
*     <xsd:enumeration value="darkGray"/>
*     <xsd:enumeration value="lightGray"/>
*     <xsd:enumeration value="none"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @example
* ```typescript
* new Highlight("yellow"); // Yellow highlight
* new Highlight("cyan"); // Cyan highlight
* ```
*
* @internal
*/
var Highlight = class extends XmlComponent {
	constructor(color) {
		super("w:highlight");
		this.root.push(new Attributes({ val: color }));
	}
};
/**
* Language module for WordprocessingML run properties.
*
* This module provides support for specifying the language of text content,
* which affects spell checking, grammar checking, and hyphenation.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @module
*/
/**
* Creates a language component for run properties.
*
* This function creates a language element that specifies the language for text content.
* The language setting affects spell checking, grammar checking, and hyphenation.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @param options - Language options for different text types
* @returns XmlComponent representing the language element
*
* @example
* ```typescript
* // Set language for English (US)
* createLanguageComponent({ value: "en-US" });
*
* // Set different languages for different scripts
* createLanguageComponent({
*   value: "en-US",
*   eastAsia: "ja-JP",
*   bidirectional: "ar-SA",
* });
* ```
*/
var createLanguageComponent = (options) => new BuilderElement({
	name: "w:lang",
	attributes: {
		value: {
			key: "w:val",
			value: options.value
		},
		eastAsia: {
			key: "w:eastAsia",
			value: options.eastAsia
		},
		bidirectional: {
			key: "w:bidi",
			value: options.bidirectional
		}
	}
});
/**
* Run fonts module for WordprocessingML documents.
*
* This module provides support for specifying fonts for different character sets
* within a run. Fonts can be specified separately for ASCII, complex script (CS),
* East Asian, and high ANSI character ranges.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @module
*/
/**
* Creates font settings for a run in a WordprocessingML document.
*
* The rFonts element specifies which fonts should be used for different character
* ranges in a run. This allows documents to use different fonts for ASCII, complex
* script, East Asian, and high ANSI characters.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Fonts">
*   <xsd:attribute name="hint" type="ST_Hint"/>
*   <xsd:attribute name="ascii" type="s:ST_String"/>
*   <xsd:attribute name="hAnsi" type="s:ST_String"/>
*   <xsd:attribute name="eastAsia" type="s:ST_String"/>
*   <xsd:attribute name="cs" type="s:ST_String"/>
*   <xsd:attribute name="asciiTheme" type="ST_Theme"/>
*   <xsd:attribute name="hAnsiTheme" type="ST_Theme"/>
*   <xsd:attribute name="eastAsiaTheme" type="ST_Theme"/>
*   <xsd:attribute name="cstheme" type="ST_Theme"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Use same font for all character sets
* createRunFonts("Arial");
*
* // Specify different fonts for different character sets
* createRunFonts({
*   ascii: "Arial",
*   eastAsia: "MS Mincho",
*   cs: "Arial",
*   hAnsi: "Arial",
* });
*
* // Use the theme's font for body text, in every character set
* createRunFonts({ theme: "body" });
* ```
*/
var createRunFonts = (nameOrAttrs, hint) => {
	if (typeof nameOrAttrs === "string") {
		const name = nameOrAttrs;
		return new BuilderElement({
			name: "w:rFonts",
			attributes: {
				ascii: {
					key: "w:ascii",
					value: name
				},
				cs: {
					key: "w:cs",
					value: name
				},
				eastAsia: {
					key: "w:eastAsia",
					value: name
				},
				hAnsi: {
					key: "w:hAnsi",
					value: name
				},
				hint: {
					key: "w:hint",
					value: hint
				}
			}
		});
	}
	if ("theme" in nameOrAttrs) {
		const theme = nameOrAttrs.theme === "headings" ? "major" : "minor";
		return new BuilderElement({
			name: "w:rFonts",
			attributes: {
				ascii: {
					key: "w:asciiTheme",
					value: `${theme}HAnsi`
				},
				eastAsia: {
					key: "w:eastAsiaTheme",
					value: `${theme}EastAsia`
				},
				hAnsi: {
					key: "w:hAnsiTheme",
					value: `${theme}HAnsi`
				},
				cs: {
					key: "w:cstheme",
					value: `${theme}Bidi`
				}
			}
		});
	}
	const attrs = nameOrAttrs;
	return new BuilderElement({
		name: "w:rFonts",
		attributes: {
			ascii: {
				key: "w:ascii",
				value: attrs.ascii
			},
			cs: {
				key: "w:cs",
				value: attrs.cs
			},
			eastAsia: {
				key: "w:eastAsia",
				value: attrs.eastAsia
			},
			hAnsi: {
				key: "w:hAnsi",
				value: attrs.hAnsi
			},
			hint: {
				key: "w:hint",
				value: attrs.hint
			}
		}
	});
};
/**
* Subscript and superscript module for WordprocessingML documents.
*
* This module provides vertical alignment elements for subscript
* and superscript text formatting.
*
* Reference: http://officeopenxml.com/WPtextFormatting.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_VerticalAlignRun">
*   <xsd:attribute name="val" type="ST_VerticalAlignRun" use="required"/>
* </xsd:complexType>
* <xsd:simpleType name="ST_VerticalAlignRun">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="baseline"/>
*     <xsd:enumeration value="superscript"/>
*     <xsd:enumeration value="subscript"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @module
*/
/**
* Creates a vertical alignment run element.
* @internal
*/
var createVerticalAlignRun = (type) => new BuilderElement({
	name: "w:vertAlign",
	attributes: { val: {
		key: "w:val",
		value: type
	} }
});
/**
* Creates superscript text formatting.
*
* Raises text above the baseline, commonly used for exponents
* and ordinal indicators.
*/
var createSuperScript = () => createVerticalAlignRun("superscript");
/**
* Creates subscript text formatting.
*
* Lowers text below the baseline, commonly used for chemical
* formulas and footnote references.
*/
var createSubScript = () => createVerticalAlignRun("subscript");
/**
* Underline module for WordprocessingML documents.
*
* This module provides support for underlining text with various styles and colors.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @module
*/
/**
* Underline style types for text.
*
* Defines the various underline patterns that can be applied to text runs.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_Underline">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="single"/>
*     <xsd:enumeration value="words"/>
*     <xsd:enumeration value="double"/>
*     <xsd:enumeration value="thick"/>
*     <xsd:enumeration value="dotted"/>
*     <xsd:enumeration value="dottedHeavy"/>
*     <xsd:enumeration value="dash"/>
*     <xsd:enumeration value="dashedHeavy"/>
*     <xsd:enumeration value="dashLong"/>
*     <xsd:enumeration value="dashLongHeavy"/>
*     <xsd:enumeration value="dotDash"/>
*     <xsd:enumeration value="dashDotHeavy"/>
*     <xsd:enumeration value="dotDotDash"/>
*     <xsd:enumeration value="dashDotDotHeavy"/>
*     <xsd:enumeration value="wave"/>
*     <xsd:enumeration value="wavyHeavy"/>
*     <xsd:enumeration value="wavyDouble"/>
*     <xsd:enumeration value="none"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var UnderlineType = {
	/** Single underline */
	SINGLE: "single",
	/** Underline words only (not spaces) */
	WORDS: "words",
	/** Double underline */
	DOUBLE: "double",
	/** Thick single underline */
	THICK: "thick",
	/** Dotted underline */
	DOTTED: "dotted",
	/** Heavy dotted underline */
	DOTTEDHEAVY: "dottedHeavy",
	/** Dashed underline */
	DASH: "dash",
	/** Heavy dashed underline */
	DASHEDHEAVY: "dashedHeavy",
	/** Long dashed underline */
	DASHLONG: "dashLong",
	/** Heavy long dashed underline */
	DASHLONGHEAVY: "dashLongHeavy",
	/** Dot-dash underline */
	DOTDASH: "dotDash",
	/** Heavy dot-dash underline */
	DASHDOTHEAVY: "dashDotHeavy",
	/** Dot-dot-dash underline */
	DOTDOTDASH: "dotDotDash",
	/** Heavy dot-dot-dash underline */
	DASHDOTDOTHEAVY: "dashDotDotHeavy",
	/** Wave underline */
	WAVE: "wave",
	/** Heavy wave underline */
	WAVYHEAVY: "wavyHeavy",
	/** Double wave underline */
	WAVYDOUBLE: "wavyDouble",
	/** No underline */
	NONE: "none"
};
/**
* Creates underline formatting for a run in a WordprocessingML document.
*
* The u element specifies the style and optional color of underline
* formatting applied to text.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Underline">
*   <xsd:attribute name="val" type="ST_Underline" use="required"/>
*   <xsd:attribute name="color" type="ST_HexColor"/>
*   <xsd:attribute name="themeColor" type="ST_ThemeColor"/>
*   <xsd:attribute name="themeTint" type="ST_UcharHexNumber"/>
*   <xsd:attribute name="themeShade" type="ST_UcharHexNumber"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Simple single underline
* createUnderline();
*
* // Double underline
* createUnderline(UnderlineType.DOUBLE);
*
* // Red wavy underline
* createUnderline(UnderlineType.WAVE, "FF0000");
*
* // Underline in the theme's first accent color
* createUnderline(UnderlineType.SINGLE, { theme: "accent1" });
* ```
*/
var createUnderline = (underlineType = UnderlineType.SINGLE, color) => createColorElement("w:u", [{
	key: "w:val",
	value: underlineType
}, {
	keys: COLOR_ATTRIBUTES,
	color
}]);
/**
* Represents run properties (rPr) in a WordprocessingML document.
*
* Run properties specify all character-level formatting applied to text,
* such as bold, italic, font, size, color, underline, and other text effects.
*
* Reference: http://officeopenxml.com/WPtextFormatting.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_RPr">
*   <xsd:sequence>
*     <xsd:group ref="EG_RPrContent" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* The EG_RPrBase group includes elements like rStyle, rFonts, b, bCs, i, iCs,
* caps, smallCaps, strike, dstrike, outline, shadow, emboss, imprint, noProof,
* snapToGrid, vanish, color, spacing, w, kern, position, sz, szCs, highlight,
* u, effect, bdr, shd, vertAlign, rtl, em, lang, and more.
*/
var RunProperties = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:rPr");
		if (!options) return;
		if (options.style) this.push(new StringValueElement("w:rStyle", options.style));
		if (options.font) {
			if (typeof options.font === "string") this.push(createRunFonts(options.font));
			else if ("name" in options.font) this.push(createRunFonts(options.font.name, options.font.hint));
			else this.push(createRunFonts(options.font));
		}
		if (options.bold !== void 0) this.push(new OnOffElement("w:b", options.bold));
		if (options.boldComplexScript === void 0 && options.bold !== void 0 || options.boldComplexScript) {
			var _options$boldComplexS;
			this.push(new OnOffElement("w:bCs", (_options$boldComplexS = options.boldComplexScript) !== null && _options$boldComplexS !== void 0 ? _options$boldComplexS : options.bold));
		}
		if (options.italics !== void 0) this.push(new OnOffElement("w:i", options.italics));
		if (options.italicsComplexScript === void 0 && options.italics !== void 0 || options.italicsComplexScript) {
			var _options$italicsCompl;
			this.push(new OnOffElement("w:iCs", (_options$italicsCompl = options.italicsComplexScript) !== null && _options$italicsCompl !== void 0 ? _options$italicsCompl : options.italics));
		}
		if (options.smallCaps !== void 0) this.push(new OnOffElement("w:smallCaps", options.smallCaps));
		else if (options.allCaps !== void 0) this.push(new OnOffElement("w:caps", options.allCaps));
		if (options.strike !== void 0) this.push(new OnOffElement("w:strike", options.strike));
		if (options.doubleStrike !== void 0) this.push(new OnOffElement("w:dstrike", options.doubleStrike));
		if (options.emboss !== void 0) this.push(new OnOffElement("w:emboss", options.emboss));
		if (options.imprint !== void 0) this.push(new OnOffElement("w:imprint", options.imprint));
		if (options.noProof !== void 0) this.push(new OnOffElement("w:noProof", options.noProof));
		if (options.snapToGrid !== void 0) this.push(new OnOffElement("w:snapToGrid", options.snapToGrid));
		if (options.vanish !== void 0) this.push(new OnOffElement("w:vanish", options.vanish));
		if (options.color) this.push(new Color(options.color));
		if (options.characterSpacing) this.push(new CharacterSpacing(options.characterSpacing));
		if (options.scale !== void 0) this.push(new NumberValueElement("w:w", options.scale));
		if (options.kern) this.push(new HpsMeasureElement("w:kern", options.kern));
		if (options.position) this.push(new StringValueElement("w:position", options.position));
		if (options.size !== void 0) this.push(new HpsMeasureElement("w:sz", options.size));
		const szCs = options.sizeComplexScript === void 0 || options.sizeComplexScript === true ? options.size : options.sizeComplexScript;
		if (szCs) this.push(new HpsMeasureElement("w:szCs", szCs));
		if (options.highlight) this.push(new Highlight(options.highlight));
		if (options.underline) this.push(createUnderline(options.underline.type, options.underline.color));
		if (options.effect) this.push(new StringValueElement("w:effect", options.effect));
		if (options.border) this.push(createBorderElement("w:bdr", options.border));
		if (options.shading) this.push(createShading(options.shading));
		if (options.fitText) this.push(createFitText(options.fitText));
		if (options.subScript) this.push(createSubScript());
		if (options.superScript) this.push(createSuperScript());
		if (options.rightToLeft !== void 0) this.push(new OnOffElement("w:rtl", options.rightToLeft));
		if (options.emphasisMark) this.push(createEmphasisMark(options.emphasisMark.type));
		if (options.language) this.push(createLanguageComponent(options.language));
		if (options.eastAsianLayout) this.push(createEastAsianLayout(options.eastAsianLayout));
		if (options.specVanish !== void 0) this.push(new OnOffElement("w:specVanish", options.specVanish));
		if (options.math !== void 0) this.push(new OnOffElement("w:oMath", options.math));
		if (options.revision) this.push(new RunPropertiesChange(options.revision));
	}
	push(item) {
		this.root.push(item);
	}
};
var ParagraphRunProperties = class extends RunProperties {
	constructor(options) {
		super(options);
		if (options === null || options === void 0 ? void 0 : options.insertion) this.push(new InsertionTrackChange(options.insertion));
		if (options === null || options === void 0 ? void 0 : options.deletion) this.push(new DeletionTrackChange(options.deletion));
	}
};
/**
* Represents a run properties change element for revision tracking.
*
* This element is used to track changes to run properties when revision
* tracking is enabled in the document.
*/
var RunPropertiesChange = class extends XmlComponent {
	constructor(options) {
		super("w:rPrChange");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
		this.addChildElement(new RunProperties(options));
	}
};
/**
* Text module for WordprocessingML run content.
*
* This module provides the Text class for text content within runs.
*
* @module
*/
/**
* Represents a text element within a run.
*
* Text is the container for actual character content in a Word document.
* It corresponds to the `<w:t>` element.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Text">
*   <xsd:simpleContent>
*     <xsd:extension base="s:ST_String">
*       <xsd:attribute ref="xml:space" use="optional"/>
*     </xsd:extension>
*   </xsd:simpleContent>
* </xsd:complexType>
* ```
*/
var Text = class extends XmlComponent {
	constructor(options) {
		super("w:t");
		if (typeof options === "string") {
			this.root.push(new TextAttributes({ space: SpaceType.PRESERVE }));
			this.root.push(options);
		} else {
			var _options$space;
			this.root.push(new TextAttributes({ space: (_options$space = options.space) !== null && _options$space !== void 0 ? _options$space : SpaceType.DEFAULT }));
			this.root.push(options.text);
		}
	}
};
/**
* Constants for page number field types.
*
* These values are used to insert dynamic page number fields into a document.
*
* Reference: http://officeopenxml.com/WPfields.php
*
* @publicApi
*/
var PageNumber = {
	/** Inserts the current page number */
	CURRENT: "CURRENT",
	/** Inserts the total number of pages in the document */
	TOTAL_PAGES: "TOTAL_PAGES",
	/** Inserts the total number of pages in the current section */
	TOTAL_PAGES_IN_SECTION: "TOTAL_PAGES_IN_SECTION",
	/** Inserts the current section number */
	CURRENT_SECTION: "SECTION"
};
/** The parts of the field a page number child shows, in order, or undefined when the child is text */
var pageNumberFieldOf = (child) => {
	switch (child) {
		case PageNumber.CURRENT: return [
			createBegin(),
			new Page(),
			createSeparate(),
			createEnd()
		];
		case PageNumber.TOTAL_PAGES: return [
			createBegin(),
			new NumberOfPages(),
			createSeparate(),
			createEnd()
		];
		case PageNumber.TOTAL_PAGES_IN_SECTION: return [
			createBegin(),
			new NumberOfPagesSection(),
			createSeparate(),
			createEnd()
		];
		case PageNumber.CURRENT_SECTION: return [
			createBegin(),
			new CurrentSection(),
			createSeparate(),
			createEnd()
		];
		default: return;
	}
};
/**
* Represents a run of text with uniform formatting in a WordprocessingML document.
*
* A run is the lowest level unit of text in a paragraph. All content within a run
* shares the same formatting properties (bold, italic, font, size, etc.).
*
* Reference: http://officeopenxml.com/WPtext.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_R">
*   <xsd:sequence>
*     <xsd:group ref="EG_RPr" minOccurs="0"/>
*     <xsd:group ref="EG_RunInnerContent" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="rsidRPr" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidDel" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidR" type="ST_LongHexNumber"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Simple run with text
* new Run({ text: "Hello World" });
*
* // Bold and italic run
* new Run({ text: "Formatted", bold: true, italics: true });
*
* // Run with page number
* new Run({ children: [PageNumber.CURRENT] });
* ```
*/
var Run = class Run extends XmlComponent {
	constructor(options) {
		super("w:r");
		_defineProperty(this, "properties", void 0);
		_defineProperty(this, "following", []);
		this.properties = new RunProperties(options);
		this.root.push(this.properties);
		if (options.break) for (let i = 0; i < options.break; i++) this.root.push(createBreak());
		if (options.children) for (const [index, child] of options.children.entries()) {
			if (elementOf(child) === "w:r") {
				const rest = options.children.slice(index + 1);
				this.following = [child, ...rest.length > 0 ? [new Run(_objectSpread2(_objectSpread2({}, options), {}, {
					break: void 0,
					children: rest
				}))] : []];
				break;
			}
			if (typeof child === "string") {
				const field = pageNumberFieldOf(child);
				if (field) {
					const rest = options.children.slice(index + 1);
					const runOf = (children) => new Run(_objectSpread2(_objectSpread2({}, options), {}, {
						break: void 0,
						children
					}));
					const beginsHere = this.root.length === 1;
					if (beginsHere) this.root.push(field[0]);
					const parts = beginsHere ? field.slice(1) : field;
					this.following = [...parts.map((part) => runOf([part])), ...rest.length > 0 ? [runOf(rest)] : []];
					break;
				}
				this.root.push(new Text(child));
				continue;
			}
			this.root.push(child);
		}
		else if (options.text !== void 0) this.root.push(new Text(options.text));
	}
	get writtenAs() {
		return this.following.length > 0 ? [this, ...this.following.flatMap((run) => {
			var _run$writtenAs;
			return (_run$writtenAs = run.writtenAs) !== null && _run$writtenAs !== void 0 ? _run$writtenAs : run;
		})] : void 0;
	}
};
/**
* Represents a text run in a WordprocessingML document.
*
* TextRun is a convenience class that extends Run, allowing you to pass
* either a string or full run options. This is the most common way to
* add text content to a paragraph.
*
* Reference: http://officeopenxml.com/WPtext.php
*
* @publicApi
*
* @example
* ```typescript
* // Simple text
* new TextRun("Hello World");
*
* // Formatted text
* new TextRun({ text: "Bold Text", bold: true });
* ```
*/
var TextRun = class extends Run {
	constructor(options) {
		super(typeof options === "string" ? { text: options } : options);
	}
};
/**
* Target mode types for relationships.
*
* Indicates whether a relationship target is external to the package.
*/
var TargetModeType = { 
/** Target is external to the package (e.g., hyperlink to a URL) */
EXTERNAL: "External" };
/**
* Creates a single relationship between parts in an OPC package.
*
* A relationship defines a typed connection from a source part to a target part,
* identified by a unique ID within the relationships collection.
*
* @example
* ```typescript
* // Internal relationship to an image
* createRelationship("rId1", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", "media/image1.png");
*
* // External relationship to a hyperlink
* createRelationship("rId2", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", "https://example.com", TargetModeType.EXTERNAL);
* ```
*/
var createRelationship = (id, type, target, targetMode) => new BuilderElement({
	name: "Relationship",
	attributes: {
		id: {
			key: "Id",
			value: id
		},
		type: {
			key: "Type",
			value: type
		},
		target: {
			key: "Target",
			value: target
		},
		targetMode: {
			key: "TargetMode",
			value: targetMode
		}
	}
});
/**
* Child elements for document properties.
*
* This module provides hyperlink elements that can be attached to
* drawing elements for interactive behavior.
*
* @module
*/
/**
* Creates a click hyperlink element for a drawing.
*
* This element defines what happens when a user clicks on a drawing element.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Hyperlink">
*   <xsd:group ref="EG_PContent" minOccurs="0" maxOccurs="unbounded"/>
*   <xsd:attribute name="tgtFrame" type="s:ST_String"/>
*   <xsd:attribute name="tooltip" type="s:ST_String"/>
*   <xsd:attribute name="docLocation" type="s:ST_String"/>
*   <xsd:attribute name="history" type="s:ST_OnOff"/>
*   <xsd:attribute name="anchor" type="s:ST_String"/>
*   <xsd:attribute ref="r:id"/>
* </xsd:complexType>
* ```
*
* @param linkId - The relationship ID for the hyperlink target
* @param hasXmlNs - Whether to include the XML namespace declaration
* @returns An XML component representing the click hyperlink
*/
var createHyperlinkClick = (linkId, hasXmlNs) => new BuilderElement({
	name: "a:hlinkClick",
	attributes: _objectSpread2(_objectSpread2({}, hasXmlNs ? { xmlns: {
		key: "xmlns:a",
		value: "http://schemas.openxmlformats.org/drawingml/2006/main"
	} } : {}), {}, { id: {
		key: "r:id",
		value: `rId${linkId}`
	} })
});
/**
* A link from a drawing to a web address: the `a:hlinkClick` element, and the relationship that holds the address.
*
* The relationship is added to the part the drawing is written in (the document, a header or a footer) when it is written.
*/
var DrawingLink = class {
	constructor(link) {
		_defineProperty(this, "link", void 0);
		_defineProperty(this, "linkId", uniqueId());
		_defineProperty(this, "addedTo", /* @__PURE__ */ new WeakSet());
		this.link = link;
	}
	createClick(declareNamespace) {
		return createHyperlinkClick(this.linkId, declareNamespace);
	}
	addRelationship(context) {
		const relationships = context.viewWrapper.Relationships;
		if (this.addedTo.has(relationships)) return;
		this.addedTo.add(relationships);
		relationships.addRelationship(this.linkId, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", this.link, TargetModeType.EXTERNAL);
	}
};
var LARGEST_ROMAN = 32767;
var LARGEST_LETTERS = 780;
var ROMAN = [
	[1e3, "M"],
	[900, "CM"],
	[500, "D"],
	[400, "CD"],
	[100, "C"],
	[90, "XC"],
	[50, "L"],
	[40, "XL"],
	[10, "X"],
	[9, "IX"],
	[5, "V"],
	[4, "IV"],
	[1, "I"]
];
var roman = (value) => value <= LARGEST_ROMAN ? ROMAN.reduce(({ rest, text }, [amount, numeral]) => ({
	rest: rest % amount,
	text: text + numeral.repeat(Math.floor(rest / amount))
}), {
	rest: value,
	text: ""
}).text : void 0;
var letters = (value) => value === 0 ? "" : value <= LARGEST_LETTERS ? String.fromCharCode(65 + (value - 1) % 26).repeat(Math.ceil(value / 26)) : void 0;
var ordinal = (value) => {
	var _ref;
	return `${value}${value % 100 >= 11 && value % 100 <= 13 ? "th" : (_ref = [
		"th",
		"st",
		"nd",
		"rd"
	][value % 10]) !== null && _ref !== void 0 ? _ref : "th"}`;
};
/**
* The number formats of a field's `\*` switch that are written as Word writes them, by their names in any capitals.
* Word writes roman numerals and letters in small letters when the name starts with a small letter, as `roman`, and in
* capitals otherwise, as `Roman` and `ROMAN`
*/
var numberWriterOf = (format) => {
	const small = format.charAt(0) !== format.charAt(0).toUpperCase();
	const inCase = (write) => (value) => {
		var _write;
		return small ? (_write = write(value)) === null || _write === void 0 ? void 0 : _write.toLowerCase() : write(value);
	};
	switch (format.toLowerCase()) {
		case "arabic": return String;
		case "roman": return inCase(roman);
		case "alphabetic": return inCase(letters);
		case "ordinal": return (value) => value > 0 ? ordinal(value) : void 0;
		case "arabicdash": return (value) => `- ${value} -`;
		default: return;
	}
};
var PLAIN_FORMATS = /* @__PURE__ */ new Set([
	"mergeformat",
	"charformat",
	"mergeformatinet"
]);
var CASE_FORMATS = /* @__PURE__ */ new Set([
	"upper",
	"lower",
	"firstcap",
	"caps"
]);
/**
* Whether Word's text for a picture of a field's `\#` switch is known: one of digits (`0`), digits only where the number
* has them (`#`) and commas between thousands, as Word wrote `00`, `000`, `0`, `#` and `#,##0` for page numbers
* (`scripts/layout-probes/word-page-fields.ts` PF5 to PF7)
*/
var isNumberPicture = (picture) => /^[#0,]*[#0][#0,]*$/.test(picture);
/**
* A number with a picture: with as many digits as it has `0`s at least, which Word fills with 0s (5 is 05 with `00`), and
* its thousands between commas when it has one (1234 is 1,234 with `#,##0`). Undefined where a `#` has no digit of the
* number, which Word writes as a space, not yet seen
*/
var inNumberPicture = (value, picture) => {
	const zeros = [...picture].filter((character) => character === "0").length;
	const places = zeros + [...picture].filter((character) => character === "#").length;
	const digits = String(value).padStart(zeros, "0");
	if (digits.length < places || zeros === 0 && value === 0) return;
	return picture.includes(",") ? digits.replace(/\B(?=(\d{3})+$)/g, ",") : digits;
};
/**
* Text in the capitals of a field's switch, applied after its number's format, as Word wrote `\* roman \* Upper` as V,
* `\* Ordinal \* Upper` as 5TH, and "above" with `\* Upper` as ABOVE (`word-page-fields.ts` PF3 and PF5)
*/
var inCapitals = (text, capitals) => {
	switch (capitals) {
		case "upper": return text.toUpperCase();
		case "lower": return text.toLowerCase();
		case "firstcap": return text.charAt(0).toUpperCase() + text.slice(1);
		default: return text;
	}
};
/**
* Writes estimated page numbers into the fields of a tree of elements that show them: those docx formats to write a
* document, and those `patchDocument` parses from a template. Not part of the public API.
*
* A page reference is a PAGEREF field, and the numbers of pages of the document and of a section are NUMPAGES and
* SECTIONPAGES fields. Each field's result is written just after its `separate` field character, and any result it had
* is taken out.
*
* @module
*/
/** Reads a field that shows a page's number or a number of pages, or undefined for another field */
var numberFieldOf = (instruction) => {
	var _match;
	const field = (/* @__PURE__ */ new RegExp("^\\s*(PAGEREF|NUMPAGES|SECTIONPAGES)\\b(.*)$", "is")).exec(instruction);
	const reference = (field === null || field === void 0 ? void 0 : field[1].toUpperCase()) === "PAGEREF" ? (/* @__PURE__ */ new RegExp("^\\s*(\"?)([^\\s\"\\\\]+)\\1(.*)$", "s")).exec(field[2]) : void 0;
	if (!field || field[1].toUpperCase() === "PAGEREF" && !reference) return;
	const parts = (_match = (reference ? reference[3] : field[2]).match(/"[^"]*"|\S+/g)) !== null && _match !== void 0 ? _match : [];
	let numberFormat;
	let picture;
	const capitals = [];
	let relative = false;
	let written = true;
	for (let index = 0; index < parts.length; index++) {
		const part = parts[index];
		const argument = () => {
			var _parts$index;
			return (part.length > 2 ? part.slice(2) : (_parts$index = parts[++index]) !== null && _parts$index !== void 0 ? _parts$index : "").replace(/^"(.*)"$/, "$1");
		};
		if (/^\\p$/i.test(part)) relative = true;
		else if (part.startsWith("\\#")) {
			var _picture;
			const value = argument();
			written && (written = picture === void 0 && isNumberPicture(value));
			(_picture = picture) !== null && _picture !== void 0 || (picture = value);
		} else if (part.startsWith("\\*")) {
			const name = argument();
			const lower = name.toLowerCase();
			if (CASE_FORMATS.has(lower)) capitals.push(lower);
			else if (name !== "" && !PLAIN_FORMATS.has(lower)) {
				var _numberFormat;
				written && (written = numberFormat === void 0 && numberWriterOf(name) !== void 0);
				(_numberFormat = numberFormat) !== null && _numberFormat !== void 0 || (numberFormat = name);
			}
		}
	}
	const own = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, numberFormat === void 0 ? {} : { numberFormat }), picture === void 0 ? {} : { picture }), capitals.length === 0 ? {} : { capitals: capitals[0] }), {}, { written: written && capitals.length <= 1 && capitals[0] !== "caps" && (numberFormat === void 0 || picture === void 0) });
	return reference ? _objectSpread2({
		type: "pageReference",
		bookmark: reference[2],
		relative
	}, own) : _objectSpread2({
		type: "pageCount",
		scope: field[1].toUpperCase() === "NUMPAGES" ? "document" : "section"
	}, own);
};
/**
* Whether a field is a table of contents that writes the number of a SEQ field before each page number (`\s`), such as
* 2-5 for page 5 of chapter 2, which isn't written
*/
var prefixesPageNumbers = (instruction) => (/* @__PURE__ */ new RegExp("^\\s*TOC\\b.*\\\\s\\b", "is")).test(instruction);
/**
* The result of a field that shows a page's number or a number of pages, or undefined to leave it as it is. A field
* the estimate has no number for is left as it is, or made blank, and so is a page number in a table of contents that
* writes a SEQ field's number before it.
*/
var resultFrom = (instruction, { enclosing, within, inTextBox }, { estimate, sectionPageCount, blank, relativeTo }) => {
	const field = numberFieldOf(instruction);
	if (field === void 0) return;
	const { bookmarks, pageCount, bookmarkPageNumbers } = estimate;
	const { numberFormat, picture, capitals, written } = field;
	const writesNumber = numberFormat !== void 0 || picture !== void 0;
	/** A number in the field's format of its own, or as it is */
	const inFormat = (value) => value === void 0 ? void 0 : picture === void 0 ? numberWriterOf(numberFormat !== null && numberFormat !== void 0 ? numberFormat : "arabic")(value) : inNumberPicture(value, picture);
	const position = field.type === "pageReference" && field.relative && within === "counted" && !inTextBox ? relativeTo === null || relativeTo === void 0 ? void 0 : relativeTo(field.bookmark) : void 0;
	let result;
	if (!written) result = void 0;
	else if (field.type === "pageCount") result = inFormat(field.scope === "document" ? pageCount : sectionPageCount);
	else if (enclosing.some(prefixesPageNumbers)) result = void 0;
	else if (writesNumber) result = inFormat(bookmarkPageNumbers === null || bookmarkPageNumbers === void 0 ? void 0 : bookmarkPageNumbers.get(field.bookmark));
	else result = field.relative ? position : bookmarks.get(field.bookmark);
	return result === void 0 ? blank ? "" : void 0 : inCapitals(result, capitals);
};
/** Where the content of an element is: in what an application that doesn't read Word's own shows, or in deleted text */
var placeIn = (name, within) => name === "mc:Fallback" || within === "fallback" ? "fallback" : name === "w:del" || name === "w:moveFrom" ? "deleted" : within;
/**
* Writes the results the filling works out into the fields in the elements, in order.
*/
var fillFields = (tree, elements, open, filling, within = "counted", inTextBox = false) => {
	for (let index = 0; index < elements.length; index++) {
		const element = elements[index];
		const name = tree.nameOf(element);
		if (name === void 0) continue;
		const current = open[open.length - 1];
		if (name === "w:fldChar") {
			const type = tree.attributeOf(element, "w:fldCharType");
			if (type === "begin") open.push({
				begin: element,
				instruction: "",
				inResult: false
			});
			else if (type === "separate" && current) {
				tree.writeClean(current.begin, current.instruction);
				current.inResult = true;
				current.result = filling.resultOf(current.instruction, {
					within,
					enclosing: open.slice(0, -1).map((field) => field.instruction),
					inTextBox
				});
				if (current.result !== void 0) {
					elements.splice(index + 1, 0, tree.textElement(current.result));
					index++;
				}
			} else if (type === "end") open.pop();
		} else if (name === "w:instrText" && current && !current.inResult) current.instruction += tree.textOf(element);
		else if ((name === "w:t" || name === "w:tab" || name === "w:br" || name === "w:cr") && (current === null || current === void 0 ? void 0 : current.result) !== void 0) {
			elements.splice(index, 1);
			index--;
		} else if (name === "w:fldSimple") {
			const result = filling.resultOf(String(tree.attributeOf(element, "w:instr")), {
				within,
				enclosing: open.map((field) => field.instruction),
				inTextBox
			});
			if (result === void 0) {
				var _tree$contentOf;
				fillFields(tree, (_tree$contentOf = tree.contentOf(element)) !== null && _tree$contentOf !== void 0 ? _tree$contentOf : [], [], filling, within, inTextBox);
			} else tree.setSimpleFieldResult(element, result);
		} else {
			var _tree$contentOf2;
			if (name === "w:p") {
				var _filling$beforeParagr;
				(_filling$beforeParagr = filling.beforeParagraph) === null || _filling$beforeParagr === void 0 || _filling$beforeParagr.call(filling, element);
			}
			fillFields(tree, (_tree$contentOf2 = tree.contentOf(element)) !== null && _tree$contentOf2 !== void 0 ? _tree$contentOf2 : [], open, filling, placeIn(name, within), inTextBox || name === "w:txbxContent");
			if (name === "w:p") filling.afterParagraph(element);
		}
	}
};
/** The section properties (`w:sectPr`) in the elements, in order: those of the paragraphs that end sections, and the last */
var sectionPropertiesIn = (tree, elements) => elements.flatMap((element) => {
	var _tree$contentOf3;
	const name = tree.nameOf(element);
	if (name === void 0) return [];
	return name === "w:sectPr" ? [element] : sectionPropertiesIn(tree, (_tree$contentOf3 = tree.contentOf(element)) !== null && _tree$contentOf3 !== void 0 ? _tree$contentOf3 : []);
});
/** Whether a paragraph ends a section: whether its properties have the section's */
var endsSection = (tree, paragraph) => {
	var _tree$contentOf4;
	return ((_tree$contentOf4 = tree.contentOf(paragraph)) !== null && _tree$contentOf4 !== void 0 ? _tree$contentOf4 : []).some((child) => {
		var _tree$contentOf5;
		return tree.nameOf(child) === "w:pPr" && ((_tree$contentOf5 = tree.contentOf(child)) !== null && _tree$contentOf5 !== void 0 ? _tree$contentOf5 : []).some((part) => tree.nameOf(part) === "w:sectPr");
	});
};
/**
* The number of pages each header and footer shows in its SECTIONPAGES fields, by the id of the relationship to it:
* that of the sections whose pages it is on, when they all have the same. A section without a header or footer of a kind
* has the one of the section before, as Word lays them out.
*/
var partPageCountsOf = (tree, body, sectionPageCounts) => {
	const countsOfParts = sectionPropertiesIn(tree, [body]).reduce((all, properties) => {
		var _tree$contentOf6, _all;
		const references = ((_tree$contentOf6 = tree.contentOf(properties)) !== null && _tree$contentOf6 !== void 0 ? _tree$contentOf6 : []).flatMap((child) => {
			const name = tree.nameOf(child);
			return name === "w:headerReference" || name === "w:footerReference" ? [[`${name} ${String(tree.attributeOf(child, "w:type"))}`, String(tree.attributeOf(child, "r:id"))]] : [];
		});
		return [...all, new Map([...(_all = all[all.length - 1]) !== null && _all !== void 0 ? _all : [], ...references])];
	}, []).reduce((counts, parts, section) => {
		for (const id of parts.values()) {
			var _counts$get;
			counts.set(id, [...(_counts$get = counts.get(id)) !== null && _counts$get !== void 0 ? _counts$get : [], sectionPageCounts[section]]);
		}
		return counts;
	}, /* @__PURE__ */ new Map());
	return new Map([...countsOfParts].flatMap(([id, [first, ...rest]]) => first !== void 0 && rest.every((count) => count === first) ? [[id, first]] : []));
};
/**
* Writes the estimated page numbers into the fields of a document's body that show them: its PAGEREF fields, in its
* tables of contents and elsewhere, and its NUMPAGES and SECTIONPAGES fields.
*
* @returns The number of pages each header and footer shows in its SECTIONPAGES fields, by the id of the relationship to it
*/
var fillBodyFields = (tree, body, estimate, { blank }) => {
	const { sectionPageCounts = [], relativePositions } = estimate;
	let section = 0;
	const relativeCounts = /* @__PURE__ */ new Map();
	const relativeTo = (bookmark) => {
		var _relativeCounts$get, _relativePositions$ge;
		const count = (_relativeCounts$get = relativeCounts.get(bookmark)) !== null && _relativeCounts$get !== void 0 ? _relativeCounts$get : 0;
		relativeCounts.set(bookmark, count + 1);
		return relativePositions === null || relativePositions === void 0 || (_relativePositions$ge = relativePositions.get(bookmark)) === null || _relativePositions$ge === void 0 ? void 0 : _relativePositions$ge[count];
	};
	fillFields(tree, [body], [], {
		resultOf: (instruction, place) => resultFrom(instruction, place, {
			estimate,
			sectionPageCount: sectionPageCounts[section],
			blank,
			relativeTo
		}),
		afterParagraph: (paragraph) => {
			section += endsSection(tree, paragraph) ? 1 : 0;
		}
	});
	return partPageCountsOf(tree, body, sectionPageCounts);
};
/**
* Writes the estimated page numbers into the fields of a header, footer, footnote or endnote that show them, with the
* number of pages its SECTIONPAGES fields show, if it is known. A page reference with `\p` in a footnote or endnote
* (`notes`) writes "on page" and its bookmark's page, whatever page it is on, as Word writes it
* (`word-page-fields.docx` PF8f, PF8g)
*/
var fillPartFields = (tree, part, estimate, { blank, sectionPageCount, notes = false }) => {
	const onPage = (bookmark) => {
		const page = estimate.bookmarks.get(bookmark);
		return page === void 0 ? void 0 : `on page ${page}`;
	};
	fillFields(tree, [part], [], {
		resultOf: (instruction, place) => resultFrom(instruction, place, _objectSpread2({
			estimate,
			sectionPageCount,
			blank
		}, notes ? { relativeTo: onPage } : {})),
		afterParagraph: () => void 0
	});
};
/** Writes the numbers of the SEQ fields of a document's body into them */
var fillSequenceFields = (tree, body, { beforeParagraph, resultOf }) => fillFields(tree, [body], [], {
	resultOf: (instruction, { within }) => resultOf(instruction, within),
	beforeParagraph,
	afterParagraph: () => void 0
});
/**
* Field Instruction module for Table of Contents.
*
* This module handles the generation of TOC field instruction text
* that controls how the table of contents is built.
*
* Reference: http://officeopenxml.com/WPfieldInstructions.php
*
* @module
*/
/**
* Represents a field instruction for a Table of Contents.
*
* The FieldInstruction class generates the TOC field code string that Word uses
* to determine how to build the table of contents, including which headings to include,
* formatting options, and other TOC-specific settings.
*
* Reference: http://officeopenxml.com/WPfieldInstructions.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="instrText" type="CT_Text"/>
* ```
*
* @example
* ```typescript
* // Basic TOC field instruction
* new FieldInstruction({ headingStyleRange: "1-3" });
*
* // TOC with hyperlinks and custom styles
* new FieldInstruction({
*   hyperlink: true,
*   headingStyleRange: "1-3",
*   stylesWithLevels: [new StyleLevel("CustomStyle", 2)],
* });
* ```
*/
var FieldInstruction = class extends XmlComponent {
	constructor(properties = {}) {
		super("w:instrText");
		_defineProperty(this, "properties", void 0);
		this.properties = properties;
		this.root.push(new TextAttributes({ space: SpaceType.PRESERVE }));
		let instruction = "TOC";
		if (this.properties.captionLabel) instruction = `${instruction} \\a "${this.properties.captionLabel}"`;
		if (this.properties.entriesFromBookmark) instruction = `${instruction} \\b "${this.properties.entriesFromBookmark}"`;
		if (this.properties.captionLabelIncludingNumbers) instruction = `${instruction} \\c "${this.properties.captionLabelIncludingNumbers}"`;
		if (this.properties.sequenceAndPageNumbersSeparator) instruction = `${instruction} \\d "${this.properties.sequenceAndPageNumbersSeparator}"`;
		if (this.properties.tcFieldIdentifier) instruction = `${instruction} \\f "${this.properties.tcFieldIdentifier}"`;
		if (this.properties.hyperlink) instruction = `${instruction} \\h`;
		if (this.properties.tcFieldLevelRange) instruction = `${instruction} \\l "${this.properties.tcFieldLevelRange}"`;
		if (this.properties.pageNumbersEntryLevelsRange) instruction = `${instruction} \\n "${this.properties.pageNumbersEntryLevelsRange}"`;
		if (this.properties.headingStyleRange) instruction = `${instruction} \\o "${this.properties.headingStyleRange}"`;
		if (this.properties.entryAndPageNumberSeparator) instruction = `${instruction} \\p "${this.properties.entryAndPageNumberSeparator}"`;
		if (this.properties.seqFieldIdentifierForPrefix) instruction = `${instruction} \\s "${this.properties.seqFieldIdentifierForPrefix}"`;
		if (this.properties.stylesWithLevels && this.properties.stylesWithLevels.length) {
			const styles = this.properties.stylesWithLevels.map((sl) => `${sl.styleName},${sl.level}`).join(",");
			instruction = `${instruction} \\t "${styles}"`;
		}
		if (this.properties.useAppliedParagraphOutlineLevel) instruction = `${instruction} \\u`;
		if (this.properties.preserveTabInEntries) instruction = `${instruction} \\w`;
		if (this.properties.preserveNewLineInEntries) instruction = `${instruction} \\x`;
		if (this.properties.hideTabAndPageNumbersInWebView) instruction = `${instruction} \\z`;
		this.root.push(instruction);
	}
};
/**
* Structured Document Tag Content module.
*
* This module represents the content container for structured document tags,
* including table of contents elements.
*
* Reference: http://officeopenxml.com/WPtableOfContents.php
*
* @module
*/
/**
* Represents the content portion of a Structured Document Tag.
*
* The StructuredDocumentTagContent contains the actual content elements
* (paragraphs, tables, etc.) within a structured document tag, such as
* the paragraphs that make up a table of contents.
*
* Reference: http://officeopenxml.com/WPtableOfContents.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SdtContentBlock">
*   <xsd:group ref="EG_ContentBlockContent" minOccurs="0" maxOccurs="unbounded"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const content = new StructuredDocumentTagContent();
* content.addChildElement(new Paragraph("Content"));
* ```
*/
var StructuredDocumentTagContent = class extends XmlComponent {
	constructor() {
		super("w:sdtContent");
	}
};
/**
* The beginning of a table of contents' field: dirty or clean, as the caller set it, or else dirty unless the document
* is given page numbers
*/
var beginOf = (beginDirty) => beginDirty === void 0 ? createBeginDirtyWithoutPageNumbers() : createBegin(beginDirty);
/** The formatted tables of contents, with what each is filled in with, or undefined when it was given its content */
var writtenTables = /* @__PURE__ */ new WeakMap();
/**
* The ids of the bookmarks on a body's headings: the first for its first bookmarked heading, and so on. Each is taken
* from the counter every bookmark shares, the first time it is needed, so a document packed again is written the same.
*/
var HeadingBookmarkIds = class {
	constructor() {
		_defineProperty(this, "ids", []);
	}
	get(index) {
		var _this$ids, _this$ids$index;
		(_this$ids$index = (_this$ids = this.ids)[index]) !== null && _this$ids$index !== void 0 || (_this$ids[index] = bookmarkUniqueNumericId());
		return this.ids[index];
	}
};
/** The name of a formatted element, or `_attr` for its parent's attributes */
var nameOf$4 = (element) => typeof element === "object" && element !== null ? Object.keys(element)[0] : void 0;
/** The children of a formatted element. An element with only attributes has them as its one child */
var childrenOf$1 = (element) => {
	const name = nameOf$4(element);
	const content = name === void 0 ? void 0 : element[name];
	return Array.isArray(content) ? content : content === void 0 ? [] : [content];
};
var childOf$2 = (element, name) => childrenOf$1(element).find((child) => nameOf$4(child) === name);
var attributeOf = (element, attribute) => {
	var _childOf;
	return (_childOf = childOf$2(element, "_attr")) === null || _childOf === void 0 || (_childOf = _childOf._attr) === null || _childOf === void 0 ? void 0 : _childOf[attribute];
};
/** An attribute such as `w:val="2"` as a number. Imported XML gives it as a string */
var numberAttributeOf = (element, attribute) => {
	const value = attributeOf(element, attribute);
	return value === void 0 ? void 0 : Number(value);
};
/** The block-level containers of paragraphs: tables, their rows and cells, and content controls */
var BLOCK_CONTAINERS = /* @__PURE__ */ new Set([
	"w:tbl",
	"w:tr",
	"w:tc",
	"w:sdt",
	"w:sdtContent",
	"w:customXml"
]);
/**
* The paragraphs and the tables of contents, in the order they are in the body. A table of contents isn't looked into,
* so the paragraphs in it aren't taken for headings. Nor are paragraphs in text boxes, as in Word.
*/
var blocksOf = (elements) => elements.flatMap((element) => {
	const name = nameOf$4(element);
	if (name === "w:p" || writtenTables.has(element)) return [element];
	return name !== void 0 && BLOCK_CONTAINERS.has(name) ? blocksOf(childrenOf$1(element)) : [];
});
/** The elements in a paragraph that its text is in. Deleted text, field instructions and drawings aren't */
var TEXT_CONTAINERS = /* @__PURE__ */ new Set([
	"w:r",
	"w:hyperlink",
	"w:ins",
	"w:moveTo",
	"w:smartTag",
	"w:customXml",
	"w:sdt",
	"w:sdtContent",
	"w:fldSimple",
	"w:dir",
	"w:bdo"
]);
/** The text an element in a run stands for, such as `\t` for a tab. A page or column break isn't text */
var textOfRunContent = (element) => {
	switch (nameOf$4(element)) {
		case "w:t": return childrenOf$1(element).filter((child) => typeof child === "string").join("");
		case "w:tab": return "	";
		case "w:br": return [void 0, "textWrapping"].includes(attributeOf(element, "w:type")) ? "\n" : "";
		case "w:cr": return "\n";
		case "w:noBreakHyphen": return "-";
		default: return "";
	}
};
/** The text of a paragraph. Of a field, only its result is text, not its instruction */
var textOf$1 = (paragraph) => {
	const fields = [];
	const read = (element) => {
		const name = nameOf$4(element);
		if (name !== void 0 && TEXT_CONTAINERS.has(name)) return childrenOf$1(element).map(read).join("");
		if (name === "w:fldChar") {
			const type = attributeOf(element, "w:fldCharType");
			if (type === "begin") fields.push(false);
			else if (type === "separate") fields[fields.length - 1] = true;
			else fields.pop();
			return "";
		}
		return fields.every(Boolean) ? textOfRunContent(element) : "";
	};
	return childrenOf$1(paragraph).map(read).join("");
};
/** The bookmarks started and ended in an element, in order */
var bookmarkMarksOf = (element) => {
	const name = nameOf$4(element);
	if (name === "w:bookmarkStart") return [{
		start: true,
		id: attributeOf(element, "w:id"),
		name: attributeOf(element, "w:name")
	}];
	if (name === "w:bookmarkEnd") return [{
		start: false,
		id: attributeOf(element, "w:id")
	}];
	return name === void 0 || name === "_attr" ? [] : childrenOf$1(element).flatMap(bookmarkMarksOf);
};
/**
* The names of the bookmarks each paragraph is in, for the `\b` switch: those open where it starts, followed through the
* body, and those that start in it.
*/
var bookmarksOf = (paragraphs) => {
	const open = /* @__PURE__ */ new Map();
	return paragraphs.map((paragraph) => {
		const marks = bookmarkMarksOf(paragraph);
		const names = /* @__PURE__ */ new Set([...open.values(), ...marks.flatMap((mark) => mark.start ? [mark.name] : [])]);
		for (const mark of marks) if (mark.start) open.set(mark.id, mark.name);
		else open.delete(mark.id);
		return names;
	});
};
/** The details of each paragraph that could be a heading. The bookmarks it is in are only followed when needed */
var paragraphDetailsOf = (paragraphs, followBookmarks) => {
	const bookmarks = followBookmarks ? bookmarksOf(paragraphs) : [];
	return paragraphs.map((element, index) => {
		var _bookmarks$index;
		const properties = childOf$2(element, "w:pPr");
		return {
			element,
			styleId: attributeOf(childOf$2(properties, "w:pStyle"), "w:val"),
			outlineLevel: numberAttributeOf(childOf$2(properties, "w:outlineLvl"), "w:val"),
			text: textOf$1(element),
			bookmarks: (_bookmarks$index = bookmarks[index]) !== null && _bookmarks$index !== void 0 ? _bookmarks$index : /* @__PURE__ */ new Set()
		};
	});
};
/** The document's paragraph styles, by id, read from the styles as they are written */
var stylesOf = (context) => {
	var _context$file;
	const styles = (_context$file = context.file) === null || _context$file === void 0 || (_context$file = _context$file.Styles) === null || _context$file === void 0 ? void 0 : _context$file.prepForXml(context);
	return new Map(childrenOf$1(styles).filter((style) => nameOf$4(style) === "w:style" && ["paragraph", void 0].includes(attributeOf(style, "w:type"))).map((style) => [attributeOf(style, "w:styleId"), {
		name: attributeOf(childOf$2(style, "w:name"), "w:val"),
		basedOn: attributeOf(childOf$2(style, "w:basedOn"), "w:val"),
		outlineLevel: numberAttributeOf(childOf$2(childOf$2(style, "w:pPr"), "w:outlineLvl"), "w:val")
	}]));
};
/** A range such as `1-3` */
var parseRange = (range) => {
	const match = /^\s*(\d+)\s*-\s*(\d+)\s*$/.exec(range);
	return match ? [Number(match[1]), Number(match[2])] : void 0;
};
var isWithin = (level, [from, to]) => level >= from && level <= to;
/** The level of a built-in heading style, Heading 1 to Heading 9, by its name, or by its id when it has no name */
var headingLevelOf = (styleId, styles) => {
	var _styles$get$name, _styles$get;
	if (styleId === void 0) return;
	const match = /^heading ?([1-9])$/i.exec((_styles$get$name = (_styles$get = styles.get(styleId)) === null || _styles$get === void 0 ? void 0 : _styles$get.name) !== null && _styles$get$name !== void 0 ? _styles$get$name : styleId);
	return match ? Number(match[1]) : void 0;
};
/**
* A style's outline level, from 0: its own, or else the one of the style it is based on. A built-in heading style has
* its heading's. Following the styles it is based on stops after as many as there are, in case they loop.
*/
var styleOutlineLevelOf = (styleId, styles, depth = 0) => {
	var _style$outlineLevel;
	if (styleId === void 0 || depth > styles.size) return;
	const style = styles.get(styleId);
	const heading = headingLevelOf(styleId, styles);
	return (_style$outlineLevel = style === null || style === void 0 ? void 0 : style.outlineLevel) !== null && _style$outlineLevel !== void 0 ? _style$outlineLevel : heading === void 0 ? styleOutlineLevelOf(style === null || style === void 0 ? void 0 : style.basedOn, styles, depth + 1) : heading - 1;
};
/**
* Reads the heading level of the document's paragraphs, as the `\s` switch of a SEQ field follows it: the level of a
* paragraph in a built-in heading style, Heading 1 to Heading 9. A paragraph whose outline level is another, or that has
* one without a heading style, is `"unclear"`, as which of the two Word follows hasn't been checked. Other paragraphs
* are undefined.
*/
var headingLevels = (context) => {
	const styles = stylesOf(context);
	return (paragraph) => {
		const properties = childOf$2(paragraph, "w:pPr");
		const styleId = attributeOf(childOf$2(properties, "w:pStyle"), "w:val");
		const heading = headingLevelOf(styleId, styles);
		const outlineLevel = outlineLevelOf({
			styleId,
			outlineLevel: numberAttributeOf(childOf$2(properties, "w:outlineLvl"), "w:val")
		}, styles);
		const outline = outlineLevel === void 0 || outlineLevel >= 9 ? void 0 : outlineLevel + 1;
		if (heading !== void 0 && (outline === void 0 || outline === heading)) return heading;
		return outline === void 0 ? void 0 : "unclear";
	};
};
/** A paragraph's outline level, from 0: its own, or else its style's */
var outlineLevelOf = (paragraph, styles) => {
	var _paragraph$outlineLev;
	return (_paragraph$outlineLev = paragraph.outlineLevel) !== null && _paragraph$outlineLev !== void 0 ? _paragraph$outlineLev : styleOutlineLevelOf(paragraph.styleId, styles);
};
/** The level a table of contents gives a paragraph, or undefined when it doesn't include it */
var levelIn = (properties, paragraph, styles) => {
	var _styles$get2;
	const { entriesFromBookmark, headingStyleRange, stylesWithLevels = [], useAppliedParagraphOutlineLevel } = properties;
	if (paragraph.text.trim() === "" || entriesFromBookmark && !paragraph.bookmarks.has(entriesFromBookmark)) return;
	const names = [paragraph.styleId, paragraph.styleId === void 0 ? void 0 : (_styles$get2 = styles.get(paragraph.styleId)) === null || _styles$get2 === void 0 ? void 0 : _styles$get2.name].filter((name) => name !== void 0).map((name) => name.toLowerCase());
	const listed = stylesWithLevels.find((style) => names.includes(style.styleName.toLowerCase()));
	if (listed) return listed.level;
	const namesItsEntries = Boolean(headingStyleRange) || stylesWithLevels.length > 0 || Boolean(useAppliedParagraphOutlineLevel) || Boolean(properties.tcFieldIdentifier) || Boolean(properties.tcFieldLevelRange) || Boolean(properties.captionLabel) || Boolean(properties.captionLabelIncludingNumbers);
	const headingRange = headingStyleRange ? parseRange(headingStyleRange) : namesItsEntries ? void 0 : [1, 9];
	const heading = headingLevelOf(paragraph.styleId, styles);
	if (headingRange && heading !== void 0 && isWithin(heading, headingRange)) return heading;
	const outlineLevel = useAppliedParagraphOutlineLevel ? outlineLevelOf(paragraph, styles) : void 0;
	return outlineLevel !== void 0 && isWithin(outlineLevel + 1, headingRange !== null && headingRange !== void 0 ? headingRange : [1, 9]) ? outlineLevel + 1 : void 0;
};
/** The runs of an entry's title. Tabs and line breaks are kept only when the table of contents keeps them (\w and \x) */
var titleRunsOf = (title, properties) => {
	const text = properties.preserveTabInEntries ? title : title.replace(/\t/g, " ");
	return (properties.preserveNewLineInEntries ? text.split("\n") : [text.replace(/\n/g, " ")]).map((line, index) => new TextRun({
		break: index > 0 ? 1 : void 0,
		children: line.split("	").flatMap((part, partIndex) => [...partIndex > 0 ? [new Tab()] : [], ...part === "" ? [] : [part]])
	}));
};
/**
* The runs of a heading's list number at the start of its entry: the number and a tab, or the number and a space, which
* Word writes after a number its list follows with a space or with nothing
*/
var numberRunsOf = ({ text, separator }) => separator === "tab" ? [new TextRun(text), new TextRun({ children: [new Tab()] })] : [new TextRun(`${text} `)];
/**
* The left tab stop after a heading's number in its entry, as Word places it, in twips: past the number, as wide as Word
* measures it, by 240 twips, and 240 more for each level of the table below the first, at the next multiple of 240 up to
* 1920, and where it falls past that. Word goes by its Normal template's 12 points here, not the document's font, size or
* indents (`scripts/layout-probes/word-toc-numbers.ts`)
*/
var numberTabStopOf = (level, width) => {
	const end = 240 * (level - 1) + width + 240;
	return end <= 1920 ? Math.ceil(end / 240) * 240 : Math.round(end);
};
/**
* The paragraph style of the entries at a level: the built-in TOC style, found by its name, "toc 1" to "toc 9", such as
* a template's in another language, or else docx's own, `TOC1` to `TOC9`, which indent the levels as Word's do.
*/
var entryStyleOf = (level, styles) => {
	var _find$, _find;
	return (_find$ = (_find = [...styles].find(([, style]) => {
		var _style$name;
		return ((_style$name = style.name) === null || _style$name === void 0 ? void 0 : _style$name.toLowerCase()) === `toc ${level}`;
	})) === null || _find === void 0 ? void 0 : _find[0]) !== null && _find$ !== void 0 ? _find$ : `TOC${level}`;
};
/** The formatted content of a table of contents with its entries */
var contentOf = ({ properties, beginDirty, textWidth, tabLeader }, entries, styles, context) => {
	var _parseRange;
	const withoutPageNumbers = properties.pageNumbersEntryLevelsRange ? (_parseRange = parseRange(properties.pageNumbersEntryLevelsRange)) !== null && _parseRange !== void 0 ? _parseRange : [1, 9] : void 0;
	const content = new StructuredDocumentTagContent();
	entries.forEach((entry, index) => {
		var _entry$listNumber;
		const hasPageNumber = withoutPageNumbers === void 0 || !isWithin(entry.level, withoutPageNumbers);
		const children = [
			...entry.listNumber ? numberRunsOf(entry.listNumber) : [],
			...titleRunsOf(entry.title, properties),
			...hasPageNumber ? [new TextRun({ children: [properties.entryAndPageNumberSeparator || new Tab()] }), new PageReference(entry.bookmark, { hyperlink: properties.hyperlink })] : []
		];
		content.addChildElement(new Paragraph({
			style: entryStyleOf(entry.level, styles),
			tabStops: [...((_entry$listNumber = entry.listNumber) === null || _entry$listNumber === void 0 ? void 0 : _entry$listNumber.separator) === "tab" ? [{
				type: "left",
				position: numberTabStopOf(entry.level, entry.listNumber.width)
			}] : [], {
				type: "right",
				position: textWidth,
				leader: tabLeader
			}],
			children: [...index === 0 ? [new Run({ children: [
				beginOf(beginDirty),
				new FieldInstruction(properties),
				createSeparate()
			] })] : [], ...properties.hyperlink ? [new InternalHyperlink({
				anchor: entry.bookmark,
				children
			})] : children]
		}));
	});
	content.addChildElement(new Paragraph({ children: [new Run({ children: [createEnd()] })] }));
	return content.prepForXml(context);
};
/** Puts a bookmark around the content of a formatted paragraph */
var bookmark = (paragraph, name, id, context) => {
	const children = childrenOf$1(paragraph);
	const start = children.findIndex((child) => nameOf$4(child) === "w:pPr") + 1;
	paragraph["w:p"] = [
		...children.slice(0, start),
		new BookmarkStart(name, id).prepForXml(context),
		...children.slice(start),
		new BookmarkEnd(id).prepForXml(context)
	];
};
/**
* Fills in the tables of contents in a formatted body from its headings, and bookmarks the headings they list. A
* table of contents that doesn't list any heading is left empty, for Word to fill in. Given how to work out the headings'
* list numbers, the entry of a numbered heading starts with its number, once the headings are bookmarked.
*/
var fillTablesOfContents = (body, context, bookmarkIds, listNumbersOf) => {
	const blocks = blocksOf(childrenOf$1(body));
	const tables = blocks.flatMap((block) => {
		const options = writtenTables.get(block);
		return options ? [[block, options]] : [];
	});
	if (tables.length === 0) return;
	const styles = stylesOf(context);
	const followBookmarks = tables.some(([, { properties }]) => Boolean(properties.entriesFromBookmark));
	const headings = paragraphDetailsOf(blocks.filter((block) => nameOf$4(block) === "w:p"), followBookmarks).map((paragraph) => ({
		paragraph,
		levels: tables.map(([, { properties }]) => levelIn(properties, paragraph, styles))
	})).filter(({ levels }) => levels.some((level) => level !== void 0)).map((heading, index) => _objectSpread2(_objectSpread2({}, heading), {}, { id: bookmarkIds.get(index) }));
	for (const { paragraph, id } of headings) bookmark(paragraph.element, `_Toc${id}`, id, context);
	const listNumbers = headings.length > 0 ? listNumbersOf === null || listNumbersOf === void 0 ? void 0 : listNumbersOf(body) : void 0;
	tables.forEach(([table, options], index) => {
		const entries = headings.flatMap(({ paragraph, levels, id }) => {
			const level = levels[index];
			const listNumber = listNumbers === null || listNumbers === void 0 ? void 0 : listNumbers.get(`_Toc${id}`);
			return level === void 0 ? [] : [_objectSpread2({
				title: paragraph.text,
				level,
				bookmark: `_Toc${id}`
			}, listNumber ? { listNumber } : {})];
		});
		if (entries.length === 0) return;
		table["w:sdt"] = childrenOf$1(table).map((child) => nameOf$4(child) === "w:sdtContent" ? contentOf(options, entries, styles, context) : child);
	});
};
/**
* Caption numbers written into the SEQ fields of a document, such as the 2 of "Figure 2", when the document is given page
* numbers.
*
* A SEQ field (`SequentialIdentifier`) shows how many SEQ fields of its identifier, such as "Figure", there are up to and
* including it, so the number doesn't depend on how the pages are laid out. Its switches change the count: `\r 5` starts
* it again from 5, `\c` repeats the number of the one before, `\s 1` starts it again after each Heading 1, `\h` hides the
* number, and `\* ROMAN` writes it in roman numerals. `docx` writes SEQ fields dirty, for Word to number when it opens the
* document, which makes Word ask to update the fields. When the document is given page numbers, each is written clean
* with its number, counted as Word counts it. What Word does was read from its PDF of `scripts/layout-probes/word-seq.ts`.
*
* Word counts the SEQ fields of the body, those in text boxes and hidden text too, in order, and counts an identifier in
* any capitals, or in quotes, as the same one. It writes the SEQ fields of headers, footers, footnotes and endnotes as an
* error, "Error! Main Document Only.", and doesn't count them with the body's.
*
* Where Word's count isn't known, the field is left blank rather than given a number that could be wrong: a switch it
* doesn't follow, a SEQ field in deleted text, and every SEQ field of an identifier that also has SEQ fields in a comment.
* The fields of its identifier after one whose number isn't known are left blank too, until one starts the count again
* with `\r`. A number in a format not followed is left blank, but the count goes on.
*
* @module
*/
var IDENTIFIER = /* @__PURE__ */ new RegExp("^\\p{L}[\\p{L}\\p{N}_]*$", "u");
/** Reads the switches of a SEQ field, and a bookmark before them, or undefined when one of them isn't followed */
var sequenceOf = (switches) => {
	var _step, _format;
	let step;
	let hidden = false;
	let format;
	let caseFormat = false;
	let picture = false;
	for (let index = 0; index < switches.length; index++) {
		var _switches, _next;
		const name = switches[index];
		const argument = (_switches = switches[index + 1]) !== null && _switches !== void 0 ? _switches : "";
		let next;
		if (index === 0 && !name.startsWith("\\")) next = { type: "bookmark" };
		else if (name === "\\c" || name === "\\n") next = { type: name === "\\c" ? "repeat" : "next" };
		else if ((name === "\\r" || name === "\\s") && /^\d+$/.test(argument)) {
			index++;
			next = name === "\\r" ? {
				type: "reset",
				to: Number(argument)
			} : {
				type: "heading",
				level: Number(argument)
			};
		} else if (name === "\\h") hidden = true;
		else if (name === "\\#" && index + 1 < switches.length) {
			index++;
			picture = true;
		} else if (name === "\\*" && index + 1 < switches.length) {
			const value = switches[++index];
			if (CASE_FORMATS.has(value.toLowerCase())) caseFormat = true;
			else if (!PLAIN_FORMATS.has(value.toLowerCase())) {
				if (format !== void 0) return;
				format = value;
			}
		} else return;
		if (next && step) return;
		step = (_next = next) !== null && _next !== void 0 ? _next : step;
	}
	if ((step === null || step === void 0 ? void 0 : step.type) === "bookmark" && switches.length > 1) return;
	const written = !picture && !(caseFormat && format !== void 0 && format.toLowerCase() !== "arabic");
	return {
		step: (_step = step) !== null && _step !== void 0 ? _step : { type: "next" },
		hidden: hidden && format === void 0,
		format: written ? (_format = format) !== null && _format !== void 0 ? _format : "ARABIC" : ""
	};
};
/** Reads a SEQ field's instruction, or undefined when the field isn't a SEQ field */
var sequenceFieldOf = (instruction) => {
	var _match$1$match;
	const match = (/* @__PURE__ */ new RegExp("^\\s*SEQ\\b(.*)$", "is")).exec(instruction);
	if (!match) return;
	const [written, ...switches] = (_match$1$match = match[1].match(/"[^"]*"|\S+/g)) !== null && _match$1$match !== void 0 ? _match$1$match : [];
	if (written === void 0) return {};
	const identifier = written.replace(/^"(.*)"$/, "$1");
	return IDENTIFIER.test(identifier) ? {
		identifier,
		sequence: sequenceOf(switches)
	} : { identifier };
};
/** Whether a field's instruction is that of a SEQ field */
var isSequenceField = (instruction) => sequenceFieldOf(instruction) !== void 0;
/** The identifier, in small letters, of each SEQ field in the formatted elements */
var identifiersIn = (element) => {
	if (typeof element !== "object" || element === null) return [];
	if (Array.isArray(element)) return element.flatMap(identifiersIn);
	return Object.entries(element).flatMap(([name, content]) => {
		return [...(name === "w:instrText" && Array.isArray(content) ? content : name === "_attr" ? [content["w:instr"]] : []).flatMap((instruction) => {
			const field = typeof instruction === "string" ? sequenceFieldOf(instruction) : void 0;
			return (field === null || field === void 0 ? void 0 : field.identifier) === void 0 ? [] : [field.identifier.toLowerCase()];
		}), ...identifiersIn(content)];
	});
};
/** The identifiers, in small letters, of the SEQ fields in the document's comments, whose count in Word isn't known */
var identifiersInCommentsOf = (context) => {
	var _context$file;
	const comments = (_context$file = context.file) === null || _context$file === void 0 ? void 0 : _context$file.Comments;
	if (!comments) return /* @__PURE__ */ new Set();
	const wrapper = {
		View: comments,
		Relationships: comments.Relationships
	};
	return new Set(identifiersIn(comments.prepForXml(_objectSpread2(_objectSpread2({}, context), {}, {
		viewWrapper: wrapper,
		stack: []
	}))));
};
/** Counts the SEQ fields of a document's body, in order, as Word counts them */
var sequenceNumbering = (context) => {
	const levelOf = headingLevels(context);
	const numbers = /* @__PURE__ */ new Map();
	const counted = /* @__PURE__ */ new Map();
	const headingsAt = [];
	let unclearAt = -1;
	let paragraph = -1;
	let unknown;
	/**
	* The number of a field that starts the count again after headings of a level or a higher one (`\s`): the number of
	* fields of its identifier since the last of them, with it, as Word counts them. It isn't known when a paragraph
	* whose level isn't clear came after that heading, or a field since it whose number didn't follow as the next one's
	*/
	const afterHeading = (key, level) => {
		var _counted$get;
		const headingAt = Math.max(-1, ...headingsAt.slice(1, level + 1).filter((at) => at !== void 0));
		const since = ((_counted$get = counted.get(key)) !== null && _counted$get !== void 0 ? _counted$get : []).filter((field) => field.paragraph >= headingAt);
		const followed = since.every(({ step }) => (step === null || step === void 0 ? void 0 : step.type) === "next" || (step === null || step === void 0 ? void 0 : step.type) === "heading" && step.level === level);
		return unclearAt > headingAt || !followed ? void 0 : since.length + 1;
	};
	return {
		startParagraph: (element) => {
			paragraph++;
			const level = levelOf(element);
			if (level === "unclear") unclearAt = paragraph;
			else if (level !== void 0) headingsAt[level] = paragraph;
		},
		numberOf: (instruction, place) => {
			var _unknown, _counted$get2, _numberWriterOf;
			const { identifier, sequence } = sequenceFieldOf(instruction);
			if (identifier === void 0 || place === "fallback") return;
			(_unknown = unknown) !== null && _unknown !== void 0 || (unknown = identifiersInCommentsOf(context));
			const key = identifier.toLowerCase();
			if ((sequence === null || sequence === void 0 ? void 0 : sequence.step.type) === "bookmark" && place === "counted" && !unknown.has(key)) return;
			const before = numbers.has(key) ? numbers.get(key) : 0;
			const step = unknown.has(key) || place === "deleted" ? void 0 : sequence === null || sequence === void 0 ? void 0 : sequence.step;
			const value = (step === null || step === void 0 ? void 0 : step.type) === "reset" ? step.to : (step === null || step === void 0 ? void 0 : step.type) === "repeat" ? before : (step === null || step === void 0 ? void 0 : step.type) === "heading" ? afterHeading(key, step.level) : (step === null || step === void 0 ? void 0 : step.type) === "next" && before !== void 0 ? before + 1 : void 0;
			numbers.set(key, value);
			counted.set(key, [...(_counted$get2 = counted.get(key)) !== null && _counted$get2 !== void 0 ? _counted$get2 : [], _objectSpread2({ paragraph }, value === void 0 ? {} : { step })]);
			return value === void 0 || sequence === void 0 ? void 0 : sequence.hidden ? "" : (_numberWriterOf = numberWriterOf(sequence.format)) === null || _numberWriterOf === void 0 ? void 0 : _numberWriterOf(value);
		}
	};
};
/**
* Page numbers written into the fields of a document that show them, when it is written, from an estimate of its pages.
*
* A page reference is a PAGEREF field, such as the page number of an entry in a table of contents, and the numbers of
* pages of the document and of a section are NUMPAGES and SECTIONPAGES fields. Word works their results out when it
* updates the fields, or lays the pages out, and until then, and in applications that don't, the fields show the results
* they were written with. `docx` doesn't lay out pages, so it writes the results empty, unless the document is given a
* {@link PageNumberEstimator}, such as `estimatePageNumbers` from `docx/layout`. Then, once the body is written, each of
* those fields in the body, and then in the headers and footers, is given the number the estimator worked out.
*
* Page references and tables of contents are written dirty, so Word updates them when it opens the document, and asks
* "This document contains fields that may refer to other files. Do you want to update the fields in this document?".
* When the document is given page numbers, they are written clean, so Word shows them as they are and doesn't ask. A
* page number the estimator didn't work out is left blank, until the fields are updated. So are SEQ fields, the numbers
* of captions, which are given their numbers then too.
*
* @module
*/
var nameOf$3 = (element) => {
	const name = typeof element === "object" && element !== null && !Array.isArray(element) ? Object.keys(element)[0] : void 0;
	return name === "_attr" ? void 0 : name;
};
var textElement = (text) => ({ "w:t": [{ _attr: { "xml:space": "preserve" } }, text] });
/** The elements docx formats to write a document */
var FORMATTED = {
	nameOf: nameOf$3,
	contentOf: (element) => {
		const content = element[nameOf$3(element)];
		return Array.isArray(content) ? content : void 0;
	},
	attributeOf: (element, attribute) => {
		var _holder$_attr;
		const content = element[nameOf$3(element)];
		const holder = Array.isArray(content) ? content.find((child) => typeof child === "object" && child !== null && "_attr" in child) : content;
		return holder === null || holder === void 0 || (_holder$_attr = holder._attr) === null || _holder$_attr === void 0 ? void 0 : _holder$_attr[attribute];
	},
	textOf: (element) => FORMATTED.contentOf(element).filter((part) => typeof part === "string").join(""),
	textElement,
	writeClean: (begin) => {
		if (isDirtyWithoutPageNumbers(begin)) {
			const attributes = begin["w:fldChar"]._attr;
			begin["w:fldChar"] = { _attr: Object.fromEntries(Object.entries(attributes).filter(([key]) => key !== "w:dirty")) };
		}
	},
	setSimpleFieldResult: (element, text) => {
		const content = element["w:fldSimple"];
		element["w:fldSimple"] = [...(Array.isArray(content) ? content : [content]).filter((child) => typeof child === "object" && child !== null && "_attr" in child), { "w:r": [textElement(text)] }];
	}
};
/** The estimate of each document's pages, and the numbers of pages its headers and footers show, once its body is written */
var estimates = /* @__PURE__ */ new WeakMap();
/**
* Writes the numbers of the SEQ fields of a formatted body into them, counted as Word counts them (see
* {@link sequenceNumbering}), and writes them clean, whether or not their numbers were worked out. It is done after its
* tables of contents are filled in from its headings, as Word leaves a heading's SEQ number out of its entry.
*/
var fillSequenceNumbers = (body, context) => {
	const { startParagraph, numberOf } = sequenceNumbering(context);
	fillSequenceFields(FORMATTED, body, {
		beforeParagraph: (paragraph) => startParagraph(paragraph),
		resultOf: (instruction, within) => isSequenceField(instruction) ? numberOf(instruction, within) : void 0
	});
};
/**
* Writes the page numbers the estimator works out into the fields of a formatted body that show them: the PAGEREF fields
* in its tables of contents and elsewhere, those with `\p` and in number formats of their own, and its NUMPAGES and
* SECTIONPAGES fields. A field whose number the estimator didn't work out is left as it is. Page references and tables
* of contents are written clean, whether or not their numbers were worked out. The estimate is kept for the document's
* headers and footers.
*/
var fillPageNumbers = (body, context, estimator) => {
	const estimate = estimator(body, context);
	const partPageCounts = fillBodyFields(FORMATTED, body, estimate, { blank: false });
	if (context.file) estimates.set(context.file, {
		estimate,
		partPageCounts
	});
};
/**
* Writes the page numbers worked out for the document a header, footer, footnote, endnote or comment is in into the
* fields of the formatted part that show them, once the document's body is written. Its page references and SEQ fields
* are written clean, and its SEQ fields are left blank: Word writes them as an error, "Error! Main Document Only.".
*
* @param part - The formatted part, if it has anything to write
* @param context - The context it was formatted in, with the document it is in
* @param referenceId - The number of the relationship to a header or footer. The SECTIONPAGES fields of the other parts
* are left as they are
*/
var fillPartPageNumbers = (part, context, referenceId) => {
	const written = context.file && estimates.get(context.file);
	if (!part || !written) return;
	const sectionPageCount = referenceId === void 0 ? void 0 : written.partPageCounts.get(`rId${referenceId}`);
	const notes = "w:footnotes" in part || "w:endnotes" in part;
	fillPartFields(FORMATTED, part, written.estimate, {
		blank: false,
		sectionPageCount,
		notes
	});
};
/**
* Attributes for the Relationships element.
*
* Defines the XML namespace for the relationships part.
*
* @example
* ```typescript
* new RelationshipsAttributes({
*   xmlns: "http://schemas.openxmlformats.org/package/2006/relationships"
* });
* ```
*/
var RelationshipsAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { xmlns: "xmlns" });
	}
};
/**
* Relationships module for Open Packaging Conventions.
*
* This module provides support for managing relationships between
* parts in an OPC package (DOCX file).
*
* Reference: http://officeopenxml.com/anatomyofOOXML.php
*
* @module
*/
/**
* Represents a collection of relationships in an OPC package.
*
* Relationships define connections between package parts, such as
* linking the main document to its headers, footers, images, etc.
*
* Reference: http://officeopenxml.com/anatomyofOOXML.php
*
* @example
* ```typescript
* const relationships = new Relationships();
* relationships.addRelationship(
*   1,
*   "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
*   "media/image1.png"
* );
* ```
*/
var Relationships = class Relationships extends XmlComponent {
	constructor() {
		super("Relationships");
		this.root.push(new RelationshipsAttributes({ xmlns: "http://schemas.openxmlformats.org/package/2006/relationships" }));
	}
	/**
	* Creates a new relationship to another part in the package.
	*
	* @param id - Unique identifier for this relationship (will be prefixed with "rId")
	* @param type - Relationship type URI (e.g., image, header, hyperlink)
	* @param target - Path to the target part
	* @param targetMode - Optional mode indicating if target is external
	*/
	addRelationship(id, type, target, targetMode) {
		this.root.push(createRelationship(`rId${id}`, type, target, targetMode));
	}
	/**
	* Creates a copy of the relationships given. Relationships added to the copy aren't added to them, so the compiler
	* adds the ones it writes for a part, such as to its images, to a copy, and packing a document again doesn't add
	* them a second time.
	*
	* Static, as `IContext` is public and has `Relationships`, so a new instance member would change the public API.
	*
	* @param relationships - The relationships to copy
	*/
	static copy(relationships) {
		const copy = new Relationships();
		copy.root.push(...relationships.root.slice(1));
		return copy;
	}
	/**
	* Gets the count of relationships in this collection.
	* Excludes the attributes element from the count.
	*/
	get RelationshipCount() {
		return this.root.length - 1;
	}
};
/**
* Comment module for WordprocessingML documents.
*
* This module provides support for comments (annotations) in documents. Comments
* consist of comment ranges (start/end markers), comment references, and the
* actual comment content.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @module
*/
/**
* @internal
*/
var CommentAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			id: "w:id",
			initials: "w:initials",
			author: "w:author",
			date: "w:date"
		});
	}
};
/**
* @internal
*/
var RootCommentsAttributes = class extends XmlAttributeComponent {
	constructor(..._args3) {
		super(..._args3);
		_defineProperty(this, "xmlKeys", {
			"xmlns:wpc": "xmlns:wpc",
			"xmlns:cx": "xmlns:cx",
			"xmlns:cx1": "xmlns:cx1",
			"xmlns:cx2": "xmlns:cx2",
			"xmlns:cx3": "xmlns:cx3",
			"xmlns:cx4": "xmlns:cx4",
			"xmlns:cx5": "xmlns:cx5",
			"xmlns:cx6": "xmlns:cx6",
			"xmlns:cx7": "xmlns:cx7",
			"xmlns:cx8": "xmlns:cx8",
			"xmlns:mc": "xmlns:mc",
			"xmlns:aink": "xmlns:aink",
			"xmlns:am3d": "xmlns:am3d",
			"xmlns:o": "xmlns:o",
			"xmlns:r": "xmlns:r",
			"xmlns:m": "xmlns:m",
			"xmlns:v": "xmlns:v",
			"xmlns:wp14": "xmlns:wp14",
			"xmlns:wp": "xmlns:wp",
			"xmlns:w10": "xmlns:w10",
			"xmlns:w": "xmlns:w",
			"xmlns:w14": "xmlns:w14",
			"xmlns:w15": "xmlns:w15",
			"xmlns:w16cex": "xmlns:w16cex",
			"xmlns:w16cid": "xmlns:w16cid",
			"xmlns:w16": "xmlns:w16",
			"xmlns:w16sdtdh": "xmlns:w16sdtdh",
			"xmlns:w16se": "xmlns:w16se",
			"xmlns:wpg": "xmlns:wpg",
			"xmlns:wpi": "xmlns:wpi",
			"xmlns:wne": "xmlns:wne",
			"xmlns:wps": "xmlns:wps",
			"mc:Ignorable": "mc:Ignorable"
		});
	}
};
/**
* Represents a single comment in a WordprocessingML document.
*
* Contains the actual content of a comment, including author information
* and the comment text (typically paragraphs).
*
* Reference: http://officeopenxml.com/WPrun.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Comment">
*   <xsd:sequence>
*     <xsd:group ref="EG_BlockLevelElts" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="initials" type="s:ST_String"/>
*   <xsd:attribute name="author" type="s:ST_String"/>
*   <xsd:attribute name="date" type="s:ST_DateTime"/>
*   <xsd:attribute name="id" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Comment({
*   id: 0,
*   author: "John Doe",
*   initials: "JD",
*   children: [new Paragraph("This is a comment")],
* });
* ```
*/
var Comment = class extends XmlComponent {
	constructor({ id, initials, author, date = /* @__PURE__ */ new Date(), children }, paraId) {
		super("w:comment");
		_defineProperty(this, "paraId", void 0);
		this.paraId = paraId;
		this.root.push(new CommentAttributes({
			id,
			initials,
			author,
			date: date.toISOString()
		}));
		for (const child of children) this.root.push(child);
	}
	/**
	* Serializes this comment to XML, injecting w14:paraId and w14:textId into the last
	* paragraph when threading is active. These attributes link the comment to its
	* corresponding w15:commentEx entry in commentsExtended.xml.
	*/
	prepForXml(context) {
		const result = super.prepForXml(context);
		if (!result || !this.paraId) return result;
		const commentChildren = result["w:comment"];
		if (!Array.isArray(commentChildren)) return result;
		for (let i = commentChildren.length - 1; i >= 0; i--) {
			const child = commentChildren[i];
			if (child && typeof child === "object" && "w:p" in child) {
				const pChildren = child["w:p"];
				if (Array.isArray(pChildren)) pChildren.unshift({ _attr: {
					"w14:paraId": this.paraId,
					"w14:textId": this.paraId
				} });
				break;
			}
		}
		return result;
	}
};
/**
* Converts a comment ID to a deterministic 8-character uppercase hex paraId.
*/
var commentIdToParaId = (id) => (id + 1).toString(16).toUpperCase().padStart(8, "0");
/**
* Represents the comments container in a WordprocessingML document.
*
* This is the root element for the comments.xml file that stores all
* comment definitions in the document. When any comment uses `parentId`,
* threading is activated and thread data is generated for commentsExtended.xml.
*
* Reference: http://officeopenxml.com/WPrun.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="comments" type="CT_Comments"/>
* <xsd:complexType name="CT_Comments">
*   <xsd:sequence>
*     <xsd:element name="comment" type="CT_Comment" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Comments({
*   children: [
*     {
*       id: 0,
*       author: "John Doe",
*       children: [new Paragraph("First comment")],
*     },
*     {
*       id: 1,
*       author: "Jane Smith",
*       parentId: 0,
*       children: [new Paragraph("Reply to first comment")],
*     },
*   ],
* });
* ```
*/
var Comments = class extends XmlComponent {
	constructor({ children }) {
		super("w:comments");
		_defineProperty(this, "relationships", void 0);
		_defineProperty(this, "threadData", void 0);
		_defineProperty(this, "commentIdsData", void 0);
		_defineProperty(this, "isEmpty", void 0);
		this.isEmpty = children.length === 0;
		this.root.push(new RootCommentsAttributes({
			"xmlns:wpc": "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
			"xmlns:cx": "http://schemas.microsoft.com/office/drawing/2014/chartex",
			"xmlns:cx1": "http://schemas.microsoft.com/office/drawing/2015/9/8/chartex",
			"xmlns:cx2": "http://schemas.microsoft.com/office/drawing/2015/10/21/chartex",
			"xmlns:cx3": "http://schemas.microsoft.com/office/drawing/2016/5/9/chartex",
			"xmlns:cx4": "http://schemas.microsoft.com/office/drawing/2016/5/10/chartex",
			"xmlns:cx5": "http://schemas.microsoft.com/office/drawing/2016/5/11/chartex",
			"xmlns:cx6": "http://schemas.microsoft.com/office/drawing/2016/5/12/chartex",
			"xmlns:cx7": "http://schemas.microsoft.com/office/drawing/2016/5/13/chartex",
			"xmlns:cx8": "http://schemas.microsoft.com/office/drawing/2016/5/14/chartex",
			"xmlns:mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
			"xmlns:aink": "http://schemas.microsoft.com/office/drawing/2016/ink",
			"xmlns:am3d": "http://schemas.microsoft.com/office/drawing/2017/model3d",
			"xmlns:o": "urn:schemas-microsoft-com:office:office",
			"xmlns:r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
			"xmlns:m": "http://schemas.openxmlformats.org/officeDocument/2006/math",
			"xmlns:v": "urn:schemas-microsoft-com:vml",
			"xmlns:wp14": "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
			"xmlns:wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
			"xmlns:w10": "urn:schemas-microsoft-com:office:word",
			"xmlns:w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
			"xmlns:w14": "http://schemas.microsoft.com/office/word/2010/wordml",
			"xmlns:w15": "http://schemas.microsoft.com/office/word/2012/wordml",
			"xmlns:w16cex": "http://schemas.microsoft.com/office/word/2018/wordml/cex",
			"xmlns:w16cid": "http://schemas.microsoft.com/office/word/2016/wordml/cid",
			"xmlns:w16": "http://schemas.microsoft.com/office/word/2018/wordml",
			"xmlns:w16sdtdh": "http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash",
			"xmlns:w16se": "http://schemas.microsoft.com/office/word/2015/wordml/symex",
			"xmlns:wpg": "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
			"xmlns:wpi": "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
			"xmlns:wne": "http://schemas.microsoft.com/office/word/2006/wordml",
			"xmlns:wps": "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
			"mc:Ignorable": "w14 w15 wp14"
		}));
		const hasThreading = children.some((child) => child.parentId !== void 0);
		const hasDurableIds = children.some((child) => child.durableId !== void 0);
		if (hasThreading || hasDurableIds) {
			const idToParaId = new Map(children.map((child) => [child.id, commentIdToParaId(child.id)]));
			for (const child of children) this.root.push(new Comment(child, idToParaId.get(child.id)));
			if (hasThreading) this.threadData = children.map((child) => ({
				paraId: idToParaId.get(child.id),
				parentParaId: child.parentId !== void 0 ? idToParaId.get(child.parentId) : void 0,
				done: child.resolved
			}));
			if (hasDurableIds) this.commentIdsData = children.map((child) => {
				var _child$durableId;
				return {
					paraId: idToParaId.get(child.id),
					durableId: (_child$durableId = child.durableId) !== null && _child$durableId !== void 0 ? _child$durableId : idToParaId.get(child.id)
				};
			});
		} else for (const child of children) this.root.push(new Comment(child));
		this.relationships = new Relationships();
	}
	get Relationships() {
		return this.relationships;
	}
	/** Thread data for commentsExtended.xml, or undefined when no comments use parentId. */
	get ThreadData() {
		return this.threadData;
	}
	/** Comment id data for commentsIds.xml, or undefined when no comments carry a durableId. */
	get CommentIdsData() {
		return this.commentIdsData;
	}
	/** Whether there are no comments, in which case the document has no comments.xml part. */
	get IsEmpty() {
		return this.isEmpty;
	}
	/**
	* Formats the comments, with the page numbers worked out for their document written into their fields, when the
	* document's body is written with an estimate of its pages.
	*/
	prepForXml(context) {
		const xml = super.prepForXml(context);
		fillPartPageNumbers(xml, context);
		return xml;
	}
};
/**
* CommentsExtended module for WordprocessingML documents.
*
* Generates word/commentsExtended.xml which stores comment reply threading
* relationships using w15:commentEx elements.
*
* Reference: ISO/IEC 29500 + Microsoft wml-2012.xsd
*
* @module
*/
/**
* @internal
*/
var CommentsExtendedAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			"xmlns:wpc": "xmlns:wpc",
			"xmlns:mc": "xmlns:mc",
			"xmlns:w15": "xmlns:w15",
			"mc:Ignorable": "mc:Ignorable"
		});
	}
};
/**
* @internal
*/
var CommentExAttributes = class extends XmlAttributeComponent {
	constructor(..._args2) {
		super(..._args2);
		_defineProperty(this, "xmlKeys", {
			paraId: "w15:paraId",
			paraIdParent: "w15:paraIdParent",
			done: "w15:done"
		});
	}
};
/**
* @internal
*/
var CommentEx = class extends XmlComponent {
	constructor(options) {
		super("w15:commentEx");
		this.root.push(new CommentExAttributes({
			paraId: options.paraId,
			paraIdParent: options.parentParaId,
			done: options.done !== void 0 ? options.done ? "1" : "0" : void 0
		}));
	}
};
/**
* Represents the commentsExtended part (word/commentsExtended.xml).
*
* Contains w15:commentEx elements that define comment reply threading
* and resolved status.
*
* ## XSD Schema (wml-2012.xsd)
* ```xml
* <xsd:complexType name="CT_CommentsEx">
*   <xsd:sequence>
*     <xsd:element name="commentEx" type="CT_CommentEx" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var CommentsExtended = class extends XmlComponent {
	constructor(threadData) {
		super("w15:commentsEx");
		this.root.push(new CommentsExtendedAttributes({
			"xmlns:wpc": "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
			"xmlns:mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
			"xmlns:w15": "http://schemas.microsoft.com/office/word/2012/wordml",
			"mc:Ignorable": "w15"
		}));
		for (const data of threadData) this.root.push(new CommentEx(data));
	}
};
/**
* @internal
*/
var CommentIdAttributes = class extends XmlAttributeComponent {
	constructor(..._args3) {
		super(..._args3);
		_defineProperty(this, "xmlKeys", {
			paraId: "w16cid:paraId",
			durableId: "w16cid:durableId"
		});
	}
};
/**
* @internal
*/
var CommentId = class extends XmlComponent {
	constructor(options) {
		super("w16cid:commentId");
		this.root.push(new CommentIdAttributes({
			paraId: options.paraId,
			durableId: options.durableId
		}));
	}
};
/**
* @internal
*/
var CommentsIdsAttributes = class extends XmlAttributeComponent {
	constructor(..._args4) {
		super(..._args4);
		_defineProperty(this, "xmlKeys", {
			"xmlns:w16cid": "xmlns:w16cid",
			"xmlns:mc": "xmlns:mc",
			"mc:Ignorable": "mc:Ignorable"
		});
	}
};
/**
* Represents the commentsIds part (word/commentsIds.xml).
*
* Contains w16cid:commentId elements that map each comment's volatile paraId
* to a stable w16cid:durableId preserved by Word across edits.
*
* ## XSD Schema (wml-cid.xsd)
* ```xml
* <xsd:complexType name="CT_CommentsIds">
*   <xsd:sequence>
*     <xsd:element name="commentId" type="CT_CommentId" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var CommentsIds = class extends XmlComponent {
	constructor(commentIdsData) {
		super("w16cid:commentsIds");
		this.root.push(new CommentsIdsAttributes({
			"xmlns:w16cid": "http://schemas.microsoft.com/office/word/2016/wordml/cid",
			"xmlns:mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
			"mc:Ignorable": "w16cid"
		}));
		for (const data of commentIdsData) this.root.push(new CommentId(data));
	}
};
/**
* Represents a reference to an endnote.
*
* Used within endnote content to refer back to the endnote marker.
*/
var EndnoteReference = class extends EmptyElement {
	constructor() {
		super("w:endnoteRef");
	}
};
/**
* Represents a tab character.
*
* Inserts a tab stop, advancing to the next tab position in the paragraph.
*
* @publicApi
*/
var Tab = class extends EmptyElement {
	constructor() {
		super("w:tab");
	}
};
/**
* Represents a page break before setting for paragraph properties.
*
* When applied to a paragraph, ensures the paragraph begins on a new page.
*
* Reference: http://officeopenxml.com/WPparagraphProperties.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_OnOff">
*   <xsd:attribute name="val" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Paragraph({
*   pageBreakBefore: true,
*   children: [new TextRun("This text starts on a new page")],
* });
* ```
*/
var PageBreakBefore = class extends XmlComponent {
	constructor() {
		super("w:pageBreakBefore");
	}
};
/**
* Paragraph spacing module for WordprocessingML documents.
*
* This module provides spacing options for paragraphs including space before,
* space after, and line spacing.
*
* Reference: http://officeopenxml.com/WPspacing.php
*
* @module
*/
/**
* Line spacing rule types.
*
* Specifies how the line height is calculated.
*
* @publicApi
*/
var LineRuleType = {
	/** Line spacing is at least the specified value */
	AT_LEAST: "atLeast",
	/** Writes `exactly`, which isn't a value the schema allows, so Word ignores it. Use {@link LineRuleType.EXACT} for an exact line height. */
	EXACTLY: "exactly",
	/** Line spacing is exactly the specified value */
	EXACT: "exact",
	/** Line spacing is automatically determined based on content */
	AUTO: "auto"
};
/**
* Creates paragraph spacing element for a WordprocessingML document.
*
* The spacing element specifies the spacing between lines and paragraphs.
*
* Reference: http://officeopenxml.com/WPspacing.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Spacing">
*   <xsd:attribute name="before" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="beforeLines" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="beforeAutospacing" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="after" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="afterLines" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="afterAutospacing" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="line" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="lineRule" type="ST_LineSpacingRule" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Paragraph({
*   spacing: {
*     before: 200,
*     after: 200,
*     line: 360,
*     lineRule: LineRuleType.AT_LEAST,
*   },
*   children: [new TextRun("Paragraph with custom spacing")],
* });
* ```
*/
var createSpacing = ({ after, before, line, lineRule, beforeAutoSpacing, afterAutoSpacing }) => new BuilderElement({
	name: "w:spacing",
	attributes: {
		after: {
			key: "w:after",
			value: after
		},
		before: {
			key: "w:before",
			value: before
		},
		line: {
			key: "w:line",
			value: line
		},
		lineRule: {
			key: "w:lineRule",
			value: lineRule
		},
		beforeAutoSpacing: {
			key: "w:beforeAutospacing",
			value: beforeAutoSpacing
		},
		afterAutoSpacing: {
			key: "w:afterAutospacing",
			value: afterAutoSpacing
		}
	}
});
/**
* Creates a paragraph style reference for a WordprocessingML document.
*
* The pStyle element specifies the paragraph style to apply to the paragraph.
*
* Reference: http://officeopenxml.com/WPstyle.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_String">
*   <xsd:attribute name="val" type="s:ST_String" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Using a built-in heading style
* new Paragraph({
*   style: HeadingLevel.HEADING_1,
*   children: [new TextRun("Chapter 1")],
* });
*
* // Using a custom style
* new Paragraph({
*   style: "MyCustomStyle",
*   children: [new TextRun("Styled text")],
* });
* ```
*/
var createParagraphStyle = (styleId) => new BuilderElement({
	name: "w:pStyle",
	attributes: { val: {
		key: "w:val",
		value: styleId
	} }
});
/**
* Tab stop module for WordprocessingML documents.
*
* This module provides tab stop definitions for paragraphs.
*
* Reference: http://officeopenxml.com/WPtab.php
*
* @module
*/
/**
* Tab stop alignment types.
*
* Specifies the type of tab stop and how text aligns to it.
*
* @publicApi
*/
var TabStopType = {
	/** Left-aligned tab stop */
	LEFT: "left",
	/** Right-aligned tab stop */
	RIGHT: "right",
	/** Center-aligned tab stop */
	CENTER: "center",
	/** Bar tab stop - inserts a vertical bar at the position */
	BAR: "bar",
	/** Clears a tab stop at the specified position */
	CLEAR: "clear",
	/** Decimal-aligned tab stop - aligns on decimal point */
	DECIMAL: "decimal",
	/** End-aligned tab stop (right-to-left equivalent) */
	END: "end",
	/** List tab stop for numbered lists */
	NUM: "num",
	/** Start-aligned tab stop (left-to-right equivalent) */
	START: "start"
};
/**
* Creates a single tab stop item element.
*
* Reference: http://officeopenxml.com/WPtab.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TabStop">
*   <xsd:attribute name="val" type="ST_TabJc" use="required"/>
*   <xsd:attribute name="leader" type="ST_TabTlc" use="optional"/>
*   <xsd:attribute name="pos" type="ST_SignedTwipsMeasure" use="required"/>
* </xsd:complexType>
* ```
*/
var createTabStopItem = ({ type, position, leader }) => new BuilderElement({
	name: "w:tab",
	attributes: {
		val: {
			key: "w:val",
			value: type
		},
		pos: {
			key: "w:pos",
			value: signedTwipsMeasureValue(position)
		},
		leader: {
			key: "w:leader",
			value: leader
		}
	}
});
/**
* Creates a collection of tab stops for a WordprocessingML document.
*
* Tab stops define the positions where text will align when a tab character is used.
*
* Reference: http://officeopenxml.com/WPtab.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Tabs">
*   <xsd:sequence>
*     <xsd:element name="tab" type="CT_TabStop" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Paragraph({
*   tabStops: [
*     { type: TabStopType.LEFT, position: 2000 },
*     { type: TabStopType.CENTER, position: 4000 },
*     { type: TabStopType.RIGHT, position: TabStopPosition.MAX, leader: LeaderType.DOT },
*   ],
*   children: [new TextRun("Text\twith\ttabs")],
* });
* ```
*/
var createTabStop = (tabDefinitions) => new BuilderElement({
	name: "w:tabs",
	children: tabDefinitions.map((tabDefinition) => createTabStopItem(tabDefinition))
});
/**
* Numbering properties module for WordprocessingML documents.
*
* This module provides numbering and list properties for paragraphs.
*
* @module
*/
/**
* Represents numbering properties for a paragraph.
*
* The numPr element specifies the numbering definition instance and level
* for the paragraph, enabling numbered and bulleted lists.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_NumPr">
*   <xsd:sequence>
*     <xsd:element name="ilvl" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="numId" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="numberingChange" type="CT_TrackChangeNumbering" minOccurs="0"/>
*     <xsd:element name="ins" type="CT_TrackChange" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a bulleted list item at level 0
* new Paragraph({
*   numbering: {
*     reference: "my-bullet-list",
*     level: 0,
*   },
*   children: [new TextRun("First item")],
* });
*
* // Create a numbered list item at level 1
* new Paragraph({
*   numbering: {
*     reference: "my-numbered-list",
*     level: 1,
*   },
*   children: [new TextRun("Nested item")],
* });
* ```
*/
var NumberProperties = class extends XmlComponent {
	constructor(numberId, indentLevel) {
		super("w:numPr");
		this.root.push(new IndentLevel(indentLevel));
		this.root.push(new NumberId(numberId));
	}
};
/**
* Represents the indentation level (ilvl) for a numbered or bulleted list.
*
* The ilvl element specifies the list level (0-9) for the paragraph.
*
* @internal
*/
var IndentLevel = class extends XmlComponent {
	constructor(level) {
		super("w:ilvl");
		if (level > 9) throw new Error("Level cannot be greater than 9. Read more here: https://answers.microsoft.com/en-us/msoffice/forum/all/does-word-support-more-than-9-list-levels/d130fdcd-1781-446d-8c84-c6c79124e4d7");
		this.root.push(new Attributes({ val: level }));
	}
};
/**
* Represents the numbering definition ID (numId) for a numbered or bulleted list.
*
* The numId element specifies which numbering definition to use for the paragraph.
*
* @internal
*/
var NumberId = class extends XmlComponent {
	constructor(id) {
		super("w:numId");
		this.root.push(new Attributes({ val: typeof id === "string" ? `{${id}}` : id }));
	}
};
/**
* FileChild module for WordprocessingML documents.
*
* FileChild is the base class for block-level elements that can appear
* in the document body, such as paragraphs and tables.
*
* @module
*/
/**
* Base class for document body children.
*
* FileChild represents a block-level element that can be added directly
* to the document body. Examples include Paragraph and Table.
*/
var FileChild = class extends XmlComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(
			this,
			/** Marker property identifying this as a FileChild */
			"fileChild",
			Symbol()
		);
	}
};
/**
* Hyperlink attributes module for WordprocessingML documents.
*
* This module provides attribute components for hyperlink elements.
*
* Reference: http://officeopenxml.com/WPhyperlink.php
*
* @module
*/
/**
* Attributes for the hyperlink element.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Hyperlink">
*   <xsd:group ref="EG_PContent" minOccurs="0" maxOccurs="unbounded"/>
*   <xsd:attribute name="tgtFrame" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="tooltip" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="docLocation" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="history" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="anchor" type="s:ST_String" use="optional"/>
*   <xsd:attribute ref="r:id"/>
* </xsd:complexType>
* ```
*/
var HyperlinkAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			id: "r:id",
			history: "w:history",
			anchor: "w:anchor"
		});
	}
};
/**
* Represents a concrete hyperlink in a WordprocessingML document.
*
* This class is the low-level implementation of hyperlinks used internally.
* Use InternalHyperlink or ExternalHyperlink for creating hyperlinks in documents.
*
* Reference: http://officeopenxml.com/WPhyperlink.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="hyperlink" type="CT_Hyperlink"/>
*
* <xsd:complexType name="CT_Hyperlink">
*   <xsd:group ref="EG_PContent" minOccurs="0" maxOccurs="unbounded"/>
*   <xsd:attribute name="tgtFrame" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="tooltip" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="docLocation" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="history" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="anchor" type="s:ST_String" use="optional"/>
*   <xsd:attribute ref="r:id"/>
* </xsd:complexType>
* ```
*/
var ConcreteHyperlink = class extends XmlComponent {
	/**
	* @param children - Inline content of the hyperlink
	* @param relationshipId - Id of the external relationship, without the rId prefix
	* @param anchor - Bookmark name or external URL fragment
	* @param externalLink - The full address of an external hyperlink, so the relationship id is kept alongside its anchor
	*/
	constructor(children, relationshipId, anchor, externalLink) {
		super("w:hyperlink");
		_defineProperty(this, "linkId", void 0);
		_defineProperty(this, "drawingLink", void 0);
		this.linkId = relationshipId;
		this.drawingLink = anchor && externalLink !== void 0 ? new DrawingLink(externalLink) : void 0;
		const attributes = new HyperlinkAttributes({
			history: 1,
			anchor: anchor ? anchor : void 0,
			id: !anchor || externalLink !== void 0 ? `rId${this.linkId}` : void 0
		});
		this.root.push(attributes);
		children.forEach((child) => {
			this.root.push(child);
		});
	}
	/**
	* Creates the `a:hlinkClick` of a picture in the hyperlink, which links to the same address.
	*
	* The hyperlink decides which relationship its pictures use, rather than the pictures reading `linkId`, because only it
	* knows whether that relationship has lost the fragment to `w:anchor`. The picture's relationship is added as the
	* picture is written, through the context's relationships, so it lands in the part the picture is in, both when
	* packing and when patching.
	*
	* @param context - The context the picture is written in, whose relationships get the picture's link if it has its own
	* @param declareNamespace - Declares the DrawingML namespace, for elements outside `a:graphic` such as `wp:docPr`
	*/
	createDrawingClick(context, declareNamespace) {
		if (!this.drawingLink) return createHyperlinkClick(this.linkId, declareNamespace);
		this.drawingLink.addRelationship(context);
		return this.drawingLink.createClick(declareNamespace);
	}
};
/**
* Represents an internal hyperlink to a bookmark within the document.
*
* Internal hyperlinks use the anchor attribute to reference a bookmark by name.
* The bookmark must exist in the document for the hyperlink to function.
*
* Reference: http://officeopenxml.com/WPhyperlink.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:element name="hyperlink" type="CT_Hyperlink"/>
*
* <xsd:complexType name="CT_Hyperlink">
*   <xsd:group ref="EG_PContent" minOccurs="0" maxOccurs="unbounded"/>
*   <xsd:attribute name="anchor" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="history" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a bookmark
* new Bookmark({
*   id: "section1",
*   children: [new TextRun("Section 1")],
* });
*
* // Link to the bookmark
* new InternalHyperlink({
*   children: [new TextRun({ text: "Go to Section 1", style: "Hyperlink" })],
*   anchor: "section1",
* });
* ```
*/
var InternalHyperlink = class extends ConcreteHyperlink {
	constructor(options) {
		super(options.children, uniqueId(), options.anchor);
	}
};
/**
* Represents an external hyperlink to a URL outside the document.
*
* External hyperlinks create a relationship to an external resource (URL).
* The relationship is created during document preparation and the hyperlink
* is converted to a ConcreteHyperlink with the relationship ID.
* URL fragments of at most 255 UTF-16 units are written as anchors, preserving any additional # characters.
* Longer fragments stay in the original relationship URI to avoid exceeding Word's anchor limit;
* those links retain the existing limitations for fragments with multiple # characters.
* Word appends the anchor to the relationship target as described in MS-OI29500 §17.16.22:
* https://learn.microsoft.com/en-us/openspecs/office_standards/ms-oi29500/df06e423-11a6-4a36-bfb3-82139e531781
*
* Reference: http://officeopenxml.com/WPhyperlink.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:element name="hyperlink" type="CT_Hyperlink"/>
*
* <xsd:complexType name="CT_Hyperlink">
*   <xsd:group ref="EG_PContent" minOccurs="0" maxOccurs="unbounded"/>
*   <xsd:attribute ref="r:id"/>
*   <xsd:attribute name="history" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="anchor" type="s:ST_String" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new ExternalHyperlink({
*   children: [new TextRun({ text: "Visit Example", style: "Hyperlink" })],
*   link: "https://example.com",
* });
* ```
*/
var ExternalHyperlink = class extends XmlComponent {
	constructor(options) {
		super("w:externalHyperlink");
		_defineProperty(this, "options", void 0);
		this.options = options;
	}
};
/**
* Bookmark attributes module for WordprocessingML documents.
*
* This module provides attribute components for bookmark start and end elements.
*
* Reference: http://officeopenxml.com/WPbookmark.php
*
* @module
*/
/**
* Attributes for the bookmark start element.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Bookmark">
*   <xsd:complexContent>
*     <xsd:extension base="CT_BookmarkRange">
*       <xsd:attribute name="name" type="s:ST_String" use="required"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_BookmarkRange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_MarkupRange">
*       <xsd:attribute name="colFirst" type="ST_DecimalNumber" use="optional"/>
*       <xsd:attribute name="colLast" type="ST_DecimalNumber" use="optional"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_MarkupRange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_Markup">
*       <xsd:attribute name="displacedByCustomXml" type="ST_DisplacedByCustomXml" use="optional"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_Markup">
*   <xsd:attribute name="id" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*/
var BookmarkStartAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			id: "w:id",
			name: "w:name"
		});
	}
};
/**
* Attributes for the bookmark end element.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_MarkupRange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_Markup">
*       <xsd:attribute name="displacedByCustomXml" type="ST_DisplacedByCustomXml" use="optional"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_Markup">
*   <xsd:attribute name="id" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*/
var BookmarkEndAttributes = class extends XmlAttributeComponent {
	constructor(..._args2) {
		super(..._args2);
		_defineProperty(this, "xmlKeys", { id: "w:id" });
	}
};
/**
* Bookmark module for WordprocessingML documents.
*
* Bookmarks are used to identify a location or selection of text within a document.
* They can be used as targets for hyperlinks.
*
* Reference: http://officeopenxml.com/WPbookmark.php
*
* @module
*/
/**
* Represents a bookmark in a WordprocessingML document.
*
* A bookmark identifies a location or range of content that can be referenced
* elsewhere, such as from a hyperlink or table of contents. The bookmark consists
* of a start marker, content, and an end marker.
*
* Reference: http://officeopenxml.com/WPbookmark.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:element name="bookmarkStart" type="CT_Bookmark"/>
* <xsd:element name="bookmarkEnd" type="CT_MarkupRange"/>
*
* <xsd:complexType name="CT_Bookmark">
*   <xsd:complexContent>
*     <xsd:extension base="CT_BookmarkRange">
*       <xsd:attribute name="name" type="s:ST_String" use="required"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a bookmark around a heading
* new Bookmark({
*   id: "section1",
*   children: [new TextRun("Section 1 Heading")],
* });
*
* // Link to the bookmark from elsewhere
* new InternalHyperlink({
*   children: [new TextRun("Go to Section 1")],
*   anchor: "section1",
* });
* ```
*/
var Bookmark = class Bookmark {
	constructor(options) {
		_defineProperty(this, "start", void 0);
		_defineProperty(this, "children", void 0);
		_defineProperty(this, "end", void 0);
		const linkId = bookmarkUniqueNumericId();
		this.start = new BookmarkStart(options.id, linkId);
		this.children = options.children;
		this.end = new BookmarkEnd(linkId);
	}
	/**
	* The components written in this bookmark's place: its start, its children and its end. A bookmark in its
	* children is written the same way, so one bookmark can hold another.
	*
	* @internal
	*/
	get writtenAs() {
		return [
			this.start,
			...this.children.flatMap((child) => child instanceof Bookmark ? child.writtenAs : [child]),
			this.end
		];
	}
};
/**
* Represents the start marker of a bookmark range.
*
* This element marks the beginning of a bookmarked region in the document.
* It must be paired with a corresponding BookmarkEnd element with the same id.
*
* The id must be unique in the document. `Bookmark` takes its ids from
* `bookmarkUniqueNumericId`, so take this one from it too, or it can be the
* same as a `Bookmark`'s.
*
* Reference: http://officeopenxml.com/WPbookmark.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="bookmarkStart" type="CT_Bookmark"/>
*
* <xsd:complexType name="CT_Bookmark">
*   <xsd:complexContent>
*     <xsd:extension base="CT_BookmarkRange">
*       <xsd:attribute name="name" type="s:ST_String" use="required"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // A bookmark across two paragraphs
* const id = bookmarkUniqueNumericId();
* new Paragraph({ children: [new BookmarkStart("myBookmark", id), new TextRun("First")] });
* new Paragraph({ children: [new TextRun("Last"), new BookmarkEnd(id)] });
* ```
*/
var BookmarkStart = class extends XmlComponent {
	constructor(id, linkId) {
		super("w:bookmarkStart");
		const attributes = new BookmarkStartAttributes({
			name: id,
			id: linkId
		});
		this.root.push(attributes);
	}
};
/**
* Represents the end marker of a bookmark range.
*
* This element marks the end of a bookmarked region in the document.
* It must be paired with a corresponding BookmarkStart element with the same id,
* taken from `bookmarkUniqueNumericId` (see `BookmarkStart`).
*
* Reference: http://officeopenxml.com/WPbookmark.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="bookmarkEnd" type="CT_MarkupRange"/>
*
* <xsd:complexType name="CT_MarkupRange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_Markup">
*       <xsd:attribute name="displacedByCustomXml" type="ST_DisplacedByCustomXml" use="optional"/>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const id = bookmarkUniqueNumericId();
* new BookmarkStart("myBookmark", id);
* new BookmarkEnd(id);
* ```
*/
var BookmarkEnd = class extends XmlComponent {
	constructor(linkId) {
		super("w:bookmarkEnd");
		const attributes = new BookmarkEndAttributes({ id: linkId });
		this.root.push(attributes);
	}
};
/**
* Outline level module for WordprocessingML documents.
*
* This module provides the outline level element which specifies
* the outline level of a paragraph for document outline/TOC purposes.
*
* Reference: http://officeopenxml.com/WPparagraph.php
*
* @module
*/
/**
* Creates an outline level element for a paragraph.
*
* The outline level determines the paragraph's position in the document
* outline and affects table of contents generation. Level 0 corresponds
* to Heading 1, level 1 to Heading 2, etc.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_DecimalNumber">
*   <xsd:attribute name="val" type="xsd:integer" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Set outline level to 0 (Heading 1)
* createOutlineLevel(0);
*
* // Set outline level to 2 (Heading 3)
* createOutlineLevel(2);
* ```
*/
var createOutlineLevel = (level) => new BuilderElement({
	name: "w:outlineLvl",
	attributes: { val: {
		key: "w:val",
		value: level
	} }
});
/**
* Page reference field instruction module for WordprocessingML documents.
*
* This module provides the field instruction element for page references,
* which displays the page number of a bookmarked location.
*
* Reference: http://officeopenxml.com/WPfields.php
*
* @module
*/
/**
* Represents a PAGEREF field instruction.
*
* The PAGEREF field inserts the page number of the page containing
* the specified bookmark. It can optionally create a hyperlink
* and display relative positioning (e.g., "on the previous page").
*
* @example
* ```typescript
* // Basic page reference
* new PageReferenceFieldInstruction("figure_1");
*
* // Page reference with hyperlink and relative position
* new PageReferenceFieldInstruction("table_1", {
*   hyperlink: true,
*   useRelativePosition: true,
* });
* ```
*
* @internal
*/
var PageReferenceFieldInstruction = class extends XmlComponent {
	constructor(bookmarkId, options = {}) {
		super("w:instrText");
		this.root.push(new TextAttributes({ space: SpaceType.PRESERVE }));
		let instruction = `PAGEREF ${bookmarkId}`;
		if (options.hyperlink) instruction = `${instruction} \\h`;
		if (options.useRelativePosition) instruction = `${instruction} \\p`;
		this.root.push(instruction);
	}
};
/**
* Page reference module for WordprocessingML documents.
*
* This module provides page reference elements for cross-referencing
* the page number of a bookmarked location.
*
* Reference: https://www.ecma-international.org/publications/standards/Ecma-376.htm (Part 1, Page 1234)
*
* @module
*/
/**
* Represents a page reference (PAGEREF) field.
*
* The PAGEREF field displays the page number of the page containing
* the specified bookmark, useful for cross-references like "see page 5".
*
* It is written dirty, so Word fills in the page number when it opens the document, after asking to. When the
* document is given `pageNumbers`, it is written clean, with the number they work out, or blank when they couldn't,
* and Word doesn't ask.
*
* @publicApi
*
* @example
* ```typescript
* // Simple page reference
* new PageReference("figure_1_bookmark");
*
* // With hyperlink
* new PageReference("table_2", { hyperlink: true });
*
* // With relative position (e.g., "above" or "on page 5")
* new PageReference("section_3", {
*   hyperlink: true,
*   useRelativePosition: true,
* });
* ```
*/
var PageReference = class extends Run {
	constructor(bookmarkId, options = {}) {
		super({ children: [
			createBeginDirtyWithoutPageNumbers(),
			new PageReferenceFieldInstruction(bookmarkId, options),
			createSeparate(),
			createEnd()
		] });
	}
};
/**
* External hyperlink targets and fragments for WordprocessingML.
*
* Word appends the anchor to the relationship target, separated by a # character.
* Reference: https://learn.microsoft.com/en-us/openspecs/office_standards/ms-oi29500/df06e423-11a6-4a36-bfb3-82139e531781
*
* @module
*/
var MAX_ANCHOR_LENGTH = 255;
/**
* Splits a nonempty fragment that fits Word's anchor limit without decoding or normalizing either part.
* Longer fragments stay in the original relationship URI, retaining its existing multi-hash limitations.
*/
var externalHyperlinkTarget = (link) => {
	const index = link.indexOf("#");
	const fragmentLength = link.length - index - 1;
	return index > 0 && fragmentLength > 0 && fragmentLength <= MAX_ANCHOR_LENGTH ? {
		target: link.slice(0, index),
		anchor: link.slice(index + 1)
	} : { target: link };
};
/**
* The key a list's numbering id is found by while a document is written, which paragraphs write as a placeholder for it.
*
* Internal: not exported from the numbering module.
*
* @module
*/
/**
* Gives the key of a list of a numbering reference: the list of an `instance` paragraphs give, or a list a paragraph
* restarts with `restart`, which has an id of its own so it is never mistaken for one of the numbered instances.
*
* @param reference - The list's numbering reference
* @param instance - The `instance` that paragraphs give, used when the list isn't a restarted one
* @param restartedListId - For a list a paragraph restarts, the id of that restart
* @returns The list's key
*/
var listKey = (reference, instance, restartedListId) => restartedListId === void 0 ? `${reference}-${instance}` : `${reference}-restart ${restartedListId}`;
/**
* Creates a font relationship element for embedding fonts.
*/
var createFontRelationship = ({ id, fontKey, subsetted }, name) => new BuilderElement({
	name,
	attributes: _objectSpread2({ id: {
		key: "r:id",
		value: id
	} }, fontKey ? { fontKey: {
		key: "w:fontKey",
		value: `{${fontKey.toUpperCase()}}`
	} } : {}),
	children: [...subsetted ? [new OnOffElement("w:subsetted", subsetted)] : []]
});
/**
* Creates a font element with the specified options.
*
* This function builds a complete font definition including optional embedded font files,
* font signature, character set, and other font properties.
*
* Reference: http://www.datypic.com/sc/ooxml/e-w_font-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Font">
*   <xsd:sequence>
*     <xsd:element name="altName" type="CT_String" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="panose1" type="CT_Panose" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="charset" type="CT_Charset" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="family" type="CT_FontFamily" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="notTrueType" type="CT_OnOff" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="pitch" type="CT_Pitch" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="sig" type="CT_FontSig" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="embedRegular" type="CT_FontRel" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="embedBold" type="CT_FontRel" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="embedItalic" type="CT_FontRel" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="embedBoldItalic" type="CT_FontRel" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="name" type="s:ST_String" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const font = createFont({
*   name: "Arial",
*   family: "swiss",
*   pitch: "variable",
*   charset: CharacterSet.ANSI
* });
* ```
*/
var createFont = ({ name, altName, panose1, charset, family, notTrueType, pitch, sig, embedRegular, embedBold, embedItalic, embedBoldItalic }) => new BuilderElement({
	name: "w:font",
	attributes: { name: {
		key: "w:name",
		value: name
	} },
	children: [
		...altName ? [createStringElement("w:altName", altName)] : [],
		...panose1 ? [createStringElement("w:panose1", panose1)] : [],
		...charset ? [createStringElement("w:charset", charset)] : [],
		...family ? [createStringElement("w:family", family)] : [],
		...notTrueType ? [new OnOffElement("w:notTrueType", notTrueType)] : [],
		...pitch ? [createStringElement("w:pitch", pitch)] : [],
		...sig ? [new BuilderElement({
			name: "w:sig",
			attributes: {
				usb0: {
					key: "w:usb0",
					value: sig.usb0
				},
				usb1: {
					key: "w:usb1",
					value: sig.usb1
				},
				usb2: {
					key: "w:usb2",
					value: sig.usb2
				},
				usb3: {
					key: "w:usb3",
					value: sig.usb3
				},
				csb0: {
					key: "w:csb0",
					value: sig.csb0
				},
				csb1: {
					key: "w:csb1",
					value: sig.csb1
				}
			}
		})] : [],
		...embedRegular ? [createFontRelationship(embedRegular, "w:embedRegular")] : [],
		...embedBold ? [createFontRelationship(embedBold, "w:embedBold")] : [],
		...embedItalic ? [createFontRelationship(embedItalic, "w:embedItalic")] : [],
		...embedBoldItalic ? [createFontRelationship(embedBoldItalic, "w:embedBoldItalic")] : []
	]
});
/**
* Creates an embedded font with default settings.
*
* This helper function creates a font definition with standard font signature
* values that work for most common fonts. The signature specifies Unicode
* and code page ranges supported by the font.
*
* @returns XmlComponent representing the font definition
*
* @example
* ```typescript
* const font = createEmbeddedFont({
*   name: "Arial",
*   embedRegular: { id: "rId1", fontKey: "12345678-1234-1234-1234-123456789012" },
*   embedBold: { id: "rId2", fontKey: "12345678-1234-1234-1234-123456789013" },
* });
* ```
*/
var createEmbeddedFont = ({ name, characterSet, embedRegular, embedBold, embedItalic, embedBoldItalic }) => createFont({
	name,
	sig: {
		usb0: "E0002AFF",
		usb1: "C000247B",
		usb2: "00000009",
		usb3: "00000000",
		csb0: "000001FF",
		csb1: "00000000"
	},
	charset: characterSet,
	family: "auto",
	pitch: "variable",
	embedRegular,
	embedBold,
	embedItalic,
	embedBoldItalic
});
/**
* Font Table module for WordprocessingML documents.
*
* This module provides support for embedding fonts in the document.
*
* Reference: http://www.datypic.com/sc/ooxml/e-w_fonts.html
*
* @module
*/
/**
* Creates a font table element containing embedded fonts.
*
* The font table allows custom fonts to be embedded in the document
* so they display correctly even if not installed on the viewer's system.
*
* Reference: http://www.datypic.com/sc/ooxml/e-w_fonts.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_FontsList">
*   <xsd:sequence>
*     <xsd:element name="font" type="CT_Font" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var createFontTable = (fonts) => new BuilderElement({
	name: "w:fonts",
	attributes: {
		mc: {
			key: "xmlns:mc",
			value: "http://schemas.openxmlformats.org/markup-compatibility/2006"
		},
		r: {
			key: "xmlns:r",
			value: "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
		},
		w: {
			key: "xmlns:w",
			value: "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
		},
		w14: {
			key: "xmlns:w14",
			value: "http://schemas.microsoft.com/office/word/2010/wordml"
		},
		w15: {
			key: "xmlns:w15",
			value: "http://schemas.microsoft.com/office/word/2012/wordml"
		},
		w16cex: {
			key: "xmlns:w16cex",
			value: "http://schemas.microsoft.com/office/word/2018/wordml/cex"
		},
		w16cid: {
			key: "xmlns:w16cid",
			value: "http://schemas.microsoft.com/office/word/2016/wordml/cid"
		},
		w16: {
			key: "xmlns:w16",
			value: "http://schemas.microsoft.com/office/word/2018/wordml"
		},
		w16sdtdh: {
			key: "xmlns:w16sdtdh",
			value: "http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
		},
		w16se: {
			key: "xmlns:w16se",
			value: "http://schemas.microsoft.com/office/word/2015/wordml/symex"
		},
		Ignorable: {
			key: "mc:Ignorable",
			value: "w14 w15 w16se w16cid w16 w16cex w16sdtdh"
		}
	},
	children: fonts.map(createEmbeddedFont)
});
var FACES = [
	{
		option: "data",
		element: "embedRegular",
		bold: false,
		italic: false
	},
	{
		option: "bold",
		element: "embedBold",
		bold: true,
		italic: false
	},
	{
		option: "italic",
		element: "embedItalic",
		bold: false,
		italic: true
	},
	{
		option: "boldItalic",
		element: "embedBoldItalic",
		bold: true,
		italic: true
	}
];
/**
* Wrapper class for managing the font table and its relationships.
*
* Creates a font table with embedded font files and manages the relationships
* required for font embedding. Each face of a font is embedded as a file of its own,
* with a unique key for obfuscation.
*
* @example
* ```typescript
* const fontWrapper = new FontWrapper([
*   { name: "CustomFont", data: fontBuffer, bold: boldFontBuffer }
* ]);
* ```
*/
var FontWrapper = class {
	constructor(options) {
		_defineProperty(this, "options", void 0);
		_defineProperty(this, "fontTable", void 0);
		_defineProperty(this, "relationships", void 0);
		_defineProperty(
			this,
			/** @deprecated Use `files`, which has the file and key of each face a font embeds, not only the regular face's key */
			"fontOptionsWithKey",
			[]
		);
		_defineProperty(
			this,
			/** The files of the faces the fonts embed, in order: the Nth is `fonts/font<N>.odttf`, with the relationship `rId<N>` */
			"files",
			[]
		);
		this.options = options;
		const faces = options.map((font) => FACES.flatMap(({ option, element, bold, italic }) => {
			const data = font[option];
			return data ? [{
				element,
				file: {
					name: font.name,
					data,
					bold,
					italic,
					fontKey: uniqueUuid()
				}
			}] : [];
		}));
		this.files = faces.flatMap((ofFont) => ofFont.map(({ file }) => file));
		this.fontOptionsWithKey = options.map((font, index) => _objectSpread2(_objectSpread2({}, font), {}, { fontKey: faces[index][0].file.fontKey }));
		this.fontTable = createFontTable(options.map((font, index) => _objectSpread2({
			name: font.name,
			characterSet: font.characterSet
		}, Object.fromEntries(faces[index].map(({ element, file }) => [element, {
			id: `rId${this.files.indexOf(file) + 1}`,
			fontKey: file.fontKey
		}])))));
		this.relationships = new Relationships();
		for (let i = 0; i < this.files.length; i++) this.relationships.addRelationship(i + 1, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/font", `fonts/font${i + 1}.odttf`);
	}
	get View() {
		return this.fontTable;
	}
	get Relationships() {
		return this.relationships;
	}
};
/**
* Word wrap module for WordprocessingML documents.
*
* This module provides word wrap settings for paragraphs.
*
* Reference: http://officeopenxml.com/WPalignment.php
*
* @see http://officeopenxml.com/WPtableAlignment.php
*
* @module
*/
/**
* Creates word wrap settings element for a WordprocessingML document.
*
* The wordWrap element specifies whether word wrap should be disabled
* for the paragraph.
*/
var createWordWrap = () => new BuilderElement({
	name: "w:wordWrap",
	attributes: { val: {
		key: "w:val",
		value: 0
	} }
});
/**
* Creates a frame properties XML component for paragraph text frames.
*
* Frames allow paragraphs to be positioned absolutely on the page with text wrapping.
* They support both coordinate-based and alignment-based positioning, along with
* drop cap effects and various text wrapping options.
*
* Reference: http://officeopenxml.com/WPparagraph-textFrames.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_FramePr">
*   <xsd:attribute name="dropCap" type="ST_DropCap" use="optional"/>
*   <xsd:attribute name="lines" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="w" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="h" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="vSpace" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="hSpace" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="wrap" type="ST_Wrap" use="optional"/>
*   <xsd:attribute name="hAnchor" type="ST_HAnchor" use="optional"/>
*   <xsd:attribute name="vAnchor" type="ST_VAnchor" use="optional"/>
*   <xsd:attribute name="x" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="xAlign" type="s:ST_XAlign" use="optional"/>
*   <xsd:attribute name="y" type="ST_SignedTwipsMeasure" use="optional"/>
*   <xsd:attribute name="yAlign" type="s:ST_YAlign" use="optional"/>
*   <xsd:attribute name="hRule" type="ST_HeightRule" use="optional"/>
*   <xsd:attribute name="anchorLock" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Frame with absolute positioning
* createFrameProperties({
*   type: "absolute",
*   position: { x: 1440, y: 1440 }, // 1 inch from anchor
*   width: 2880, // 2 inches
*   height: 1440, // 1 inch
*   anchor: {
*     horizontal: FrameAnchorType.PAGE,
*     vertical: FrameAnchorType.PAGE,
*   },
*   wrap: FrameWrap.AROUND,
* });
*
* // Frame with alignment positioning and drop cap
* createFrameProperties({
*   type: "alignment",
*   alignment: {
*     x: HorizontalPositionAlign.LEFT,
*     y: VerticalPositionAlign.TOP,
*   },
*   width: 1440,
*   height: 1440,
*   anchor: {
*     horizontal: FrameAnchorType.TEXT,
*     vertical: FrameAnchorType.TEXT,
*   },
*   dropCap: DropCapType.DROP,
*   lines: 3,
* });
* ```
*
* @param options - Frame positioning and formatting options
* @returns XmlComponent representing the frame properties element
*/
var createFrameProperties = (options) => {
	var _options$space, _options$space2;
	return new BuilderElement({
		name: "w:framePr",
		attributes: {
			anchorLock: {
				key: "w:anchorLock",
				value: options.anchorLock
			},
			dropCap: {
				key: "w:dropCap",
				value: options.dropCap
			},
			width: {
				key: "w:w",
				value: options.width
			},
			height: {
				key: "w:h",
				value: options.height
			},
			x: {
				key: "w:x",
				value: options.position ? options.position.x : void 0
			},
			y: {
				key: "w:y",
				value: options.position ? options.position.y : void 0
			},
			anchorHorizontal: {
				key: "w:hAnchor",
				value: options.anchor.horizontal
			},
			anchorVertical: {
				key: "w:vAnchor",
				value: options.anchor.vertical
			},
			spaceHorizontal: {
				key: "w:hSpace",
				value: (_options$space = options.space) === null || _options$space === void 0 ? void 0 : _options$space.horizontal
			},
			spaceVertical: {
				key: "w:vSpace",
				value: (_options$space2 = options.space) === null || _options$space2 === void 0 ? void 0 : _options$space2.vertical
			},
			rule: {
				key: "w:hRule",
				value: options.rule
			},
			alignmentX: {
				key: "w:xAlign",
				value: options.alignment ? options.alignment.x : void 0
			},
			alignmentY: {
				key: "w:yAlign",
				value: options.alignment ? options.alignment.y : void 0
			},
			lines: {
				key: "w:lines",
				value: options.lines
			},
			wrap: {
				key: "w:wrap",
				value: options.wrap
			}
		}
	});
};
/**
* The restarted list that paragraphs leaving out `instance` are in, by list reference, for each part being written, as
* the id of the restart. A paragraph that restarts a list moves the paragraphs after it in the part onto its own list,
* and before any does, they are in instance 0. Each part is written
* with a context of its own, so the lists of one part, or of the same part written again, start from the first list.
*/
var currentRestartedLists = /* @__PURE__ */ new WeakMap();
var restartedListIds = uniqueNumericIdCreator();
/**
* The alignment to write for each side of the page in a right-to-left paragraph.
*
* Word and LibreOffice read `w:jc` `left` and `right` as the start and end of the paragraph, the same as
* `start` and `end` (ISO/IEC 29500-4 maps the transitional `left` and `right` onto the strict `start` and `end`,
* and [MS-OE376] 2.3.1.13 notes the same for Word 2007). So in a `w:bidi` paragraph `left` lands on the right
* side of the page. Swapping keeps `AlignmentType.LEFT` and `AlignmentType.RIGHT` on the side of the page they name.
* `left` and `right` are written rather than `end` and `start` because Word 2007 does not know `start` and `end`.
*/
var RIGHT_TO_LEFT_ALIGNMENTS = {
	left: "right",
	right: "left"
};
/**
* Represents paragraph properties (pPr) in a WordprocessingML document.
*
* The paragraph properties element specifies all formatting applied to a paragraph,
* including alignment, spacing, indentation, borders, numbering, and style references.
*
* Reference: http://officeopenxml.com/WPparagraphProperties.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PPr">
*   <xsd:complexContent>
*     <xsd:extension base="CT_PPrBase">
*       <xsd:sequence>
*         <xsd:element name="rPr" type="CT_ParaRPr" minOccurs="0"/>
*         <xsd:element name="sectPr" type="CT_SectPr" minOccurs="0"/>
*         <xsd:element name="pPrChange" type="CT_PPrChange" minOccurs="0"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* The base type CT_PPrBase contains:
* ```xml
* <xsd:complexType name="CT_PPrBase">
*   <xsd:sequence>
*     <xsd:element name="pStyle" type="CT_String" minOccurs="0"/>
*     <xsd:element name="keepNext" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="keepLines" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="pageBreakBefore" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="framePr" type="CT_FramePr" minOccurs="0"/>
*     <xsd:element name="widowControl" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="numPr" type="CT_NumPr" minOccurs="0"/>
*     <xsd:element name="suppressLineNumbers" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="pBdr" type="CT_PBdr" minOccurs="0"/>
*     <xsd:element name="shd" type="CT_Shd" minOccurs="0"/>
*     <xsd:element name="tabs" type="CT_Tabs" minOccurs="0"/>
*     <xsd:element name="suppressAutoHyphens" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="kinsoku" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="wordWrap" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="overflowPunct" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="topLinePunct" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="autoSpaceDE" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="autoSpaceDN" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="bidi" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="adjustRightInd" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="snapToGrid" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="spacing" type="CT_Spacing" minOccurs="0"/>
*     <xsd:element name="ind" type="CT_Ind" minOccurs="0"/>
*     <xsd:element name="contextualSpacing" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="mirrorIndents" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="suppressOverlap" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="jc" type="CT_Jc" minOccurs="0"/>
*     <xsd:element name="textDirection" type="CT_TextDirection" minOccurs="0"/>
*     <xsd:element name="textAlignment" type="CT_TextAlignment" minOccurs="0"/>
*     <xsd:element name="textboxTightWrap" type="CT_TextboxTightWrap" minOccurs="0"/>
*     <xsd:element name="outlineLvl" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="divId" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="cnfStyle" type="CT_Cnf" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Basic paragraph with alignment
* new ParagraphProperties({
*   alignment: AlignmentType.CENTER,
* });
*
* // Formatted paragraph with spacing and indentation
* new ParagraphProperties({
*   alignment: AlignmentType.JUSTIFIED,
*   spacing: { before: 200, after: 200, line: 360 },
*   indent: { left: 720, right: 720 },
* });
*
* // Heading with outline level
* new ParagraphProperties({
*   heading: HeadingLevel.HEADING_1,
*   outlineLevel: 0,
*   keepNext: true,
* });
*
* // Numbered list item
* new ParagraphProperties({
*   numbering: {
*     reference: "my-numbering",
*     level: 0,
*     instance: 0,
*   },
* });
*
* // Paragraph with borders and shading
* new ParagraphProperties({
*   border: {
*     top: { style: BorderStyle.SINGLE, size: 6, color: "000000" },
*     bottom: { style: BorderStyle.SINGLE, size: 6, color: "000000" },
*   },
*   shading: { fill: "EEEEEE" },
* });
* ```
*/
var ParagraphProperties = class extends IgnoreIfEmptyXmlComponent {
	/**
	* Creates paragraph properties.
	*
	* @param options - The paragraph formatting to emit
	* @param config - Controls how the element is assembled; see {@link IParagraphPropertiesConfig}
	*/
	constructor(options, { implicitListParagraphStyle = true, inListOrder = true } = {}) {
		super("w:pPr", options === null || options === void 0 ? void 0 : options.includeIfEmpty);
		_defineProperty(this, "numbering", void 0);
		_defineProperty(
			this,
			/** The paragraph's `w:numPr`, which is written again with its list's id each time the paragraph is written */
			"numberProperties",
			void 0
		);
		if (!options) return this;
		if (options.heading) this.push(createParagraphStyle(options.heading));
		if (implicitListParagraphStyle) {
			if (options.bullet) this.push(createParagraphStyle("ListParagraph"));
			if (options.numbering && !options.numbering.custom && !options.style && !options.heading) this.push(createParagraphStyle("ListParagraph"));
		}
		if (options.style) this.push(createParagraphStyle(options.style));
		if (options.keepNext !== void 0) this.push(new OnOffElement("w:keepNext", options.keepNext));
		if (options.keepLines !== void 0) this.push(new OnOffElement("w:keepLines", options.keepLines));
		if (options.pageBreakBefore) this.push(new PageBreakBefore());
		if (options.frame) this.push(createFrameProperties(options.frame));
		if (options.widowControl !== void 0) this.push(new OnOffElement("w:widowControl", options.widowControl));
		if (options.bullet) this.push(new NumberProperties(1, options.bullet.level));
		if (options.numbering) {
			const { reference: list, instance, level, restart } = options.numbering;
			const reference = typeof list === "string" ? list : list.reference;
			const numberProperties = new NumberProperties(listKey(reference, instance !== null && instance !== void 0 ? instance : 0), level);
			this.numbering = {
				reference,
				level,
				instance,
				restartedListId: restart && inListOrder && instance === void 0 ? restartedListIds() : void 0,
				definition: typeof list === "string" ? void 0 : list
			};
			this.numberProperties = numberProperties;
			this.push(numberProperties);
		} else if (options.numbering === false) this.push(new NumberProperties(0, 0));
		if (options.border) this.push(new Border(options.border));
		if (options.thematicBreak) this.push(new ThematicBreak());
		if (options.shading) this.push(createShading(options.shading));
		if (options.wordWrap) this.push(createWordWrap());
		if (options.overflowPunctuation) this.push(new OnOffElement("w:overflowPunct", options.overflowPunctuation));
		/**
		* FIX: Multitab support for Libre Writer
		* Ensure there is only one w:tabs tag with multiple w:tab
		*/
		const tabDefinitions = [
			...options.rightTabStop !== void 0 ? [{
				type: TabStopType.RIGHT,
				position: options.rightTabStop
			}] : [],
			...options.tabStops ? options.tabStops : [],
			...options.leftTabStop !== void 0 ? [{
				type: TabStopType.LEFT,
				position: options.leftTabStop
			}] : []
		];
		if (tabDefinitions.length > 0) this.push(createTabStop(tabDefinitions));
		/**
		*  FIX - END
		*/
		if (options.bidirectional !== void 0) this.push(new OnOffElement("w:bidi", options.bidirectional));
		if (options.spacing) this.push(createSpacing(options.spacing));
		if (options.indent) this.push(createIndent(options.indent));
		if (options.contextualSpacing !== void 0) this.push(new OnOffElement("w:contextualSpacing", options.contextualSpacing));
		if (options.alignment) this.push(createAlignment(options.bidirectional && RIGHT_TO_LEFT_ALIGNMENTS[options.alignment] || options.alignment));
		if (options.outlineLevel !== void 0) this.push(createOutlineLevel(options.outlineLevel));
		if (options.suppressLineNumbers !== void 0) this.push(new OnOffElement("w:suppressLineNumbers", options.suppressLineNumbers));
		if (options.autoSpaceEastAsianText !== void 0) this.push(new OnOffElement("w:autoSpaceDN", options.autoSpaceEastAsianText));
		if (options.run) this.push(new ParagraphRunProperties(options.run));
		if (options.revision) this.push(new ParagraphPropertiesChange(options.revision));
	}
	/**
	* Adds a property element to the paragraph properties.
	*
	* @param item - The XML component to add to the paragraph properties
	*/
	push(item) {
		this.root.push(item);
	}
	/**
	* Adds the section properties (`w:sectPr`) of the section this paragraph ends.
	*
	* They go after the paragraph's run properties and before its revision (`w:pPrChange`),
	* the order CT_PPr gives them.
	*
	* @param sectionProperties - The properties of the section the paragraph ends
	*/
	addSectionProperties(sectionProperties) {
		const revisionIndex = this.root.findIndex((item) => item instanceof ParagraphPropertiesChange);
		if (revisionIndex === -1) {
			this.root.push(sectionProperties);
			return;
		}
		this.root.splice(revisionIndex, 0, sectionProperties);
	}
	/**
	* Removes the section properties added with {@link addSectionProperties}.
	*
	* @param sectionProperties - The properties of the section to remove
	*/
	removeSectionProperties(sectionProperties) {
		const index = this.root.indexOf(sectionProperties);
		if (index !== -1) this.root.splice(index, 1);
	}
	/**
	* Prepares the paragraph properties for XML serialization.
	*
	* This method works out which list instance a numbered paragraph is in, from where it is in its part when it
	* leaves out `instance`, and creates the concrete numbering instance for it before the properties are converted to XML.
	*
	* @param context - The XML context containing document and file information
	* @returns The prepared XML object, or undefined if the component should be ignored
	*/
	prepForXml(context) {
		var _this$numbering;
		if (this.numbering) {
			var _this$numbering$resta, _currentRestartedList;
			const { reference, level, instance = 0, definition } = this.numbering;
			const restartedListId = this.numbering.instance === void 0 ? (_this$numbering$resta = this.numbering.restartedListId) !== null && _this$numbering$resta !== void 0 ? _this$numbering$resta : (_currentRestartedList = currentRestartedLists.get(context)) === null || _currentRestartedList === void 0 ? void 0 : _currentRestartedList.get(reference) : void 0;
			if (!(context.viewWrapper instanceof FontWrapper)) context.file.Numbering.createConcreteNumberingInstance(reference, instance, definition, restartedListId);
			const numberProperties = new NumberProperties(listKey(reference, instance, restartedListId), level);
			this.root.splice(this.root.indexOf(this.numberProperties), 1, numberProperties);
			this.numberProperties = numberProperties;
		}
		const result = super.prepForXml(context);
		if (((_this$numbering = this.numbering) === null || _this$numbering === void 0 ? void 0 : _this$numbering.restartedListId) !== void 0) {
			var _currentRestartedList2;
			currentRestartedLists.set(context, new Map([...(_currentRestartedList2 = currentRestartedLists.get(context)) !== null && _currentRestartedList2 !== void 0 ? _currentRestartedList2 : [], [this.numbering.reference, this.numbering.restartedListId]]));
		}
		return result;
	}
};
var ParagraphPropertiesChange = class extends XmlComponent {
	constructor(options) {
		super("w:pPrChange");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
		this.root.push(new ParagraphProperties(_objectSpread2(_objectSpread2({}, options), {}, { includeIfEmpty: true }), { inListOrder: false }));
	}
};
/**
* Represents a paragraph in a WordprocessingML document.
*
* A paragraph is the primary unit of block-level content in a document and can contain
* various inline elements such as text runs, images, hyperlinks, and bookmarks.
*
* Reference: http://officeopenxml.com/WPparagraph.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_P">
*   <xsd:sequence>
*     <xsd:element name="pPr" type="CT_PPr" minOccurs="0"/>
*     <xsd:group ref="EG_PContent" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="rsidRPr" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidR" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidDel" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidP" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidRDefault" type="ST_LongHexNumber"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Simple paragraph with text
* new Paragraph("Hello World");
*
* // Paragraph with options
* new Paragraph({
*   children: [new TextRun("Hello"), new TextRun({ text: "World", bold: true })],
*   alignment: AlignmentType.CENTER,
* });
* ```
*/
var Paragraph = class Paragraph extends FileChild {
	constructor(options) {
		super("w:p");
		_defineProperty(
			this,
			/** The options the paragraph was made with. A paragraph made from a string has it as its `text` */
			"options",
			void 0
		);
		_defineProperty(this, "properties", void 0);
		_defineProperty(this, "alignment", void 0);
		this.options = typeof options === "string" ? { text: options } : options;
		if (typeof options === "string") {
			this.alignment = {};
			this.properties = new ParagraphProperties({});
			this.root.push(this.properties);
			this.root.push(new TextRun(options));
			return this;
		}
		this.alignment = {
			alignment: options.alignment,
			bidirectional: options.bidirectional
		};
		this.properties = new ParagraphProperties(options);
		this.root.push(this.properties);
		if (options.text) this.root.push(new TextRun(options.text));
		if (options.children) for (const child of options.children) {
			if (child instanceof Bookmark) {
				this.root.push(...child.writtenAs);
				continue;
			}
			this.root.push(child);
		}
	}
	prepForXml(context) {
		for (const element of this.root) if (elementOf(element) === "w:externalHyperlink") {
			const index = this.root.indexOf(element);
			const { options } = element;
			const { target, anchor } = externalHyperlinkTarget(options.link);
			const concreteHyperlink = new ConcreteHyperlink(options.children, uniqueId(), anchor, options.link);
			context.viewWrapper.Relationships.addRelationship(concreteHyperlink.linkId, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", target, TargetModeType.EXTERNAL);
			this.root[index] = concreteHyperlink;
		}
		return super.prepForXml(context);
	}
	/**
	* Ends a section at this paragraph by adding the section's properties to the paragraph's properties,
	* as Word does with the last paragraph of each section but the last.
	*
	* The body adds them only while it is written and removes them afterwards with
	* {@link removeSectionProperties}, so the same paragraph can be used in other documents.
	*
	* @internal
	* @param sectionProperties - The properties of the section the paragraph ends
	*/
	addSectionProperties(sectionProperties) {
		this.properties.addSectionProperties(sectionProperties);
	}
	/**
	* Removes the section properties added with {@link addSectionProperties}.
	*
	* @internal
	* @param sectionProperties - The properties of the section to remove
	*/
	removeSectionProperties(sectionProperties) {
		this.properties.removeSectionProperties(sectionProperties);
	}
	/**
	* The paragraph's alignment and direction, which a table gives the empty paragraphs of the cells it adds below a
	* cell merged down rows (`rowSpan`), so that the merged cell is aligned as one.
	*
	* @internal
	*/
	get Alignment() {
		return this.alignment;
	}
	/**
	* Makes a new paragraph with the paragraph's options and these, which take the place of its own, such as to indent
	* the paragraphs a parser made. The paragraph itself is left as it is, and the new one has the same children.
	*
	* Each option given replaces the paragraph's whole option: to keep the rest of its spacing, give
	* `spacing: { ...paragraph.options.spacing, before: 240 }`. An option given as `undefined` is removed.
	*
	* @example
	* ```typescript
	* const indented = paragraphs.map((paragraph) => paragraph.with({ indent: { left: 720, right: 720 } }));
	* ```
	*/
	with(options) {
		return new Paragraph(_objectSpread2(_objectSpread2({}, this.options), options));
	}
	addRunToFront(run) {
		this.root.splice(1, 0, run);
		return this;
	}
};
/**
* Vertical alignment module for WordprocessingML documents.
*
* This module provides vertical alignment options for table cells and sections.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_VerticalJc">
*   <xsd:attribute name="val" type="ST_VerticalJc" use="required"/>
* </xsd:complexType>
*
* <xsd:simpleType name="ST_VerticalJc">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="both"/>
*     <xsd:enumeration value="top"/>
*     <xsd:enumeration value="center"/>
*     <xsd:enumeration value="bottom"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @module
*/
/**
* Enumeration for table-cell vertical alignment. Only `top`, `center`, `bottom`
* are valid according to ECMA-376 (§17.18.87 ST_VerticalJc within `<w:tcPr>`).
*
* @publicApi
*/
var VerticalAlignTable = {
	TOP: "top",
	CENTER: "center",
	BOTTOM: "bottom"
};
_objectSpread2(_objectSpread2({}, VerticalAlignTable), {}, { BOTH: "both" });
/**
* Creates a vertical alignment element in a WordprocessingML document.
*
* Used in table cells and sections to control vertical text positioning.
*
* @example
* ```typescript
* createVerticalAlign(VerticalAlignTable.CENTER);
* ```
*/
var createVerticalAlign = (value) => new BuilderElement({
	name: "w:vAlign",
	attributes: { verticalAlign: {
		key: "w:val",
		value
	} }
});
/**
* Columns module for WordprocessingML section properties.
*
* Defines multi-column layouts within document sections.
*
* Reference: http://officeopenxml.com/WPsectionPr.php
*
* @module
*/
/**
* Creates column layout settings (cols) for a document section.
*
* This element defines the multi-column layout properties for a section,
* including column count, spacing, and whether columns have equal or custom widths.
*
* Reference: http://officeopenxml.com/WPsectionPr.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Columns">
*   <xsd:sequence minOccurs="0">
*     <xsd:element name="col" type="CT_Column" maxOccurs="45"/>
*   </xsd:sequence>
*   <xsd:attribute name="equalWidth" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="space" type="s:ST_TwipsMeasure" use="optional" default="720"/>
*   <xsd:attribute name="num" type="ST_DecimalNumber" use="optional" default="1"/>
*   <xsd:attribute name="sep" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Two equal-width columns with separator
* createColumns({
*   count: 2,
*   space: 720,
*   separate: true,
*   equalWidth: true
* });
*
* // Custom column widths
* createColumns({
*   equalWidth: false,
*   children: [
*     { width: 3000, space: 720 },
*     { width: 4000, space: 0 }
*   ]
* });
* ```
*/
var createColumns = ({ space, count, separate, equalWidth, children }) => new BuilderElement({
	name: "w:cols",
	attributes: {
		space: {
			key: "w:space",
			value: space === void 0 ? void 0 : twipsMeasureValue(space)
		},
		count: {
			key: "w:num",
			value: count === void 0 ? void 0 : decimalNumber(count)
		},
		separate: {
			key: "w:sep",
			value: separate
		},
		equalWidth: {
			key: "w:equalWidth",
			value: equalWidth
		}
	},
	children: !equalWidth && children ? children : void 0
});
/**
* This element specifies the settings for the document grid, which enables precise layout of full-width East Asian language characters within a document by specifying the desired number of characters per line and lines per page for all East Asian text content in this section.
*
* Reference: https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_docGrid_topic_ID0EHU5S.html
*
* ```xml
* <xsd:complexType name="CT_DocGrid">
*   <xsd:attribute name="type" type="ST_DocGrid"/>
*   <xsd:attribute name="linePitch" type="ST_DecimalNumber"/>
*   <xsd:attribute name="charSpace" type="ST_DecimalNumber"/>
* </xsd:complexType>
* ```
* @returns
*/
var createDocumentGrid = ({ type, linePitch, charSpace }) => new BuilderElement({
	name: "w:docGrid",
	attributes: {
		type: {
			key: "w:type",
			value: type
		},
		linePitch: {
			key: "w:linePitch",
			value: decimalNumber(linePitch)
		},
		charSpace: {
			key: "w:charSpace",
			value: charSpace ? decimalNumber(charSpace) : void 0
		}
	}
});
/**
* This simple type specifies the possible types of headers and footers which may be specified for a given header or footer reference in a document. This value determines the page(s) on which the current header or footer shall be displayed.
*
* Reference: https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_ST_HdrFtr_topic_ID0E2UW2.html
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_HdrFtr">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="even"/>
*     <xsd:enumeration value="default"/>
*     <xsd:enumeration value="first"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*/
var HeaderFooterReferenceType = {
	/** Specifies that this header or footer shall appear on every page in this section which is not overridden with a specific `even` or `first` page header/footer. In a section with all three types specified, this type shall be used on all odd numbered pages (counting from the `first` page in the section, not the section numbering). */
	DEFAULT: "default",
	/** Specifies that this header or footer shall appear on the first page in this section. The appearance of this header or footer is contingent on the setting of the `titlePg` element (§2.10.6). */
	FIRST: "first",
	/** Specifies that this header or footer shall appear on all even numbered pages in this section (counting from the first page in the section, not the section numbering). The appearance of this header or footer is contingent on the setting of the `evenAndOddHeaders` element (§2.10.1). */
	EVEN: "even"
};
var HeaderFooterType = {
	HEADER: "w:headerReference",
	FOOTER: "w:footerReference"
};
var createHeaderFooterReference = (type, options) => new BuilderElement({
	name: type,
	attributes: {
		type: {
			key: "w:type",
			value: options.type || HeaderFooterReferenceType.DEFAULT
		},
		id: {
			key: "r:id",
			value: `rId${options.id}`
		}
	}
});
/**
* This element specifies the settings for line numbering to be displayed before each column of text in this section in the document.
*
* References:
* - https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_lnNumType_topic_ID0EVRAT.html
* - http://officeopenxml.com/WPsectionLineNumbering.php
*
* ## XSD Schema
*
* ```xml
* <xsd:complexType name="CT_LineNumber">
*   <xsd:attribute name="countBy" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="start" type="ST_DecimalNumber" use="optional" default="1"/>
*   <xsd:attribute name="distance" type="s:ST_TwipsMeasure" use="optional"/>
*   <xsd:attribute name="restart" type="ST_LineNumberRestart" use="optional" default="newPage"/>
* </xsd:complexType>
* ```
*/
var createLineNumberType = ({ countBy, start, restart, distance }) => new BuilderElement({
	name: "w:lnNumType",
	attributes: {
		countBy: {
			key: "w:countBy",
			value: countBy === void 0 ? void 0 : decimalNumber(countBy)
		},
		start: {
			key: "w:start",
			value: start === void 0 ? void 0 : decimalNumber(start)
		},
		restart: {
			key: "w:restart",
			value: restart
		},
		distance: {
			key: "w:distance",
			value: distance === void 0 ? void 0 : twipsMeasureValue(distance)
		}
	}
});
var createNoteProperties = ({ name, position, numberFormat, start, restart }) => new BuilderElement({
	name,
	children: [
		...position === void 0 ? [] : [new BuilderElement({
			name: "w:pos",
			attributes: { val: {
				key: "w:val",
				value: position
			} }
		})],
		...numberFormat ? [new BuilderElement({
			name: "w:numFmt",
			attributes: {
				val: {
					key: "w:val",
					value: numberFormat.type
				},
				format: {
					key: "w:format",
					value: numberFormat.format
				}
			}
		})] : [],
		...start === void 0 ? [] : [new BuilderElement({
			name: "w:numStart",
			attributes: { val: {
				key: "w:val",
				value: decimalNumber(start)
			} }
		})],
		...restart === void 0 ? [] : [new BuilderElement({
			name: "w:numRestart",
			attributes: { val: {
				key: "w:val",
				value: restart
			} }
		})]
	]
});
/**
* Creates the footnote properties (footnotePr) of a section.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_FtnProps">
*   <xsd:sequence>
*     <xsd:element name="pos" type="CT_FtnPos" minOccurs="0"/>
*     <xsd:element name="numFmt" type="CT_NumFmt" minOccurs="0"/>
*     <xsd:group ref="EG_FtnEdnNumProps" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Footnotes at the end of the section, numbered a, b, c and restarting in each section
* createFootnoteProperties({
*   position: FootnotePosition.SECTION_END,
*   numberFormat: { type: NumberFormat.LOWER_LETTER },
*   restart: NoteNumberRestart.EACH_SECTION,
* });
* ```
*/
var createFootnoteProperties = (options) => createNoteProperties(_objectSpread2({ name: "w:footnotePr" }, options));
/**
* Creates the endnote properties (endnotePr) of a section.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_EdnProps">
*   <xsd:sequence>
*     <xsd:element name="pos" type="CT_EdnPos" minOccurs="0"/>
*     <xsd:element name="numFmt" type="CT_NumFmt" minOccurs="0"/>
*     <xsd:group ref="EG_FtnEdnNumProps" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Endnotes at the end of the document, numbered 001, 002, 003
* createEndnoteProperties({
*   position: EndnotePosition.DOCUMENT_END,
*   numberFormat: { type: NumberFormat.CUSTOM, format: "001" },
* });
* ```
*/
var createEndnoteProperties = (options) => createNoteProperties(_objectSpread2({ name: "w:endnotePr" }, options));
var PageBordersAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			display: "w:display",
			offsetFrom: "w:offsetFrom",
			zOrder: "w:zOrder"
		});
	}
};
/**
* Represents page borders (pgBorders) for a document section.
*
* This element specifies the borders to display around pages in a section,
* including which pages display the borders and how they are positioned.
*
* Reference: http://officeopenxml.com/WPsectionBorders.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PageBorders">
*   <xsd:sequence>
*     <xsd:element name="top" type="CT_TopPageBorder" minOccurs="0"/>
*     <xsd:element name="left" type="CT_PageBorder" minOccurs="0"/>
*     <xsd:element name="bottom" type="CT_BottomPageBorder" minOccurs="0"/>
*     <xsd:element name="right" type="CT_PageBorder" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="zOrder" type="ST_PageBorderZOrder" use="optional" default="front"/>
*   <xsd:attribute name="display" type="ST_PageBorderDisplay" use="optional"/>
*   <xsd:attribute name="offsetFrom" type="ST_PageBorderOffset" use="optional" default="text"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Add page borders to all pages
* new PageBorders({
*   pageBorders: {
*     display: PageBorderDisplay.ALL_PAGES,
*     offsetFrom: PageBorderOffsetFrom.PAGE,
*     zOrder: PageBorderZOrder.FRONT
*   },
*   pageBorderTop: { style: BorderStyle.SINGLE, size: 24, color: "000000" },
*   pageBorderBottom: { style: BorderStyle.SINGLE, size: 24, color: "000000" }
* });
* ```
*/
var PageBorders = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:pgBorders");
		if (!options) return this;
		if (options.pageBorders) this.root.push(new PageBordersAttributes({
			display: options.pageBorders.display,
			offsetFrom: options.pageBorders.offsetFrom,
			zOrder: options.pageBorders.zOrder
		}));
		else this.root.push(new PageBordersAttributes({}));
		if (options.pageBorderTop) this.root.push(createBorderElement("w:top", options.pageBorderTop));
		if (options.pageBorderLeft) this.root.push(createBorderElement("w:left", options.pageBorderLeft));
		if (options.pageBorderBottom) this.root.push(createBorderElement("w:bottom", options.pageBorderBottom));
		if (options.pageBorderRight) this.root.push(createBorderElement("w:right", options.pageBorderRight));
	}
};
/**
* Page margin module for WordprocessingML section properties.
*
* Defines page margins for document sections.
*
* Reference: http://officeopenxml.com/WPsectionPr.php
*
* @module
*/
/**
* Creates page margins (pgMar) for a document section.
*
* This element specifies the page margins for all pages in a section,
* including top, bottom, left, right, header, footer, and gutter margins.
*
* Reference: http://officeopenxml.com/WPsectionPr.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PageMar">
*   <xsd:attribute name="top" type="ST_SignedTwipsMeasure" use="required"/>
*   <xsd:attribute name="right" type="s:ST_TwipsMeasure" use="required"/>
*   <xsd:attribute name="bottom" type="ST_SignedTwipsMeasure" use="required"/>
*   <xsd:attribute name="left" type="s:ST_TwipsMeasure" use="required"/>
*   <xsd:attribute name="header" type="s:ST_TwipsMeasure" use="required"/>
*   <xsd:attribute name="footer" type="s:ST_TwipsMeasure" use="required"/>
*   <xsd:attribute name="gutter" type="s:ST_TwipsMeasure" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create page margins with 1 inch margins (1440 twips = 1 inch)
* createPageMargin(1440, 1440, 1440, 1440, 720, 720, 0);
* ```
*/
var createPageMargin = (top, right, bottom, left, header, footer, gutter) => new BuilderElement({
	name: "w:pgMar",
	attributes: {
		top: {
			key: "w:top",
			value: signedTwipsMeasureValue(top)
		},
		right: {
			key: "w:right",
			value: twipsMeasureValue(right)
		},
		bottom: {
			key: "w:bottom",
			value: signedTwipsMeasureValue(bottom)
		},
		left: {
			key: "w:left",
			value: twipsMeasureValue(left)
		},
		header: {
			key: "w:header",
			value: twipsMeasureValue(header)
		},
		footer: {
			key: "w:footer",
			value: twipsMeasureValue(footer)
		},
		gutter: {
			key: "w:gutter",
			value: twipsMeasureValue(gutter)
		}
	}
});
/**
* Specifies the separator character between chapter number and page number.
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_ChapterSep">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="hyphen"/>
*     <xsd:enumeration value="period"/>
*     <xsd:enumeration value="colon"/>
*     <xsd:enumeration value="emDash"/>
*     <xsd:enumeration value="enDash"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var PageNumberSeparator = {
	/** Hyphen separator (-) */
	HYPHEN: "hyphen",
	/** Period separator (.) */
	PERIOD: "period",
	/** Colon separator (:) */
	COLON: "colon",
	/** Em dash separator (—) */
	EM_DASH: "emDash",
	/** En dash separator (–), written as `enDash` */
	EN_DASH: "endash"
};
/**
* Creates page numbering settings (pgNumType) for a document section.
*
* This element specifies the page numbering format and starting value
* for all pages in a section.
*
* Reference: http://officeopenxml.com/WPSectionPgNumType.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PageNumber">
*   <xsd:attribute name="fmt" type="ST_NumberFormat" use="optional" default="decimal"/>
*   <xsd:attribute name="start" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="chapStyle" type="ST_DecimalNumber" use="optional"/>
*   <xsd:attribute name="chapSep" type="ST_ChapterSep" use="optional" default="hyphen"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Start page numbering at 5 with lowercase roman numerals
* createPageNumberType({
*   start: 5,
*   formatType: NumberFormat.LOWER_ROMAN
* });
* ```
*/
var createPageNumberType = ({ start, formatType, separator, chapterHeadingLevel }) => new BuilderElement({
	name: "w:pgNumType",
	attributes: {
		start: {
			key: "w:start",
			value: start === void 0 ? void 0 : decimalNumber(start)
		},
		formatType: {
			key: "w:fmt",
			value: formatType
		},
		separator: {
			key: "w:chapSep",
			value: separator === PageNumberSeparator.EN_DASH ? "enDash" : separator
		},
		chapterHeadingLevel: {
			key: "w:chapStyle",
			value: chapterHeadingLevel === void 0 ? void 0 : decimalNumber(chapterHeadingLevel)
		}
	}
});
/**
* This simple type specifies the orientation of all pages in the parent section. This information is used to determine the actual paper size to use when printing the file.
*
* Reference: https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_ST_PageOrientation_topic_ID0EKBK3.html
*
* ## XSD Schema
*
* ```xml
* <xsd:simpleType name="ST_PageOrientation">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="portrait"/>
*     <xsd:enumeration value="landscape"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var PageOrientation = {
	/**
	* ## Portrait Mode
	*
	* Specifies that pages in this section shall be printed in portrait mode.
	*/
	PORTRAIT: "portrait",
	/**
	* ## Landscape Mode
	*
	* Specifies that pages in this section shall be printed in landscape mode, which prints the page contents with a 90 degree rotation with respect to the normal page orientation.
	*/
	LANDSCAPE: "landscape"
};
/**
* This element specifies the properties (size and orientation) for all pages in the current section.
*
* Reference: https://c-rex.net/samples/ooxml/e1/Part4/OOXML_P4_DOCX_pgSz_topic_ID0ENEDT.html?hl=pgsz%2Cpage%2Csize
*
* ## XSD Schema
*
* ```xml
* <xsd:complexType name="CT_PageSz">
*   <xsd:attribute name="w" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="h" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="orient" type="ST_PageOrientation" use="optional"/>
*   <xsd:attribute name="code" type="ST_DecimalNumber" use="optional"/>
* </xsd:complexType>
* ```
*/
var createPageSize = ({ width, height, orientation, code }) => {
	const widthTwips = twipsMeasureValue(width);
	const heightTwips = twipsMeasureValue(height);
	return new BuilderElement({
		name: "w:pgSz",
		attributes: {
			width: {
				key: "w:w",
				value: orientation === PageOrientation.LANDSCAPE ? heightTwips : widthTwips
			},
			height: {
				key: "w:h",
				value: orientation === PageOrientation.LANDSCAPE ? widthTwips : heightTwips
			},
			orientation: {
				key: "w:orient",
				value: orientation
			},
			code: {
				key: "w:code",
				value: code
			}
		}
	});
};
var PageTextDirectionAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { val: "w:val" });
	}
};
/**
* Represents text direction (textDirection) for pages in a section.
*
* This element specifies the direction and orientation of text flow
* for all pages in a section.
*
* Reference: http://officeopenxml.com/WPsectionPr.php
*
* @example
* ```typescript
* // Horizontal text flow (left-to-right, top-to-bottom)
* new PageTextDirection(PageTextDirectionType.LEFT_TO_RIGHT_TOP_TO_BOTTOM);
*
* // Vertical text flow (top-to-bottom, right-to-left)
* new PageTextDirection(PageTextDirectionType.TOP_TO_BOTTOM_RIGHT_TO_LEFT);
* ```
*/
var PageTextDirection = class extends XmlComponent {
	constructor(value) {
		super("w:textDirection");
		this.root.push(new PageTextDirectionAttributes({ val: value }));
	}
};
/**
* Creates section type (type) for a document section.
*
* This element specifies the type of section break, which determines
* where the new section begins relative to the previous section.
*
* Reference: http://officeopenxml.com/WPsection.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SectType">
*   <xsd:attribute name="val" type="ST_SectionMark"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a continuous section (no page break)
* createSectionType(SectionType.CONTINUOUS);
*
* // Create a section that starts on next odd page
* createSectionType(SectionType.ODD_PAGE);
* ```
*/
var createSectionType = (value) => new BuilderElement({
	name: "w:type",
	attributes: { val: {
		key: "w:val",
		value
	} }
});
/**
* Default margin values for sections (in twips).
*
* Standard margins are 1 inch (1440 twips) on all sides.
* Header/footer margins are 0.5 inches (708 twips) from page edge.
*
* @property TOP - Top margin: 1440 twips (1 inch)
* @property RIGHT - Right margin: 1440 twips (1 inch)
* @property BOTTOM - Bottom margin: 1440 twips (1 inch)
* @property LEFT - Left margin: 1440 twips (1 inch)
* @property HEADER - Header margin: 708 twips (0.5 inches)
* @property FOOTER - Footer margin: 708 twips (0.5 inches)
* @property GUTTER - Gutter margin: 0 twips
*/
var sectionMarginDefaults = {
	/** Top margin: 1440 twips (1 inch) */
	TOP: 1440,
	/** Right margin: 1440 twips (1 inch) */
	RIGHT: 1440,
	/** Bottom margin: 1440 twips (1 inch) */
	BOTTOM: 1440,
	/** Left margin: 1440 twips (1 inch) */
	LEFT: 1440,
	/** Header margin from top: 708 twips (0.5 inches) */
	HEADER: 708,
	/** Footer margin from bottom: 708 twips (0.5 inches) */
	FOOTER: 708,
	/** Gutter margin for binding: 0 twips */
	GUTTER: 0
};
/**
* Default page size values (in twips, A4 portrait).
*
* A4 size is 210mm x 297mm (8.27" x 11.69").
*
* @property WIDTH - Page width: 11906 twips (8.27 inches, 210mm)
* @property HEIGHT - Page height: 16838 twips (11.69 inches, 297mm)
* @property ORIENTATION - Page orientation: portrait
*/
var sectionPageSizeDefaults = {
	/** Page width: 11906 twips (8.27 inches, 210mm) */
	WIDTH: 11906,
	/** Page height: 16838 twips (11.69 inches, 297mm) */
	HEIGHT: 16838,
	/** Page orientation: portrait */
	ORIENTATION: PageOrientation.PORTRAIT
};
/**
* Represents section properties (sectPr) in a WordprocessingML document.
*
* Section properties define the page layout for a section of the document,
* including page size, margins, headers/footers, columns, and page numbering.
* A document can contain multiple sections with different properties.
*
* Reference: http://officeopenxml.com/WPsection.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_SectPr">
*   <xsd:sequence>
*     <xsd:group ref="EG_HdrFtrReferences" minOccurs="0" maxOccurs="6"/>
*     <xsd:group ref="EG_SectPrContents" minOccurs="0"/>
*     <xsd:element name="sectPrChange" type="CT_SectPrChange" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attributeGroup ref="AG_SectPrAttributes"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create section with custom page size and margins
* new SectionProperties({
*   page: {
*     size: {
*       width: 12240,
*       height: 15840,
*       orientation: PageOrientation.PORTRAIT
*     },
*     margin: {
*       top: 1440,
*       right: 1440,
*       bottom: 1440,
*       left: 1440
*     },
*     pageNumbers: {
*       start: 1,
*       formatType: NumberFormat.DECIMAL
*     }
*   },
*   column: {
*     count: 2,
*     space: 720
*   }
* });
* ```
*/
var SectionProperties = class SectionProperties extends XmlComponent {
	constructor({ page: { size: { width = sectionPageSizeDefaults.WIDTH, height = sectionPageSizeDefaults.HEIGHT, orientation = sectionPageSizeDefaults.ORIENTATION, code } = {}, margin: { top = sectionMarginDefaults.TOP, right = sectionMarginDefaults.RIGHT, bottom = sectionMarginDefaults.BOTTOM, left = sectionMarginDefaults.LEFT, header = sectionMarginDefaults.HEADER, footer = sectionMarginDefaults.FOOTER, gutter = sectionMarginDefaults.GUTTER } = {}, pageNumbers = {}, borders, textDirection } = {}, grid: { linePitch = 360, charSpace, type: gridType } = {}, headerWrapperGroup = {}, footerWrapperGroup = {}, lineNumbers, titlePage, verticalAlign, column, type, footnoteProperties, endnoteProperties, revision } = {}) {
		super("w:sectPr");
		_defineProperty(
			this,
			/**
			* Width, in twips, available to block-level content in this section.
			*
			* This is the page width (accounting for orientation) minus the left and right
			* margins and the gutter. When the section is laid out in several columns, it is
			* the width of a single column. Percentage table widths are resolved against it.
			*/
			"availableTextWidth",
			void 0
		);
		this.availableTextWidth = SectionProperties.calculateAvailableTextWidth({
			pageWidth: orientation === PageOrientation.LANDSCAPE ? height : width,
			left,
			right,
			gutter,
			column
		});
		this.addHeaderFooterGroup(HeaderFooterType.HEADER, headerWrapperGroup);
		this.addHeaderFooterGroup(HeaderFooterType.FOOTER, footerWrapperGroup);
		if (footnoteProperties) this.root.push(createFootnoteProperties(footnoteProperties));
		if (endnoteProperties) this.root.push(createEndnoteProperties(endnoteProperties));
		if (type) this.root.push(createSectionType(type));
		this.root.push(createPageSize({
			width,
			height,
			orientation,
			code
		}));
		this.root.push(createPageMargin(top, right, bottom, left, header, footer, gutter));
		if (borders) this.root.push(new PageBorders(borders));
		if (lineNumbers) this.root.push(createLineNumberType(lineNumbers));
		this.root.push(createPageNumberType(pageNumbers));
		if (column) this.root.push(createColumns(column));
		if (verticalAlign) this.root.push(createVerticalAlign(verticalAlign));
		if (titlePage !== void 0) this.root.push(new OnOffElement("w:titlePg", titlePage));
		if (textDirection) this.root.push(new PageTextDirection(textDirection));
		this.root.push(createDocumentGrid({
			linePitch,
			charSpace,
			type: gridType
		}));
		if (revision) this.root.push(new SectionPropertiesChange(revision));
	}
	/**
	* Width, in twips, available to block-level content (paragraphs and tables) in this section.
	*
	* Page width minus the left and right margins and the gutter, divided among the
	* section's columns when there is more than one. Tables use this to resolve
	* percentage widths into the absolute twip grid that Google Docs, Apple Pages and
	* other consumers lay tables out from.
	*
	* @example
	* ```typescript
	* // A4 portrait with 1 inch margins
	* new SectionProperties().AvailableTextWidth; // 11906 - 1440 - 1440 = 9026
	* ```
	*/
	get AvailableTextWidth() {
		return this.availableTextWidth;
	}
	static calculateAvailableTextWidth({ pageWidth, left, right, gutter, column }) {
		var _column$count, _column$space;
		const textWidth = universalMeasureToTwips(pageWidth) - universalMeasureToTwips(left) - universalMeasureToTwips(right) - universalMeasureToTwips(gutter);
		const columnCount = (_column$count = column === null || column === void 0 ? void 0 : column.count) !== null && _column$count !== void 0 ? _column$count : 1;
		if (columnCount <= 1) return textWidth;
		return (textWidth - universalMeasureToTwips((_column$space = column === null || column === void 0 ? void 0 : column.space) !== null && _column$space !== void 0 ? _column$space : 720) * (columnCount - 1)) / columnCount;
	}
	addHeaderFooterGroup(type, group) {
		if (group.default) this.root.push(createHeaderFooterReference(type, {
			type: HeaderFooterReferenceType.DEFAULT,
			id: group.default.View.ReferenceId
		}));
		if (group.first) this.root.push(createHeaderFooterReference(type, {
			type: HeaderFooterReferenceType.FIRST,
			id: group.first.View.ReferenceId
		}));
		if (group.even) this.root.push(createHeaderFooterReference(type, {
			type: HeaderFooterReferenceType.EVEN,
			id: group.even.View.ReferenceId
		}));
	}
};
var SectionPropertiesChange = class extends XmlComponent {
	constructor(options) {
		super("w:sectPrChange");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
		this.root.push(new SectionProperties(options));
	}
};
/**
* Document body module for WordprocessingML documents.
*
* Reference: http://officeopenxml.com/WPdocument.php
*
* @module
*/
/**
* Represents the document body in a WordprocessingML document.
*
* The body element is the container for all block-level content in the document.
* This includes paragraphs, tables, and section properties that define page layout.
*
* The body supports multiple sections, where each section (except the last one) must
* have its section properties stored in a paragraph's properties at the end of that
* section. The last section's properties are stored as a direct child of the body element.
*
* Reference: http://officeopenxml.com/WPdocument.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Body">
*   <xsd:sequence>
*     <xsd:group ref="EG_BlockLevelElts" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="sectPr" minOccurs="0" maxOccurs="1" type="CT_SectPr"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Body is typically created internally by the Document class
* const doc = new Document({});
* const body = doc.Body;
*
* // Add content to the body via Document.add()
* doc.add(new Paragraph("Content in first section"));
*
* // Add a new section
* body.addSection({
*   page: {
*     size: { width: 12240, height: 15840 },
*   },
* });
*
* // Content after addSection belongs to the new section
* doc.add(new Paragraph("Content in second section"));
* ```
*/
var Body = class extends XmlComponent {
	constructor({ pageNumbers } = {}) {
		super("w:body");
		_defineProperty(this, "sections", []);
		_defineProperty(
			this,
			/**
			* Section properties that were moved into a paragraph at the end of their section
			* by {@link addSection}, keyed by that paragraph. Used to find the section that
			* governs a given child of the body, and to write each section's properties into
			* its paragraph while the body is written.
			*/
			"sectionParagraphs",
			/* @__PURE__ */ new Map()
		);
		_defineProperty(this, "headingBookmarkIds", new HeadingBookmarkIds());
		_defineProperty(this, "pageNumbers", void 0);
		this.pageNumbers = pageNumbers;
	}
	/**
	* Finds the section properties that govern a top-level child of the body.
	*
	* A section's properties are stored after its content (either in the closing
	* paragraph of the section or, for the last section, at the end of the body), so
	* the governing section is the first one found at or after the child. When no
	* child is given (or it is not a direct child of the body), the first section is
	* returned.
	*
	* @param child - A direct child of the body (paragraph, table, etc.)
	* @returns The governing section properties, or undefined if the body has no sections
	*/
	getSectionPropertiesFor(child) {
		const start = child ? Math.max(this.root.indexOf(child), 0) : 0;
		for (let i = start; i < this.root.length; i++) {
			const component = this.root[i];
			if (component instanceof SectionProperties) return component;
			const section = this.sectionParagraphs.get(component);
			if (section) return section;
		}
		return this.sections[this.sections.length - 1];
	}
	/**
	* Adds new section properties to the document body.
	*
	* Creates a new section by moving the previous section's properties into the last
	* paragraph of that section, and then adding the new section as the current section.
	* When that section doesn't end with a paragraph of its own (it ends with a table, or
	* it is empty), an empty paragraph is added to hold its properties.
	*
	* According to the OOXML specification:
	* - Section properties for all sections except the last must be stored in a paragraph's
	*   properties (pPr/sectPr) at the end of each section
	* - The last section's properties are stored as a direct child of the body element (w:body/w:sectPr)
	*
	* @param options - Section properties configuration (page size, margins, headers, footers, etc.)
	*/
	addSection(options) {
		const currentSection = this.sections.pop();
		const lastParagraph = this.lastParagraphOfSection();
		if (currentSection && lastParagraph) this.sectionParagraphs.set(lastParagraph, currentSection);
		else {
			const sectionParagraph = this.createSectionParagraph();
			this.root.push(sectionParagraph);
			if (currentSection) this.sectionParagraphs.set(sectionParagraph, currentSection);
		}
		this.sections.push(new SectionProperties(options));
	}
	/**
	* Prepares the body element for XML serialization.
	*
	* Ensures that the last section's properties are placed as a direct child of the body
	* element, as required by the OOXML specification. Once the body is written, its tables
	* of contents are filled in from its headings, and, when the body has a page number
	* estimator, its page references are given their page numbers. Its SEQ fields are given
	* their numbers after the tables of contents are filled in, as Word leaves a heading's SEQ
	* number out of its entry.
	*
	* @param context - The XML serialization context
	* @returns The prepared XML object or undefined
	*/
	prepForXml(context) {
		var _this$pageNumbers;
		if (this.sections.length === 1) {
			this.root.splice(0, 1);
			this.root.push(this.sections.pop());
		}
		for (const [paragraph, section] of this.sectionParagraphs) paragraph.addSectionProperties(section);
		let xml;
		try {
			xml = super.prepForXml(context);
		} finally {
			for (const [paragraph, section] of this.sectionParagraphs) paragraph.removeSectionProperties(section);
		}
		const listNumbers = (_this$pageNumbers = this.pageNumbers) === null || _this$pageNumbers === void 0 ? void 0 : _this$pageNumbers.listNumbers;
		fillTablesOfContents(xml, context, this.headingBookmarkIds, listNumbers && ((body) => listNumbers(body, context)));
		if (this.pageNumbers) {
			fillSequenceNumbers(xml, context);
			fillPageNumbers(xml, context, this.pageNumbers);
		}
		return xml;
	}
	/**
	* Adds a block-level component to the body.
	*
	* This method is used internally by the Document class to add paragraphs,
	* tables, and other block-level elements to the document body.
	*
	* @param component - The XML component to add (paragraph, table, etc.)
	*/
	push(component) {
		const section = component instanceof Paragraph ? this.sectionParagraphs.get(component) : void 0;
		if (section) {
			const sectionParagraph = this.createSectionParagraph();
			this.root.splice(this.root.indexOf(component) + 1, 0, sectionParagraph);
			this.sectionParagraphs.delete(component);
			this.sectionParagraphs.set(sectionParagraph, section);
		}
		this.root.push(component);
	}
	/**
	* The paragraph the current section ends with, which can hold its properties.
	*
	* There is none when the section ends with something other than a paragraph, or is empty:
	* its last child is then the placeholder at the start of the body (removed when the body is
	* written) or the paragraph that ends the section before, which has properties of its own.
	*/
	lastParagraphOfSection() {
		const last = this.root[this.root.length - 1];
		return last instanceof Paragraph && last !== this.root[0] && !this.sectionParagraphs.has(last) && this.root.indexOf(last) === this.root.length - 1 ? last : void 0;
	}
	/**
	* An empty paragraph to end a section that has no paragraph of its own to end it. The section's
	* properties are written into it with the others, when the body is written.
	*/
	createSectionParagraph() {
		return new Paragraph({});
	}
};
/**
* Table width module for WordprocessingML documents.
*
* This module provides width specifications for tables and cells.
*
* Reference: http://officeopenxml.com/WPtableWidth.php
*
* @module
*/
/**
* Width type values for tables and cells.
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_TblWidth">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="nil"/>
*     <xsd:enumeration value="pct"/>
*     <xsd:enumeration value="dxa"/>
*     <xsd:enumeration value="auto"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @publicApi
*/
var WidthType = {
	/** Auto. */
	AUTO: "auto",
	/** Value is in twentieths of a point */
	DXA: "dxa",
	/** No (empty) value. */
	NIL: "nil",
	/** Value is in percentage. */
	PERCENTAGE: "pct"
};
/**
* Creates a table width element in a WordprocessingML document.
*
* Used for specifying widths of tables, cells, margins, and indentation.
*
* Reference: http://officeopenxml.com/WPtableWidth.php
*
* @example
* ```typescript
* createTableWidthElement("w:tblW", { size: 5000, type: WidthType.DXA });
* createTableWidthElement("w:tcW", { size: 50, type: WidthType.PERCENTAGE });
* ```
*/
var createTableWidthElement = (name, { type = WidthType.AUTO, size }) => {
	let tableWidthValue = size;
	if (type === WidthType.PERCENTAGE && typeof size === "number") tableWidthValue = Math.round(size * 50);
	return new BuilderElement({
		name,
		attributes: {
			type: {
				key: "w:type",
				value: type
			},
			size: {
				key: "w:w",
				value: measurementOrPercentValue(tableWidthValue)
			}
		}
	});
};
/**
* Column width resolution for tables.
*
* Word lays a table out from its preferred widths (`w:tblW` / `w:tcW`) and only treats
* the table grid (`w:tblGrid`) as a hint. Google Docs, Apple Pages, QuickLook and other
* consumers do the opposite: they take the grid's absolute twip values as the physical
* column widths and ignore percentage preferences. A grid of placeholder values therefore
* collapses every column in those consumers, which is the long-standing "tables are
* broken in Google Docs / Pages" report (#1457, #349, #216, #3015).
*
* This module derives a grid in twips from the table's and cells' preferred widths,
* resolved against the width actually available to the table, so the table renders the
* same everywhere. It is used when the caller does not supply explicit `columnWidths`.
*
* Reference: http://officeopenxml.com/WPtableGrid.php
*
* @module
*/
/**
* Text width, in twips, of a section with the default page size and margins
* (A4 portrait with 1 inch margins). Used when a table is formatted without access to
* its section, e.g. by a bare `Formatter` or inside the patcher.
*/
var DEFAULT_AVAILABLE_WIDTH = sectionPageSizeDefaults.WIDTH - sectionMarginDefaults.LEFT - sectionMarginDefaults.RIGHT - sectionMarginDefaults.GUTTER;
var columnSpanOf = (cell) => cell.options.columnSpan || 1;
/**
* Resolves a preferred width (`ITableWidthProperties`) into twips.
*
* Percentages are taken relative to `referenceWidth`: the available text width for a
* table, or the table width for a cell. Auto and nil widths express no preference.
*
* @param width - The preferred width, if any
* @param referenceWidth - Width in twips that percentages are relative to
* @returns The width in twips, or undefined when there is no usable preference
*/
var resolvePreferredWidth = (width, referenceWidth) => {
	if (!width) return;
	const { type = WidthType.AUTO, size } = width;
	if (type !== WidthType.PERCENTAGE && type !== WidthType.DXA) return;
	const twips = typeof size === "number" ? type === WidthType.PERCENTAGE ? size / 100 * referenceWidth : size : size.endsWith("%") ? Number(size.slice(0, -1)) / 100 * referenceWidth : universalMeasureToTwips(size);
	return twips > 0 ? twips : void 0;
};
/**
* Resolves the width of a table in twips.
*
* A table without a usable preferred width (auto, nil or non-positive) takes up the
* whole available width, which is also what Word does when a table is inserted.
*
* @param width - The table's preferred width, if any
* @param availableWidth - Width in twips available to the table
* @returns The table width in twips
*/
var resolveTableWidth = (width, availableWidth) => {
	var _resolvePreferredWidt;
	return (_resolvePreferredWidt = resolvePreferredWidth(width, availableWidth)) !== null && _resolvePreferredWidt !== void 0 ? _resolvePreferredWidt : availableWidth;
};
/**
* Counts the grid columns of a table: the largest number of columns (taking
* `columnSpan` into account) spanned by any of its rows.
*/
var countGridColumns = (rows) => Math.max(0, ...rows.map((row) => row.cells.reduce((count, cell) => count + columnSpanOf(cell), 0)));
/**
* Derives the widths of a table's grid columns, in twips.
*
* The algorithm mirrors what Word writes into `w:tblGrid` after laying a table out:
*
* 1. The table width is resolved against the available width.
* 2. Each column takes the preferred width of the first cell (top to bottom) that
*    occupies exactly that column. Percentages are relative to the table width.
* 3. Cells spanning several columns share their width among the spanned columns that
*    are still unresolved.
* 4. Any column still unresolved gets an equal share of what is left of the table
*    width (or an equal share of the table width if nothing is left).
*
* @param options.rows - The table rows (including any vertical-merge continuation cells)
* @param options.width - The table's preferred width
* @param options.availableWidth - Width in twips available to the table (text width of the section, or the parent cell for nested tables)
* @returns One width per grid column, rounded to whole twips
*
* @example
* ```typescript
* // A 100% table with 90% / 10% cells in a 9026 twip wide section
* resolveColumnWidths({ rows, width: { size: 100, type: WidthType.PERCENTAGE }, availableWidth: 9026 });
* // => [8123, 903]
* ```
*/
var resolveColumnWidths = ({ rows, width, availableWidth }) => {
	const columnCount = countGridColumns(rows);
	if (columnCount === 0) return [];
	const tableWidth = resolveTableWidth(width, availableWidth);
	const widths = Array.from({ length: columnCount }, () => void 0);
	const spanningCells = [];
	for (const row of rows) {
		let column = 0;
		for (const cell of row.cells) {
			const span = columnSpanOf(cell);
			const cellWidth = resolvePreferredWidth(cell.options.width, tableWidth);
			if (cellWidth !== void 0) {
				if (span === 1) {
					var _column, _widths$_column;
					(_widths$_column = widths[_column = column]) !== null && _widths$_column !== void 0 || (widths[_column] = cellWidth);
				} else spanningCells.push({
					start: column,
					span,
					width: cellWidth
				});
			}
			column += span;
		}
	}
	for (const { start, span, width: cellWidth } of spanningCells) {
		const columns = Array.from({ length: span }, (_, i) => start + i).filter((column) => column < columnCount);
		const unresolvedSpanColumns = columns.filter((column) => widths[column] === void 0);
		const remaining = cellWidth - columns.reduce((sum, column) => {
			var _widths$column;
			return sum + ((_widths$column = widths[column]) !== null && _widths$column !== void 0 ? _widths$column : 0);
		}, 0);
		if (unresolvedSpanColumns.length > 0 && remaining > 0) for (const column of unresolvedSpanColumns) widths[column] = remaining / unresolvedSpanColumns.length;
	}
	const unresolvedColumns = widths.flatMap((columnWidth, column) => columnWidth === void 0 ? [column] : []);
	if (unresolvedColumns.length > 0) {
		const remaining = tableWidth - widths.reduce((sum, columnWidth) => sum + (columnWidth !== null && columnWidth !== void 0 ? columnWidth : 0), 0);
		const share = remaining > 0 ? remaining / unresolvedColumns.length : tableWidth / columnCount;
		for (const column of unresolvedColumns) widths[column] = share;
	}
	return widths.map((columnWidth) => Math.round(columnWidth));
};
/**
* Table grid module for WordprocessingML documents.
*
* The table grid defines the column structure of a table.
*
* Reference: http://officeopenxml.com/WPtableGrid.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblGridCol">
*   <xsd:attribute name="w" type="s:ST_TwipsMeasure"/>
* </xsd:complexType>
* <xsd:complexType name="CT_TblGridBase">
*   <xsd:sequence>
*     <xsd:element name="gridCol" type="CT_TblGridCol" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* <xsd:complexType name="CT_TblGridChange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_Markup">
*       <xsd:sequence>
*         <xsd:element name="tblGrid" type="CT_TblGridBase"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @module
*/
/**
* Creates a single column in the table grid.
*
* The gridCol element specifies the width of a single column.
*/
var createGridCol = (width) => new BuilderElement({
	name: "w:gridCol",
	attributes: width !== void 0 ? { width: {
		key: "w:w",
		value: twipsMeasureValue(width)
	} } : void 0
});
/**
* Creates the table grid for a WordprocessingML document.
*
* The tblGrid element defines the number and width of columns in the table.
*
* Reference: http://officeopenxml.com/WPtableGrid.php
*/
var TableGrid = class extends XmlComponent {
	constructor(widths, revision) {
		super("w:tblGrid");
		for (const width of widths) this.root.push(createGridCol(width));
		if (revision) this.root.push(new TableGridChange(revision));
	}
};
var TableGridChangeAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { id: "w:id" });
	}
};
var TableGridChange = class extends XmlComponent {
	constructor(options) {
		super("w:tblGridChange");
		this.root.push(new TableGridChangeAttributes({ id: options.id }));
		this.root.push(new TableGrid(options.columnWidths));
	}
};
var InsertedTableRow = class extends XmlComponent {
	constructor(options) {
		super("w:ins");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
	}
};
var DeletedTableRow = class extends XmlComponent {
	constructor(options) {
		super("w:del");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
	}
};
var InsertedTableCell = class extends XmlComponent {
	constructor(options) {
		super("w:cellIns");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
	}
};
var DeletedTableCell = class extends XmlComponent {
	constructor(options) {
		super("w:cellDel");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
	}
};
var CellMergeAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			id: "w:id",
			author: "w:author",
			date: "w:date",
			verticalMerge: "w:vMerge",
			verticalMergeOriginal: "w:vMergeOrig"
		});
	}
};
var CellMerge = class extends XmlComponent {
	constructor(options) {
		super("w:cellMerge");
		this.root.push(new CellMergeAttributes(options));
	}
};
/**
* Table cell margin module for WordprocessingML documents.
*
* This module provides cell margin settings for tables and individual cells.
* Margins define the padding between cell content and cell borders.
*
* Reference: http://officeopenxml.com/WPtableCellProperties-Margins.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblCellMar">
*   <xsd:sequence>
*     <xsd:element name="top" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="start" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="left" type="CT_TblWidth" minOccurs="0"/>
*     <xsd:element name="bottom" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="end" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="right" type="CT_TblWidth" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @module
*/
/**
* Builds an array of margin child elements based on the provided options.
*
* @internal
*/
var buildMarginChildren = ({ marginUnitType = WidthType.DXA, top, left, bottom, right }) => [
	{
		name: "w:top",
		size: top
	},
	{
		name: "w:left",
		size: left
	},
	{
		name: "w:bottom",
		size: bottom
	},
	{
		name: "w:right",
		size: right
	}
].filter((entry) => entry.size !== void 0).map(({ name, size }) => createTableWidthElement(name, {
	type: marginUnitType,
	size
}));
/**
* Creates a table-level cell margin element (tblCellMar).
*
* The tblCellMar element specifies the default cell margins for all cells
* in the table. Individual cells can override these defaults using
* cell-level margins (tcMar).
*
* Reference: http://officeopenxml.com/WPtableCellProperties-Margins.php
*
* @param options - The margin options
* @returns An XmlComponent representing the tblCellMar element, or undefined if no margins specified
*
* @example
* ```typescript
* // Table with 100 twip margins on all sides
* new Table({
*   rows: [...],
*   margins: {
*     top: 100,
*     bottom: 100,
*     left: 100,
*     right: 100,
*   },
* });
* ```
*/
var createTableCellMargin = (options) => {
	const children = buildMarginChildren(options);
	if (children.length === 0) return;
	return new BuilderElement({
		name: "w:tblCellMar",
		children
	});
};
/**
* Creates a cell-level margin element (tcMar).
*
* The tcMar element specifies the margins for a specific table cell,
* overriding any table-level default margins (tblCellMar).
*
* Reference: http://officeopenxml.com/WPtableCellProperties-Margins.php
*
* @param options - The margin options
* @returns An XmlComponent representing the tcMar element, or undefined if no margins specified
*
* @example
* ```typescript
* // Cell with custom margins
* new TableCell({
*   children: [...],
*   margins: {
*     top: 50,
*     bottom: 50,
*     left: 100,
*     right: 100,
*   },
* });
* ```
*/
var createCellMargin = (options) => {
	const children = buildMarginChildren(options);
	if (children.length === 0) return;
	return new BuilderElement({
		name: "w:tcMar",
		children
	});
};
/**
* Table cell components module for WordprocessingML documents.
*
* This module provides XML components for table cell properties including borders,
* grid span (column span), vertical merge, and text direction.
*
* Reference: http://officeopenxml.com/WPtableCell.php
*
* @module
*/
/**
* Represents table cell borders (tcBorders) in a WordprocessingML document.
*
* The tcBorders element specifies the borders for a single table cell. Each border
* can be configured independently with different styles, colors, and widths.
*
* Reference: http://officeopenxml.com/WPtableCell.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TcBorders">
*   <xsd:sequence>
*     <xsd:element name="top" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="start" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="left" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="bottom" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="end" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="right" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="insideH" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="insideV" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="tl2br" type="CT_Border" minOccurs="0"/>
*     <xsd:element name="tr2bl" type="CT_Border" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new TableCellBorders({
*   top: { style: BorderStyle.SINGLE, size: 6, color: "FF0000" },
*   bottom: { style: BorderStyle.SINGLE, size: 6, color: "0000FF" },
*   diagonalDown: { style: BorderStyle.SINGLE, size: 4, color: "000000" },
* });
* ```
*/
var TableCellBorders = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:tcBorders");
		if (options.top) this.root.push(createBorderElement("w:top", options.top));
		if (options.start) this.root.push(createBorderElement("w:start", options.start));
		if (options.left) this.root.push(createBorderElement("w:left", options.left));
		if (options.bottom) this.root.push(createBorderElement("w:bottom", options.bottom));
		if (options.end) this.root.push(createBorderElement("w:end", options.end));
		if (options.right) this.root.push(createBorderElement("w:right", options.right));
		if (options.diagonalDown) this.root.push(createBorderElement("w:tl2br", options.diagonalDown));
		if (options.diagonalUp) this.root.push(createBorderElement("w:tr2bl", options.diagonalUp));
	}
};
/**
* Attributes for the GridSpan element.
*/
var GridSpanAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { val: "w:val" });
	}
};
/**
* Represents a grid span (gridSpan) element in a WordprocessingML document.
*
* The gridSpan element specifies the number of logical columns this cell spans
* in the table grid. This is used to merge cells horizontally (column span).
*
* Reference: http://officeopenxml.com/WPtableCell.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_DecimalNumber">
*   <xsd:attribute name="val" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Cell spanning 3 columns
* new GridSpan(3);
* ```
*/
var GridSpan = class extends XmlComponent {
	constructor(value) {
		super("w:gridSpan");
		this.root.push(new GridSpanAttributes({ val: decimalNumber(value) }));
	}
};
/**
* Vertical merge types for table cells.
*
* Defines the merge behavior for vertically merged cells (row span).
*/
var VerticalMergeType = {
	/**
	* Cell that is merged with upper one.
	* This cell continues a vertical merge started by a cell above it.
	*/
	CONTINUE: "continue",
	/**
	* Cell that is starting the vertical merge.
	* This cell begins a new vertical merge region.
	*/
	RESTART: "restart"
};
/**
* Attributes for the VerticalMerge element.
*/
var VerticalMergeAttributes = class extends XmlAttributeComponent {
	constructor(..._args2) {
		super(..._args2);
		_defineProperty(this, "xmlKeys", { val: "w:val" });
	}
};
/**
* Represents a vertical merge (vMerge) element in a WordprocessingML document.
*
* The vMerge element specifies that this cell is part of a vertically merged region.
* Cells can either restart a new merge region or continue an existing one from above.
* This is used to create row spans in tables.
*
* Reference: http://officeopenxml.com/WPtableCell.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_VMerge">
*   <xsd:attribute name="val" type="ST_Merge"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // First cell in a vertical merge
* new VerticalMerge(VerticalMergeType.RESTART);
*
* // Subsequent cells that continue the merge
* new VerticalMerge(VerticalMergeType.CONTINUE);
* ```
*/
var VerticalMerge = class extends XmlComponent {
	constructor(value) {
		super("w:vMerge");
		this.root.push(new VerticalMergeAttributes({ val: value }));
	}
};
/**
* Attributes for the TDirection element.
*/
var TDirectionAttributes = class extends XmlAttributeComponent {
	constructor(..._args3) {
		super(..._args3);
		_defineProperty(this, "xmlKeys", { val: "w:val" });
	}
};
/**
* Represents a text direction (textDirection) element in a WordprocessingML document.
*
* The textDirection element specifies the flow of text within a table cell. This is
* useful for creating rotated text or supporting different writing systems.
*
* Reference: http://officeopenxml.com/WPtableCell.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TextDirection">
*   <xsd:attribute name="val" type="ST_TextDirection" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Vertical text flowing from top to bottom
* new TDirection(TextDirection.TOP_TO_BOTTOM_RIGHT_TO_LEFT);
* ```
*/
var TDirection = class extends XmlComponent {
	constructor(value) {
		super("w:textDirection");
		this.root.push(new TDirectionAttributes({ val: value }));
	}
};
/**
* Table cell properties module for WordprocessingML documents.
*
* This module provides cell-level properties including width, borders,
* shading, margins, and merge settings.
*
* Reference: http://officeopenxml.com/WPtableCellProperties.php
*
* @module
*/
/**
* Represents table cell properties (tcPr) in a WordprocessingML document.
*
* The tcPr element specifies properties for a table cell including width,
* borders, shading, margins, text direction, vertical alignment, and merge settings.
* These properties control the appearance and behavior of individual table cells.
*
* Reference: http://officeopenxml.com/WPtableCellProperties.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TcPr">
*   <xsd:complexContent>
*     <xsd:extension base="CT_TcPrInner">
*       <xsd:sequence>
*         <xsd:element name="tcPrChange" type="CT_TcPrChange" minOccurs="0"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_TcPrInner">
*   <xsd:complexContent>
*     <xsd:extension base="CT_TcPrBase">
*       <xsd:sequence>
*         <xsd:group ref="EG_CellMarkupElements" minOccurs="0" maxOccurs="1"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_TcPrBase">
*   <xsd:sequence>
*     <xsd:element name="cnfStyle" type="CT_Cnf" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tcW" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="gridSpan" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="hMerge" type="CT_HMerge" minOccurs="0"/>
*     <xsd:element name="vMerge" type="CT_VMerge" minOccurs="0"/>
*     <xsd:element name="tcBorders" type="CT_TcBorders" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="shd" type="CT_Shd" minOccurs="0"/>
*     <xsd:element name="noWrap" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="tcMar" type="CT_TcMar" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="textDirection" type="CT_TextDirection" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tcFitText" type="CT_OnOff" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="vAlign" type="CT_VerticalJc" minOccurs="0"/>
*     <xsd:element name="hideMark" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="headers" type="CT_Headers" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
*
* <xsd:group name="EG_CellMarkupElements">
*   <xsd:choice>
*     <xsd:element name="cellIns" type="CT_TrackChange" minOccurs="0"/>
*     <xsd:element name="cellDel" type="CT_TrackChange" minOccurs="0"/>
*     <xsd:element name="cellMerge" type="CT_CellMergeTrackChange" minOccurs="0"/>
*   </xsd:choice>
* </xsd:group>
*
* <xsd:complexType name="CT_TcPrChange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_TrackChange">
*       <xsd:sequence>
*         <xsd:element name="tcPr" type="CT_TcPrInner" minOccurs="1"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new TableCellProperties({
*   width: { size: 3000, type: WidthType.DXA },
*   shading: { fill: "EEEEEE" },
*   verticalAlign: VerticalAlign.CENTER,
*   columnSpan: 2,
* });
* ```
*/
var TableCellProperties = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:tcPr", options.includeIfEmpty);
		_defineProperty(this, "hasWidth", void 0);
		_defineProperty(this, "hasColumnWidth", false);
		this.hasWidth = options.width !== void 0;
		if (options.width) this.root.push(createTableWidthElement("w:tcW", options.width));
		if (options.columnSpan) this.root.push(new GridSpan(options.columnSpan));
		if (options.verticalMerge) this.root.push(new VerticalMerge(options.verticalMerge));
		else if (options.rowSpan && options.rowSpan > 1) this.root.push(new VerticalMerge(VerticalMergeType.RESTART));
		if (options.borders) this.root.push(new TableCellBorders(options.borders));
		if (options.shading) this.root.push(createShading(options.shading));
		if (options.margins) {
			const cellMargin = createCellMargin(options.margins);
			if (cellMargin) this.root.push(cellMargin);
		}
		if (options.textDirection) this.root.push(new TDirection(options.textDirection));
		if (options.verticalAlign) this.root.push(createVerticalAlign(options.verticalAlign));
		if (options.insertion) this.root.push(new InsertedTableCell(options.insertion));
		if (options.deletion) this.root.push(new DeletedTableCell(options.deletion));
		if (options.cellMerge) this.root.push(new CellMerge(options.cellMerge));
		if (options.revision) this.root.push(new TableCellPropertiesChange(options.revision));
	}
	/**
	* Gives a cell without a width of its own the width of the table's columns it spans, in twips.
	*
	* @internal
	*/
	setColumnWidth(twips) {
		if (this.hasWidth) return;
		this.root.splice(0, this.hasColumnWidth ? 1 : 0, createTableWidthElement("w:tcW", {
			size: twips,
			type: WidthType.DXA
		}));
		this.hasColumnWidth = true;
	}
};
var TableCellPropertiesChange = class extends XmlComponent {
	constructor(options) {
		super("w:tcPrChange");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
		this.root.push(new TableCellProperties(_objectSpread2(_objectSpread2({}, options), {}, { includeIfEmpty: true })));
	}
};
/**
* Represents a table cell in a WordprocessingML document.
*
* A table cell is the basic unit of content within a table. Each cell can contain
* paragraphs, nested tables, or other block-level content. Cells must always end
* with a paragraph element.
*
* Reference: http://officeopenxml.com/WPtableCell.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Tc">
*   <xsd:sequence>
*     <xsd:element name="tcPr" type="CT_TcPr" minOccurs="0" maxOccurs="1"/>
*     <xsd:group ref="EG_BlockLevelElts" minOccurs="1" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="id" type="s:ST_String" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new TableCell({
*   children: [new Paragraph("Cell content")],
*   width: { size: 3000, type: WidthType.DXA },
* });
* ```
*/
var TableCell = class extends XmlComponent {
	constructor(options) {
		super("w:tc");
		_defineProperty(
			this,
			/**
			* The options the cell was created with.
			*
			* Its borders and shading are declared with hex colors, as they were before they took colors of the document's
			* theme, so that code reading them still compiles. A cell given a theme color has it here as it was given.
			*/
			"options",
			void 0
		);
		_defineProperty(this, "properties", void 0);
		this.options = options;
		this.properties = new TableCellProperties(options);
		this.root.push(this.properties);
		for (const child of options.children) this.root.push(child);
	}
	/**
	* Gives the cell, unless it has a width of its own, the width of the table's columns it spans, in twips.
	*
	* @internal
	*/
	setColumnWidth(twips) {
		this.properties.setColumnWidth(twips);
	}
	prepForXml(context) {
		if (elementOf(this.root[this.root.length - 1]) !== "w:p") this.root.push(new Paragraph({}));
		return super.prepForXml(context);
	}
};
/**
* On/off elements of tables that Office only takes "on" and "off" for.
*
* @module
*/
/**
* Creates an on/off element that Office only takes "on" and "off" for.
*
* ISO 29500 types a table's w:bidiVisual and a row's w:cantSplit and w:tblHeader as CT_OnOff, which takes true, false,
* 1, 0, on and off. Office's schema types them as CT_OnOffOnly, which only takes on and off, so Word's validator rejects
* w:val="false". Off is written as "off", which both accept.
*
* @example
* ```typescript
* createOnOffOnlyElement("w:cantSplit", true);
* // Generates: <w:cantSplit/>
*
* createOnOffOnlyElement("w:cantSplit", false);
* // Generates: <w:cantSplit w:val="off"/>
* ```
*
* @internal
*/
var createOnOffOnlyElement = (name, value) => value ? new OnOffElement(name) : new StringValueElement(name, "off");
/**
* Table cell spacing module for WordprocessingML documents.
*
* This module provides cell spacing settings for tables, controlling
* the space between cells in a table.
*
* Reference: http://officeopenxml.com/WPtableCellSpacing.php
*
* @module
*/
/**
* Cell spacing measurement types.
*
* ## XSD Schema
* ```xml
* <xsd:simpleType name="ST_TblCellSpacing">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="nil"/>
*     <xsd:enumeration value="dxa"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*/
var CellSpacingType = {
	/** Value is in twentieths of a point */
	DXA: "dxa",
	/** No (empty) value. */
	NIL: "nil"
};
/**
* Creates table cell spacing in a WordprocessingML document.
*
* The tblCellSpacing element specifies the spacing between cells in a table.
*
* Reference: http://officeopenxml.com/WPtableCellSpacing.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblCellSpacing">
*   <xsd:attribute name="w" type="ST_MeasurementOrPercent"/>
*   <xsd:attribute name="type" type="ST_TblCellSpacing"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* createTableCellSpacing({ value: 100, type: CellSpacingType.DXA });
* ```
*/
var createTableCellSpacing = ({ type = CellSpacingType.DXA, value }) => new BuilderElement({
	name: "w:tblCellSpacing",
	attributes: {
		type: {
			key: "w:type",
			value: type
		},
		value: {
			key: "w:w",
			value: measurementOrPercentValue(value)
		}
	}
});
/**
* Table borders module for WordprocessingML documents.
*
* This module provides border options for tables.
*
* Reference: http://officeopenxml.com/WPtableBorders.php
*
* @module
*/
var NONE_BORDER = {
	style: BorderStyle.NONE,
	size: 0,
	color: "auto"
};
var DEFAULT_BORDER = {
	style: BorderStyle.SINGLE,
	size: 4,
	color: "auto"
};
/**
* Represents table borders in a WordprocessingML document.
*
* The tblBorders element specifies the borders for all cells in the table. Each side that isn't given is a thin single
* line, unless `fillMissingSides` is false, when it is left to the table's style.
*
* Reference: http://officeopenxml.com/WPtableBorders.php
*
* @publicApi
*
* @example
* ```typescript
* new TableBorders({
*   top: { style: BorderStyle.SINGLE, size: 6, color: "000000" },
*   bottom: { style: BorderStyle.SINGLE, size: 6, color: "000000" },
* });
*
* // To remove all borders
* new TableBorders(TableBorders.NONE);
* ```
*/
var TableBorders = class extends IgnoreIfEmptyXmlComponent {
	constructor(options, { fillMissingSides = true } = {}) {
		super("w:tblBorders");
		const sides = [
			["w:top", options.top],
			["w:left", options.left],
			["w:bottom", options.bottom],
			["w:right", options.right],
			["w:insideH", options.insideHorizontal],
			["w:insideV", options.insideVertical]
		];
		for (const [elementName, border] of sides) {
			const resolved = border !== null && border !== void 0 ? border : fillMissingSides ? DEFAULT_BORDER : void 0;
			if (resolved) this.root.push(createBorderElement(elementName, resolved));
		}
	}
};
_defineProperty(TableBorders, "NONE", {
	top: NONE_BORDER,
	bottom: NONE_BORDER,
	left: NONE_BORDER,
	right: NONE_BORDER,
	insideHorizontal: NONE_BORDER,
	insideVertical: NONE_BORDER
});
/**
* Relative horizontal position values for floating tables.
*/
var RelativeHorizontalPosition = {
	CENTER: "center",
	INSIDE: "inside",
	LEFT: "left",
	OUTSIDE: "outside",
	RIGHT: "right"
};
/**
* Relative vertical position values for floating tables.
*/
var RelativeVerticalPosition = {
	CENTER: "center",
	INSIDE: "inside",
	BOTTOM: "bottom",
	OUTSIDE: "outside",
	/**
	* In line with the text, with no text beside it. Word places a floating table lined up inline at the top of the
	* paragraph after it, with text beside it, so the table is written in line with the text instead.
	*/
	INLINE: "inline",
	TOP: "top"
};
/**
* Creates floating table properties in a WordprocessingML document.
*
* This element specifies the positioning of a floating table,
* including anchor points, offsets, and text wrapping behavior.
* The overlap option isn't part of it: the table properties write it as w:tblOverlap.
*
* Reference: http://officeopenxml.com/WPtableFloating.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblPPr">
*   <xsd:attribute name="leftFromText" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="rightFromText" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="topFromText" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="bottomFromText" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="vertAnchor" type="ST_VAnchor"/>
*   <xsd:attribute name="horzAnchor" type="ST_HAnchor"/>
*   <xsd:attribute name="tblpXSpec" type="s:ST_XAlign"/>
*   <xsd:attribute name="tblpX" type="ST_SignedTwipsMeasure"/>
*   <xsd:attribute name="tblpYSpec" type="s:ST_YAlign"/>
*   <xsd:attribute name="tblpY" type="ST_SignedTwipsMeasure"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* createTableFloatProperties({
*   horizontalAnchor: TableAnchorType.MARGIN,
*   relativeHorizontalPosition: RelativeHorizontalPosition.CENTER,
*   topFromText: 200,
*   bottomFromText: 200,
* });
* ```
*/
var createTableFloatProperties = ({ horizontalAnchor, verticalAnchor, absoluteHorizontalPosition, relativeHorizontalPosition, absoluteVerticalPosition, relativeVerticalPosition, bottomFromText, topFromText, leftFromText, rightFromText }) => new BuilderElement({
	name: "w:tblpPr",
	attributes: {
		leftFromText: {
			key: "w:leftFromText",
			value: leftFromText === void 0 ? void 0 : twipsMeasureValue(leftFromText)
		},
		rightFromText: {
			key: "w:rightFromText",
			value: rightFromText === void 0 ? void 0 : twipsMeasureValue(rightFromText)
		},
		topFromText: {
			key: "w:topFromText",
			value: topFromText === void 0 ? void 0 : twipsMeasureValue(topFromText)
		},
		bottomFromText: {
			key: "w:bottomFromText",
			value: bottomFromText === void 0 ? void 0 : twipsMeasureValue(bottomFromText)
		},
		absoluteHorizontalPosition: {
			key: "w:tblpX",
			value: absoluteHorizontalPosition === void 0 ? void 0 : signedTwipsMeasureValue(absoluteHorizontalPosition)
		},
		absoluteVerticalPosition: {
			key: "w:tblpY",
			value: absoluteVerticalPosition === void 0 ? void 0 : signedTwipsMeasureValue(absoluteVerticalPosition)
		},
		horizontalAnchor: {
			key: "w:horzAnchor",
			value: horizontalAnchor
		},
		relativeHorizontalPosition: {
			key: "w:tblpXSpec",
			value: relativeHorizontalPosition
		},
		relativeVerticalPosition: {
			key: "w:tblpYSpec",
			value: relativeVerticalPosition
		},
		verticalAnchor: {
			key: "w:vertAnchor",
			value: verticalAnchor
		}
	}
});
/**
* Creates table layout settings in a WordprocessingML document.
*
* The tblLayout element specifies the algorithm used to lay out the table.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblLayoutType">
*   <xsd:attribute name="type" type="ST_TblLayoutType"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* createTableLayout(TableLayoutType.FIXED);
* ```
*/
var createTableLayout = (type) => new BuilderElement({
	name: "w:tblLayout",
	attributes: { type: {
		key: "w:type",
		value: type
	} }
});
/**
* Table look module for WordprocessingML documents.
*
* Table look specifies conditional formatting settings that determine which
* special formatting is applied to a table. These settings control whether
* special formatting is applied to the first row, last row, first column,
* last column, and whether to display horizontal or vertical banding.
*
* Reference: http://officeopenxml.com/WPtblLook.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblLook">
*   <xsd:attribute name="firstRow" type="s:ST_OnOff"/>
*   <xsd:attribute name="lastRow" type="s:ST_OnOff"/>
*   <xsd:attribute name="firstColumn" type="s:ST_OnOff"/>
*   <xsd:attribute name="lastColumn" type="s:ST_OnOff"/>
*   <xsd:attribute name="noHBand" type="s:ST_OnOff"/>
*   <xsd:attribute name="noVBand" type="s:ST_OnOff"/>
* </xsd:complexType>
* ```
*
* @module
*/
/**
* Creates a table look element for conditional formatting settings.
*
* The tblLook element specifies which conditional formatting settings
* are active for a table. These settings work in conjunction with table
* styles to apply special formatting to specific regions of the table.
*
* Reference: http://officeopenxml.com/WPtblLook.php
*
* @example
* ```typescript
* // Table with header row formatting and alternating row colors
* new Table({
*   rows: [...],
*   tableLook: {
*     firstRow: true,
*     noHBand: false,
*     noVBand: true,
*   },
* });
* ```
*/
var createTableLook = ({ firstRow, lastRow, firstColumn, lastColumn, noHBand, noVBand }) => new BuilderElement({
	name: "w:tblLook",
	attributes: {
		firstRow: {
			key: "w:firstRow",
			value: firstRow
		},
		lastRow: {
			key: "w:lastRow",
			value: lastRow
		},
		firstColumn: {
			key: "w:firstColumn",
			value: firstColumn
		},
		lastColumn: {
			key: "w:lastColumn",
			value: lastColumn
		},
		noHBand: {
			key: "w:noHBand",
			value: noHBand
		},
		noVBand: {
			key: "w:noVBand",
			value: noVBand
		}
	}
});
/**
* Table properties module for WordprocessingML documents.
*
* This module provides table-level properties including width, borders,
* layout, alignment, and margins.
*
* Reference: http://officeopenxml.com/WPtableProperties.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TblPrBase">
*   <xsd:sequence>
*     <xsd:element name="tblStyle" type="CT_String" minOccurs="0"/>
*     <xsd:element name="tblpPr" type="CT_TblPPr" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblOverlap" type="CT_TblOverlap" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="bidiVisual" type="CT_OnOff" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblStyleRowBandSize" type="CT_DecimalNumber" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblStyleColBandSize" type="CT_DecimalNumber" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblW" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="jc" type="CT_JcTable" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblCellSpacing" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblInd" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblBorders" type="CT_TblBorders" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="shd" type="CT_Shd" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblLayout" type="CT_TblLayoutType" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblCellMar" type="CT_TblCellMar" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblLook" type="CT_TblLook" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblCaption" type="CT_String" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblDescription" type="CT_String" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
* </xsd:complexType>
*
* <xsd:complexType name="CT_TblPrChange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_TrackChange">
*       <xsd:sequence>
*         <xsd:element name="tblPr" type="CT_TblPrBase"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @module
*/
var createTableOverlap = (overlap) => new BuilderElement({
	name: "w:tblOverlap",
	attributes: { val: {
		key: "w:val",
		value: overlap
	} }
});
var INLINE_ALIGNMENTS = {
	[RelativeHorizontalPosition.LEFT]: AlignmentType.LEFT,
	[RelativeHorizontalPosition.CENTER]: AlignmentType.CENTER,
	[RelativeHorizontalPosition.RIGHT]: AlignmentType.RIGHT
};
/**
* Represents table properties (tblPr) in a WordprocessingML document.
*
* The tblPr element specifies the properties for a table including width,
* alignment, borders, margins, and layout.
*
* Reference: http://officeopenxml.com/WPtableProperties.php
*/
var TableProperties = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		var _options$float, _options$alignment, _options$float2;
		super("w:tblPr", options.includeIfEmpty);
		if (options.style) this.root.push(new StringValueElement("w:tblStyle", options.style));
		const inline = ((_options$float = options.float) === null || _options$float === void 0 ? void 0 : _options$float.relativeVerticalPosition) === RelativeVerticalPosition.INLINE;
		const float = inline ? void 0 : options.float;
		if (float) this.root.push(createTableFloatProperties(float));
		if (float === null || float === void 0 ? void 0 : float.overlap) this.root.push(createTableOverlap(float.overlap));
		if (options.visuallyRightToLeft !== void 0) this.root.push(createOnOffOnlyElement("w:bidiVisual", options.visuallyRightToLeft));
		if (options.width) this.root.push(createTableWidthElement("w:tblW", options.width));
		const alignment = (_options$alignment = options.alignment) !== null && _options$alignment !== void 0 ? _options$alignment : inline && ((_options$float2 = options.float) === null || _options$float2 === void 0 ? void 0 : _options$float2.relativeHorizontalPosition) ? INLINE_ALIGNMENTS[options.float.relativeHorizontalPosition] : void 0;
		if (alignment) this.root.push(createAlignment(alignment));
		if (options.cellSpacing) this.root.push(createTableCellSpacing(options.cellSpacing));
		if (options.indent) this.root.push(createTableWidthElement("w:tblInd", options.indent));
		if (options.borders) this.root.push(new TableBorders(options.borders, { fillMissingSides: !options.style }));
		if (options.shading) this.root.push(createShading(options.shading));
		if (options.layout) this.root.push(createTableLayout(options.layout));
		if (options.cellMargin) {
			const cellMargin = createTableCellMargin(options.cellMargin);
			if (cellMargin) this.root.push(cellMargin);
		}
		if (options.tableLook) this.root.push(createTableLook(options.tableLook));
		if (options.revision) this.root.push(new TablePropertiesChange(options.revision));
	}
};
var TablePropertiesChange = class extends XmlComponent {
	constructor(options) {
		super("w:tblPrChange");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
		this.root.push(new TableProperties(_objectSpread2(_objectSpread2({}, options), {}, { includeIfEmpty: true })));
	}
};
/**
* Creates table row height (trHeight) in a WordprocessingML document.
*
* The trHeight element specifies the height of a table row, along with a rule
* determining how the height should be applied.
*
* Reference: http://officeopenxml.com/WPtableRow.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Height">
*   <xsd:attribute name="val" type="s:ST_TwipsMeasure"/>
*   <xsd:attribute name="hRule" type="ST_HeightRule"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* createTableRowHeight(1000, HeightRule.EXACT);
* ```
*/
var createTableRowHeight = (value, rule) => new BuilderElement({
	name: "w:trHeight",
	attributes: {
		value: {
			key: "w:val",
			value: twipsMeasureValue(value)
		},
		rule: {
			key: "w:hRule",
			value: rule
		}
	}
});
/**
* Table row properties module for WordprocessingML documents.
*
* This module provides row-level properties including height and header row settings.
*
* Reference: http://officeopenxml.com/WPtableRowProperties.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_TrPrBase">
*   <xsd:choice maxOccurs="unbounded">
*     <xsd:element name="cnfStyle" type="CT_Cnf" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="divId" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="gridBefore" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="gridAfter" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="wBefore" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="wAfter" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="cantSplit" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="trHeight" type="CT_Height" minOccurs="0"/>
*     <xsd:element name="tblHeader" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="tblCellSpacing" type="CT_TblWidth" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="jc" type="CT_JcTable" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="hidden" type="CT_OnOff" minOccurs="0"/>
*   </xsd:choice>
* </xsd:complexType>
* <xsd:complexType name="CT_TrPr">
*   <xsd:complexContent>
*     <xsd:extension base="CT_TrPrBase">
*       <xsd:sequence>
*         <xsd:element name="ins" type="CT_TrackChange" minOccurs="0"/>
*         <xsd:element name="del" type="CT_TrackChange" minOccurs="0"/>
*         <xsd:element name="trPrChange" type="CT_TrPrChange" minOccurs="0"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* <xsd:complexType name="CT_TrPrChange">
*   <xsd:complexContent>
*     <xsd:extension base="CT_TrackChange">
*       <xsd:sequence>
*         <xsd:element name="trPr" type="CT_TrPrBase" minOccurs="1"/>
*       </xsd:sequence>
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
* ```
*
* @module
*/
/**
* Represents table row properties (trPr) in a WordprocessingML document.
*
* The trPr element specifies properties for a table row including height,
* whether it can split across pages, and whether it's a header row.
*
* Reference: http://officeopenxml.com/WPtableRowProperties.php
*
* @example
* ```typescript
* new TableRowProperties({
*   cantSplit: true,
*   tableHeader: true,
*   height: {
*     value: 1000,
*     rule: HeightRule.EXACT,
*   },
* });
* ```
*/
var TableRowProperties = class extends IgnoreIfEmptyXmlComponent {
	constructor(options) {
		super("w:trPr", options.includeIfEmpty);
		if (options.cantSplit !== void 0) this.root.push(createOnOffOnlyElement("w:cantSplit", options.cantSplit));
		if (options.tableHeader !== void 0) this.root.push(createOnOffOnlyElement("w:tblHeader", options.tableHeader));
		if (options.height) this.root.push(createTableRowHeight(options.height.value, options.height.rule));
		if (options.cellSpacing) this.root.push(createTableCellSpacing(options.cellSpacing));
		if (options.insertion) this.root.push(new InsertedTableRow(options.insertion));
		if (options.deletion) this.root.push(new DeletedTableRow(options.deletion));
		if (options.revision) this.root.push(new TableRowPropertiesChange(options.revision));
	}
};
var TableRowPropertiesChange = class extends XmlComponent {
	constructor(options) {
		super("w:trPrChange");
		this.root.push(new ChangeAttributes({
			id: options.id,
			author: options.author,
			date: options.date
		}));
		this.root.push(new TableRowProperties(_objectSpread2(_objectSpread2({}, options), {}, { includeIfEmpty: true })));
	}
};
/**
* Table row module for WordprocessingML documents.
*
* Reference: http://officeopenxml.com/WPtableRow.php
*
* @module
*/
var childrenOf = (element, name) => {
	const content = element[name];
	return Array.isArray(content) ? content : [];
};
var nameOf$2 = (element) => Object.keys(element)[0];
/**
* The paragraph with `keepNext` in its properties, unless it has its own. It goes after the paragraph's style, as
* the schema orders them.
*/
var withKeepNext = (paragraph, keepNext) => {
	const children = childrenOf(paragraph, "w:p");
	const properties = children.find((child) => nameOf$2(child) === "w:pPr");
	if (!properties) return { "w:p": [{ "w:pPr": [keepNext] }, ...children] };
	const settings = childrenOf(properties, "w:pPr");
	if (settings.some((setting) => nameOf$2(setting) === "w:keepNext")) return paragraph;
	const before = settings.filter((setting) => nameOf$2(setting) === "w:pStyle").length;
	const newProperties = { "w:pPr": [
		...settings.slice(0, before),
		keepNext,
		...settings.slice(before)
	] };
	return { "w:p": children.map((child) => child === properties ? newProperties : child) };
};
/**
* Represents a table row in a WordprocessingML document.
*
* A table row is a single row of cells within a table. Each row contains
* one or more table cells that hold the actual content. A row with no cells
* isn't written, as Word can't open a document with one.
*
* Reference: http://officeopenxml.com/WPtableRow.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Row">
*   <xsd:sequence>
*     <xsd:element name="tblPrEx" type="CT_TblPrEx" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="trPr" type="CT_TrPr" minOccurs="0" maxOccurs="1"/>
*     <xsd:group ref="EG_ContentCellContent" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="rsidRPr" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidR" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidDel" type="ST_LongHexNumber"/>
*   <xsd:attribute name="rsidTr" type="ST_LongHexNumber"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new TableRow({
*   children: [
*     new TableCell({ children: [new Paragraph("Cell 1")] }),
*     new TableCell({ children: [new Paragraph("Cell 2")] }),
*   ],
* });
* ```
*/
var TableRow = class extends XmlComponent {
	constructor(options) {
		super("w:tr");
		_defineProperty(this, "options", void 0);
		this.options = options;
		this.root.push(new TableRowProperties(options));
		for (const child of options.children) this.root.push(child);
	}
	prepForXml(context) {
		if (this.cells.length === 0) return;
		const xml = super.prepForXml(context);
		if (!xml || this.options.keepNext === void 0) return xml;
		const keepNext = new OnOffElement("w:keepNext", this.options.keepNext).prepForXml(context);
		return { "w:tr": childrenOf(xml, "w:tr").map((child) => nameOf$2(child) === "w:tc" ? { "w:tc": childrenOf(child, "w:tc").map((content) => nameOf$2(content) === "w:p" ? withKeepNext(content, keepNext) : content) } : child) };
	}
	get CellCount() {
		return this.options.children.length;
	}
	get cells() {
		return this.root.filter((xmlComponent) => elementOf(xmlComponent) === "w:tc");
	}
	addCellToIndex(cell, index) {
		this.root.splice(index + 1, 0, cell);
	}
	addCellToColumnIndex(cell, columnIndex) {
		const rootIndex = this.columnIndexToRootIndex(columnIndex, true);
		this.addCellToIndex(cell, rootIndex - 1);
	}
	rootIndexToColumnIndex(rootIndex) {
		if (rootIndex < 1 || rootIndex >= this.root.length) throw new Error(`cell 'rootIndex' should between 1 to ${this.root.length - 1}`);
		let colIdx = 0;
		for (let rootIdx = 1; rootIdx < rootIndex; rootIdx++) {
			const cell = this.root[rootIdx];
			colIdx += cell.options.columnSpan || 1;
		}
		return colIdx;
	}
	columnIndexToRootIndex(columnIndex, allowEndNewCell = false) {
		if (columnIndex < 0) throw new Error(`cell 'columnIndex' should not less than zero`);
		let colIdx = 0;
		let rootIdx = 1;
		while (colIdx <= columnIndex) {
			if (rootIdx >= this.root.length) {
				if (allowEndNewCell) return this.root.length;
				else throw new Error(`cell 'columnIndex' should not great than ${colIdx - 1}`);
			}
			const cell = this.root[rootIdx];
			rootIdx += 1;
			colIdx += cell && cell.options.columnSpan || 1;
		}
		return rootIdx - 1;
	}
};
/**
* Table module for WordprocessingML documents.
*
* Reference: http://officeopenxml.com/WPtableGrid.php
*
* @module
*/
/**
* Represents a table in a WordprocessingML document.
*
* A table is a set of paragraphs (and other block-level content) arranged in rows and columns.
* Tables are used to organize content into a grid structure.
*
* Reference: http://officeopenxml.com/WPtable.php
*
* @publicApi
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Tbl">
*   <xsd:sequence>
*     <xsd:group ref="EG_RangeMarkupElements" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="tblPr" type="CT_TblPr"/>
*     <xsd:element name="tblGrid" type="CT_TblGrid"/>
*     <xsd:group ref="EG_ContentRowContent" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new Table({
*   rows: [
*     new TableRow({
*       children: [
*         new TableCell({ children: [new Paragraph("Cell 1")] }),
*         new TableCell({ children: [new Paragraph("Cell 2")] }),
*       ],
*     }),
*   ],
* });
* ```
*/
var Table = class Table extends FileChild {
	constructor({ rows, width, columnWidths, columnWidthsRevision, margins, indent, float, layout, style, borders, alignment, visuallyRightToLeft, tableLook, cellSpacing, revision }) {
		super("w:tbl");
		_defineProperty(this, "rows", void 0);
		_defineProperty(this, "width", void 0);
		_defineProperty(this, "columnWidths", void 0);
		_defineProperty(this, "columnWidthsRevision", void 0);
		_defineProperty(
			this,
			/**
			* Grid column widths in twips: the explicit `columnWidths`, or the widths derived
			* from the table and cell widths (re-resolved against the actual page or parent
			* cell every time the table is serialized).
			*/
			"resolvedColumnWidths",
			void 0
		);
		this.rows = rows;
		this.width = width !== null && width !== void 0 ? width : { size: 100 };
		this.columnWidths = columnWidths;
		this.columnWidthsRevision = columnWidthsRevision;
		rows.forEach((row, rowIndex) => {
			if (rowIndex === rows.length - 1) return;
			let columnIndex = 0;
			row.cells.forEach((cell) => {
				if (cell.options.rowSpan && cell.options.rowSpan > 1) {
					const lastChild = cell.options.children[cell.options.children.length - 1];
					const continueCell = new TableCell({
						rowSpan: cell.options.rowSpan - 1,
						columnSpan: cell.options.columnSpan,
						width: cell.options.width,
						borders: cell.options.borders,
						shading: cell.options.shading,
						margins: cell.options.margins,
						textDirection: cell.options.textDirection,
						verticalAlign: cell.options.verticalAlign,
						children: lastChild instanceof Paragraph ? [new Paragraph(lastChild.Alignment)] : [],
						verticalMerge: VerticalMergeType.CONTINUE
					});
					rows[rowIndex + 1].addCellToColumnIndex(continueCell, columnIndex);
				}
				columnIndex += cell.options.columnSpan || 1;
			});
		});
		this.setCellWidths(DEFAULT_AVAILABLE_WIDTH);
		this.resolvedColumnWidths = columnWidths !== null && columnWidths !== void 0 ? columnWidths : resolveColumnWidths({
			rows,
			width: this.width,
			availableWidth: DEFAULT_AVAILABLE_WIDTH
		});
		this.root.push(new TableProperties({
			borders: style ? borders : borders !== null && borders !== void 0 ? borders : {},
			width: this.width,
			indent,
			float,
			layout,
			style,
			alignment,
			cellMargin: margins,
			visuallyRightToLeft,
			tableLook,
			cellSpacing,
			revision
		}));
		this.root.push(new TableGrid(this.resolvedColumnWidths, columnWidthsRevision));
		for (const row of rows) this.root.push(row);
	}
	/**
	* Widths of the grid columns in twips, as they will be written to `w:tblGrid`.
	*
	* These are the explicit `columnWidths` when given, otherwise the widths derived
	* from the table and cell widths. Derived widths are resolved against the page (or
	* the parent cell for nested tables) during serialization, so before that they
	* reflect the default page size.
	*/
	get ColumnWidths() {
		return this.resolvedColumnWidths;
	}
	/**
	* Width in twips, according to the grid, of a cell in one of this table's rows.
	*
	* Used by nested tables to resolve their own widths against the cell they sit in.
	*
	* @param row - A row of this table
	* @param cell - A cell of that row
	* @returns The summed width of the grid columns the cell spans, or undefined if the cell cannot be located on the grid
	*/
	getCellWidth(row, cell) {
		const { cells } = row;
		const cellIndex = cells.indexOf(cell);
		if (cellIndex === -1) return;
		const start = cells.slice(0, cellIndex).reduce((column, previous) => column + (previous.options.columnSpan || 1), 0);
		const columns = this.resolvedColumnWidths.slice(start, start + (cell.options.columnSpan || 1));
		return columns.length === 0 ? void 0 : columns.reduce((sum, columnWidth) => sum + columnWidth, 0);
	}
	/**
	* Resolves derived grid column widths against the width actually available to the
	* table (the section's text width, or the parent cell for nested tables) before
	* serializing.
	*/
	prepForXml(context) {
		this.setCellWidths(this.resolveAvailableWidth(context));
		if (this.columnWidths === void 0) {
			this.resolvedColumnWidths = resolveColumnWidths({
				rows: this.rows,
				width: this.width,
				availableWidth: this.resolveAvailableWidth(context)
			});
			const gridIndex = this.root.findIndex((component) => component instanceof TableGrid);
			this.root[gridIndex] = new TableGrid(this.resolvedColumnWidths, this.columnWidthsRevision);
		}
		return super.prepForXml(context);
	}
	/**
	* Gives each cell without a width of its own the width of the `columnWidths` it spans, as Word sizes the columns of
	* cells without a width to their content, whatever the grid says. When the table's width is wider than the columns
	* add up to, they are scaled up to fill it, as Word and LibreOffice lay them out, so columns given as proportions
	* keep them.
	*/
	setCellWidths(availableWidth) {
		var _resolvePreferredWidt;
		if (this.columnWidths === void 0) return;
		const total = this.columnWidths.reduce((sum, columnWidth) => sum + columnWidth, 0);
		const tableWidth = (_resolvePreferredWidt = resolvePreferredWidth(this.width, availableWidth)) !== null && _resolvePreferredWidt !== void 0 ? _resolvePreferredWidt : 0;
		const scale = total > 0 && tableWidth > total ? tableWidth / total : 1;
		for (const row of this.rows) {
			let column = 0;
			for (const cell of row.cells) {
				const span = cell.options.columnSpan || 1;
				const spanned = this.columnWidths.slice(column, column + span);
				const cellWidth = Math.round(spanned.reduce((sum, columnWidth) => sum + columnWidth, 0) * scale);
				if (spanned.length === span && cellWidth > 0) cell.setColumnWidth(cellWidth);
				column += span;
			}
		}
	}
	/**
	* Finds the width in twips available to this table from the serialization context:
	* the parent cell for a nested table, otherwise the text width of the section the
	* table belongs to (the first section for headers, footers and other parts). Falls
	* back to the default page when the context carries no document.
	*/
	resolveAvailableWidth(context) {
		var _context$file, _stack, _section$AvailableTex;
		const { stack } = context;
		const cell = stack[stack.length - 1];
		const row = stack[stack.length - 2];
		const parentTable = stack[stack.length - 3];
		if (cell instanceof TableCell && row instanceof TableRow && parentTable instanceof Table) {
			const cellWidth = parentTable.getCellWidth(row, cell);
			if (cellWidth !== void 0) return cellWidth;
		}
		const bodyIndex = stack.findIndex((component) => component instanceof Body);
		const documentBody = (_context$file = context.file) === null || _context$file === void 0 || (_context$file = _context$file.Document) === null || _context$file === void 0 ? void 0 : _context$file.View.Body;
		const section = bodyIndex >= 0 ? stack[bodyIndex].getSectionPropertiesFor((_stack = stack[bodyIndex + 1]) !== null && _stack !== void 0 ? _stack : this) : documentBody === null || documentBody === void 0 ? void 0 : documentBody.getSectionPropertiesFor();
		return (_section$AvailableTex = section === null || section === void 0 ? void 0 : section.AvailableTextWidth) !== null && _section$AvailableTex !== void 0 ? _section$AvailableTex : DEFAULT_AVAILABLE_WIDTH;
	}
};
/**
* App Properties Attributes module for WordprocessingML documents.
*
* Provides namespace attributes for extended document properties.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesExtended.xsd
*
* @module
*/
/**
* XML namespace attributes for the app properties element.
*
* @property xmlns - Main namespace for extended properties
* @property vt - Namespace for variant types
*/
var AppPropertiesAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			xmlns: "xmlns",
			vt: "xmlns:vt"
		});
	}
};
/**
* App Properties module for WordprocessingML documents.
*
* Provides support for extended document properties specific to Office applications.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesExtended.xsd
*
* @module
*/
/**
* Represents the extended application properties of a WordprocessingML document.
*
* Extended properties contain application-specific metadata such as total editing time,
* word count, character count, and other Office-specific information.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesExtended.xsd
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Properties">
*   <xsd:sequence>
*     <xsd:element name="Template" type="xsd:string" minOccurs="0"/>
*     <xsd:element name="Manager" type="xsd:string" minOccurs="0"/>
*     <xsd:element name="Company" type="xsd:string" minOccurs="0"/>
*     <xsd:element name="Pages" type="xsd:int" minOccurs="0"/>
*     <xsd:element name="Words" type="xsd:int" minOccurs="0"/>
*     <xsd:element name="Characters" type="xsd:int" minOccurs="0"/>
*     <xsd:element name="PresentationFormat" type="xsd:string" minOccurs="0"/>
*     <xsd:element name="Lines" type="xsd:int" minOccurs="0"/>
*     <xsd:element name="Paragraphs" type="xsd:int" minOccurs="0"/>
*     <xsd:element name="CharactersWithSpaces" type="xsd:int" minOccurs="0"/>
*     <xsd:element name="Application" type="xsd:string" minOccurs="0"/>
*     <xsd:element name="DocSecurity" type="xsd:int" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const appProps = new AppProperties();
* ```
*/
var AppProperties = class extends XmlComponent {
	constructor() {
		super("Properties");
		this.root.push(new AppPropertiesAttributes({
			xmlns: "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties",
			vt: "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"
		}));
	}
};
/**
* Attributes for the Types (Content Types) element.
*
* Defines the XML namespace for the content types part.
*
* @example
* ```typescript
* new ContentTypeAttributes({
*   xmlns: "http://schemas.openxmlformats.org/package/2006/content-types"
* });
* ```
*/
var ContentTypeAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { xmlns: "xmlns" });
	}
};
/**
* Creates a default content type mapping by file extension.
*
* Default elements map file extensions (e.g., "png", "xml") to MIME content types.
* This tells the package reader what type of content to expect for files with
* a given extension.
*
* @example
* ```typescript
* // Map .png files to image/png content type
* createDefault("image/png", "png");
*
* // Map .xml files to application/xml content type
* createDefault("application/xml", "xml");
* ```
*/
var createDefault = (contentType, extension) => new BuilderElement({
	name: "Default",
	attributes: {
		contentType: {
			key: "ContentType",
			value: contentType
		},
		extension: {
			key: "Extension",
			value: extension
		}
	}
});
/**
* Creates a content type override for a specific part.
*
* Override elements map specific part paths to MIME content types,
* taking precedence over default extension mappings. This is used for
* important parts like document.xml, styles.xml, etc.
*
* @example
* ```typescript
* // Override content type for the main document part
* createOverride(
*   "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml",
*   "/word/document.xml"
* );
*
* // Override for a header part
* createOverride(
*   "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml",
*   "/word/header1.xml"
* );
* ```
*/
var createOverride = (contentType, partName) => new BuilderElement({
	name: "Override",
	attributes: {
		contentType: {
			key: "ContentType",
			value: contentType
		},
		partName: {
			key: "PartName",
			value: partName
		}
	}
});
/**
* Content Types module for Open Packaging Conventions.
*
* This module provides the [Content_Types].xml part which defines
* the content types for all parts in the DOCX package.
*
* Reference: http://officeopenxml.com/anatomyofOOXML.php
*
* @module
*/
/**
* Represents the Content Types part of an OPC package.
*
* ContentTypes maps file extensions and specific paths to their
* MIME content types, enabling applications to process each part correctly.
*
* Reference: http://officeopenxml.com/anatomyofOOXML.php
*
* @example
* ```typescript
* const contentTypes = new ContentTypes();
* contentTypes.addHeader(1); // Add header1.xml
* contentTypes.addFooter(1); // Add footer1.xml
* ```
*/
var ContentTypes = class extends XmlComponent {
	/**
	* @param options.macros - Whether the document has VBA macros, which makes its main part a macro-enabled document
	* and adds the VBA project (word/vbaProject.bin)
	*/
	constructor({ macros = false } = {}) {
		super("Types");
		this.root.push(new ContentTypeAttributes({ xmlns: "http://schemas.openxmlformats.org/package/2006/content-types" }));
		this.root.push(createDefault("image/png", "png"));
		this.root.push(createDefault("image/jpeg", "jpeg"));
		this.root.push(createDefault("image/jpeg", "jpg"));
		this.root.push(createDefault("image/bmp", "bmp"));
		this.root.push(createDefault("image/gif", "gif"));
		this.root.push(createDefault("image/svg+xml", "svg"));
		this.root.push(createDefault("application/vnd.openxmlformats-package.relationships+xml", "rels"));
		this.root.push(createDefault("application/xml", "xml"));
		this.root.push(createDefault("application/vnd.openxmlformats-officedocument.obfuscatedFont", "odttf"));
		this.root.push(createOverride(macros ? "application/vnd.ms-word.document.macroEnabled.main+xml" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml", "/word/document.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml", "/word/styles.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-package.core-properties+xml", "/docProps/core.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.custom-properties+xml", "/docProps/custom.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.extended-properties+xml", "/docProps/app.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml", "/word/numbering.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml", "/word/footnotes.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml", "/word/endnotes.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml", "/word/settings.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.fontTable+xml", "/word/fontTable.xml"));
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.theme+xml", "/word/theme/theme1.xml"));
		if (macros) this.root.push(createOverride("application/vnd.ms-office.vbaProject", "/word/vbaProject.bin"));
	}
	/**
	* Registers the comments part in the content types.
	*/
	addComments() {
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml", "/word/comments.xml"));
	}
	/**
	* Registers the commentsExtended part in the content types.
	*/
	addCommentsExtended() {
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.commentsExtended+xml", "/word/commentsExtended.xml"));
	}
	/**
	* Registers the commentsIds part in the content types.
	*/
	addCommentsIds() {
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.commentsIds+xml", "/word/commentsIds.xml"));
	}
	/**
	* Registers a footer part in the content types.
	*
	* @param index - Footer index number (e.g., 1 for footer1.xml)
	*/
	addFooter(index) {
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml", `/word/footer${index}.xml`));
	}
	/**
	* Registers a part by its name, such as a chart or an embedded workbook that a drawing adds to the package.
	*
	* @param contentType - The part's content type
	* @param partName - The part's name, from the root of the package, such as "/word/charts/chart1.xml"
	*/
	addOverride(contentType, partName) {
		this.root.push(createOverride(contentType, partName));
	}
	/**
	* Registers a header part in the content types.
	*
	* @param index - Header index number (e.g., 1 for header1.xml)
	*/
	addHeader(index) {
		this.root.push(createOverride("application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml", `/word/header${index}.xml`));
	}
};
/**
* Document attributes module for WordprocessingML documents.
*
* This module defines the XML namespace declarations used in OOXML documents.
* These namespaces are required for proper document parsing and generation.
*
* Reference: http://officeopenxml.com/anatomyofOOXML.php
*
* @module
*/
/**
* XML namespace URIs used in WordprocessingML documents.
*
* These namespaces define the various XML schemas that can be referenced
* in a document, including WordprocessingML, DrawingML, VML, and others.
*/
var DocumentAttributeNamespaces = {
	wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
	mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
	o: "urn:schemas-microsoft-com:office:office",
	r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
	m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
	v: "urn:schemas-microsoft-com:vml",
	wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
	wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
	w10: "urn:schemas-microsoft-com:office:word",
	w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
	w14: "http://schemas.microsoft.com/office/word/2010/wordml",
	w15: "http://schemas.microsoft.com/office/word/2012/wordml",
	wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
	wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
	wne: "http://schemas.microsoft.com/office/word/2006/wordml",
	wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
	cp: "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
	dc: "http://purl.org/dc/elements/1.1/",
	dcterms: "http://purl.org/dc/terms/",
	dcmitype: "http://purl.org/dc/dcmitype/",
	xsi: "http://www.w3.org/2001/XMLSchema-instance",
	cx: "http://schemas.microsoft.com/office/drawing/2014/chartex",
	cx1: "http://schemas.microsoft.com/office/drawing/2015/9/8/chartex",
	cx2: "http://schemas.microsoft.com/office/drawing/2015/10/21/chartex",
	cx3: "http://schemas.microsoft.com/office/drawing/2016/5/9/chartex",
	cx4: "http://schemas.microsoft.com/office/drawing/2016/5/10/chartex",
	cx5: "http://schemas.microsoft.com/office/drawing/2016/5/11/chartex",
	cx6: "http://schemas.microsoft.com/office/drawing/2016/5/12/chartex",
	cx7: "http://schemas.microsoft.com/office/drawing/2016/5/13/chartex",
	cx8: "http://schemas.microsoft.com/office/drawing/2016/5/14/chartex",
	aink: "http://schemas.microsoft.com/office/drawing/2016/ink",
	am3d: "http://schemas.microsoft.com/office/drawing/2017/model3d",
	w16cex: "http://schemas.microsoft.com/office/word/2018/wordml/cex",
	w16cid: "http://schemas.microsoft.com/office/word/2016/wordml/cid",
	w16: "http://schemas.microsoft.com/office/word/2018/wordml",
	w16sdtdh: "http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash",
	w16se: "http://schemas.microsoft.com/office/word/2015/wordml/symex"
};
/**
* Represents XML namespace attributes for a WordprocessingML document.
*
* This class generates the xmlns declarations required at the root element
* of document.xml and other document parts.
*
* @example
* ```typescript
* new DocumentAttributes(['w', 'r', 'wp'], 'w14 w15');
* // Generates: xmlns:w="..." xmlns:r="..." xmlns:wp="..." mc:Ignorable="w14 w15"
* ```
*
* @internal
*/
var DocumentAttributes = class extends XmlAttributeComponent {
	constructor(ns, Ignorable) {
		super(_objectSpread2({ Ignorable }, Object.fromEntries(ns.map((n) => [n, DocumentAttributeNamespaces[n]]))));
		_defineProperty(this, "xmlKeys", _objectSpread2({ Ignorable: "mc:Ignorable" }, Object.fromEntries(Object.keys(DocumentAttributeNamespaces).map((key) => [key, `xmlns:${key}`]))));
	}
};
/**
* Represents the core properties of a WordprocessingML document.
*
* Core properties contain document metadata based on Dublin Core elements,
* including title, subject, creator, keywords, description, and modification tracking.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCore.xsd
*
* ## XSD Schema
* ```xml
* <xs:complexType name="CT_CoreProperties">
*   <xs:all>
*     <xs:element name="category" minOccurs="0" maxOccurs="1" type="xs:string"/>
*     <xs:element name="contentStatus" minOccurs="0" maxOccurs="1" type="xs:string"/>
*     <xs:element ref="dcterms:created" minOccurs="0" maxOccurs="1"/>
*     <xs:element ref="dc:creator" minOccurs="0" maxOccurs="1"/>
*     <xs:element ref="dc:description" minOccurs="0" maxOccurs="1"/>
*     <xs:element ref="dc:identifier" minOccurs="0" maxOccurs="1"/>
*     <xs:element name="keywords" minOccurs="0" maxOccurs="1" type="CT_Keywords"/>
*     <xs:element ref="dc:language" minOccurs="0" maxOccurs="1"/>
*     <xs:element name="lastModifiedBy" minOccurs="0" maxOccurs="1" type="xs:string"/>
*     <xs:element name="lastPrinted" minOccurs="0" maxOccurs="1" type="xs:dateTime"/>
*     <xs:element ref="dcterms:modified" minOccurs="0" maxOccurs="1"/>
*     <xs:element name="revision" minOccurs="0" maxOccurs="1" type="xs:string"/>
*     <xs:element ref="dc:subject" minOccurs="0" maxOccurs="1"/>
*     <xs:element ref="dc:title" minOccurs="0" maxOccurs="1"/>
*     <xs:element name="version" minOccurs="0" maxOccurs="1" type="xs:string"/>
*   </xs:all>
* </xs:complexType>
* ```
*
* @example
* ```typescript
* const coreProps = new CoreProperties({
*   title: "My Document",
*   subject: "Sample Document",
*   creator: "John Doe",
*   keywords: "docx, example",
*   description: "A sample document",
*   lastModifiedBy: "Jane Doe",
*   revision: 1
* });
* ```
*/
var CoreProperties = class extends XmlComponent {
	constructor(options) {
		super("cp:coreProperties");
		this.root.push(new DocumentAttributes([
			"cp",
			"dc",
			"dcterms",
			"dcmitype",
			"xsi"
		]));
		if (options.title) this.root.push(new StringContainer("dc:title", options.title));
		if (options.subject) this.root.push(new StringContainer("dc:subject", options.subject));
		if (options.creator) this.root.push(new StringContainer("dc:creator", options.creator));
		if (options.keywords) this.root.push(new StringContainer("cp:keywords", options.keywords));
		if (options.description) this.root.push(new StringContainer("dc:description", options.description));
		if (options.lastModifiedBy) this.root.push(new StringContainer("cp:lastModifiedBy", options.lastModifiedBy));
		if (options.revision) this.root.push(new StringContainer("cp:revision", String(options.revision)));
		this.root.push(new TimestampElement("dcterms:created"));
		this.root.push(new TimestampElement("dcterms:modified"));
	}
};
/**
* Attributes for timestamp elements in core properties.
* Specifies the W3C DateTime Format type for timestamps.
*/
var TimestampElementProperties = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { type: "xsi:type" });
	}
};
/**
* Represents a timestamp element (created or modified date).
* Uses W3C DateTime Format (dcterms:W3CDTF) for dates.
*/
var TimestampElement = class extends XmlComponent {
	constructor(name) {
		super(name);
		this.root.push(new TimestampElementProperties({ type: "dcterms:W3CDTF" }));
		this.root.push(dateTimeValue(/* @__PURE__ */ new Date()));
	}
};
/**
* Custom Properties Attributes module for WordprocessingML documents.
*
* Provides namespace attributes for custom document properties.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCustom.xsd
*
* @module
*/
/**
* XML namespace attributes for the custom properties element.
*
* @property xmlns - Main namespace for custom properties
* @property vt - Namespace for variant types
*/
var CustomPropertiesAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			xmlns: "xmlns",
			vt: "xmlns:vt"
		});
	}
};
/**
* Custom Property Attributes module for WordprocessingML documents.
*
* Provides attributes for individual custom document properties.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCustom.xsd
*
* @module
*/
/**
* XML attributes for a custom property element.
*
* @property formatId - Format identifier (GUID)
* @property pid - Property identifier (unique ID)
* @property name - Property name
*/
var CustomPropertyAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			formatId: "fmtid",
			pid: "pid",
			name: "name"
		});
	}
};
/**
* Custom Property module for WordprocessingML documents.
*
* Provides support for individual custom document properties.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCustom.xsd
*
* @module
*/
/**
* Represents a single custom document property.
*
* Custom properties allow storing arbitrary key-value pairs in the document metadata.
* Each property has a unique name and a string value.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCustom.xsd
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Property">
*   <xsd:sequence>
*     <xsd:element name="lpwstr" type="xsd:string" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="fmtid" type="ST_Guid" use="required"/>
*   <xsd:attribute name="pid" type="xsd:int" use="required"/>
*   <xsd:attribute name="name" type="xsd:string"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const customProp = new CustomProperty(2, {
*   name: "Department",
*   value: "Engineering"
* });
* ```
*/
var CustomProperty = class extends XmlComponent {
	constructor(id, properties) {
		super("property");
		this.root.push(new CustomPropertyAttributes({
			formatId: "{D5CDD505-2E9C-101B-9397-08002B2CF9AE}",
			pid: id.toString(),
			name: properties.name
		}));
		this.root.push(new CustomPropertyValue(properties.value));
	}
};
/**
* Represents the value of a custom property.
* Uses the variant type "long pointer to wide string" for string values.
*/
var CustomPropertyValue = class extends XmlComponent {
	constructor(value) {
		super("vt:lpwstr");
		this.root.push(value);
	}
};
/**
* Custom Properties module for WordprocessingML documents.
*
* Provides support for managing custom document properties collection.
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCustom.xsd
*
* @module
*/
/**
* Represents the collection of custom document properties.
*
* Custom properties allow storing arbitrary metadata as name-value pairs.
* Each property is assigned a unique ID starting from 2 (per Office specification).
*
* Reference: ISO-IEC29500-4_2016 shared-documentPropertiesCustom.xsd
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_CustomProperties">
*   <xsd:sequence>
*     <xsd:element name="property" type="CT_Property" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* const customProps = new CustomProperties([
*   { name: "Department", value: "Engineering" },
*   { name: "Project", value: "Alpha" }
* ]);
* ```
*/
var CustomProperties = class extends XmlComponent {
	constructor(properties) {
		super("Properties");
		_defineProperty(this, "nextId", void 0);
		_defineProperty(this, "properties", []);
		this.root.push(new CustomPropertiesAttributes({
			xmlns: "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties",
			vt: "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"
		}));
		this.nextId = 2;
		for (const property of properties) this.addCustomProperty(property);
	}
	prepForXml(context) {
		this.root.splice(1, this.root.length - 1, ...this.properties);
		return super.prepForXml(context);
	}
	addCustomProperty(property) {
		this.properties.push(new CustomProperty(this.nextId++, property));
	}
};
/**
* Document bibliography module: the sources that a document's citations and bibliographies refer to.
*
* Word keeps a document's sources in a custom XML part, customXml/item1.xml, whose root is a `b:Sources` element, and
* lists them in its Source Manager. The part's properties, customXml/itemProps1.xml, give it an id and name the schema
* of its XML, the bibliography's.
*
* Reference: ooxml-schemas/ISO-IEC29500-4_2016/shared-bibliography.xsd and shared-customXmlDataProperties.xsd
*
* @module
*/
/**
* The properties of the part that a document's sources are in (customXml/itemProps1.xml): its id, and the schema of its
* XML, the bibliography's.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_DatastoreItem">
*   <xsd:sequence>
*     <xsd:element name="schemaRefs" type="CT_DatastoreSchemaRefs" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="itemID" type="s:ST_Guid" use="required"/>
* </xsd:complexType>
* ```
*
* @param itemId - The part's id, a GUID in braces, such as "{6E3A1B2C-4D5E-4F60-8A7B-9C0D1E2F3A4B}"
*/
var createSourcesProperties = (itemId) => new BuilderElement({
	name: "ds:datastoreItem",
	attributes: {
		itemId: {
			key: "ds:itemID",
			value: itemId
		},
		namespace: {
			key: "xmlns:ds",
			value: "http://schemas.openxmlformats.org/officeDocument/2006/customXml"
		}
	},
	children: [new BuilderElement({
		name: "ds:schemaRefs",
		children: [new BuilderElement({
			name: "ds:schemaRef",
			attributes: { uri: {
				key: "ds:uri",
				value: "http://schemas.openxmlformats.org/officeDocument/2006/bibliography"
			} }
		})]
	})]
});
/**
* Document macros module: a document's VBA macros, which make it a macro-enabled document (.docm).
*
* The macros are a VBA project, which Word keeps in word/vbaProject.bin. The events of the document that the project
* handles are listed in word/vbaData.xml, as Word only runs a handler, such as `Document_Open`, for an event listed
* there.
*
* Reference: ooxml-schemas/microsoft/wml-2006.xsd (CT_VbaSuppData), [MS-OFFMACRO2]
*
* @module
*/
var EVENT_ELEMENTS = {
	new: "wne:eventDocNew",
	open: "wne:eventDocOpen",
	close: "wne:eventDocClose",
	sync: "wne:eventDocSync",
	xmlAfterInsert: "wne:eventDocXmlAfterInsert",
	xmlBeforeDelete: "wne:eventDocXmlBeforeDelete",
	contentControlAfterAdd: "wne:eventDocContentControlAfterInsert",
	contentControlBeforeDelete: "wne:eventDocContentControlBeforeDelete",
	contentControlOnExit: "wne:eventDocContentControlOnExit",
	contentControlOnEnter: "wne:eventDocContentControlOnEnter",
	contentControlBeforeStoreUpdate: "wne:eventDocStoreUpdate",
	contentControlBeforeContentUpdate: "wne:eventDocContentControlContentUpdate",
	buildingBlockInsert: "wne:eventDocBuildingBlockAfterInsert"
};
/**
* The events of a document that its macros handle (word/vbaData.xml).
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_VbaSuppData">
*   <xsd:sequence>
*     <xsd:element name="docEvents" type="CT_DocEvents" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="mcds" type="CT_Mcds" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var createMacroEvents = (events) => new BuilderElement({
	name: "wne:vbaSuppData",
	attributes: { namespace: {
		key: "xmlns:wne",
		value: "http://schemas.microsoft.com/office/word/2006/wordml"
	} },
	children: [new BuilderElement({
		name: "wne:docEvents",
		children: Object.entries(EVENT_ELEMENTS).filter(([event]) => events.includes(event)).map(([, name]) => new BuilderElement({ name }))
	})]
});
/**
* Represents a document background in a WordprocessingML document.
*
* The background element specifies the background color or theme color
* for the document.
*
* Reference: http://officeopenxml.com/WPdocument.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Background">
*   <xsd:sequence>
*     <xsd:sequence maxOccurs="unbounded">
*       <xsd:any processContents="lax" namespace="urn:schemas-microsoft-com:vml" minOccurs="0" maxOccurs="unbounded"/>
*       <xsd:any processContents="lax" namespace="urn:schemas-microsoft-com:office:office" minOccurs="0" maxOccurs="unbounded"/>
*     </xsd:sequence>
*     <xsd:element name="drawing" type="CT_Drawing" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="color" type="ST_HexColor" use="optional" default="auto"/>
*   <xsd:attribute name="themeColor" type="ST_ThemeColor" use="optional"/>
*   <xsd:attribute name="themeTint" type="ST_UcharHexNumber" use="optional"/>
*   <xsd:attribute name="themeShade" type="ST_UcharHexNumber" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* new DocumentBackground({ color: "FFFF00" }); // Yellow background
* new DocumentBackground({ color: { theme: "accent1", lighter: 80 } }); // A light version of the theme's first accent color
* ```
*/
var DocumentBackground = class extends XmlComponent {
	/**
	* @throws If a color isn't valid, or `color` is a theme color and `themeColor`, `themeShade` or `themeTint` is given
	*/
	constructor({ color, themeColor, themeShade, themeTint }) {
		super("w:background");
		if (typeof color === "object" && (themeColor !== void 0 || themeShade !== void 0 || themeTint !== void 0)) throw new Error("Invalid background. Expected a theme color in color, or themeColor, themeShade and themeTint, not both");
		this.root.push(new ColorAttributeComponent([
			{
				keys: COLOR_ATTRIBUTES,
				color
			},
			{
				key: "w:themeColor",
				value: themeColor
			},
			{
				key: "w:themeShade",
				value: themeShade === void 0 ? void 0 : uCharHexNumber(themeShade)
			},
			{
				key: "w:themeTint",
				value: themeTint === void 0 ? void 0 : uCharHexNumber(themeTint)
			}
		]));
	}
};
/**
* Represents the main document element in a WordprocessingML document.
*
* The document element is the root element of the main document part. It contains
* the body element which holds all the content of the document.
*
* Reference: http://officeopenxml.com/WPdocument.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="document" type="CT_Document"/>
*
* <xsd:complexType name="CT_Document">
*   <xsd:complexContent>
*     <xsd:extension base="CT_DocumentBase">
*       <xsd:sequence>
*         <xsd:element name="body" type="CT_Body" minOccurs="0" maxOccurs="1"/>
*       </xsd:sequence>
*       <xsd:attribute name="conformance" type="s:ST_ConformanceClass"/>
*       <xsd:attribute ref="mc:Ignorable" use="optional" />
*     </xsd:extension>
*   </xsd:complexContent>
* </xsd:complexType>
*
* <xsd:complexType name="CT_DocumentBase">
*   <xsd:sequence>
*     <xsd:element name="background" type="CT_Background" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a document with default options
* const doc = new Document({});
*
* // Create a document with background
* const doc = new Document({
*   background: {
*     color: "FF0000",
*   },
* });
*
* // Add content to the document
* doc.add(new Paragraph("Hello World"));
* doc.add(new Table({ rows: [...] }));
* ```
*/
var Document = class extends XmlComponent {
	constructor(options) {
		super("w:document");
		_defineProperty(this, "body", void 0);
		this.root.push(new DocumentAttributes([
			"wpc",
			"mc",
			"o",
			"r",
			"m",
			"v",
			"wp14",
			"wp",
			"w10",
			"w",
			"w14",
			"w15",
			"wpg",
			"wpi",
			"wne",
			"wps",
			"cx",
			"cx1",
			"cx2",
			"cx3",
			"cx4",
			"cx5",
			"cx6",
			"cx7",
			"cx8",
			"aink",
			"am3d",
			"w16cex",
			"w16cid",
			"w16",
			"w16sdtdh",
			"w16se"
		], "w14 w15 wp14"));
		this.body = new Body({ pageNumbers: options.pageNumbers });
		if (options.background) this.root.push(new DocumentBackground(options.background));
		this.root.push(this.body);
	}
	/**
	* Adds a block-level element to the document body.
	*
	* @param item - The element to add (paragraph, table, table of contents, hyperlink, or any other file child)
	* @returns The Document instance for method chaining
	*/
	add(item) {
		this.body.push(item);
		return this;
	}
	/**
	* Gets the document body element.
	*
	* @returns The Body instance containing all document content
	*/
	get Body() {
		return this.body;
	}
};
/**
* Document wrapper module for WordprocessingML documents.
*
* This module provides wrappers that combine the main document/header/footer
* views with their associated relationships, enabling proper management of
* document parts and their references.
*
* @module
*/
/**
* Wrapper for the main document body.
*
* DocumentWrapper combines the main Document view with its Relationships,
* managing the primary content of the .docx file along with references to
* images, hyperlinks, and other linked resources.
*
* @example
* ```typescript
* const wrapper = new DocumentWrapper({
*   sections: [{
*     children: [new Paragraph("Hello World")],
*   }],
* });
* ```
*/
var DocumentWrapper = class {
	constructor(options) {
		_defineProperty(this, "document", void 0);
		_defineProperty(this, "relationships", void 0);
		this.document = new Document(options);
		this.relationships = new Relationships();
	}
	get View() {
		return this.document;
	}
	get Relationships() {
		return this.relationships;
	}
};
/**
* Footnote continuation separator module for WordprocessingML documents.
*
* This module provides the continuation separator element that defines
* the line used when footnotes span multiple pages.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents a footnote continuation separator in WordprocessingML.
*
* ContinuationSeperator creates the separator line that appears when
* footnotes continue from a previous page to the current page.
*
* ## XSD Schema
* ```xml
* <xsd:element name="continuationSeparator" type="CT_Empty" minOccurs="0"/>
* ```
*
* @internal
*/
var ContinuationSeperator = class extends XmlComponent {
	constructor() {
		super("w:continuationSeparator");
	}
};
/**
* Footnote continuation separator run module for WordprocessingML documents.
*
* This module provides the run containing the continuation separator element.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents a footnote continuation separator run in WordprocessingML.
*
* ContinuationSeperatorRun creates a run containing the continuation
* separator element that defines the line used when footnotes continue
* from a previous page.
*
* @internal
*/
var ContinuationSeperatorRun = class extends Run {
	constructor() {
		super({});
		this.root.push(new ContinuationSeperator());
	}
};
/**
* Footnote separator module for WordprocessingML documents.
*
* This module provides the separator element that defines the line
* separating body text from footnotes.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents a footnote separator in WordprocessingML.
*
* Seperator creates the separator line that appears between the main
* document text and the footnote area at the bottom of the page.
*
* ## XSD Schema
* ```xml
* <xsd:element name="separator" type="CT_Empty" minOccurs="0"/>
* ```
*
* @internal
*/
var Seperator = class extends XmlComponent {
	constructor() {
		super("w:separator");
	}
};
/**
* Footnote separator run module for WordprocessingML documents.
*
* This module provides the run containing the separator element.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents a footnote separator run in WordprocessingML.
*
* SeperatorRun creates a run containing the separator element that
* defines the horizontal line between body text and footnotes.
*
* @internal
*/
var SeperatorRun = class extends Run {
	constructor() {
		super({});
		this.root.push(new Seperator());
	}
};
/**
* The first paragraph of a footnote or endnote, written with the run that shows the note's number before its content.
*
* The run is added to what the paragraph is written as, rather than to the paragraph, so a paragraph in more than one
* note, such as the notes of two documents, or two notes with the same content, has one number in each.
*
* @internal
*/
var FirstNoteParagraph = class extends XmlComponent {
	constructor(paragraph, mark) {
		super("w:p");
		_defineProperty(this, "paragraph", void 0);
		_defineProperty(this, "mark", void 0);
		this.paragraph = paragraph;
		this.mark = mark;
	}
	prepForXml(context) {
		const content = this.paragraph.prepForXml(context)["w:p"];
		const children = Array.isArray(content) ? content : [];
		const index = children.length > 0 && "w:pPr" in children[0] ? 1 : 0;
		return { "w:p": [
			...children.slice(0, index),
			this.mark.prepForXml(context),
			...children.slice(index)
		] };
	}
};
var EndnoteAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			type: "w:type",
			id: "w:id"
		});
	}
};
var EndnoteRefRun = class extends Run {
	constructor() {
		super({ style: "EndnoteReference" });
		this.root.push(new EndnoteReference());
	}
};
var EndnoteType = {
	SEPARATOR: "separator",
	CONTINUATION_SEPARATOR: "continuationSeparator"
};
var Endnote = class extends XmlComponent {
	constructor(options) {
		super("w:endnote");
		this.root.push(new EndnoteAttributes({
			type: options.type,
			id: options.id
		}));
		for (const [index, child] of options.children.entries()) this.root.push(index === 0 ? new FirstNoteParagraph(child, new EndnoteRefRun()) : child);
	}
};
var EndnotesAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			wpc: "xmlns:wpc",
			mc: "xmlns:mc",
			o: "xmlns:o",
			r: "xmlns:r",
			m: "xmlns:m",
			v: "xmlns:v",
			wp14: "xmlns:wp14",
			wp: "xmlns:wp",
			w10: "xmlns:w10",
			w: "xmlns:w",
			w14: "xmlns:w14",
			w15: "xmlns:w15",
			wpg: "xmlns:wpg",
			wpi: "xmlns:wpi",
			wne: "xmlns:wne",
			wps: "xmlns:wps",
			Ignorable: "mc:Ignorable"
		});
	}
};
var Endnotes = class extends XmlComponent {
	constructor() {
		super("w:endnotes");
		_defineProperty(this, "ownNotes", /* @__PURE__ */ new Map());
		_defineProperty(this, "highestId", 0);
		this.root.push(new EndnotesAttributes({
			wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
			mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
			o: "urn:schemas-microsoft-com:office:office",
			r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
			m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
			v: "urn:schemas-microsoft-com:vml",
			wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
			wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
			w10: "urn:schemas-microsoft-com:office:word",
			w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
			w14: "http://schemas.microsoft.com/office/word/2010/wordml",
			w15: "http://schemas.microsoft.com/office/word/2012/wordml",
			wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
			wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
			wne: "http://schemas.microsoft.com/office/word/2006/wordml",
			wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
			Ignorable: "w14 w15 wp14"
		}));
		const begin = new Endnote({
			id: -1,
			type: EndnoteType.SEPARATOR,
			children: [new Paragraph({
				spacing: {
					after: 0,
					line: 240,
					lineRule: LineRuleType.AUTO
				},
				children: [new SeperatorRun()]
			})]
		});
		this.root.push(begin);
		const spacing = new Endnote({
			id: 0,
			type: EndnoteType.CONTINUATION_SEPARATOR,
			children: [new Paragraph({
				spacing: {
					after: 0,
					line: 240,
					lineRule: LineRuleType.AUTO
				},
				children: [new ContinuationSeperatorRun()]
			})]
		});
		this.root.push(spacing);
	}
	createEndnote(id, paragraph) {
		const endnote = new Endnote({
			id,
			children: paragraph
		});
		this.root.push(endnote);
		if (Number.isFinite(id)) this.highestId = Math.max(this.highestId, Math.floor(id));
	}
	/**
	* The id of the endnote that a reference run brings with it, which is added to the endnotes the first time the run
	* is written, with an id no other endnote has. Word has endnotes only in a document's body, so a run written
	* anywhere else, such as in a header, has none, and its endnote isn't added.
	*
	* @internal
	* @param reference - The run, which has the same endnote each time it is written
	* @param endnote - The endnote's content
	* @param context - The context the run is written in
	* @returns The endnote's id, or undefined outside the document's body
	*/
	idOf(reference, endnote, context) {
		if (context.viewWrapper !== context.file.Document) return;
		const existing = this.ownNotes.get(reference);
		if (existing !== void 0) return existing;
		const id = this.highestId + 1;
		this.createEndnote(id, endnote.children);
		this.ownNotes.set(reference, id);
		return id;
	}
	/**
	* Formats the endnotes, with the page numbers worked out for their document written into their fields, when the
	* document's body is written with an estimate of its pages.
	*/
	prepForXml(context) {
		const xml = super.prepForXml(context);
		fillPartPageNumbers(xml, context);
		return xml;
	}
};
var EndnotesWrapper = class {
	constructor() {
		_defineProperty(this, "endnotes", void 0);
		_defineProperty(this, "relationships", void 0);
		this.endnotes = new Endnotes();
		this.relationships = new Relationships();
	}
	get View() {
		return this.endnotes;
	}
	get Relationships() {
		return this.relationships;
	}
};
/**
* Component for managing XML namespace attributes on footer elements.
*
* This class handles the serialization of namespace declarations that are required
* for proper XML validation and processing of footer content in WordprocessingML documents.
*
* @example
* ```typescript
* new FooterAttributes({
*   w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
*   r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
* });
* ```
*/
var FooterAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			wpc: "xmlns:wpc",
			mc: "xmlns:mc",
			o: "xmlns:o",
			r: "xmlns:r",
			m: "xmlns:m",
			v: "xmlns:v",
			wp14: "xmlns:wp14",
			wp: "xmlns:wp",
			w10: "xmlns:w10",
			w: "xmlns:w",
			w14: "xmlns:w14",
			w15: "xmlns:w15",
			wpg: "xmlns:wpg",
			wpi: "xmlns:wpi",
			wne: "xmlns:wne",
			wps: "xmlns:wps",
			cp: "xmlns:cp",
			dc: "xmlns:dc",
			dcterms: "xmlns:dcterms",
			dcmitype: "xmlns:dcmitype",
			xsi: "xmlns:xsi",
			type: "xsi:type"
		});
	}
};
/**
* Footer module for WordprocessingML documents.
*
* Footers are repeated at the bottom of each page in a section.
*
* Reference: http://officeopenxml.com/WPfooters.php
*
* @module
*/
/**
* Represents a footer in a WordprocessingML document.
*
* A footer is the portion of the document that appears at the bottom of each page in a section.
* Footers can contain block-level elements such as paragraphs and tables. Each section can
* have up to three different footers: first page, even pages, and odd pages.
*
* Reference: http://officeopenxml.com/WPfooters.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_HdrFtr">
*   <xsd:group ref="EG_BlockLevelElts" minOccurs="1" maxOccurs="unbounded"/>
* </xsd:complexType>
*
* <xsd:element name="ftr" type="CT_HdrFtr"/>
* ```
*
* @example
* ```typescript
* // Create a simple footer with page numbers
* const footer = new Footer(1);
* footer.add(new Paragraph({
*   alignment: AlignmentType.CENTER,
*   children: [new TextRun("Page "), PageNumber.CURRENT]
* }));
*
* // Create a footer with a table
* const footer = new Footer(2);
* footer.add(new Table({
*   rows: [
*     new TableRow({
*       children: [new TableCell({ children: [new Paragraph("Footer Content")] })]
*     })
*   ]
* }));
* ```
*/
var Footer$1 = class extends InitializableXmlComponent {
	constructor(referenceNumber, initContent) {
		super("w:ftr", initContent);
		_defineProperty(this, "refId", void 0);
		this.refId = referenceNumber;
		if (!initContent) this.root.push(new FooterAttributes({
			wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
			mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
			o: "urn:schemas-microsoft-com:office:office",
			r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
			m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
			v: "urn:schemas-microsoft-com:vml",
			wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
			wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
			w10: "urn:schemas-microsoft-com:office:word",
			w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
			w14: "http://schemas.microsoft.com/office/word/2010/wordml",
			w15: "http://schemas.microsoft.com/office/word/2012/wordml",
			wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
			wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
			wne: "http://schemas.microsoft.com/office/word/2006/wordml",
			wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape"
		}));
	}
	get ReferenceId() {
		return this.refId;
	}
	add(item) {
		this.root.push(item);
	}
	/**
	* Formats the footer, with the page numbers worked out for its document written into its fields, when the document's
	* body is written with an estimate of its pages.
	*/
	prepForXml(context) {
		const xml = super.prepForXml(context);
		fillPartPageNumbers(xml, context, this.refId);
		return xml;
	}
};
/**
* Wrapper for document footers.
*
* FooterWrapper combines a Footer view with its Relationships and Media,
* enabling footers to contain paragraphs, tables, images, and hyperlinks.
* Each section can have multiple footers for different page types.
*
* Reference: http://officeopenxml.com/WPfooter.php
*
* @example
* ```typescript
* const footerWrapper = new FooterWrapper(media, 1);
* footerWrapper.add(new Paragraph("Page Footer"));
* footerWrapper.add(new Table({
*   rows: [new TableRow({ children: [new TableCell({ children: [new Paragraph("Cell")] })] })],
* }));
* ```
*/
var FooterWrapper = class {
	constructor(media, referenceId, initContent) {
		_defineProperty(this, "media", void 0);
		_defineProperty(this, "footer", void 0);
		_defineProperty(this, "relationships", void 0);
		this.media = media;
		this.footer = new Footer$1(referenceId, initContent);
		this.relationships = new Relationships();
	}
	add(item) {
		this.footer.add(item);
	}
	addChildElement(childElement) {
		this.footer.addChildElement(childElement);
	}
	get View() {
		return this.footer;
	}
	get Relationships() {
		return this.relationships;
	}
	get Media() {
		return this.media;
	}
};
/**
* Footnote attributes module for WordprocessingML documents.
*
* This module defines attributes for individual footnote elements.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents the attributes for a footnote element.
*
* FootnoteAttributes defines the type and unique identifier for each footnote.
*
* @internal
*/
var FootnoteAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			type: "w:type",
			id: "w:id"
		});
	}
};
/**
* Footnote reference marker module for WordprocessingML documents.
*
* This module provides the automatic footnote reference marker that appears
* at the beginning of footnote content.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents a footnote reference marker in WordprocessingML.
*
* FootnoteRef creates the automatic reference mark (typically a superscript
* number) that appears at the beginning of the footnote content itself.
* This corresponds to the w:footnoteRef element in OOXML.
*
* ## XSD Schema
* ```xml
* <xsd:element name="footnoteRef" type="CT_Empty" minOccurs="0"/>
* ```
*
* @internal
*/
var FootnoteRef = class extends XmlComponent {
	constructor() {
		super("w:footnoteRef");
	}
};
/**
* Footnote Reference Run module for WordprocessingML documents.
*
* This module provides the footnote reference marker that appears
* at the start of a footnote.
*
* @module
*/
/**
* Represents a footnote reference run in a WordprocessingML document.
*
* FootnoteRefRun displays the footnote reference mark (usually a superscript
* number) at the beginning of the footnote content.
*
* @internal
*/
var FootnoteRefRun = class extends Run {
	constructor() {
		super({ style: "FootnoteReference" });
		this.root.push(new FootnoteRef());
	}
};
/**
* Enumeration of footnote types.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @publicApi
*/
var FootnoteType = {
	/** Separator line between body text and footnotes */
	SEPERATOR: "separator",
	/** Continuation separator for footnotes spanning pages */
	CONTINUATION_SEPERATOR: "continuationSeparator"
};
/**
* Represents a footnote in a WordprocessingML document.
*
* Footnotes appear at the bottom of the page and are referenced
* from the main document text using footnote reference marks.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_FtnEdn">
*   <xsd:sequence>
*     <xsd:group ref="EG_BlockLevelElts" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="type" type="ST_FtnEdn"/>
*   <xsd:attribute name="id" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a footnote with content
* const footnote = new Footnote({
*   id: 1,
*   children: [
*     new Paragraph({
*       children: [
*         new TextRun("This is the footnote content."),
*       ],
*     }),
*   ],
* });
* ```
*/
var Footnote = class extends XmlComponent {
	constructor(options) {
		super("w:footnote");
		this.root.push(new FootnoteAttributes({
			type: options.type,
			id: options.id
		}));
		for (const [index, child] of options.children.entries()) this.root.push(index === 0 ? new FirstNoteParagraph(child, new FootnoteRefRun()) : child);
	}
};
/**
* Footnotes attributes module for WordprocessingML documents.
*
* This module defines XML namespace attributes for the footnotes element.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents the XML namespace attributes for the footnotes root element.
*
* FootnotesAttributes defines all necessary XML namespace declarations
* for the footnotes.xml part of a WordprocessingML document.
*
* @internal
*/
var FootnotesAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			wpc: "xmlns:wpc",
			mc: "xmlns:mc",
			o: "xmlns:o",
			r: "xmlns:r",
			m: "xmlns:m",
			v: "xmlns:v",
			wp14: "xmlns:wp14",
			wp: "xmlns:wp",
			w10: "xmlns:w10",
			w: "xmlns:w",
			w14: "xmlns:w14",
			w15: "xmlns:w15",
			wpg: "xmlns:wpg",
			wpi: "xmlns:wpi",
			wne: "xmlns:wne",
			wps: "xmlns:wps",
			Ignorable: "mc:Ignorable"
		});
	}
};
/**
* Footnotes module for WordprocessingML documents.
*
* This module manages the collection of footnotes in a document, including
* separator and continuation separator footnotes that appear by default.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* @module
*/
/**
* Represents the footnotes collection in a WordprocessingML document.
*
* FootNotes manages all footnotes in a document and automatically creates
* the required separator and continuation separator footnotes. These special
* footnotes define the line that separates body text from footnotes and the
* line used when footnotes continue across pages.
*
* Reference: http://officeopenxml.com/WPfootnotes.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Footnotes">
*   <xsd:sequence maxOccurs="unbounded">
*     <xsd:element name="footnote" type="CT_FtnEdn" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // FootNotes is typically managed internally by the Document class
* // Users create footnotes through the Document API
* const doc = new Document({
*   sections: [{
*     children: [
*       new Paragraph({
*         children: [
*           new TextRun("Text with footnote"),
*           new FootnoteReferenceRun(1),
*         ],
*       }),
*     ],
*     footnotes: {
*       1: {
*         children: [new Paragraph("Footnote content")],
*       },
*     },
*   }],
* });
* ```
*/
var FootNotes = class extends XmlComponent {
	constructor() {
		super("w:footnotes");
		_defineProperty(this, "ownNotes", /* @__PURE__ */ new Map());
		_defineProperty(this, "highestId", 0);
		this.root.push(new FootnotesAttributes({
			wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
			mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
			o: "urn:schemas-microsoft-com:office:office",
			r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
			m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
			v: "urn:schemas-microsoft-com:vml",
			wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
			wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
			w10: "urn:schemas-microsoft-com:office:word",
			w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
			w14: "http://schemas.microsoft.com/office/word/2010/wordml",
			w15: "http://schemas.microsoft.com/office/word/2012/wordml",
			wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
			wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
			wne: "http://schemas.microsoft.com/office/word/2006/wordml",
			wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
			Ignorable: "w14 w15 wp14"
		}));
		const begin = new Footnote({
			id: -1,
			type: FootnoteType.SEPERATOR,
			children: [new Paragraph({
				spacing: {
					after: 0,
					line: 240,
					lineRule: LineRuleType.AUTO
				},
				children: [new SeperatorRun()]
			})]
		});
		this.root.push(begin);
		const spacing = new Footnote({
			id: 0,
			type: FootnoteType.CONTINUATION_SEPERATOR,
			children: [new Paragraph({
				spacing: {
					after: 0,
					line: 240,
					lineRule: LineRuleType.AUTO
				},
				children: [new ContinuationSeperatorRun()]
			})]
		});
		this.root.push(spacing);
	}
	/**
	* Creates and adds a new footnote to the collection.
	*
	* @param id - Unique numeric identifier for the footnote
	* @param paragraph - Array of paragraphs that make up the footnote content
	*/
	createFootNote(id, paragraph) {
		const footnote = new Footnote({
			id,
			children: paragraph
		});
		this.root.push(footnote);
		if (Number.isFinite(id)) this.highestId = Math.max(this.highestId, Math.floor(id));
	}
	/**
	* The id of the footnote that a reference run brings with it, which is added to the footnotes the first time the
	* run is written, with an id no other footnote has. Word has footnotes only in a document's body, so a run written
	* anywhere else, such as in a header, has none, and its footnote isn't added.
	*
	* @internal
	* @param reference - The run, which has the same footnote each time it is written
	* @param footnote - The footnote's content
	* @param context - The context the run is written in
	* @returns The footnote's id, or undefined outside the document's body
	*/
	idOf(reference, footnote, context) {
		if (context.viewWrapper !== context.file.Document) return;
		const existing = this.ownNotes.get(reference);
		if (existing !== void 0) return existing;
		const id = this.highestId + 1;
		this.createFootNote(id, footnote.children);
		this.ownNotes.set(reference, id);
		return id;
	}
	/**
	* Formats the footnotes, with the page numbers worked out for their document written into their fields, when the
	* document's body is written with an estimate of its pages.
	*/
	prepForXml(context) {
		const xml = super.prepForXml(context);
		fillPartPageNumbers(xml, context);
		return xml;
	}
};
/**
* Wrapper class for managing footnotes in a document.
*
* Encapsulates the footnotes collection and its relationships,
* implementing the IViewWrapper interface for consistent access.
*
* @example
* ```typescript
* const wrapper = new FootnotesWrapper();
* const footnotes = wrapper.View;
* const relationships = wrapper.Relationships;
* ```
*/
var FootnotesWrapper = class {
	constructor() {
		_defineProperty(this, "footnotess", void 0);
		_defineProperty(this, "relationships", void 0);
		this.footnotess = new FootNotes();
		this.relationships = new Relationships();
	}
	get View() {
		return this.footnotess;
	}
	get Relationships() {
		return this.relationships;
	}
};
/**
* Component for managing XML namespace attributes on header elements.
*
* This class handles the serialization of namespace declarations that are required
* for proper XML validation and processing of header content in WordprocessingML documents.
*
* @example
* ```typescript
* new HeaderAttributes({
*   w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
*   r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
* });
* ```
*/
var HeaderAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			wpc: "xmlns:wpc",
			mc: "xmlns:mc",
			o: "xmlns:o",
			r: "xmlns:r",
			m: "xmlns:m",
			v: "xmlns:v",
			wp14: "xmlns:wp14",
			wp: "xmlns:wp",
			w10: "xmlns:w10",
			w: "xmlns:w",
			w14: "xmlns:w14",
			w15: "xmlns:w15",
			wpg: "xmlns:wpg",
			wpi: "xmlns:wpi",
			wne: "xmlns:wne",
			wps: "xmlns:wps",
			cp: "xmlns:cp",
			dc: "xmlns:dc",
			dcterms: "xmlns:dcterms",
			dcmitype: "xmlns:dcmitype",
			xsi: "xmlns:xsi",
			type: "xsi:type",
			cx: "xmlns:cx",
			cx1: "xmlns:cx1",
			cx2: "xmlns:cx2",
			cx3: "xmlns:cx3",
			cx4: "xmlns:cx4",
			cx5: "xmlns:cx5",
			cx6: "xmlns:cx6",
			cx7: "xmlns:cx7",
			cx8: "xmlns:cx8",
			w16cid: "xmlns:w16cid",
			w16se: "xmlns:w16se"
		});
	}
};
/**
* Header module for WordprocessingML documents.
*
* Headers are repeated at the top of each page in a section.
*
* Reference: http://officeopenxml.com/WPheaders.php
*
* @module
*/
/**
* Represents a header in a WordprocessingML document.
*
* A header is the portion of the document that appears at the top of each page in a section.
* Headers can contain block-level elements such as paragraphs and tables. Each section can
* have up to three different headers: first page, even pages, and odd pages.
*
* Reference: http://officeopenxml.com/WPheaders.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_HdrFtr">
*   <xsd:group ref="EG_BlockLevelElts" minOccurs="1" maxOccurs="unbounded"/>
* </xsd:complexType>
*
* <xsd:element name="hdr" type="CT_HdrFtr"/>
* ```
*
* @example
* ```typescript
* // Create a simple header
* const header = new Header(1);
* header.add(new Paragraph("Company Name"));
*
* // Create a header with a table
* const header = new Header(2);
* header.add(new Table({
*   rows: [
*     new TableRow({
*       children: [new TableCell({ children: [new Paragraph("Header Content")] })]
*     })
*   ]
* }));
* ```
*/
var Header$1 = class extends InitializableXmlComponent {
	constructor(referenceNumber, initContent) {
		super("w:hdr", initContent);
		_defineProperty(this, "refId", void 0);
		this.refId = referenceNumber;
		if (!initContent) this.root.push(new HeaderAttributes({
			wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
			mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
			o: "urn:schemas-microsoft-com:office:office",
			r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
			m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
			v: "urn:schemas-microsoft-com:vml",
			wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
			wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
			w10: "urn:schemas-microsoft-com:office:word",
			w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
			w14: "http://schemas.microsoft.com/office/word/2010/wordml",
			w15: "http://schemas.microsoft.com/office/word/2012/wordml",
			wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
			wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
			wne: "http://schemas.microsoft.com/office/word/2006/wordml",
			wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
			cx: "http://schemas.microsoft.com/office/drawing/2014/chartex",
			cx1: "http://schemas.microsoft.com/office/drawing/2015/9/8/chartex",
			cx2: "http://schemas.microsoft.com/office/drawing/2015/10/21/chartex",
			cx3: "http://schemas.microsoft.com/office/drawing/2016/5/9/chartex",
			cx4: "http://schemas.microsoft.com/office/drawing/2016/5/10/chartex",
			cx5: "http://schemas.microsoft.com/office/drawing/2016/5/11/chartex",
			cx6: "http://schemas.microsoft.com/office/drawing/2016/5/12/chartex",
			cx7: "http://schemas.microsoft.com/office/drawing/2016/5/13/chartex",
			cx8: "http://schemas.microsoft.com/office/drawing/2016/5/14/chartex",
			w16cid: "http://schemas.microsoft.com/office/word/2016/wordml/cid",
			w16se: "http://schemas.microsoft.com/office/word/2015/wordml/symex"
		}));
	}
	get ReferenceId() {
		return this.refId;
	}
	add(item) {
		this.root.push(item);
	}
	/**
	* Formats the header, with the page numbers worked out for its document written into its fields, when the document's
	* body is written with an estimate of its pages.
	*/
	prepForXml(context) {
		const xml = super.prepForXml(context);
		fillPartPageNumbers(xml, context, this.refId);
		return xml;
	}
};
/**
* Wrapper for document headers.
*
* HeaderWrapper combines a Header view with its Relationships and Media,
* enabling headers to contain paragraphs, tables, images, and hyperlinks.
* Each section can have multiple headers for different page types.
*
* Reference: http://officeopenxml.com/WPheader.php
*
* @example
* ```typescript
* const headerWrapper = new HeaderWrapper(media, 1);
* headerWrapper.add(new Paragraph("Page Header"));
* headerWrapper.add(new Table({
*   rows: [new TableRow({ children: [new TableCell({ children: [new Paragraph("Cell")] })] })],
* }));
* ```
*/
var HeaderWrapper = class {
	constructor(media, referenceId, initContent) {
		_defineProperty(this, "media", void 0);
		_defineProperty(this, "header", void 0);
		_defineProperty(this, "relationships", void 0);
		this.media = media;
		this.header = new Header$1(referenceId, initContent);
		this.relationships = new Relationships();
	}
	add(item) {
		this.header.add(item);
		return this;
	}
	addChildElement(childElement) {
		this.header.addChildElement(childElement);
	}
	get View() {
		return this.header;
	}
	get Relationships() {
		return this.relationships;
	}
	get Media() {
		return this.media;
	}
};
/**
* Numbers images by type, media/image1.png, media/image2.png and media/image1.jpg, as `PackageParts.takePath` does,
* when the images aren't in a package with other parts.
*/
var sequentialMediaPaths = () => {
	const counts = /* @__PURE__ */ new Map();
	return (extension) => {
		var _counts$get;
		const count = ((_counts$get = counts.get(extension)) !== null && _counts$get !== void 0 ? _counts$get : 0) + 1;
		counts.set(extension, count);
		return `media/image${count}.${extension}`;
	};
};
/**
* Manages embedded media (images) in a document.
*
* Media stores all images referenced in the document and provides access to their data for packaging into the DOCX
* file. Each image is stored under a unique key, such as a hash of its data, so an image used twice is stored once.
*
* In the package, images are named as Word names them: image1.png, image2.png and so on in word/media, numbered in
* the order they are added. The numbering is by type, so a document with a PNG and a JPEG has image1.png and
* image1.jpg. Word for the web shows images with Word's own names, and has been seen to show an empty box in place of
* an image whose name isn't like them. The {@link IMediaData.fileName} of an image in {@link Array}
* is the name it is written with, not the key it was added under.
*
* @example
* ```typescript
* const media = new Media();
* media.addImage("4bf7547c9322fd2143bd3e8dfa84109d9d3fed14.png", {
*   type: "png",
*   fileName: "4bf7547c9322fd2143bd3e8dfa84109d9d3fed14.png",
*   transformation: {
*     pixels: { x: 200, y: 100 },
*     emus: { x: 1828800, y: 914400 }
*   },
*   data: imageBuffer
* });
* const [image] = media.Array; // image.fileName is "image1.png"
* ```
*/
var Media = class {
	/**
	* @param takePath - Gives each image its path under word/, by its extension, so that it doesn't take the path of
	* another part of the package, such as a template's image. Default numbers them by type, media/image1.png,
	* media/image2.png and so on
	*/
	constructor(takePath = sequentialMediaPaths()) {
		_defineProperty(this, "map", /* @__PURE__ */ new Map());
		_defineProperty(this, "takePath", void 0);
		this.takePath = takePath;
	}
	/**
	* Adds an image to the media collection, once: an image added again under the same key, such as one used in the
	* body and in a header, keeps the file name it was given the first time.
	*
	* @param key - Unique identifier for this image, which the XML refers to it by until it is packed
	* @param mediaData - Complete image data including type, transformation, and raw data
	*/
	addImage(key, mediaData) {
		if (this.map.has(key)) return;
		const path = this.takePath(mediaData.type);
		this.map.set(key, _objectSpread2(_objectSpread2({}, mediaData), {}, { fileName: path.slice(path.lastIndexOf("/") + 1) }));
	}
	/**
	* Gets all images as an array, in the order they were added, each with the file name it is written with.
	*
	* @returns Read-only array of all media data in the collection
	*/
	get Array() {
		return Array.from(this.map.values());
	}
	/**
	* Gets all images with the keys they were added under, in the order they were added.
	*
	* @returns Read-only array of each image's key and media data, whose file name is the one it is written with
	*/
	get Entries() {
		return Array.from(this.map.entries());
	}
};
/**
* Numbering level definitions module for WordprocessingML documents.
*
* This module defines the formatting and behavior of individual levels within
* a numbered or bulleted list hierarchy.
*
* Reference: http://officeopenxml.com/WPnumbering-numFmt.php
*
* @module
*/
/**
* Number format types for list levels.
*
* Defines the various numbering formats available for list levels, including
* decimal, roman numerals, letters, and various international formats.
*
* Reference: http://officeopenxml.com/WPnumbering-numFmt.php
*
* @example
* ```typescript
* // Use decimal numbering (1, 2, 3...)
* format: LevelFormat.DECIMAL
*
* // Use lowercase roman numerals (i, ii, iii...)
* format: LevelFormat.LOWER_ROMAN
*
* // Use bullet points
* format: LevelFormat.BULLET
* ```
*
* @publicApi
*/
var LevelFormat = {
	/** Decimal numbering (1, 2, 3...). */
	DECIMAL: "decimal",
	/** Uppercase roman numerals (I, II, III...). */
	UPPER_ROMAN: "upperRoman",
	/** Lowercase roman numerals (i, ii, iii...). */
	LOWER_ROMAN: "lowerRoman",
	/** Uppercase letters (A, B, C...). */
	UPPER_LETTER: "upperLetter",
	/** Lowercase letters (a, b, c...). */
	LOWER_LETTER: "lowerLetter",
	/** Ordinal numbers (1st, 2nd, 3rd...). */
	ORDINAL: "ordinal",
	/** Cardinal text (one, two, three...). */
	CARDINAL_TEXT: "cardinalText",
	/** Ordinal text (first, second, third...). */
	ORDINAL_TEXT: "ordinalText",
	/** Hexadecimal numbering. */
	HEX: "hex",
	/** Chicago Manual of Style numbering. */
	CHICAGO: "chicago",
	/** Ideograph digital numbering. */
	IDEOGRAPH__DIGITAL: "ideographDigital",
	/** Japanese counting system. */
	JAPANESE_COUNTING: "japaneseCounting",
	/** Japanese aiueo ordering. */
	AIUEO: "aiueo",
	/** Japanese iroha ordering. */
	IROHA: "iroha",
	/** Full-width decimal numbering. */
	DECIMAL_FULL_WIDTH: "decimalFullWidth",
	/** Half-width decimal numbering. */
	DECIMAL_HALF_WIDTH: "decimalHalfWidth",
	/** Japanese legal numbering. */
	JAPANESE_LEGAL: "japaneseLegal",
	/** Japanese digital ten thousand numbering. */
	JAPANESE_DIGITAL_TEN_THOUSAND: "japaneseDigitalTenThousand",
	/** Decimal numbers enclosed in circles. */
	DECIMAL_ENCLOSED_CIRCLE: "decimalEnclosedCircle",
	/** Full-width decimal numbering variant 2. */
	DECIMAL_FULL_WIDTH2: "decimalFullWidth2",
	/** Full-width aiueo ordering. */
	AIUEO_FULL_WIDTH: "aiueoFullWidth",
	/** Full-width iroha ordering. */
	IROHA_FULL_WIDTH: "irohaFullWidth",
	/** Decimal with leading zeros. */
	DECIMAL_ZERO: "decimalZero",
	/** Bullet points. */
	BULLET: "bullet",
	/** Korean ganada ordering. */
	GANADA: "ganada",
	/** Korean chosung ordering. */
	CHOSUNG: "chosung",
	/** Decimal enclosed with fullstop. */
	DECIMAL_ENCLOSED_FULLSTOP: "decimalEnclosedFullstop",
	/** Decimal enclosed in parentheses. */
	DECIMAL_ENCLOSED_PARENTHESES: "decimalEnclosedParen",
	/** Decimal enclosed in circles (Chinese). */
	DECIMAL_ENCLOSED_CIRCLE_CHINESE: "decimalEnclosedCircleChinese",
	/** Ideograph enclosed in circles. */
	IDEOGRAPH_ENCLOSED_CIRCLE: "ideographEnclosedCircle",
	/** Traditional ideograph numbering. */
	IDEOGRAPH_TRADITIONAL: "ideographTraditional",
	/** Ideograph zodiac numbering. */
	IDEOGRAPH_ZODIAC: "ideographZodiac",
	/** Traditional ideograph zodiac numbering. */
	IDEOGRAPH_ZODIAC_TRADITIONAL: "ideographZodiacTraditional",
	/** Taiwanese counting system. */
	TAIWANESE_COUNTING: "taiwaneseCounting",
	/** Traditional ideograph legal numbering. */
	IDEOGRAPH_LEGAL_TRADITIONAL: "ideographLegalTraditional",
	/** Taiwanese counting thousand system. */
	TAIWANESE_COUNTING_THOUSAND: "taiwaneseCountingThousand",
	/** Taiwanese digital numbering. */
	TAIWANESE_DIGITAL: "taiwaneseDigital",
	/** Chinese counting system. */
	CHINESE_COUNTING: "chineseCounting",
	/** Simplified Chinese legal numbering. */
	CHINESE_LEGAL_SIMPLIFIED: "chineseLegalSimplified",
	/** Chinese counting thousand system. */
	CHINESE_COUNTING_THOUSAND: "chineseCountingThousand",
	/** Korean digital numbering. */
	KOREAN_DIGITAL: "koreanDigital",
	/** Korean counting system. */
	KOREAN_COUNTING: "koreanCounting",
	/** Korean legal numbering. */
	KOREAN_LEGAL: "koreanLegal",
	/** Korean digital numbering variant 2. */
	KOREAN_DIGITAL2: "koreanDigital2",
	/** Vietnamese counting system. */
	VIETNAMESE_COUNTING: "vietnameseCounting",
	/** Russian lowercase numbering. */
	RUSSIAN_LOWER: "russianLower",
	/** Russian uppercase numbering. */
	RUSSIAN_UPPER: "russianUpper",
	/** No numbering. */
	NONE: "none",
	/** Number enclosed in dashes. */
	NUMBER_IN_DASH: "numberInDash",
	/** Hebrew numbering variant 1. */
	HEBREW1: "hebrew1",
	/** Hebrew numbering variant 2. */
	HEBREW2: "hebrew2",
	/** Arabic alpha numbering. */
	ARABIC_ALPHA: "arabicAlpha",
	/** Arabic abjad numbering. */
	ARABIC_ABJAD: "arabicAbjad",
	/** Hindi vowels. */
	HINDI_VOWELS: "hindiVowels",
	/** Hindi consonants. */
	HINDI_CONSONANTS: "hindiConsonants",
	/** Hindi numbers. */
	HINDI_NUMBERS: "hindiNumbers",
	/** Hindi counting system. */
	HINDI_COUNTING: "hindiCounting",
	/** Thai letters. */
	THAI_LETTERS: "thaiLetters",
	/** Thai numbers. */
	THAI_NUMBERS: "thaiNumbers",
	/** Thai counting system. */
	THAI_COUNTING: "thaiCounting",
	/** Thai Baht text. */
	BAHT_TEXT: "bahtText",
	/** Dollar text. */
	DOLLAR_TEXT: "dollarText",
	/** Custom numbering format. */
	CUSTOM: "custom"
};
/**
* Attributes for numbering levels.
*/
var LevelAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			ilvl: "w:ilvl",
			tentative: "w:tentative"
		});
	}
};
/**
* Number format specification for a level.
*
* Specifies the numbering format to use (decimal, roman, letter, etc.).
*/
var NumberFormat$1 = class extends XmlComponent {
	constructor(value) {
		super("w:numFmt");
		this.root.push(new Attributes({ val: value }));
	}
};
/**
* Level text template for displaying the numbering.
*
* The text can include placeholders like %1, %2, etc. to reference
* numbering from different levels.
*/
var LevelText = class extends XmlComponent {
	constructor(value) {
		super("w:lvlText");
		this.root.push(new Attributes({ val: value }));
	}
};
var levelAlignment = (value) => {
	switch (value) {
		case AlignmentType.CENTER: return "center";
		case AlignmentType.END:
		case AlignmentType.RIGHT: return "right";
		default: return "left";
	}
};
/**
* Alignment specification for level numbering.
*/
var LevelJc = class extends XmlComponent {
	constructor(value) {
		super("w:lvlJc");
		this.root.push(new Attributes({ val: levelAlignment(value) }));
	}
};
/**
* Suffix specification for a level.
*
* Defines what character(s) follow the numbering text.
*/
var Suffix = class extends XmlComponent {
	constructor(value) {
		super("w:suff");
		this.root.push(new Attributes({ val: value }));
	}
};
/**
* Legal numbering style flag.
*
* When enabled, every number in the level's text is a decimal number, whatever its own level's format, such as 1.1
* rather than 一.1.
*
* Reference: http://officeopenxml.com/WPnumbering-isLgl.php
*/
var IsLegalNumberingStyle = class extends XmlComponent {
	constructor() {
		super("w:isLgl");
	}
};
/**
* Base class for numbering level definitions.
*
* Defines the formatting and behavior of a single level in a multi-level
* numbering scheme. Each level can have its own numbering format, text template,
* alignment, and styling.
*
* Reference: http://officeopenxml.com/WPnumbering-numFmt.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Lvl">
*   <xsd:sequence>
*     <xsd:element name="start" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="numFmt" type="CT_NumFmt" minOccurs="0"/>
*     <xsd:element name="lvlRestart" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="pStyle" type="CT_String" minOccurs="0"/>
*     <xsd:element name="isLgl" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="suff" type="CT_LevelSuffix" minOccurs="0"/>
*     <xsd:element name="lvlText" type="CT_LevelText" minOccurs="0"/>
*     <xsd:element name="lvlPicBulletId" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="legacy" type="CT_LvlLegacy" minOccurs="0"/>
*     <xsd:element name="lvlJc" type="CT_Jc" minOccurs="0"/>
*     <xsd:element name="pPr" type="CT_PPrGeneral" minOccurs="0"/>
*     <xsd:element name="rPr" type="CT_RPr" minOccurs="0"/>
*   </xsd:sequence>
*   <xsd:attribute name="ilvl" type="ST_DecimalNumber" use="required"/>
*   <xsd:attribute name="tplc" type="ST_LongHexNumber" use="optional"/>
*   <xsd:attribute name="tentative" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*/
var LevelBase = class extends XmlComponent {
	/**
	* Creates a new numbering level.
	*
	* @param options - Level configuration options
	* @throws Error if level is greater than 9 (Word limitation)
	*/
	constructor({ level, format, text, alignment = AlignmentType.START, start = 1, style, suffix, isLegalNumberingStyle }) {
		super("w:lvl");
		_defineProperty(this, "paragraphProperties", void 0);
		_defineProperty(this, "runProperties", void 0);
		this.root.push(new NumberValueElement("w:start", decimalNumber(start)));
		if (format) this.root.push(new NumberFormat$1(format));
		if (style === null || style === void 0 ? void 0 : style.style) this.root.push(createParagraphStyle(style.style));
		if (isLegalNumberingStyle) this.root.push(new IsLegalNumberingStyle());
		if (suffix) this.root.push(new Suffix(suffix));
		if (text) this.root.push(new LevelText(text));
		this.root.push(new LevelJc(alignment));
		this.paragraphProperties = new ParagraphProperties(style && style.paragraph, {
			implicitListParagraphStyle: false,
			inListOrder: false
		});
		this.runProperties = new RunProperties((style === null || style === void 0 ? void 0 : style.run) && _objectSpread2(_objectSpread2({}, style.run), {}, {
			highlight: void 0,
			math: void 0,
			revision: void 0
		}));
		this.root.push(this.paragraphProperties);
		this.root.push(this.runProperties);
		if (level > 9) throw new Error("Level cannot be greater than 9. Read more here: https://answers.microsoft.com/en-us/msoffice/forum/all/does-word-support-more-than-9-list-levels/d130fdcd-1781-446d-8c84-c6c79124e4d7");
		this.root.push(new LevelAttributes({
			ilvl: decimalNumber(level),
			tentative: 1
		}));
	}
};
/**
* Represents a numbering level within an abstract numbering definition.
*
* This is the standard level definition used in abstract numbering definitions.
* Each abstract numbering definition can contain up to 9 levels (0-8).
*
* Reference: http://officeopenxml.com/WPnumbering-numFmt.php
*
* @example
* ```typescript
* // Create a decimal numbered level
* const level = new Level({
*   level: 0,
*   format: LevelFormat.DECIMAL,
*   text: "%1.",
*   alignment: AlignmentType.LEFT,
*   start: 1,
* });
*
* // Create a bullet level with custom styling
* const bulletLevel = new Level({
*   level: 0,
*   format: LevelFormat.BULLET,
*   text: "\u2022",
*   alignment: AlignmentType.LEFT,
*   style: {
*     paragraph: {
*       indent: { left: 720, hanging: 360 },
*     },
*   },
* });
* ```
*/
var Level = class extends LevelBase {};
/**
* Multi-level type definitions for WordprocessingML documents.
*
* Defines the type of numbering structure (single-level, multi-level, or hybrid).
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* @module
*/
/**
* Represents the multi-level type of a numbering definition.
*
* The multi-level type specifies whether the numbering definition uses a single
* level, multiple levels, or a hybrid approach.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_MultiLevelType">
*   <xsd:attribute name="val" type="ST_MultiLevelType" use="required"/>
* </xsd:complexType>
*
* <xsd:simpleType name="ST_MultiLevelType">
*   <xsd:restriction base="xsd:string">
*     <xsd:enumeration value="singleLevel"/>
*     <xsd:enumeration value="multilevel"/>
*     <xsd:enumeration value="hybridMultilevel"/>
*   </xsd:restriction>
* </xsd:simpleType>
* ```
*
* @example
* ```typescript
* // Create a hybrid multi-level numbering
* const multiLevel = new MultiLevelType("hybridMultilevel");
*
* // Create a single-level numbering
* const singleLevel = new MultiLevelType("singleLevel");
* ```
*/
var MultiLevelType = class extends XmlComponent {
	/**
	* Creates a new multi-level type specification.
	*
	* @param value - The multi-level type: "singleLevel", "multilevel", or "hybridMultilevel"
	*/
	constructor(value) {
		super("w:multiLevelType");
		this.root.push(new Attributes({ val: value }));
	}
};
/**
* Abstract numbering definitions module for WordprocessingML documents.
*
* Abstract numbering definitions contain the formatting and style information
* that can be shared across multiple numbering instances.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* @module
*/
/**
* Attributes for abstract numbering definitions.
*
* @property abstractNumId - Unique identifier for the abstract numbering definition
* @property restartNumberingAfterBreak - Whether to restart numbering after section breaks
*/
var AbstractNumberingAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			abstractNumId: "w:abstractNumId",
			restartNumberingAfterBreak: "w15:restartNumberingAfterBreak"
		});
	}
};
/**
* Represents an abstract numbering definition in a WordprocessingML document.
*
* Abstract numbering definitions define the formatting and style of numbered or
* bulleted lists that can be referenced by concrete numbering instances.
* Each abstract definition can contain up to 9 levels.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_AbstractNum">
*   <xsd:sequence>
*     <xsd:element name="nsid" type="CT_LongHexNumber" minOccurs="0"/>
*     <xsd:element name="multiLevelType" type="CT_MultiLevelType" minOccurs="0"/>
*     <xsd:element name="tmpl" type="CT_LongHexNumber" minOccurs="0"/>
*     <xsd:element name="name" type="CT_String" minOccurs="0"/>
*     <xsd:element name="styleLink" type="CT_String" minOccurs="0"/>
*     <xsd:element name="numStyleLink" type="CT_String" minOccurs="0"/>
*     <xsd:element name="lvl" type="CT_Lvl" minOccurs="0" maxOccurs="9"/>
*   </xsd:sequence>
*   <xsd:attribute name="abstractNumId" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create an abstract numbering definition with multiple levels
* const abstractNumbering = new AbstractNumbering(1, [
*   {
*     level: 0,
*     format: LevelFormat.DECIMAL,
*     text: "%1.",
*     alignment: AlignmentType.LEFT,
*   },
*   {
*     level: 1,
*     format: LevelFormat.LOWER_LETTER,
*     text: "%2)",
*     alignment: AlignmentType.LEFT,
*   },
* ]);
* ```
*/
var AbstractNumbering = class extends XmlComponent {
	/**
	* Creates a new abstract numbering definition.
	*
	* @param id - Unique identifier for this abstract numbering definition
	* @param levelOptions - Array of level definitions (up to 9 levels)
	*/
	constructor(id, levelOptions) {
		super("w:abstractNum");
		_defineProperty(
			this,
			/** The unique identifier for this abstract numbering definition. */
			"id",
			void 0
		);
		this.root.push(new AbstractNumberingAttributes({
			abstractNumId: decimalNumber(id),
			restartNumberingAfterBreak: 0
		}));
		this.root.push(new MultiLevelType("hybridMultilevel"));
		this.id = id;
		for (const option of levelOptions) this.root.push(new Level(option));
	}
};
/**
* Concrete numbering instances module for WordprocessingML documents.
*
* Concrete numbering instances reference abstract numbering definitions and
* can override specific level settings. Each paragraph references a concrete
* numbering instance to apply list formatting.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* @module
*/
/**
* Reference to an abstract numbering definition.
*/
var AbstractNumId = class extends XmlComponent {
	constructor(value) {
		super("w:abstractNumId");
		this.root.push(new Attributes({ val: value }));
	}
};
/**
* Attributes for concrete numbering instances.
*/
var NumAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { numId: "w:numId" });
	}
};
/**
* Represents a concrete numbering instance in a WordprocessingML document.
*
* A concrete numbering instance references an abstract numbering definition and
* can override specific levels. Paragraphs reference concrete numbering instances
* to apply list formatting.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Num">
*   <xsd:sequence>
*     <xsd:element name="abstractNumId" type="CT_DecimalNumber" minOccurs="1"/>
*     <xsd:element name="lvlOverride" type="CT_NumLvl" minOccurs="0" maxOccurs="9"/>
*   </xsd:sequence>
*   <xsd:attribute name="numId" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a concrete numbering instance
* const concreteNumbering = new ConcreteNumbering({
*   numId: 1,
*   abstractNumId: 0,
*   reference: "my-numbering",
*   instance: 0,
*   overrideLevels: [
*     {
*       num: 0,
*       start: 5, // Start numbering at 5 instead of 1
*     },
*   ],
* });
* ```
*/
var ConcreteNumbering = class extends XmlComponent {
	/**
	* Creates a new concrete numbering instance.
	*
	* @param options - Configuration options for the numbering instance
	*/
	constructor(options) {
		super("w:num");
		_defineProperty(
			this,
			/** The unique identifier for this numbering instance. */
			"numId",
			void 0
		);
		_defineProperty(
			this,
			/** The reference name for this numbering instance. */
			"reference",
			void 0
		);
		_defineProperty(
			this,
			/** The instance number for tracking multiple uses. */
			"instance",
			void 0
		);
		_defineProperty(
			this,
			/** For a list a paragraph restarts, the id of that restart, as {@link IConcreteNumberingOptions.restartedListId} describes. */
			"restartedListId",
			void 0
		);
		this.numId = options.numId;
		this.reference = options.reference;
		this.instance = options.instance;
		this.restartedListId = options.restartedListId;
		this.root.push(new NumAttributes({ numId: decimalNumber(options.numId) }));
		this.root.push(new AbstractNumId(decimalNumber(options.abstractNumId)));
		if (options.overrideLevels && options.overrideLevels.length) for (const level of options.overrideLevels) this.root.push(new LevelOverride(level.num, level.start));
	}
};
/**
* Attributes for level overrides.
*/
var LevelOverrideAttributes = class extends XmlAttributeComponent {
	constructor(..._args2) {
		super(..._args2);
		_defineProperty(this, "xmlKeys", { ilvl: "w:ilvl" });
	}
};
/**
* Represents a level override in a concrete numbering instance.
*
* Level overrides allow customization of specific levels within a numbering
* instance, such as changing the starting number.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_NumLvl">
*   <xsd:sequence>
*     <xsd:element name="startOverride" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="lvl" type="CT_Lvl" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="ilvl" type="ST_DecimalNumber" use="required"/>
* </xsd:complexType>
* ```
*/
var LevelOverride = class extends XmlComponent {
	/**
	* Creates a new level override.
	*
	* @param levelNum - The level number to override (0-8)
	* @param start - Optional starting number for the level
	*/
	constructor(levelNum, start) {
		super("w:lvlOverride");
		this.root.push(new LevelOverrideAttributes({ ilvl: levelNum }));
		if (start !== void 0) this.root.push(new StartOverride(start));
	}
};
/**
* Attributes for start override values.
*/
var StartOverrideAttributes = class extends XmlAttributeComponent {
	constructor(..._args3) {
		super(..._args3);
		_defineProperty(this, "xmlKeys", { val: "w:val" });
	}
};
/**
* Represents a start override for a numbering level.
*
* This element overrides the starting number for a specific level.
*/
var StartOverride = class extends XmlComponent {
	/**
	* Creates a new start override.
	*
	* @param start - The starting number
	*/
	constructor(start) {
		super("w:startOverride");
		this.root.push(new StartOverrideAttributes({ val: start }));
	}
};
/**
* Numbering module for WordprocessingML documents.
*
* Numbering provides support for numbered and bulleted lists.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* @see https://stackoverflow.com/questions/58622437/purpose-of-abstractnum-and-numberinginstance
*
* @module
*/
/**
* Represents the numbering definitions in a WordprocessingML document.
*
* The numbering element contains abstract numbering definitions and their
* concrete instances, which are referenced by paragraphs to create lists.
* Each numbering configuration includes a default bullet list and any
* custom numbering schemes defined by the user.
*
* Reference: http://officeopenxml.com/WPnumbering.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="numbering" type="CT_Numbering"/>
*
* <xsd:complexType name="CT_Numbering">
*   <xsd:sequence>
*     <xsd:element name="numPicBullet" type="CT_NumPicBullet" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="abstractNum" type="CT_AbstractNum" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="num" type="CT_Num" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="numIdMacAtCleanup" type="CT_DecimalNumber" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create numbering with custom decimal list
* const numbering = new Numbering({
*   config: [
*     {
*       reference: "my-decimal-list",
*       levels: [
*         {
*           level: 0,
*           format: LevelFormat.DECIMAL,
*           text: "%1.",
*           alignment: AlignmentType.LEFT,
*           start: 1,
*           style: {
*             paragraph: {
*               indent: { left: 720, hanging: 360 },
*             },
*           },
*         },
*         {
*           level: 1,
*           format: LevelFormat.LOWER_LETTER,
*           text: "%2)",
*           alignment: AlignmentType.LEFT,
*           style: {
*             paragraph: {
*               indent: { left: 1440, hanging: 360 },
*             },
*           },
*         },
*       ],
*     },
*   ],
* });
* ```
*/
var Numbering = class extends XmlComponent {
	/**
	* Creates a new numbering definition collection.
	*
	* Initializes the numbering with a default bullet list configuration and
	* any custom numbering configurations provided in the options.
	*
	* @param options - Configuration options for numbering definitions
	*/
	constructor(options) {
		super("w:numbering");
		_defineProperty(this, "abstractNumberingMap", /* @__PURE__ */ new Map());
		_defineProperty(this, "concreteNumberingMap", /* @__PURE__ */ new Map());
		_defineProperty(this, "referenceConfigMap", /* @__PURE__ */ new Map());
		_defineProperty(this, "abstractNumUniqueNumericId", abstractNumUniqueNumericIdGen());
		_defineProperty(this, "concreteNumUniqueNumericId", concreteNumUniqueNumericIdGen());
		this.root.push(new DocumentAttributes([
			"wpc",
			"mc",
			"o",
			"r",
			"m",
			"v",
			"wp14",
			"wp",
			"w10",
			"w",
			"w14",
			"w15",
			"wpg",
			"wpi",
			"wne",
			"wps"
		], "w14 w15 wp14"));
		const abstractNumbering = new AbstractNumbering(this.abstractNumUniqueNumericId(), [
			{
				level: 0,
				format: LevelFormat.BULLET,
				text: "●",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: convertInchesToTwip(.5),
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 1,
				format: LevelFormat.BULLET,
				text: "○",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: convertInchesToTwip(1),
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 2,
				format: LevelFormat.BULLET,
				text: "■",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 2160,
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 3,
				format: LevelFormat.BULLET,
				text: "●",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 2880,
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 4,
				format: LevelFormat.BULLET,
				text: "○",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 3600,
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 5,
				format: LevelFormat.BULLET,
				text: "■",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 4320,
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 6,
				format: LevelFormat.BULLET,
				text: "●",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 5040,
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 7,
				format: LevelFormat.BULLET,
				text: "●",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 5760,
					hanging: convertInchesToTwip(.25)
				} } }
			},
			{
				level: 8,
				format: LevelFormat.BULLET,
				text: "●",
				alignment: AlignmentType.LEFT,
				style: { paragraph: { indent: {
					left: 6480,
					hanging: convertInchesToTwip(.25)
				} } }
			}
		]);
		this.concreteNumberingMap.set("default-bullet-numbering", new ConcreteNumbering({
			numId: 1,
			abstractNumId: abstractNumbering.id,
			reference: "default-bullet-numbering",
			instance: 0,
			overrideLevels: [{
				num: 0,
				start: 1
			}]
		}));
		this.abstractNumberingMap.set("default-bullet-numbering", abstractNumbering);
		for (const con of options.config) {
			this.abstractNumberingMap.set(con.reference, new AbstractNumbering(this.abstractNumUniqueNumericId(), con.levels));
			this.referenceConfigMap.set(con.reference, con.levels);
		}
	}
	/**
	* Prepares the numbering definitions for XML serialization.
	*
	* Adds all abstract and concrete numbering definitions to the XML tree.
	*
	* @param context - The XML context
	* @returns The prepared XML object
	*/
	prepForXml(context) {
		this.root.splice(1, this.root.length - 1, ...this.abstractNumberingMap.values(), ...this.concreteNumberingMap.values());
		return super.prepForXml(context);
	}
	/**
	* Creates a concrete numbering instance from an abstract numbering definition.
	*
	* This method creates a new concrete numbering instance that references an
	* abstract numbering definition. It's used internally when paragraphs reference
	* numbering configurations.
	*
	* @param reference - The reference name of the abstract numbering definition
	* @param instance - The instance number for this concrete numbering
	* @param definition - The list's definition, for a list a paragraph gives its own definition of. It is added with
	* its reference, unless the numbering already has a list with that reference, such as one of the document's
	* `numbering` option, which is kept
	* @param restartedListId - For a list a paragraph starts again with `restart`, the id of that restart. The list is
	* then that restart's own, not the `instance`'s
	*/
	createConcreteNumberingInstance(reference, instance, definition, restartedListId) {
		var _this$referenceConfig;
		if (definition && !this.abstractNumberingMap.has(definition.reference)) {
			this.abstractNumberingMap.set(definition.reference, new AbstractNumbering(this.abstractNumUniqueNumericId(), definition.levels));
			this.referenceConfigMap.set(definition.reference, definition.levels);
		}
		const abstractNumbering = this.abstractNumberingMap.get(reference);
		if (!abstractNumbering) return;
		const fullReference = listKey(reference, instance, restartedListId);
		if (this.concreteNumberingMap.has(fullReference)) return;
		const referenceConfigLevels = (_this$referenceConfig = this.referenceConfigMap.get(reference)) !== null && _this$referenceConfig !== void 0 ? _this$referenceConfig : [{ level: 0 }];
		const concreteNumberingSettings = {
			numId: this.concreteNumUniqueNumericId(),
			abstractNumId: abstractNumbering.id,
			reference,
			instance,
			restartedListId,
			overrideLevels: referenceConfigLevels.map(({ level, start = 1 }) => ({
				num: level,
				start: decimalNumber(start)
			}))
		};
		this.concreteNumberingMap.set(fullReference, new ConcreteNumbering(concreteNumberingSettings));
	}
	/**
	* Gets all concrete numbering instances.
	*
	* @returns An array of all concrete numbering instances
	*/
	get ConcreteNumbering() {
		return Array.from(this.concreteNumberingMap.values());
	}
	/**
	* Gets all reference configurations.
	*
	* @returns An array of all numbering reference configurations
	*/
	get ReferenceConfig() {
		return Array.from(this.referenceConfigMap.values());
	}
};
/**
* The parts added to a document's package when it is written, with their paths under word/, in the order they were
* added. Not part of the public API: `File` holds one, and the compiler writes its parts, as `patchDocument` does.
*/
var PackageParts = class {
	/**
	* @param contentTypes - Where each part's content type is added
	* @param existingPaths - The paths under word/ of the parts the package already has, such as a template's charts
	* and images, which new parts don't take
	*/
	constructor(contentTypes, existingPaths = /* @__PURE__ */ new Set()) {
		_defineProperty(this, "contentTypes", void 0);
		_defineProperty(this, "paths", /* @__PURE__ */ new Map());
		_defineProperty(this, "taken", void 0);
		_defineProperty(this, "folders", /* @__PURE__ */ new WeakMap());
		this.contentTypes = contentTypes;
		this.taken = new Set(existingPaths);
	}
	/**
	* Adds a part, and its content type, once.
	*
	* @returns The part's path under word/, such as "charts/chart1.xml"
	*/
	add(part) {
		const added = this.paths.get(part);
		if (added !== void 0) return added;
		const { folder, name, extension, contentType } = part.options;
		const path = this.takePath(folder, name, extension);
		this.paths.set(part, path);
		this.contentTypes.addOverride(contentType, `/word/${path}`);
		return path;
	}
	/**
	* Takes the lowest-numbered path in a folder that nothing has yet, so that nothing else is written there: the
	* package's own parts, the parts added, and the document's images, which `Media` names with this, as Word names
	* them: media/image1.png, media/image2.png and so on.
	*
	* @param folder - The folder under word/, such as "media"
	* @param name - The start of the file name, such as "image"
	* @param extension - The file name's extension, such as "png"
	* @returns The path under word/, such as "media/image1.png"
	*/
	takePath(folder, name, extension) {
		let index = 1;
		while (this.taken.has(`${folder}/${name}${index}.${extension}`)) index++;
		const path = `${folder}/${name}${index}.${extension}`;
		this.taken.add(path);
		return path;
	}
	/**
	* Each part added, with its path under word/, in the order they were added.
	*
	* A part related as an OLE object is listed too, though the parts are typed as they were before a part could be:
	* `File`, whose type is public, has these parts, and the compiler only writes their content.
	*/
	get Array() {
		return [...this.paths].map(([part, path]) => ({
			part,
			path
		}));
	}
	/**
	* Creates the relationships of a part whose XML is being written, so the parts its XML refers to are found from its
	* folder.
	*
	* @param path - The part's path under word/
	*/
	createRelationships(path) {
		const relationships = new Relationships();
		this.folders.set(relationships, path.slice(0, path.indexOf("/")));
		return relationships;
	}
	/**
	* The target of a relationship to a part, relative to the part the relationships are from. The document, headers,
	* footers, footnotes, endnotes and comments are all in word/.
	*
	* @param path - The part's path under word/
	*/
	getTarget(relationships, path) {
		const from = this.folders.get(relationships);
		if (from === void 0) return path;
		return path.startsWith(`${from}/`) ? path.slice(from.length + 1) : `../${path}`;
	}
};
/**
* Compatibility setting module for WordprocessingML documents.
*
* This module provides the compatibility mode version setting that controls
* which Word version's behavior the document should emulate.
*
* Reference: https://docs.microsoft.com/en-us/openspecs/office_standards/ms-docx/90138c4d-eb18-4edc-aa6c-dfb799cb1d0d
*
* @module
*/
/**
* Creates a compatibility setting for a WordprocessingML document.
*
* Currently hard-coded to set Microsoft Word compatibility mode version.
* This controls which Word version's formatting and layout behavior the document emulates.
*
* Common version values:
* - 11: Word 2003
* - 12: Word 2007
* - 14: Word 2010
* - 15: Word 2013+
*
* Reference: https://docs.microsoft.com/en-us/openspecs/office_standards/ms-docx/90138c4d-eb18-4edc-aa6c-dfb799cb1d0d
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_CompatSetting">
*   <xsd:attribute name="name" type="s:ST_String"/>
*   <xsd:attribute name="uri" type="s:ST_String"/>
*   <xsd:attribute name="val" type="s:ST_String"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Set compatibility mode to Word 2013+
* createCompatibilitySetting(15);
*
* // Set compatibility mode to Word 2010
* createCompatibilitySetting(14);
* ```
*/
var createCompatibilitySetting = (version) => new BuilderElement({
	name: "w:compatSetting",
	attributes: {
		version: {
			key: "w:val",
			value: version
		},
		name: {
			key: "w:name",
			value: "compatibilityMode"
		},
		uri: {
			key: "w:uri",
			value: "http://schemas.microsoft.com/office/word"
		}
	}
});
/**
* Compatibility module for WordprocessingML documents.
*
* This module provides compatibility settings that control how Word
* handles documents created in older versions or other word processors.
*
* Reference: http://www.datypic.com/sc/ooxml/e-w_compat-1.html
*
* @module
*/
/**
* Represents compatibility settings in a WordprocessingML document.
*
* Compatibility settings control document rendering and layout behavior
* to match older Word versions or other word processors. This ensures
* documents maintain consistent appearance across different applications.
*
* Reference: http://www.datypic.com/sc/ooxml/e-w_compat-1.html
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Compat">
*   <xsd:sequence>
*     <xsd:element name="useSingleBorderforContiguousCells" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="wpJustification" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="noTabHangInd" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="noLeading" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="usePrinterMetrics" type="CT_OnOff" minOccurs="0"/>
*     <!-- Additional compatibility elements omitted for brevity -->
*     <xsd:element name="compatSetting" type="CT_CompatSetting" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Set compatibility mode to Word 2013+
* new Compatibility({
*   version: 15,
* });
*
* // Enable specific compatibility options
* new Compatibility({
*   version: 15,
*   usePrinterMetrics: true,
*   doNotSnapToGridInCell: true,
* });
* ```
*/
var Compatibility = class extends XmlComponent {
	constructor(options) {
		super("w:compat");
		if (options.useSingleBorderforContiguousCells) this.root.push(new OnOffElement("w:useSingleBorderforContiguousCells", options.useSingleBorderforContiguousCells));
		if (options.wordPerfectJustification) this.root.push(new OnOffElement("w:wpJustification", options.wordPerfectJustification));
		if (options.noTabStopForHangingIndent) this.root.push(new OnOffElement("w:noTabHangInd", options.noTabStopForHangingIndent));
		if (options.noLeading) this.root.push(new OnOffElement("w:noLeading", options.noLeading));
		if (options.spaceForUnderline) this.root.push(new OnOffElement("w:spaceForUL", options.spaceForUnderline));
		if (options.noColumnBalance) this.root.push(new OnOffElement("w:noColumnBalance", options.noColumnBalance));
		if (options.balanceSingleByteDoubleByteWidth) this.root.push(new OnOffElement("w:balanceSingleByteDoubleByteWidth", options.balanceSingleByteDoubleByteWidth));
		if (options.noExtraLineSpacing) this.root.push(new OnOffElement("w:noExtraLineSpacing", options.noExtraLineSpacing));
		if (options.doNotLeaveBackslashAlone) this.root.push(new OnOffElement("w:doNotLeaveBackslashAlone", options.doNotLeaveBackslashAlone));
		if (options.underlineTrailingSpaces) this.root.push(new OnOffElement("w:ulTrailSpace", options.underlineTrailingSpaces));
		if (options.doNotExpandShiftReturn) this.root.push(new OnOffElement("w:doNotExpandShiftReturn", options.doNotExpandShiftReturn));
		if (options.spacingInWholePoints) this.root.push(new OnOffElement("w:spacingInWholePoints", options.spacingInWholePoints));
		if (options.lineWrapLikeWord6) this.root.push(new OnOffElement("w:lineWrapLikeWord6", options.lineWrapLikeWord6));
		if (options.printBodyTextBeforeHeader) this.root.push(new OnOffElement("w:printBodyTextBeforeHeader", options.printBodyTextBeforeHeader));
		if (options.printColorsBlack) this.root.push(new OnOffElement("w:printColBlack", options.printColorsBlack));
		if (options.spaceWidth) this.root.push(new OnOffElement("w:wpSpaceWidth", options.spaceWidth));
		if (options.showBreaksInFrames) this.root.push(new OnOffElement("w:showBreaksInFrames", options.showBreaksInFrames));
		if (options.subFontBySize) this.root.push(new OnOffElement("w:subFontBySize", options.subFontBySize));
		if (options.suppressBottomSpacing) this.root.push(new OnOffElement("w:suppressBottomSpacing", options.suppressBottomSpacing));
		if (options.suppressTopSpacing) this.root.push(new OnOffElement("w:suppressTopSpacing", options.suppressTopSpacing));
		if (options.suppressSpacingAtTopOfPage) this.root.push(new OnOffElement("w:suppressSpacingAtTopOfPage", options.suppressSpacingAtTopOfPage));
		if (options.suppressTopSpacingWP) this.root.push(new OnOffElement("w:suppressTopSpacingWP", options.suppressTopSpacingWP));
		if (options.suppressSpBfAfterPgBrk) this.root.push(new OnOffElement("w:suppressSpBfAfterPgBrk", options.suppressSpBfAfterPgBrk));
		if (options.swapBordersFacingPages) this.root.push(new OnOffElement("w:swapBordersFacingPages", options.swapBordersFacingPages));
		if (options.convertMailMergeEsc) this.root.push(new OnOffElement("w:convMailMergeEsc", options.convertMailMergeEsc));
		if (options.truncateFontHeightsLikeWP6) this.root.push(new OnOffElement("w:truncateFontHeightsLikeWP6", options.truncateFontHeightsLikeWP6));
		if (options.macWordSmallCaps) this.root.push(new OnOffElement("w:mwSmallCaps", options.macWordSmallCaps));
		if (options.usePrinterMetrics) this.root.push(new OnOffElement("w:usePrinterMetrics", options.usePrinterMetrics));
		if (options.doNotSuppressParagraphBorders) this.root.push(new OnOffElement("w:doNotSuppressParagraphBorders", options.doNotSuppressParagraphBorders));
		if (options.wrapTrailSpaces) this.root.push(new OnOffElement("w:wrapTrailSpaces", options.wrapTrailSpaces));
		if (options.footnoteLayoutLikeWW8) this.root.push(new OnOffElement("w:footnoteLayoutLikeWW8", options.footnoteLayoutLikeWW8));
		if (options.shapeLayoutLikeWW8) this.root.push(new OnOffElement("w:shapeLayoutLikeWW8", options.shapeLayoutLikeWW8));
		if (options.alignTablesRowByRow) this.root.push(new OnOffElement("w:alignTablesRowByRow", options.alignTablesRowByRow));
		if (options.forgetLastTabAlignment) this.root.push(new OnOffElement("w:forgetLastTabAlignment", options.forgetLastTabAlignment));
		if (options.adjustLineHeightInTable) this.root.push(new OnOffElement("w:adjustLineHeightInTable", options.adjustLineHeightInTable));
		if (options.autoSpaceLikeWord95) this.root.push(new OnOffElement("w:autoSpaceLikeWord95", options.autoSpaceLikeWord95));
		if (options.noSpaceRaiseLower) this.root.push(new OnOffElement("w:noSpaceRaiseLower", options.noSpaceRaiseLower));
		if (options.doNotUseHTMLParagraphAutoSpacing) this.root.push(new OnOffElement("w:doNotUseHTMLParagraphAutoSpacing", options.doNotUseHTMLParagraphAutoSpacing));
		if (options.layoutRawTableWidth) this.root.push(new OnOffElement("w:layoutRawTableWidth", options.layoutRawTableWidth));
		if (options.layoutTableRowsApart) this.root.push(new OnOffElement("w:layoutTableRowsApart", options.layoutTableRowsApart));
		if (options.useWord97LineBreakRules) this.root.push(new OnOffElement("w:useWord97LineBreakRules", options.useWord97LineBreakRules));
		if (options.doNotBreakWrappedTables) this.root.push(new OnOffElement("w:doNotBreakWrappedTables", options.doNotBreakWrappedTables));
		if (options.doNotSnapToGridInCell) this.root.push(new OnOffElement("w:doNotSnapToGridInCell", options.doNotSnapToGridInCell));
		if (options.selectFieldWithFirstOrLastCharacter) this.root.push(new OnOffElement("w:selectFldWithFirstOrLastChar", options.selectFieldWithFirstOrLastCharacter));
		if (options.applyBreakingRules) this.root.push(new OnOffElement("w:applyBreakingRules", options.applyBreakingRules));
		if (options.doNotWrapTextWithPunctuation) this.root.push(new OnOffElement("w:doNotWrapTextWithPunct", options.doNotWrapTextWithPunctuation));
		if (options.doNotUseEastAsianBreakRules) this.root.push(new OnOffElement("w:doNotUseEastAsianBreakRules", options.doNotUseEastAsianBreakRules));
		if (options.useWord2002TableStyleRules) this.root.push(new OnOffElement("w:useWord2002TableStyleRules", options.useWord2002TableStyleRules));
		if (options.growAutofit) this.root.push(new OnOffElement("w:growAutofit", options.growAutofit));
		if (options.useFELayout) this.root.push(new OnOffElement("w:useFELayout", options.useFELayout));
		if (options.useNormalStyleForList) this.root.push(new OnOffElement("w:useNormalStyleForList", options.useNormalStyleForList));
		if (options.doNotUseIndentAsNumberingTabStop) this.root.push(new OnOffElement("w:doNotUseIndentAsNumberingTabStop", options.doNotUseIndentAsNumberingTabStop));
		if (options.useAlternateEastAsianLineBreakRules) this.root.push(new OnOffElement("w:useAltKinsokuLineBreakRules", options.useAlternateEastAsianLineBreakRules));
		if (options.allowSpaceOfSameStyleInTable) this.root.push(new OnOffElement("w:allowSpaceOfSameStyleInTable", options.allowSpaceOfSameStyleInTable));
		if (options.doNotSuppressIndentation) this.root.push(new OnOffElement("w:doNotSuppressIndentation", options.doNotSuppressIndentation));
		if (options.doNotAutofitConstrainedTables) this.root.push(new OnOffElement("w:doNotAutofitConstrainedTables", options.doNotAutofitConstrainedTables));
		if (options.autofitToFirstFixedWidthCell) this.root.push(new OnOffElement("w:autofitToFirstFixedWidthCell", options.autofitToFirstFixedWidthCell));
		if (options.underlineTabInNumberingList) this.root.push(new OnOffElement("w:underlineTabInNumList", options.underlineTabInNumberingList));
		if (options.displayHangulFixedWidth) this.root.push(new OnOffElement("w:displayHangulFixedWidth", options.displayHangulFixedWidth));
		if (options.splitPgBreakAndParaMark) this.root.push(new OnOffElement("w:splitPgBreakAndParaMark", options.splitPgBreakAndParaMark));
		if (options.doNotVerticallyAlignCellWithSp) this.root.push(new OnOffElement("w:doNotVertAlignCellWithSp", options.doNotVerticallyAlignCellWithSp));
		if (options.doNotBreakConstrainedForcedTable) this.root.push(new OnOffElement("w:doNotBreakConstrainedForcedTable", options.doNotBreakConstrainedForcedTable));
		if (options.ignoreVerticalAlignmentInTextboxes) this.root.push(new OnOffElement("w:doNotVertAlignInTxbx", options.ignoreVerticalAlignmentInTextboxes));
		if (options.useAnsiKerningPairs) this.root.push(new OnOffElement("w:useAnsiKerningPairs", options.useAnsiKerningPairs));
		if (options.cachedColumnBalance) this.root.push(new OnOffElement("w:cachedColBalance", options.cachedColumnBalance));
		if (options.version) this.root.push(createCompatibilitySetting(options.version));
	}
};
/**
* Hashes the password that stops a document's protection, as Word does.
*
* Reference: ISO/IEC 29500-1 17.15.1.29 (documentProtection) and the legacy password algorithm it builds on,
* ECMA-376 Part 4 2.15.1.28
*
* @module
*/
/** How many times Word hashes the password again, which is what it writes in `w:cryptSpinCount` */
var PROTECTION_PASSWORD_SPIN_COUNT = 1e5;
var MAX_PASSWORD_LENGTH = 15;
var INITIAL_CODES = [
	57840,
	7439,
	52380,
	33984,
	4364,
	3600,
	61902,
	12606,
	6258,
	57657,
	54287,
	34041,
	10252,
	43370,
	20163
];
var ENCRYPTION_MATRIX = [
	[
		44796,
		19929,
		39858,
		10053,
		20106,
		40212,
		10761
	],
	[
		31585,
		63170,
		64933,
		60267,
		50935,
		40399,
		11199
	],
	[
		17763,
		35526,
		1453,
		2906,
		5812,
		11624,
		23248
	],
	[
		885,
		1770,
		3540,
		7080,
		14160,
		28320,
		56640
	],
	[
		55369,
		41139,
		20807,
		41614,
		21821,
		43642,
		17621
	],
	[
		28485,
		56970,
		44341,
		19019,
		38038,
		14605,
		29210
	],
	[
		60195,
		50791,
		40175,
		10751,
		21502,
		43004,
		24537
	],
	[
		18387,
		36774,
		3949,
		7898,
		15796,
		31592,
		63184
	],
	[
		47201,
		24803,
		49606,
		37805,
		14203,
		28406,
		56812
	],
	[
		17824,
		35648,
		1697,
		3394,
		6788,
		13576,
		27152
	],
	[
		43601,
		17539,
		35078,
		557,
		1114,
		2228,
		4456
	],
	[
		30388,
		60776,
		51953,
		34243,
		7079,
		14158,
		28316
	],
	[
		14128,
		28256,
		56512,
		43425,
		17251,
		34502,
		7597
	],
	[
		13105,
		26210,
		52420,
		35241,
		883,
		1766,
		3532
	],
	[
		4129,
		8258,
		16516,
		33032,
		4657,
		9314,
		18628
	]
];
var rotateLeft15 = (value) => value >> 14 & 1 | value << 1 & 32767;
/**
* The legacy key Word derives from a password before hashing it, as uppercase hex in reversed byte order. The
* standard's example is "Example", whose key 0x64CEED7E is written "7EEDCE64".
*
* @internal
*/
var legacyPasswordKey = (password) => {
	const bytes = password.slice(0, MAX_PASSWORD_LENGTH).split("").map((character) => {
		const code = character.charCodeAt(0);
		return (code & 255) !== 0 ? code & 255 : code >> 8 & 255;
	});
	const highOrderWord = bytes.reduce((word, byte, index) => ENCRYPTION_MATRIX[MAX_PASSWORD_LENGTH - bytes.length + index].reduce((current, code, bit) => byte >> bit & 1 ? current ^ code : current, word), INITIAL_CODES[bytes.length - 1]);
	const lowOrderWord = (rotateLeft15(bytes.reduceRight((word, byte) => rotateLeft15(word) ^ byte, 0)) ^ bytes.length ^ 52811) & 65535;
	return [
		lowOrderWord & 255,
		lowOrderWord >> 8,
		highOrderWord & 255,
		highOrderWord >> 8
	].map((byte) => byte.toString(16).toUpperCase().padStart(2, "0")).join("");
};
/**
* Hashes a password for `w:documentProtection` as Word does, with SHA-256: SHA-256 of the salt and the password's
* legacy key (in UTF-16LE), then SHA-256 of each hash and its iteration number (32-bit little-endian), `spinCount`
* times.
*
* Word itself uses SHA-512, and reads either. JavaScript works SHA-512's 64-bit words out in 32-bit halves, so
* 100,000 rounds of it take a second or more, where SHA-256 takes about a tenth of that.
*
* @param password - The password, of at least one character
* @param salt - The salt Word reads from `w:salt`
* @param spinCount - How many times to hash again, which Word reads from `w:cryptSpinCount`
* @returns The hash Word reads from `w:hash`
*
* @internal
*/
var hashProtectionPassword = (password, salt, spinCount) => {
	const key = [...legacyPasswordKey(password)].flatMap((character) => [character.charCodeAt(0), 0]);
	let digest = sha256(Uint8Array.from([...salt, ...key]));
	const block = new Uint8Array(digest.length + 4);
	const view = new DataView(block.buffer);
	for (let iteration = 0; iteration < spinCount; iteration++) {
		block.set(digest);
		view.setUint32(digest.length, iteration, true);
		digest = sha256(block);
	}
	return Array.from(digest);
};
/**
* Random bytes for a password's salt, from the platform's secure random numbers where it has them (browsers, and
* Node.js from 19 on). The salt is written in the document beside the hash, so it only has to differ between
* documents, and `Math.random` does that on older Node.js.
*
* @internal
*/
var randomSalt = (length) => {
	var _globalThis$crypto;
	const bytes = new Uint8Array(length);
	if (typeof ((_globalThis$crypto = globalThis.crypto) === null || _globalThis$crypto === void 0 ? void 0 : _globalThis$crypto.getRandomValues) === "function") {
		globalThis.crypto.getRandomValues(bytes);
		return [...bytes];
	}
	return [...bytes].map(() => Math.floor(Math.random() * 256));
};
/**
* Attributes of the document protection element.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_DocProtect">
*   <xsd:attribute name="edit" type="ST_DocProtect" use="optional"/>
*   <xsd:attribute name="formatting" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="enforcement" type="s:ST_OnOff"/>
*   <xsd:attributeGroup ref="AG_Password"/>
*   <xsd:attributeGroup ref="AG_TransitionalPassword"/>
* </xsd:complexType>
* ```
*/
var DocumentProtectionAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			edit: "w:edit",
			enforcement: "w:enforcement",
			cryptProviderType: "w:cryptProviderType",
			cryptAlgorithmClass: "w:cryptAlgorithmClass",
			cryptAlgorithmType: "w:cryptAlgorithmType",
			cryptAlgorithmSid: "w:cryptAlgorithmSid",
			cryptSpinCount: "w:cryptSpinCount",
			hash: "w:hash",
			salt: "w:salt"
		});
	}
};
var toBase64 = (bytes) => btoa(String.fromCharCode(...bytes));
/**
* Represents a document's protection (`w:documentProtection`), which limits what people can change in it in Word.
*
* A password is hashed as Word hashes it, with a random 16-byte salt, 100,000 times, after Word's legacy key
* derivation, but with SHA-256 (`w:cryptAlgorithmSid` 12), which is much faster here than the SHA-512 Word uses. These
* are the transitional password attributes, which Word writes.
*
* Reference: ISO/IEC 29500-1 17.15.1.29 (documentProtection)
*
* @example
* ```typescript
* new DocumentProtection({ type: DocumentProtectionType.READ_ONLY, password: "secret" });
* ```
*/
var DocumentProtection = class extends XmlComponent {
	constructor({ type, password }) {
		super("w:documentProtection");
		if (password === void 0 || password === "") {
			this.root.push(new DocumentProtectionAttributes({
				edit: type,
				enforcement: true
			}));
			return;
		}
		const salt = randomSalt(16);
		this.root.push(new DocumentProtectionAttributes({
			edit: type,
			enforcement: true,
			cryptProviderType: "rsaAES",
			cryptAlgorithmClass: "hash",
			cryptAlgorithmType: "typeAny",
			cryptAlgorithmSid: 12,
			cryptSpinCount: PROTECTION_PASSWORD_SPIN_COUNT,
			hash: toBase64(hashProtectionPassword(password, salt, PROTECTION_PASSWORD_SPIN_COUNT)),
			salt: toBase64(salt)
		}));
	}
};
/**
* Settings module for WordprocessingML documents.
*
* This module provides document-level settings including compatibility,
* track changes, headers/footers, and hyphenation options.
*
* Reference: http://officeopenxml.com/WPsettings.php
*
* @module
*/
/**
* Attributes for the settings element with XML namespace declarations.
*
* Defines the XML namespaces required for the settings.xml document part.
* These namespaces enable compatibility features, markup compatibility,
* and various Office-specific extensions.
*
* @internal
*/
var SettingsAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			wpc: "xmlns:wpc",
			mc: "xmlns:mc",
			o: "xmlns:o",
			r: "xmlns:r",
			m: "xmlns:m",
			v: "xmlns:v",
			wp14: "xmlns:wp14",
			wp: "xmlns:wp",
			w10: "xmlns:w10",
			w: "xmlns:w",
			w14: "xmlns:w14",
			w15: "xmlns:w15",
			wpg: "xmlns:wpg",
			wpi: "xmlns:wpi",
			wne: "xmlns:wne",
			wps: "xmlns:wps",
			Ignorable: "mc:Ignorable"
		});
	}
};
/**
* Represents document settings in a WordprocessingML document.
*
* Settings contain document-wide configuration options such as
* compatibility mode, track changes, hyphenation, and more.
*
* Reference: http://officeopenxml.com/WPsettings.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Settings">
*   <xsd:sequence>
*     <xsd:element name="embedTrueTypeFonts" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="trackRevisions" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="documentProtection" type="CT_DocProtect" minOccurs="0"/>
*     <xsd:element name="defaultTabStop" type="CT_TwipsMeasure" minOccurs="0"/>
*     <xsd:element name="autoHyphenation" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="consecutiveHyphenLimit" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="hyphenationZone" type="CT_TwipsMeasure" minOccurs="0"/>
*     <xsd:element name="doNotHyphenateCaps" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="evenAndOddHeaders" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="updateFields" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="compat" type="CT_Compat" minOccurs="0"/>
*     <!-- Additional elements omitted for brevity -->
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Basic settings with track changes enabled
* new Settings({
*   trackRevisions: true,
*   evenAndOddHeaders: true,
* });
*
* // Settings with compatibility mode and hyphenation
* new Settings({
*   compatibility: {
*     version: 15, // Word 2013+
*   },
*   hyphenation: {
*     autoHyphenation: true,
*     consecutiveHyphenLimit: 2,
*   },
* });
* ```
*/
var Settings = class extends XmlComponent {
	constructor(options) {
		var _options$defaultTabSt, _options$hyphenation, _options$hyphenation2, _options$hyphenation3, _options$hyphenation4, _options$compatibilit, _ref, _options$compatibilit2, _options$compatibilit3;
		super("w:settings");
		this.root.push(new SettingsAttributes({
			wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
			mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
			o: "urn:schemas-microsoft-com:office:office",
			r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
			m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
			v: "urn:schemas-microsoft-com:vml",
			wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
			wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
			w10: "urn:schemas-microsoft-com:office:word",
			w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
			w14: "http://schemas.microsoft.com/office/word/2010/wordml",
			w15: "http://schemas.microsoft.com/office/word/2012/wordml",
			wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
			wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
			wne: "http://schemas.microsoft.com/office/word/2006/wordml",
			wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
			Ignorable: "w14 w15 wp14"
		}));
		this.root.push(new OnOffElement("w:displayBackgroundShape", true));
		if (options.embedFonts !== void 0) this.root.push(new OnOffElement("w:embedTrueTypeFonts", options.embedFonts));
		if (options.trackRevisions !== void 0) this.root.push(new OnOffElement("w:trackRevisions", options.trackRevisions));
		if (options.protection !== void 0) this.root.push(new DocumentProtection(options.protection));
		this.root.push(new NumberValueElement("w:defaultTabStop", (_options$defaultTabSt = options.defaultTabStop) !== null && _options$defaultTabSt !== void 0 ? _options$defaultTabSt : 720));
		if (((_options$hyphenation = options.hyphenation) === null || _options$hyphenation === void 0 ? void 0 : _options$hyphenation.autoHyphenation) !== void 0) this.root.push(new OnOffElement("w:autoHyphenation", options.hyphenation.autoHyphenation));
		if (((_options$hyphenation2 = options.hyphenation) === null || _options$hyphenation2 === void 0 ? void 0 : _options$hyphenation2.consecutiveHyphenLimit) !== void 0) this.root.push(new NumberValueElement("w:consecutiveHyphenLimit", options.hyphenation.consecutiveHyphenLimit));
		if (((_options$hyphenation3 = options.hyphenation) === null || _options$hyphenation3 === void 0 ? void 0 : _options$hyphenation3.hyphenationZone) !== void 0) this.root.push(new NumberValueElement("w:hyphenationZone", options.hyphenation.hyphenationZone));
		if (((_options$hyphenation4 = options.hyphenation) === null || _options$hyphenation4 === void 0 ? void 0 : _options$hyphenation4.doNotHyphenateCaps) !== void 0) this.root.push(new OnOffElement("w:doNotHyphenateCaps", options.hyphenation.doNotHyphenateCaps));
		if (options.evenAndOddHeaders !== void 0) this.root.push(new OnOffElement("w:evenAndOddHeaders", options.evenAndOddHeaders));
		if (options.updateFields !== void 0) this.root.push(new OnOffElement("w:updateFields", options.updateFields));
		this.root.push(new Compatibility(_objectSpread2(_objectSpread2({}, (_options$compatibilit = options.compatibility) !== null && _options$compatibilit !== void 0 ? _options$compatibilit : {}), {}, { version: (_ref = (_options$compatibilit2 = (_options$compatibilit3 = options.compatibility) === null || _options$compatibilit3 === void 0 ? void 0 : _options$compatibilit3.version) !== null && _options$compatibilit2 !== void 0 ? _options$compatibilit2 : options.compatibilityModeVersion) !== null && _ref !== void 0 ? _ref : 15 })));
	}
};
/**
* Style components module for WordprocessingML documents.
*
* Provides common elements used in style definitions.
*
* Reference: http://officeopenxml.com/WPstyleGenProps.php
*
* @module
*/
/**
* Represents component attributes with a value.
*
* @internal
*/
var ComponentAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", { val: "w:val" });
	}
};
/**
* Represents the name element of a style.
*
* This element specifies the display name of a style as shown in the user interface.
*
* Reference: http://officeopenxml.com/WPstyleGenProps.php
*
* @example
* ```typescript
* // Typically used internally by Style class
* new Name("Heading 1");
* ```
*/
var Name = class extends XmlComponent {
	constructor(value) {
		super("w:name");
		this.root.push(new ComponentAttributes({ val: value }));
	}
};
/**
* Represents the UI priority of a style.
*
* This element specifies the sort order priority for displaying the style in the user interface.
* Lower numbers appear first in style lists.
*
* Reference: http://officeopenxml.com/WPstyleGenProps.php
*
* @example
* ```typescript
* // Typically used internally by Style class
* new UiPriority(99);
* ```
*/
var UiPriority = class extends XmlComponent {
	constructor(value) {
		super("w:uiPriority");
		this.root.push(new ComponentAttributes({ val: decimalNumber(value) }));
	}
};
/**
* Style definition module for WordprocessingML documents.
*
* Provides base style functionality for paragraph and character styles.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* @module
*/
/**
* Represents style attributes for XML serialization.
*
* @internal
*/
var StyleAttributes = class extends XmlAttributeComponent {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "xmlKeys", {
			type: "w:type",
			styleId: "w:styleId",
			default: "w:default",
			customStyle: "w:customStyle"
		});
	}
};
/**
* Represents a base style definition in a WordprocessingML document.
*
* This is the base class for paragraph and character styles. It defines common
* style properties such as name, inheritance (basedOn), UI priority, and visibility.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Style">
*   <xsd:sequence>
*     <xsd:element name="name" type="CT_String" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="aliases" type="CT_String" minOccurs="0"/>
*     <xsd:element name="basedOn" type="CT_String" minOccurs="0"/>
*     <xsd:element name="next" type="CT_String" minOccurs="0"/>
*     <xsd:element name="link" type="CT_String" minOccurs="0"/>
*     <xsd:element name="autoRedefine" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="hidden" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="uiPriority" type="CT_DecimalNumber" minOccurs="0"/>
*     <xsd:element name="semiHidden" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="unhideWhenUsed" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="qFormat" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="locked" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="personal" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="personalCompose" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="personalReply" type="CT_OnOff" minOccurs="0"/>
*     <xsd:element name="rsid" type="CT_LongHexNumber" minOccurs="0"/>
*     <xsd:element name="pPr" type="CT_PPrGeneral" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="rPr" type="CT_RPr" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblPr" type="CT_TblPrBase" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="trPr" type="CT_TrPr" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tcPr" type="CT_TcPr" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="tblStylePr" type="CT_TblStylePr" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
*   <xsd:attribute name="type" type="ST_StyleType" use="optional"/>
*   <xsd:attribute name="styleId" type="s:ST_String" use="optional"/>
*   <xsd:attribute name="default" type="s:ST_OnOff" use="optional"/>
*   <xsd:attribute name="customStyle" type="s:ST_OnOff" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // This is typically extended by StyleForParagraph or StyleForCharacter
* // See those classes for usage examples
* ```
*/
var Style = class extends XmlComponent {
	constructor(attributes, options) {
		super("w:style");
		this.root.push(new StyleAttributes(attributes));
		if (options.name) this.root.push(new Name(options.name));
		if (options.basedOn && options.basedOn !== attributes.styleId) this.root.push(new StringValueElement("w:basedOn", options.basedOn));
		if (options.next) this.root.push(new StringValueElement("w:next", options.next));
		if (options.link) this.root.push(new StringValueElement("w:link", options.link));
		if (options.uiPriority !== void 0) this.root.push(new UiPriority(options.uiPriority));
		if (options.semiHidden !== void 0) this.root.push(new OnOffElement("w:semiHidden", options.semiHidden));
		if (options.unhideWhenUsed !== void 0) this.root.push(new OnOffElement("w:unhideWhenUsed", options.unhideWhenUsed));
		if (options.quickFormat !== void 0) this.root.push(new OnOffElement("w:qFormat", options.quickFormat));
	}
};
/**
* Paragraph style module for WordprocessingML documents.
*
* Paragraph styles define formatting that applies to entire paragraphs.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* @module
*/
/**
* Represents a paragraph style in a WordprocessingML document.
*
* Paragraph styles apply formatting to entire paragraphs, including both
* paragraph-level properties (spacing, alignment, indentation) and
* run-level properties (font, size, color) for text within the paragraph.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Style">
*   <xsd:sequence>
*     <!-- Style elements including pPr for paragraph properties -->
*     <xsd:element name="pPr" type="CT_PPrGeneral" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="rPr" type="CT_RPr" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="type" type="ST_StyleType" use="optional"/>
*   <xsd:attribute name="styleId" type="s:ST_String" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a custom heading style
* new StyleForParagraph({
*   id: "CustomHeading",
*   name: "Custom Heading",
*   basedOn: "Normal",
*   paragraph: {
*     spacing: { before: 240, after: 120 },
*     alignment: AlignmentType.LEFT
*   },
*   run: {
*     size: 28,
*     bold: true,
*     color: "2E74B5"
*   }
* });
* ```
*/
var StyleForParagraph = class extends Style {
	constructor(options) {
		super({
			type: "paragraph",
			styleId: options.id
		}, options);
		_defineProperty(this, "paragraphProperties", void 0);
		_defineProperty(this, "runProperties", void 0);
		this.paragraphProperties = new ParagraphProperties(options.paragraph, {
			implicitListParagraphStyle: false,
			inListOrder: false
		});
		this.runProperties = new RunProperties(options.run);
		this.root.push(this.paragraphProperties);
		this.root.push(this.runProperties);
	}
};
/**
* Character style module for WordprocessingML documents.
*
* Character styles define formatting that applies to individual text runs.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* @module
*/
/**
* Represents a character style in a WordprocessingML document.
*
* Character styles apply formatting to individual runs of text within a paragraph,
* such as font, size, color, bold, italic, and other text-level formatting.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Style">
*   <xsd:sequence>
*     <!-- Style elements including rPr for run properties -->
*     <xsd:element name="rPr" type="CT_RPr" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="type" type="ST_StyleType" use="optional"/>
*   <xsd:attribute name="styleId" type="s:ST_String" use="optional"/>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create a custom character style for highlighting
* new StyleForCharacter({
*   id: "Highlight",
*   name: "Highlight Text",
*   basedOn: "DefaultParagraphFont",
*   run: {
*     color: "FF0000",
*     bold: true
*   }
* });
* ```
*/
var StyleForCharacter = class extends Style {
	constructor(options) {
		super({
			type: "character",
			styleId: options.id
		}, _objectSpread2({
			uiPriority: 99,
			unhideWhenUsed: true
		}, options));
		_defineProperty(this, "runProperties", void 0);
		this.runProperties = new RunProperties(options.run);
		this.root.push(this.runProperties);
	}
};
/**
* Default styles module for WordprocessingML documents.
*
* Provides pre-configured style classes for common document elements like headings,
* hyperlinks, and footnotes.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* @module
*/
/**
* Base class for heading styles.
*
* Provides common configuration for heading styles, including basedOn="Normal"
* and quickFormat enabled.
*
* @example
* ```typescript
* // Typically extended by specific heading classes
* new HeadingStyle({
*   id: "CustomHeading",
*   name: "Custom Heading",
*   run: { bold: true, size: 28 }
* });
* ```
*/
var HeadingStyle = class extends StyleForParagraph {
	constructor(options) {
		super(_objectSpread2({
			basedOn: "Normal",
			next: "Normal",
			quickFormat: true
		}, options));
	}
};
/**
* Represents the Title paragraph style.
*
* Used for document titles with larger font size and emphasis.
*
* @example
* ```typescript
* new TitleStyle({
*   run: { size: 56, bold: true }
* });
* ```
*/
var TitleStyle = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Title",
			name: "Title"
		}, options));
	}
};
/**
* Represents the Heading 1 paragraph style.
*
* First-level heading style for major document sections.
*
* @example
* ```typescript
* new Heading1Style({
*   run: { size: 32, color: "2E74B5" }
* });
* ```
*/
var Heading1Style = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Heading1",
			name: "Heading 1"
		}, options));
	}
};
/**
* Represents the Heading 2 paragraph style.
*
* Second-level heading style for subsections.
*/
var Heading2Style = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Heading2",
			name: "Heading 2"
		}, options));
	}
};
/**
* Represents the Heading 3 paragraph style.
*
* Third-level heading style for sub-subsections.
*/
var Heading3Style = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Heading3",
			name: "Heading 3"
		}, options));
	}
};
/**
* Represents the Heading 4 paragraph style.
*
* Fourth-level heading style for nested sections.
*/
var Heading4Style = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Heading4",
			name: "Heading 4"
		}, options));
	}
};
/**
* Represents the Heading 5 paragraph style.
*
* Fifth-level heading style for deeply nested sections.
*/
var Heading5Style = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Heading5",
			name: "Heading 5"
		}, options));
	}
};
/**
* Represents the Heading 6 paragraph style.
*
* Sixth-level heading style for the deepest nested sections.
*/
var Heading6Style = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Heading6",
			name: "Heading 6"
		}, options));
	}
};
/**
* Represents the Strong paragraph style.
*
* Used for emphasizing important paragraphs with bold formatting.
*/
var StrongStyle = class extends HeadingStyle {
	constructor(options) {
		super(_objectSpread2({
			id: "Strong",
			name: "Strong"
		}, options));
	}
};
/**
* Represents the List Paragraph style.
*
* Used for paragraphs within numbered or bulleted lists.
*/
var ListParagraph = class extends StyleForParagraph {
	constructor(options) {
		super(_objectSpread2({
			id: "ListParagraph",
			name: "List Paragraph",
			basedOn: "Normal",
			quickFormat: true
		}, options));
	}
};
/**
* Represents the Caption paragraph style.
*
* Word gives the captions it inserts (References > Insert Caption) the paragraph style named "caption", and this is that
* style as Word writes it: small italic text in the theme's second dark color, with space after it.
*/
var CaptionStyle = class extends StyleForParagraph {
	constructor(options) {
		super(_objectSpread2({
			id: "Caption",
			name: "caption",
			basedOn: "Normal",
			next: "Normal",
			uiPriority: 35,
			semiHidden: true,
			unhideWhenUsed: true,
			quickFormat: true,
			paragraph: { spacing: { after: 200 } },
			run: {
				italics: true,
				color: { theme: "dark2" },
				size: 18
			}
		}, options));
	}
};
/**
* Represents the Bibliography paragraph style.
*
* Word gives the paragraphs of the bibliographies it writes (References > Bibliography) the paragraph style named
* "Bibliography", and this is that style as Word writes it. It has no formatting of its own: each style of citation,
* such as APA, indents the paragraphs of its bibliography itself.
*/
var BibliographyStyle = class extends StyleForParagraph {
	constructor(options) {
		super(_objectSpread2({
			id: "Bibliography",
			name: "Bibliography",
			basedOn: "Normal",
			next: "Normal",
			uiPriority: 37,
			unhideWhenUsed: true
		}, options));
	}
};
var tableOfContentsStyles = /* @__PURE__ */ new WeakSet();
/**
* Whether a formatted style is one of docx's TOC 1 to TOC 9 styles, which a style with its name replaces, such as one in
* a template saved by Word in another language, with an id of its own.
*/
var isDefaultTableOfContentsStyle = (style) => tableOfContentsStyles.has(style);
/**
* Represents a TOC 1 to TOC 9 paragraph style, the style of the entries at a level of a table of contents.
*
* Word gives the entries it writes the paragraph styles named "toc 1" to "toc 9", and adds the styles when the
* document doesn't have them: with 5 points of space after, and each level indented by the size of the Normal style's
* font more than the level above. Without them, LibreOffice indents no level once it updates the table. Like Word's,
* they are hidden until they are used.
*/
var TableOfContentsStyle = class extends StyleForParagraph {
	/**
	* @param level - The level of the entries, 1 to 9
	* @param levelIndent - How much more each level is indented than the level above, in twips
	*/
	constructor(level, levelIndent) {
		super({
			id: `TOC${level}`,
			name: `toc ${level}`,
			basedOn: "Normal",
			next: "Normal",
			uiPriority: 39,
			semiHidden: true,
			unhideWhenUsed: true,
			paragraph: _objectSpread2({ spacing: { after: 100 } }, level > 1 ? { indent: { left: (level - 1) * levelIndent } } : {})
		});
	}
	prepForXml(context) {
		const xml = super.prepForXml(context);
		tableOfContentsStyles.add(xml);
		return xml;
	}
};
/**
* Represents the Footnote Text paragraph style.
*
* Used for the text content of footnotes with smaller font size and tighter spacing.
*/
var FootnoteText = class extends StyleForParagraph {
	constructor(options) {
		super(_objectSpread2({
			id: "FootnoteText",
			name: "footnote text",
			link: "FootnoteTextChar",
			basedOn: "Normal",
			uiPriority: 99,
			semiHidden: true,
			unhideWhenUsed: true,
			paragraph: { spacing: {
				after: 0,
				line: 240,
				lineRule: LineRuleType.AUTO
			} },
			run: { size: 20 }
		}, options));
	}
};
/**
* Represents the Footnote Reference character style.
*
* Used for footnote reference numbers in the main text, displayed as superscript.
*/
var FootnoteReferenceStyle = class extends StyleForCharacter {
	constructor(options) {
		super(_objectSpread2({
			id: "FootnoteReference",
			name: "footnote reference",
			basedOn: "DefaultParagraphFont",
			semiHidden: true,
			run: { superScript: true }
		}, options));
	}
};
/**
* Represents the Footnote Text Char character style.
*
* Character style linked to FootnoteText paragraph style for consistent formatting.
*/
var FootnoteTextChar = class extends StyleForCharacter {
	constructor(options) {
		super(_objectSpread2({
			id: "FootnoteTextChar",
			name: "Footnote Text Char",
			basedOn: "DefaultParagraphFont",
			link: "FootnoteText",
			semiHidden: true,
			run: { size: 20 }
		}, options));
	}
};
/**
* Represents the Endnote Text paragraph style.
*
* Used for the text content of endnotes with smaller font size and tighter spacing.
*/
var EndnoteText = class extends StyleForParagraph {
	constructor(options) {
		super(_objectSpread2({
			id: "EndnoteText",
			name: "endnote text",
			link: "EndnoteTextChar",
			basedOn: "Normal",
			uiPriority: 99,
			semiHidden: true,
			unhideWhenUsed: true,
			paragraph: { spacing: {
				after: 0,
				line: 240,
				lineRule: LineRuleType.AUTO
			} },
			run: { size: 20 }
		}, options));
	}
};
/**
* Represents the Endnote Reference character style.
*
* Used for endnote reference numbers in the main text, displayed as superscript.
*/
var EndnoteReferenceStyle = class extends StyleForCharacter {
	constructor(options) {
		super(_objectSpread2({
			id: "EndnoteReference",
			name: "endnote reference",
			basedOn: "DefaultParagraphFont",
			semiHidden: true,
			run: { superScript: true }
		}, options));
	}
};
/**
* Represents the Endnote Text Char character style.
*
* Character style linked to EndnoteText paragraph style for consistent formatting.
*/
var EndnoteTextChar = class extends StyleForCharacter {
	constructor(options) {
		super(_objectSpread2({
			id: "EndnoteTextChar",
			name: "Endnote Text Char",
			basedOn: "DefaultParagraphFont",
			link: "EndnoteText",
			semiHidden: true,
			run: { size: 20 }
		}, options));
	}
};
/**
* Represents the Hyperlink character style.
*
* Used for hyperlinks with blue color and single underline formatting.
*/
var HyperlinkStyle = class extends StyleForCharacter {
	constructor(options) {
		super(_objectSpread2({
			id: "Hyperlink",
			name: "Hyperlink",
			basedOn: "DefaultParagraphFont",
			run: {
				color: "0563C1",
				underline: { type: UnderlineType.SINGLE }
			}
		}, options));
	}
};
/**
* Represents the Line Number character style.
*
* Word draws a section's line numbers in the character style named "line number", whatever its id, so this style
* formats them. Like Word's, it has no formatting of its own, so line numbers take the document defaults.
*/
var LineNumberStyle = class extends StyleForCharacter {
	constructor(options) {
		super(_objectSpread2({
			id: "LineNumber",
			name: "line number",
			basedOn: "DefaultParagraphFont",
			semiHidden: true
		}, options));
	}
};
/**
* Represents the Normal Table style, the default style of tables.
*
* It gives cells the margins Word gives the tables it makes: 108 twips (0.075 inches) on the left and right. Without a
* default table style, Word gives cells no margins, so their text touches the borders, where LibreOffice and other
* applications use these margins.
*/
var NormalTableStyle = class extends Style {
	constructor() {
		super({
			type: "table",
			styleId: "TableNormal",
			default: true
		}, {
			name: "Normal Table",
			uiPriority: 99,
			semiHidden: true,
			unhideWhenUsed: true
		});
		this.root.push(new TableProperties({
			indent: {
				size: 0,
				type: WidthType.DXA
			},
			cellMargin: {
				top: 0,
				left: 108,
				bottom: 0,
				right: 108
			}
		}));
	}
};
/** The name of a formatted element, such as `w:style`, or `_attr` for its parent's attributes */
var nameOf$1 = (child) => typeof child === "object" ? Object.keys(child)[0] : void 0;
/** The attributes of a formatted `w:style` */
var attributesOf = (style) => {
	var _flat$find;
	return (_flat$find = [style["w:style"]].flat().find((part) => part._attr)) === null || _flat$find === void 0 ? void 0 : _flat$find._attr;
};
/** The id of a formatted `w:style` */
var styleIdOf = (style) => {
	var _attributesOf;
	return (_attributesOf = attributesOf(style)) === null || _attributesOf === void 0 ? void 0 : _attributesOf["w:styleId"];
};
/** The name of a formatted `w:style`, in lower case, as Word compares the names of its built-in styles */
var styleNameOf = (style) => {
	var _flat$find2;
	const name = (_flat$find2 = [style["w:style"]].flat().find((part) => nameOf$1(part) === "w:name")) === null || _flat$find2 === void 0 || (_flat$find2 = _flat$find2["w:name"]) === null || _flat$find2 === void 0 || (_flat$find2 = _flat$find2._attr) === null || _flat$find2 === void 0 ? void 0 : _flat$find2["w:val"];
	return name === void 0 ? void 0 : String(name).toLowerCase();
};
/** Whether a formatted element is a paragraph style, as a `w:style` is when its type isn't given */
var isParagraphStyle = (child) => {
	var _attributesOf$wType, _attributesOf2;
	return nameOf$1(child) === "w:style" && ((_attributesOf$wType = (_attributesOf2 = attributesOf(child)) === null || _attributesOf2 === void 0 ? void 0 : _attributesOf2["w:type"]) !== null && _attributesOf$wType !== void 0 ? _attributesOf$wType : "paragraph") === "paragraph";
};
/** Whether a formatted element is a paragraph style marked as the default for paragraphs */
var isDefaultParagraphStyle = (child) => {
	const attributes = isParagraphStyle(child) ? attributesOf(child) : void 0;
	return (attributes === null || attributes === void 0 ? void 0 : attributes["w:default"]) !== void 0 && ![
		"0",
		"false",
		"off"
	].includes(String(attributes["w:default"]));
};
/** A formatted `w:style`, marked as the default for its type */
var markedAsDefault = (style) => ({ "w:style": [style["w:style"]].flat().map((part) => part._attr ? { _attr: _objectSpread2(_objectSpread2({}, part._attr), {}, { "w:default": "1" }) } : part) });
/**
* Represents the styles definitions in a WordprocessingML document.
*
* The styles element contains document defaults, latent styles, and
* individual style definitions for paragraphs and characters. Styles provide
* a way to define consistent formatting across a document.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_Styles">
*   <xsd:sequence>
*     <xsd:element name="docDefaults" type="CT_DocDefaults" minOccurs="0"/>
*     <xsd:element name="latentStyles" type="CT_LatentStyles" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="style" type="CT_Style" minOccurs="0" maxOccurs="unbounded"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Create styles with custom paragraph and character styles
* new Styles({
*   paragraphStyles: [{
*     id: "CustomHeading",
*     name: "Custom Heading",
*     basedOn: "Normal",
*     run: { bold: true, size: 28 }
*   }],
*   characterStyles: [{
*     id: "Highlight",
*     name: "Highlight",
*     run: { color: "FF0000" }
*   }]
* });
* ```
*/
var Styles = class extends XmlComponent {
	constructor(options) {
		super("w:styles");
		if (options.initialStyles) this.root.push(options.initialStyles);
		if (options.importedStyles) for (const style of options.importedStyles) this.root.push(style);
		if (options.paragraphStyles) for (const style of options.paragraphStyles) this.root.push(new StyleForParagraph(style));
		if (options.characterStyles) for (const style of options.characterStyles) this.root.push(new StyleForCharacter(style));
	}
	/**
	* Writes the styles in the schema's order: the document defaults, the latent styles, then the styles. A style id
	* can only be used once, so a style replaces an earlier one with its id. That way external styles replace docx's
	* default styles, and paragraph and character styles replace the default and imported ones. docx's TOC 1 to TOC 9
	* styles are also replaced by a paragraph style with their name, such as a template's in another language, with an id
	* of its own. Of several document defaults, or several latent styles, the last is kept. Normal is marked as the
	* default paragraph style when no style is.
	*/
	prepForXml(context) {
		const xml = super.prepForXml(context);
		const children = xml["w:styles"];
		if (!Array.isArray(children)) return xml;
		const named = (name) => children.filter((child) => nameOf$1(child) === name);
		const ids = children.map((child) => nameOf$1(child) === "w:style" ? styleIdOf(child) : void 0);
		const unique = children.filter((child, index) => ![
			"_attr",
			"w:docDefaults",
			"w:latentStyles"
		].includes(nameOf$1(child)) && (ids[index] === void 0 || ids.lastIndexOf(ids[index]) === index));
		const otherNames = new Set(unique.filter((child) => isParagraphStyle(child) && !isDefaultTableOfContentsStyle(child)).map(styleNameOf));
		const kept = unique.filter((child) => !isDefaultTableOfContentsStyle(child) || !otherNames.has(styleNameOf(child)));
		const styles = kept.some(isDefaultParagraphStyle) ? kept : kept.map((child) => isParagraphStyle(child) && styleIdOf(child) === "Normal" ? markedAsDefault(child) : child);
		return { "w:styles": [
			...named("_attr"),
			...named("w:docDefaults").slice(-1),
			...named("w:latentStyles").slice(-1),
			...styles
		] };
	}
};
/**
* Represents default paragraph properties in a WordprocessingML document.
*
* This element defines the default paragraph formatting properties that apply
* to all paragraphs in the document unless overridden.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_PPrDefault">
*   <xsd:sequence>
*     <xsd:element name="pPr" type="CT_PPrGeneral" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Set default paragraph spacing
* new ParagraphPropertiesDefaults({
*   spacing: { after: 200, line: 276 }
* });
* ```
*/
var ParagraphPropertiesDefaults = class extends XmlComponent {
	constructor(options) {
		super("w:pPrDefault");
		this.root.push(new ParagraphProperties(options, {
			implicitListParagraphStyle: false,
			inListOrder: false
		}));
	}
};
/**
* Represents default run properties in a WordprocessingML document.
*
* This element defines the default text run formatting properties that apply
* to all text runs in the document unless overridden by styles or direct formatting.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_RPrDefault">
*   <xsd:sequence>
*     <xsd:element name="rPr" type="CT_RPr" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Set default font and size
* new RunPropertiesDefaults({
*   font: "Calibri",
*   size: 22
* });
* ```
*/
var RunPropertiesDefaults = class extends XmlComponent {
	constructor(options) {
		super("w:rPrDefault");
		this.root.push(new RunProperties(options));
	}
};
/**
* Represents document-wide default formatting in a WordprocessingML document.
*
* Document defaults define the base formatting properties that apply to all
* paragraphs and runs in a document unless overridden by a style or direct formatting.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_DocDefaults">
*   <xsd:sequence>
*     <xsd:element name="rPrDefault" type="CT_RPrDefault" minOccurs="0"/>
*     <xsd:element name="pPrDefault" type="CT_PPrDefault" minOccurs="0"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // Set default font and spacing for the document
* new DocumentDefaults({
*   run: {
*     font: "Calibri",
*     size: 22
*   },
*   paragraph: {
*     spacing: { after: 200, line: 276 }
*   }
* });
* ```
*/
var DocumentDefaults = class extends XmlComponent {
	constructor(options) {
		super("w:docDefaults");
		_defineProperty(this, "runPropertiesDefaults", void 0);
		_defineProperty(this, "paragraphPropertiesDefaults", void 0);
		this.runPropertiesDefaults = new RunPropertiesDefaults(options.run);
		this.paragraphPropertiesDefaults = new ParagraphPropertiesDefaults(options.paragraph);
		this.root.push(this.runPropertiesDefaults);
		this.root.push(this.paragraphPropertiesDefaults);
	}
};
/**
* External styles factory module for WordprocessingML documents.
*
* Provides functionality to import and parse styles from external XML sources.
*
* Reference: http://officeopenxml.com/WPstyles.php
*
* @module
*/
/**
* Factory for creating styles from external XML sources.
*
* This factory parses styles from XML (typically from a styles.xml file)
* and converts them into Styles components that can be used in the document.
*
* @example
* ```typescript
* // Import styles from an external styles.xml file
* const factory = new ExternalStylesFactory();
* const xmlData = '<?xml version="1.0"?><w:styles>...</w:styles>';
* const styles = factory.newInstance(xmlData);
* ```
*/
var ExternalStylesFactory = class {
	/**
	* Creates new Styles based on the given XML data.
	*
	* Parses the styles XML and converts them to XmlComponent instances.
	*
	* Example content from styles.xml:
	* ```xml
	* <?xml version="1.0"?>
	* <w:styles xmlns:mc="some schema" ...>
	*   <w:style w:type="paragraph" w:styleId="Heading1">
	*     <w:name w:val="heading 1"/>
	*     ...
	*   </w:style>
	*   <w:style w:type="paragraph" w:styleId="Heading2">
	*     <w:name w:val="heading 2"/>
	*     ...
	*   </w:style>
	*   <w:docDefaults>...</w:docDefaults>
	* </w:styles>
	* ```
	*
	* @param xmlData - XML string containing styles data from styles.xml
	* @returns Styles object containing all parsed styles
	* @throws Error if styles element cannot be found in the XML
	*/
	newInstance(xmlData) {
		const xmlObj = parseXml(xmlData);
		let stylesXmlElement;
		for (const xmlElm of xmlObj.elements || []) if (xmlElm.name === "w:styles") stylesXmlElement = xmlElm;
		if (stylesXmlElement === void 0) throw new Error("can not find styles element");
		const stylesElements = stylesXmlElement.elements || [];
		return {
			initialStyles: new ImportedRootElementAttributes(stylesXmlElement.attributes),
			importedStyles: stylesElements.map((childElm) => convertToXmlComponent(childElm))
		};
	}
};
/**
* How much more Word indents each level of a table of contents than the level above, in twips: the size of the Normal
* style's font. docx's Normal has no formatting, so that is the document's default size, or 10 points without one.
*/
var tableOfContentsLevelIndentOf = (options) => {
	var _options$document;
	const size = (_options$document = options.document) === null || _options$document === void 0 || (_options$document = _options$document.run) === null || _options$document === void 0 ? void 0 : _options$document.size;
	if (size === void 0) return 200;
	return Math.round(typeof size === "number" ? size * 10 : universalMeasureToTwips(size));
};
/** The styles of the entries at each level of a table of contents, as Word adds them */
var createTableOfContentsStyles = (levelIndent) => ({
	tableOfContents1: new TableOfContentsStyle(1, levelIndent),
	tableOfContents2: new TableOfContentsStyle(2, levelIndent),
	tableOfContents3: new TableOfContentsStyle(3, levelIndent),
	tableOfContents4: new TableOfContentsStyle(4, levelIndent),
	tableOfContents5: new TableOfContentsStyle(5, levelIndent),
	tableOfContents6: new TableOfContentsStyle(6, levelIndent),
	tableOfContents7: new TableOfContentsStyle(7, levelIndent),
	tableOfContents8: new TableOfContentsStyle(8, levelIndent),
	tableOfContents9: new TableOfContentsStyle(9, levelIndent)
});
/**
* docx's default styles, each under the option of `styles.default` that configures it, and Normal, the default table
* style and the TOC 1 to TOC 9 styles.
*
* @internal
*/
var createDefaultStyles = (options = {}) => {
	var _options$document2;
	return _objectSpread2(_objectSpread2({
		normal: new StyleForParagraph({
			id: "Normal",
			name: "Normal",
			quickFormat: true
		}),
		normalTable: new NormalTableStyle(),
		document: new DocumentDefaults((_options$document2 = options.document) !== null && _options$document2 !== void 0 ? _options$document2 : {}),
		title: new TitleStyle(_objectSpread2({ run: { size: 56 } }, options.title)),
		heading1: new Heading1Style(_objectSpread2({ run: {
			color: "2E74B5",
			size: 32
		} }, options.heading1)),
		heading2: new Heading2Style(_objectSpread2({ run: {
			color: "2E74B5",
			size: 26
		} }, options.heading2)),
		heading3: new Heading3Style(_objectSpread2({ run: {
			color: "1F4D78",
			size: 24
		} }, options.heading3)),
		heading4: new Heading4Style(_objectSpread2({ run: {
			color: "2E74B5",
			italics: true
		} }, options.heading4)),
		heading5: new Heading5Style(_objectSpread2({ run: { color: "2E74B5" } }, options.heading5)),
		heading6: new Heading6Style(_objectSpread2({ run: { color: "1F4D78" } }, options.heading6)),
		strong: new StrongStyle(_objectSpread2({ run: { bold: true } }, options.strong)),
		listParagraph: new ListParagraph(options.listParagraph || {}),
		caption: new CaptionStyle(options.caption || {}),
		bibliography: new BibliographyStyle(options.bibliography || {})
	}, createTableOfContentsStyles(tableOfContentsLevelIndentOf(options))), {}, {
		hyperlink: new HyperlinkStyle(options.hyperlink || {}),
		footnoteReference: new FootnoteReferenceStyle(options.footnoteReference || {}),
		footnoteText: new FootnoteText(options.footnoteText || {}),
		footnoteTextChar: new FootnoteTextChar(options.footnoteTextChar || {}),
		endnoteReference: new EndnoteReferenceStyle(options.endnoteReference || {}),
		endnoteText: new EndnoteText(options.endnoteText || {}),
		endnoteTextChar: new EndnoteTextChar(options.endnoteTextChar || {}),
		lineNumber: new LineNumberStyle(options.lineNumber || {})
	});
};
/**
* Factory for creating default document styles.
*
* This factory creates a complete set of default styles for common document elements
* such as headings, hyperlinks, and footnotes with sensible default formatting.
*
* @example
* ```typescript
* // Create default styles with custom heading colors
* const factory = new DefaultStylesFactory();
* const styles = factory.newInstance({
*   heading1: {
*     run: { color: "FF0000", size: 32 }
*   },
*   heading2: {
*     run: { color: "00FF00", size: 26 }
*   }
* });
* ```
*/
var DefaultStylesFactory = class {
	newInstance(options = {}) {
		return {
			initialStyles: new DocumentAttributes([
				"mc",
				"r",
				"w",
				"w14",
				"w15"
			], "w14 w15"),
			importedStyles: Object.values(createDefaultStyles(options))
		};
	}
};
/**
* Font scheme module for DrawingML themes.
*
* The two fonts of a document's theme: one for headings and one for body text. Styles and text that use a theme font
* change when the theme's fonts change.
*
* Reference: http://officeopenxml.com/drwTheme.php
*
* @module
*/
var OFFICE_FONTS = {
	headings: {
		latin: "Calibri Light",
		panose: "020F0302020204030204"
	},
	body: {
		latin: "Calibri",
		panose: "020F0502020204030204"
	}
};
var OFFICE_SCRIPT_FONTS = [
	[
		"Jpan",
		"游ゴシック Light",
		"游明朝"
	],
	["Hang", "맑은 고딕"],
	[
		"Hans",
		"等线 Light",
		"等线"
	],
	["Hant", "新細明體"],
	[
		"Arab",
		"Times New Roman",
		"Arial"
	],
	[
		"Hebr",
		"Times New Roman",
		"Arial"
	],
	[
		"Thai",
		"Angsana New",
		"Cordia New"
	],
	["Ethi", "Nyala"],
	["Beng", "Vrinda"],
	["Gujr", "Shruti"],
	[
		"Khmr",
		"MoolBoran",
		"DaunPenh"
	],
	["Knda", "Tunga"],
	["Guru", "Raavi"],
	["Cans", "Euphemia"],
	["Cher", "Plantagenet Cherokee"],
	["Yiii", "Microsoft Yi Baiti"],
	["Tibt", "Microsoft Himalaya"],
	["Thaa", "MV Boli"],
	["Deva", "Mangal"],
	["Telu", "Gautami"],
	["Taml", "Latha"],
	["Syrc", "Estrangelo Edessa"],
	["Orya", "Kalinga"],
	["Mlym", "Kartika"],
	["Laoo", "DokChampa"],
	["Sinh", "Iskoola Pota"],
	["Mong", "Mongolian Baiti"],
	[
		"Viet",
		"Times New Roman",
		"Arial"
	],
	["Uigh", "Microsoft Uighur"],
	["Geor", "Sylfaen"],
	["Armn", "Arial"],
	["Bugi", "Leelawadee UI"],
	["Bopo", "Microsoft JhengHei"],
	["Java", "Javanese Text"],
	["Lisu", "Segoe UI"],
	["Mymr", "Myanmar Text"],
	["Nkoo", "Ebrima"],
	["Olck", "Nirmala UI"],
	["Osma", "Ebrima"],
	["Phag", "Phagspa"],
	["Syrn", "Estrangelo Edessa"],
	["Syrj", "Estrangelo Edessa"],
	["Syre", "Estrangelo Edessa"],
	["Sora", "Nirmala UI"],
	["Tale", "Microsoft Tai Le"],
	["Talu", "Microsoft New Tai Lue"],
	["Tfng", "Ebrima"]
];
var createTextFont = (name, typeface, panose) => new BuilderElement({
	name,
	attributes: {
		typeface: {
			key: "typeface",
			value: typeface
		},
		panose: {
			key: "panose",
			value: panose
		}
	}
});
/**
* The Latin font of one of a theme's fonts, as given or as Office's.
*/
var themeLatinFont = (use, fonts) => {
	const font = fonts[use];
	const latin = typeof font === "string" ? font : font === null || font === void 0 ? void 0 : font.latin;
	return latin !== null && latin !== void 0 ? latin : OFFICE_FONTS[use].latin;
};
/**
* The font for each script of one of a theme's fonts: Office's, in Office's order, with those given in their place, and
* then the scripts Office has no font for, in the order given.
*/
var themeScriptFonts = (use, scripts = {}) => {
	const office = OFFICE_SCRIPT_FONTS.map(([script, headings, body = headings]) => {
		var _scripts$script;
		return [script, (_scripts$script = scripts[script]) !== null && _scripts$script !== void 0 ? _scripts$script : use === "headings" ? headings : body];
	});
	const officeScripts = new Set(office.map(([script]) => script));
	return [...office, ...Object.entries(scripts).filter(([script]) => !officeScripts.has(script))];
};
var createFontCollection = (use, fonts) => {
	const font = fonts[use];
	const { eastAsia = "", complexScript = "", scripts } = typeof font === "object" ? font : {};
	const latin = themeLatinFont(use, fonts);
	const office = OFFICE_FONTS[use];
	return new BuilderElement({
		name: use === "headings" ? "a:majorFont" : "a:minorFont",
		children: [
			createTextFont("a:latin", latin, latin === office.latin ? office.panose : void 0),
			createTextFont("a:ea", eastAsia),
			createTextFont("a:cs", complexScript),
			...themeScriptFonts(use, scripts).map(([script, typeface]) => new BuilderElement({
				name: "a:font",
				attributes: {
					script: {
						key: "script",
						value: script
					},
					typeface: {
						key: "typeface",
						value: typeface
					}
				}
			}))
		]
	});
};
/**
* Creates a theme's font scheme, with Office's fonts in place of those not given.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_FontScheme">
*   <xsd:sequence>
*     <xsd:element name="majorFont" type="CT_FontCollection" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="minorFont" type="CT_FontCollection" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="extLst" type="CT_OfficeArtExtensionList" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="name" type="xsd:string" use="required"/>
* </xsd:complexType>
*
* <xsd:complexType name="CT_FontCollection">
*   <xsd:sequence>
*     <xsd:element name="latin" type="CT_TextFont" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="ea" type="CT_TextFont" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="cs" type="CT_TextFont" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="font" type="CT_SupplementalFont" minOccurs="0" maxOccurs="unbounded"/>
*     <xsd:element name="extLst" type="CT_OfficeArtExtensionList" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*/
var createFontScheme = (name, fonts = {}) => new BuilderElement({
	name: "a:fontScheme",
	attributes: { name: {
		key: "name",
		value: name
	} },
	children: [createFontCollection("headings", fonts), createFontCollection("body", fonts)]
});
/**
* Format scheme module for DrawingML themes.
*
* The fills, lines and effects that shapes styled by the theme use, as Office's theme has them.
*
* Reference: http://officeopenxml.com/drwTheme.php
*
* @module
*/
/**
* The color a style is used with (`phClr`), changed by each of `changes` in turn.
*/
var createStyleColor = (changes = []) => new BuilderElement({
	name: "a:schemeClr",
	attributes: { value: {
		key: "val",
		value: "phClr"
	} },
	children: changes.map(([name, value]) => new BuilderElement({
		name: `a:${name}`,
		attributes: { value: {
			key: "val",
			value
		} }
	}))
});
var createSolidFill = (changes) => new BuilderElement({
	name: "a:solidFill",
	children: [createStyleColor(changes)]
});
/**
* A gradient from top to bottom, with a stop at the start, the middle and the end.
*/
var createGradientFill = (stops) => new BuilderElement({
	name: "a:gradFill",
	attributes: { rotateWithShape: {
		key: "rotWithShape",
		value: true
	} },
	children: [new BuilderElement({
		name: "a:gsLst",
		children: stops.map((changes, index) => new BuilderElement({
			name: "a:gs",
			attributes: { position: {
				key: "pos",
				value: index * 5e4
			} },
			children: [createStyleColor(changes)]
		}))
	}), new BuilderElement({
		name: "a:lin",
		attributes: {
			angle: {
				key: "ang",
				value: 54e5
			},
			scaled: {
				key: "scaled",
				value: false
			}
		}
	})]
});
/**
* A solid line of the given width in EMUs.
*/
var createLine = (width) => new BuilderElement({
	name: "a:ln",
	attributes: {
		width: {
			key: "w",
			value: width
		},
		cap: {
			key: "cap",
			value: "flat"
		},
		compound: {
			key: "cmpd",
			value: "sng"
		},
		alignment: {
			key: "algn",
			value: "ctr"
		}
	},
	children: [
		createSolidFill(),
		new BuilderElement({
			name: "a:prstDash",
			attributes: { value: {
				key: "val",
				value: "solid"
			} }
		}),
		new BuilderElement({
			name: "a:miter",
			attributes: { limit: {
				key: "lim",
				value: 8e5
			} }
		})
	]
});
var createEffectStyle = (effects) => new BuilderElement({
	name: "a:effectStyle",
	children: [new BuilderElement({
		name: "a:effectLst",
		children: effects
	})]
});
var createShadow = () => new BuilderElement({
	name: "a:outerShdw",
	attributes: {
		blurRadius: {
			key: "blurRad",
			value: 57150
		},
		distance: {
			key: "dist",
			value: 19050
		},
		direction: {
			key: "dir",
			value: 54e5
		},
		alignment: {
			key: "algn",
			value: "ctr"
		},
		rotateWithShape: {
			key: "rotWithShape",
			value: false
		}
	},
	children: [new BuilderElement({
		name: "a:srgbClr",
		attributes: { value: {
			key: "val",
			value: "000000"
		} },
		children: [new BuilderElement({
			name: "a:alpha",
			attributes: { value: {
				key: "val",
				value: 63e3
			} }
		})]
	})]
});
/**
* Creates Office's format scheme: from Office 2016 to 2021, the three fills, lines, effects and backgrounds that
* shapes styled by the theme use, from subtle to intense.
*
* ## XSD Schema
* ```xml
* <xsd:complexType name="CT_StyleMatrix">
*   <xsd:sequence>
*     <xsd:element name="fillStyleLst" type="CT_FillStyleList" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="lnStyleLst" type="CT_LineStyleList" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="effectStyleLst" type="CT_EffectStyleList" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="bgFillStyleLst" type="CT_BackgroundFillStyleList" minOccurs="1" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="name" type="xsd:string" use="optional" default=""/>
* </xsd:complexType>
* ```
*/
var createFormatScheme = () => new BuilderElement({
	name: "a:fmtScheme",
	attributes: { name: {
		key: "name",
		value: "Office"
	} },
	children: [
		new BuilderElement({
			name: "a:fillStyleLst",
			children: [
				createSolidFill(),
				createGradientFill([
					[
						["lumMod", 11e4],
						["satMod", 105e3],
						["tint", 67e3]
					],
					[
						["lumMod", 105e3],
						["satMod", 103e3],
						["tint", 73e3]
					],
					[
						["lumMod", 105e3],
						["satMod", 109e3],
						["tint", 81e3]
					]
				]),
				createGradientFill([
					[
						["satMod", 103e3],
						["lumMod", 102e3],
						["tint", 94e3]
					],
					[
						["satMod", 11e4],
						["lumMod", 1e5],
						["shade", 1e5]
					],
					[
						["lumMod", 99e3],
						["satMod", 12e4],
						["shade", 78e3]
					]
				])
			]
		}),
		new BuilderElement({
			name: "a:lnStyleLst",
			children: [
				createLine(6350),
				createLine(12700),
				createLine(19050)
			]
		}),
		new BuilderElement({
			name: "a:effectStyleLst",
			children: [
				createEffectStyle([]),
				createEffectStyle([]),
				createEffectStyle([createShadow()])
			]
		}),
		new BuilderElement({
			name: "a:bgFillStyleLst",
			children: [
				createSolidFill(),
				createSolidFill([["tint", 95e3], ["satMod", 17e4]]),
				createGradientFill([
					[
						["tint", 93e3],
						["satMod", 15e4],
						["shade", 98e3],
						["lumMod", 102e3]
					],
					[
						["tint", 98e3],
						["satMod", 13e4],
						["shade", 9e4],
						["lumMod", 103e3]
					],
					[["shade", 63e3], ["satMod", 12e4]]
				])
			]
		})
	]
});
/**
* Theme module for WordprocessingML documents.
*
* A document's theme (`word/theme/theme1.xml`) gives it a set of colors, a font for headings and one for body text,
* and the fills, lines and effects of shapes styled by the theme. Text, tables and shapes that use the theme's colors
* and fonts change when the theme changes, as they do in Word's Design tab.
*
* Reference: http://officeopenxml.com/drwTheme.php
*
* @module
*/
/**
* Represents the theme of a document, written to `word/theme/theme1.xml`.
*
* Every document has one: Office's theme, from Office 2016 to 2021, with the colors and fonts the options give.
*
* Reference: http://officeopenxml.com/drwTheme.php
*
* ## XSD Schema
* ```xml
* <xsd:element name="theme" type="CT_OfficeStyleSheet"/>
*
* <xsd:complexType name="CT_OfficeStyleSheet">
*   <xsd:sequence>
*     <xsd:element name="themeElements" type="CT_BaseStyles" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="objectDefaults" type="CT_ObjectStyleDefaults" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="extraClrSchemeLst" type="CT_ColorSchemeList" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="custClrLst" type="CT_CustomColorList" minOccurs="0" maxOccurs="1"/>
*     <xsd:element name="extLst" type="CT_OfficeArtExtensionList" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
*   <xsd:attribute name="name" type="xsd:string" use="optional" default=""/>
* </xsd:complexType>
*
* <xsd:complexType name="CT_BaseStyles">
*   <xsd:sequence>
*     <xsd:element name="clrScheme" type="CT_ColorScheme" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="fontScheme" type="CT_FontScheme" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="fmtScheme" type="CT_StyleMatrix" minOccurs="1" maxOccurs="1"/>
*     <xsd:element name="extLst" type="CT_OfficeArtExtensionList" minOccurs="0" maxOccurs="1"/>
*   </xsd:sequence>
* </xsd:complexType>
* ```
*
* @example
* ```typescript
* // A document whose theme has a green accent and Georgia for headings
* const doc = new Document({
*   theme: { colors: { accent1: "2E7D32" }, fonts: { headings: "Georgia" } },
*   sections: [],
* });
* ```
*/
var Theme = class extends XmlComponent {
	constructor({ name = "Office Theme", colors, fonts } = {}) {
		super("a:theme");
		_defineProperty(this, "colors", void 0);
		this.colors = themeColorValues(colors);
		this.root.push(new NextAttributeComponent({
			namespace: {
				key: "xmlns:a",
				value: "http://schemas.openxmlformats.org/drawingml/2006/main"
			},
			name: {
				key: "name",
				value: name
			}
		}));
		this.root.push(new BuilderElement({
			name: "a:themeElements",
			children: [
				createColorScheme(colors ? name : "Office", colors),
				createFontScheme(fonts ? name : "Office", fonts),
				createFormatScheme()
			]
		}));
		this.root.push(new BuilderElement({ name: "a:objectDefaults" }));
		this.root.push(new BuilderElement({ name: "a:extraClrSchemeLst" }));
	}
	/**
	* The hex color of each of the theme's colors. The system's window text and window colors are black and white.
	*/
	get Colors() {
		return this.colors;
	}
};
/**
* The paths of a package's parts, such as word/document.xml in a .docx file, and the targets of the relationships
* between them.
*
* @module
*/
/**
* The path of a part's relationships part, such as word/_rels/document.xml.rels for word/document.xml.
*/
var relationshipsPathOf = (path) => {
	const slash = path.lastIndexOf("/");
	return `${path.slice(0, slash + 1)}_rels/${path.slice(slash + 1)}.rels`;
};
/**
* The part a relationships part belongs to, or "" for the package's own (_rels/.rels), whose targets are from its root.
*/
var sourceOfRelationships = (path) => path.replace(/(^|\/)_rels\/([^/]*)\.rels$/, "$1$2");
var folderOf = (path) => path.slice(0, path.lastIndexOf("/") + 1);
/**
* The path of the part a relationship's target refers to: relative to the folder of the part the relationship belongs
* to, or from the package's root if it starts with "/". Backslashes, which some applications write, are read as slashes.
*
* @param from - The path of the part the relationship belongs to
*/
var resolveTarget = (from, target) => {
	const normalized = target.replace(/\\/g, "/");
	return (normalized.startsWith("/") ? normalized : `${folderOf(from)}${normalized}`).split("/").reduce((segments, segment) => {
		if (segment === "" || segment === ".") return segments;
		return segment === ".." ? segments.slice(0, -1) : [...segments, segment];
	}, []).join("/");
};
/**
* A relationship's target for a part, relative to the folder of the part the relationship belongs to, such as
* "../embeddings/Microsoft_Excel_Worksheet1.xlsx" from word/charts/chart1.xml.
*
* @param from - The path of the part the relationship belongs to
* @param to - The path of the part it refers to
*/
var relativeTarget = (from, to) => {
	const folders = folderOf(from).split("/").filter(Boolean);
	const segments = to.split("/");
	const common = folders.findIndex((folder, index) => index >= segments.length - 1 || segments[index] !== folder);
	const shared = common === -1 ? folders.length : common;
	return [...folders.slice(shared).map(() => ".."), ...segments.slice(shared)].join("/");
};
/**
* Whether two paths are the same part's. Part names are compared without regard to case, as the Open Packaging
* Conventions compare them, so a relationship's target such as "Theme/THEME1.xml" from word/document.xml names
* word/theme/theme1.xml.
*/
var isSamePart = (path, other) => path.toLowerCase() === other.toLowerCase();
var u8 = Uint8Array;
var u16 = Uint16Array;
var i32 = Int32Array;
var fleb = new u8([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]);
var fdeb = new u8([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]);
var clim = new u8([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]);
var freb = function(eb, start) {
	var b = new u16(31);
	for (var i = 0; i < 31; ++i) b[i] = start += 1 << eb[i - 1];
	var r = new i32(b[30]);
	for (var i = 1; i < 30; ++i) for (var j = b[i]; j < b[i + 1]; ++j) r[j] = j - b[i] << 5 | i;
	return {
		b,
		r
	};
};
var _a = freb(fleb, 2);
var fl = _a.b;
var revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0);
var fd = _b.b;
var revfd = _b.r;
var rev = new u16(32768);
for (var i = 0; i < 32768; ++i) {
	var x = (i & 43690) >> 1 | (i & 21845) << 1;
	x = (x & 52428) >> 2 | (x & 13107) << 2;
	x = (x & 61680) >> 4 | (x & 3855) << 4;
	rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
}
var hMap = (function(cd, mb, r) {
	var s = cd.length;
	var i = 0;
	var l = new u16(mb);
	for (; i < s; ++i) if (cd[i]) ++l[cd[i] - 1];
	var le = new u16(mb);
	for (i = 1; i < mb; ++i) le[i] = le[i - 1] + l[i - 1] << 1;
	var co;
	if (r) {
		co = new u16(1 << mb);
		var rvb = 15 - mb;
		for (i = 0; i < s; ++i) if (cd[i]) {
			var sv = i << 4 | cd[i];
			var r_1 = mb - cd[i];
			var v = le[cd[i] - 1]++ << r_1;
			for (var m = v | (1 << r_1) - 1; v <= m; ++v) co[rev[v] >> rvb] = sv;
		}
	} else {
		co = new u16(s);
		for (i = 0; i < s; ++i) if (cd[i]) co[i] = rev[le[cd[i] - 1]++] >> 15 - cd[i];
	}
	return co;
});
var flt = new u8(288);
for (var i = 0; i < 144; ++i) flt[i] = 8;
for (var i = 144; i < 256; ++i) flt[i] = 9;
for (var i = 256; i < 280; ++i) flt[i] = 7;
for (var i = 280; i < 288; ++i) flt[i] = 8;
var fdt = new u8(32);
for (var i = 0; i < 32; ++i) fdt[i] = 5;
var flm = /*#__PURE__*/ hMap(flt, 9, 0);
var flrm = /*#__PURE__*/ hMap(flt, 9, 1);
var fdm = /*#__PURE__*/ hMap(fdt, 5, 0);
var fdrm = /*#__PURE__*/ hMap(fdt, 5, 1);
var max = function(a) {
	var m = a[0];
	for (var i = 1; i < a.length; ++i) if (a[i] > m) m = a[i];
	return m;
};
var bits = function(d, p, m) {
	var o = p / 8 | 0;
	return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
};
var bits16 = function(d, p) {
	var o = p / 8 | 0;
	return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
};
var shft = function(p) {
	return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
	if (s == null || s < 0) s = 0;
	if (e == null || e > v.length) e = v.length;
	return new u8(v.subarray(s, e));
};
var ec = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
];
var err = function(ind, msg, nt) {
	var e = new Error(msg || ec[ind]);
	e.code = ind;
	if (Error.captureStackTrace) Error.captureStackTrace(e, err);
	if (!nt) throw e;
	return e;
};
var inflt = function(dat, st, buf, dict) {
	var sl = dat.length, dl = dict ? dict.length : 0;
	if (!sl || st.f && !st.l) return buf || new u8(0);
	var noBuf = !buf;
	var resize = noBuf || st.i != 2;
	var noSt = st.i;
	if (noBuf) buf = new u8(sl * 3);
	var cbuf = function(l) {
		var bl = buf.length;
		if (l > bl) {
			var nbuf = new u8(Math.max(bl * 2, l));
			nbuf.set(buf);
			buf = nbuf;
		}
	};
	var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
	var tbts = sl * 8;
	do {
		if (!lm) {
			final = bits(dat, pos, 1);
			var type = bits(dat, pos + 1, 3);
			pos += 3;
			if (!type) {
				var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
				if (t > sl) {
					if (noSt) err(0);
					break;
				}
				if (resize) cbuf(bt + l);
				buf.set(dat.subarray(s, t), bt);
				st.b = bt += l, st.p = pos = t * 8, st.f = final;
				continue;
			} else if (type == 1) lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
			else if (type == 2) {
				var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
				var tl = hLit + bits(dat, pos + 5, 31) + 1;
				pos += 14;
				var ldt = new u8(tl);
				var clt = new u8(19);
				for (var i = 0; i < hcLen; ++i) clt[clim[i]] = bits(dat, pos + i * 3, 7);
				pos += hcLen * 3;
				var clb = max(clt), clbmsk = (1 << clb) - 1;
				var clm = hMap(clt, clb, 1);
				for (var i = 0; i < tl;) {
					var r = clm[bits(dat, pos, clbmsk)];
					pos += r & 15;
					var s = r >> 4;
					if (s < 16) ldt[i++] = s;
					else {
						var c = 0, n = 0;
						if (s == 16) n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i - 1];
						else if (s == 17) n = 3 + bits(dat, pos, 7), pos += 3;
						else if (s == 18) n = 11 + bits(dat, pos, 127), pos += 7;
						while (n--) ldt[i++] = c;
					}
				}
				var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
				lbt = max(lt);
				dbt = max(dt);
				lm = hMap(lt, lbt, 1);
				dm = hMap(dt, dbt, 1);
			} else err(1);
			if (pos > tbts) {
				if (noSt) err(0);
				break;
			}
		}
		if (resize) cbuf(bt + 131072);
		var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
		var lpos = pos;
		for (;; lpos = pos) {
			var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
			pos += c & 15;
			if (pos > tbts) {
				if (noSt) err(0);
				break;
			}
			if (!c) err(2);
			if (sym < 256) buf[bt++] = sym;
			else if (sym == 256) {
				lpos = pos, lm = null;
				break;
			} else {
				var add = sym - 254;
				if (sym > 264) {
					var i = sym - 257, b = fleb[i];
					add = bits(dat, pos, (1 << b) - 1) + fl[i];
					pos += b;
				}
				var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
				if (!d) err(3);
				pos += d & 15;
				var dt = fd[dsym];
				if (dsym > 3) {
					var b = fdeb[dsym];
					dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
				}
				if (pos > tbts) {
					if (noSt) err(0);
					break;
				}
				if (resize) cbuf(bt + 131072);
				var end = bt + add;
				if (bt < dt) {
					var shift = dl - dt, dend = Math.min(dt, end);
					if (shift + bt < 0) err(3);
					for (; bt < dend; ++bt) buf[bt] = dict[shift + bt];
				}
				for (; bt < end; ++bt) buf[bt] = buf[bt - dt];
			}
		}
		st.l = lm, st.p = lpos, st.b = bt, st.f = final;
		if (lm) final = 1, st.m = lbt, st.d = dm, st.n = dbt;
	} while (!final);
	return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
};
var wbits = function(d, p, v) {
	v <<= p & 7;
	var o = p / 8 | 0;
	d[o] |= v;
	d[o + 1] |= v >> 8;
};
var wbits16 = function(d, p, v) {
	v <<= p & 7;
	var o = p / 8 | 0;
	d[o] |= v;
	d[o + 1] |= v >> 8;
	d[o + 2] |= v >> 16;
};
var hTree = function(d, mb) {
	var t = [];
	for (var i = 0; i < d.length; ++i) if (d[i]) t.push({
		s: i,
		f: d[i]
	});
	var s = t.length;
	var t2 = t.slice();
	if (!s) return {
		t: et,
		l: 0
	};
	if (s == 1) {
		var v = new u8(t[0].s + 1);
		v[t[0].s] = 1;
		return {
			t: v,
			l: 1
		};
	}
	t.sort(function(a, b) {
		return a.f - b.f;
	});
	t.push({
		s: -1,
		f: 25001
	});
	var l = t[0], r = t[1], i0 = 0, i1 = 1, i2 = 2;
	t[0] = {
		s: -1,
		f: l.f + r.f,
		l,
		r
	};
	while (i1 != s - 1) {
		l = t[t[i0].f < t[i2].f ? i0++ : i2++];
		r = t[i0 != i1 && t[i0].f < t[i2].f ? i0++ : i2++];
		t[i1++] = {
			s: -1,
			f: l.f + r.f,
			l,
			r
		};
	}
	var maxSym = t2[0].s;
	for (var i = 1; i < s; ++i) if (t2[i].s > maxSym) maxSym = t2[i].s;
	var tr = new u16(maxSym + 1);
	var mbt = ln(t[i1 - 1], tr, 0);
	if (mbt > mb) {
		var i = 0, dt = 0;
		var lft = mbt - mb, cst = 1 << lft;
		t2.sort(function(a, b) {
			return tr[b.s] - tr[a.s] || a.f - b.f;
		});
		for (; i < s; ++i) {
			var i2_1 = t2[i].s;
			if (tr[i2_1] > mb) {
				dt += cst - (1 << mbt - tr[i2_1]);
				tr[i2_1] = mb;
			} else break;
		}
		dt >>= lft;
		while (dt > 0) {
			var i2_2 = t2[i].s;
			if (tr[i2_2] < mb) dt -= 1 << mb - tr[i2_2]++ - 1;
			else ++i;
		}
		for (; i >= 0 && dt; --i) {
			var i2_3 = t2[i].s;
			if (tr[i2_3] == mb) {
				--tr[i2_3];
				++dt;
			}
		}
		mbt = mb;
	}
	return {
		t: new u8(tr),
		l: mbt
	};
};
var ln = function(n, l, d) {
	return n.s == -1 ? Math.max(ln(n.l, l, d + 1), ln(n.r, l, d + 1)) : l[n.s] = d;
};
var lc = function(c) {
	var s = c.length;
	while (s && !c[--s]);
	var cl = new u16(++s);
	var cli = 0, cln = c[0], cls = 1;
	var w = function(v) {
		cl[cli++] = v;
	};
	for (var i = 1; i <= s; ++i) if (c[i] == cln && i != s) ++cls;
	else {
		if (!cln && cls > 2) {
			for (; cls > 138; cls -= 138) w(32754);
			if (cls > 2) {
				w(cls > 10 ? cls - 11 << 5 | 28690 : cls - 3 << 5 | 12305);
				cls = 0;
			}
		} else if (cls > 3) {
			w(cln), --cls;
			for (; cls > 6; cls -= 6) w(8304);
			if (cls > 2) w(cls - 3 << 5 | 8208), cls = 0;
		}
		while (cls--) w(cln);
		cls = 1;
		cln = c[i];
	}
	return {
		c: cl.subarray(0, cli),
		n: s
	};
};
var clen = function(cf, cl) {
	var l = 0;
	for (var i = 0; i < cl.length; ++i) l += cf[i] * cl[i];
	return l;
};
var wfblk = function(out, pos, dat) {
	var s = dat.length;
	var o = shft(pos + 2);
	out[o] = s & 255;
	out[o + 1] = s >> 8;
	out[o + 2] = out[o] ^ 255;
	out[o + 3] = out[o + 1] ^ 255;
	for (var i = 0; i < s; ++i) out[o + i + 4] = dat[i];
	return (o + 4 + s) * 8;
};
var wblk = function(dat, out, final, syms, lf, df, eb, li, bs, bl, p) {
	wbits(out, p++, final);
	++lf[256];
	var _a = hTree(lf, 15), dlt = _a.t, mlb = _a.l;
	var _b = hTree(df, 15), ddt = _b.t, mdb = _b.l;
	var _c = lc(dlt), lclt = _c.c, nlc = _c.n;
	var _d = lc(ddt), lcdt = _d.c, ndc = _d.n;
	var lcfreq = new u16(19);
	for (var i = 0; i < lclt.length; ++i) ++lcfreq[lclt[i] & 31];
	for (var i = 0; i < lcdt.length; ++i) ++lcfreq[lcdt[i] & 31];
	var _e = hTree(lcfreq, 7), lct = _e.t, mlcb = _e.l;
	var nlcc = 19;
	for (; nlcc > 4 && !lct[clim[nlcc - 1]]; --nlcc);
	var flen = bl + 5 << 3;
	var ftlen = clen(lf, flt) + clen(df, fdt) + eb;
	var dtlen = clen(lf, dlt) + clen(df, ddt) + eb + 14 + 3 * nlcc + clen(lcfreq, lct) + 2 * lcfreq[16] + 3 * lcfreq[17] + 7 * lcfreq[18];
	if (bs >= 0 && flen <= ftlen && flen <= dtlen) return wfblk(out, p, dat.subarray(bs, bs + bl));
	var lm, ll, dm, dl;
	wbits(out, p, 1 + (dtlen < ftlen)), p += 2;
	if (dtlen < ftlen) {
		lm = hMap(dlt, mlb, 0), ll = dlt, dm = hMap(ddt, mdb, 0), dl = ddt;
		var llm = hMap(lct, mlcb, 0);
		wbits(out, p, nlc - 257);
		wbits(out, p + 5, ndc - 1);
		wbits(out, p + 10, nlcc - 4);
		p += 14;
		for (var i = 0; i < nlcc; ++i) wbits(out, p + 3 * i, lct[clim[i]]);
		p += 3 * nlcc;
		var lcts = [lclt, lcdt];
		for (var it = 0; it < 2; ++it) {
			var clct = lcts[it];
			for (var i = 0; i < clct.length; ++i) {
				var len = clct[i] & 31;
				wbits(out, p, llm[len]), p += lct[len];
				if (len > 15) wbits(out, p, clct[i] >> 5 & 127), p += clct[i] >> 12;
			}
		}
	} else lm = flm, ll = flt, dm = fdm, dl = fdt;
	for (var i = 0; i < li; ++i) {
		var sym = syms[i];
		if (sym > 255) {
			var len = sym >> 18 & 31;
			wbits16(out, p, lm[len + 257]), p += ll[len + 257];
			if (len > 7) wbits(out, p, sym >> 23 & 31), p += fleb[len];
			var dst = sym & 31;
			wbits16(out, p, dm[dst]), p += dl[dst];
			if (dst > 3) wbits16(out, p, sym >> 5 & 8191), p += fdeb[dst];
		} else wbits16(out, p, lm[sym]), p += ll[sym];
	}
	wbits16(out, p, lm[256]);
	return p + ll[256];
};
var deo = /*#__PURE__*/ new i32([
	65540,
	131080,
	131088,
	131104,
	262176,
	1048704,
	1048832,
	2114560,
	2117632
]);
var et = /*#__PURE__*/ new u8(0);
var dflt = function(dat, lvl, plvl, pre, post, st) {
	var s = st.z || dat.length;
	var o = new u8(pre + s + 5 * (1 + Math.ceil(s / 7e3)) + post);
	var w = o.subarray(pre, o.length - post);
	var lst = st.l;
	var pos = (st.r || 0) & 7;
	if (lvl) {
		if (pos) w[0] = st.r >> 3;
		var opt = deo[lvl - 1];
		var n = opt >> 13, c = opt & 8191;
		var msk_1 = (1 << plvl) - 1;
		var prev = st.p || new u16(32768), head = st.h || new u16(msk_1 + 1);
		var bs1_1 = Math.ceil(plvl / 3), bs2_1 = 2 * bs1_1;
		var hsh = function(i) {
			return (dat[i] ^ dat[i + 1] << bs1_1 ^ dat[i + 2] << bs2_1) & msk_1;
		};
		var syms = new i32(25e3);
		var lf = new u16(288), df = new u16(32);
		var lc_1 = 0, eb = 0, i = st.i || 0, li = 0, wi = st.w || 0, bs = 0;
		for (; i + 2 < s; ++i) {
			var hv = hsh(i);
			var imod = i & 32767, pimod = head[hv];
			prev[imod] = pimod;
			head[hv] = imod;
			if (wi <= i) {
				var rem = s - i;
				if ((lc_1 > 7e3 || li > 24576) && (rem > 423 || !lst)) {
					pos = wblk(dat, w, 0, syms, lf, df, eb, li, bs, i - bs, pos);
					li = lc_1 = eb = 0, bs = i;
					for (var j = 0; j < 286; ++j) lf[j] = 0;
					for (var j = 0; j < 30; ++j) df[j] = 0;
				}
				var l = 2, d = 0, ch_1 = c, dif = imod - pimod & 32767;
				if (rem > 2 && hv == hsh(i - dif)) {
					var maxn = Math.min(n, rem) - 1;
					var maxd = Math.min(32767, i);
					var ml = Math.min(258, rem);
					while (dif <= maxd && --ch_1 && imod != pimod) {
						if (dat[i + l] == dat[i + l - dif]) {
							var nl = 0;
							for (; nl < ml && dat[i + nl] == dat[i + nl - dif]; ++nl);
							if (nl > l) {
								l = nl, d = dif;
								if (nl > maxn) break;
								var mmd = Math.min(dif, nl - 2);
								var md = 0;
								for (var j = 0; j < mmd; ++j) {
									var ti = i - dif + j & 32767;
									var cd = ti - prev[ti] & 32767;
									if (cd > md) md = cd, pimod = ti;
								}
							}
						}
						imod = pimod, pimod = prev[imod];
						dif += imod - pimod & 32767;
					}
				}
				if (d) {
					syms[li++] = 268435456 | revfl[l] << 18 | revfd[d];
					var lin = revfl[l] & 31, din = revfd[d] & 31;
					eb += fleb[lin] + fdeb[din];
					++lf[257 + lin];
					++df[din];
					wi = i + l;
					++lc_1;
				} else {
					syms[li++] = dat[i];
					++lf[dat[i]];
				}
			}
		}
		for (i = Math.max(i, wi); i < s; ++i) {
			syms[li++] = dat[i];
			++lf[dat[i]];
		}
		pos = wblk(dat, w, lst, syms, lf, df, eb, li, bs, i - bs, pos);
		if (!lst) {
			st.r = pos & 7 | w[pos / 8 | 0] << 3;
			pos -= 7;
			st.h = head, st.p = prev, st.i = i, st.w = wi;
		}
	} else {
		for (var i = st.w || 0; i < s + lst; i += 65535) {
			var e = i + 65535;
			if (e >= s) {
				w[pos / 8 | 0] = lst;
				e = s;
			}
			pos = wfblk(w, pos + 1, dat.subarray(i, e));
		}
		st.i = s;
	}
	return slc(o, 0, pre + shft(pos) + post);
};
var crct = /*#__PURE__*/ (function() {
	var t = /* @__PURE__ */ new Int32Array(256);
	for (var i = 0; i < 256; ++i) {
		var c = i, k = 9;
		while (--k) c = (c & 1 && -306674912) ^ c >>> 1;
		t[i] = c;
	}
	return t;
})();
var crc = function() {
	var c = -1;
	return {
		p: function(d) {
			var cr = c;
			for (var i = 0; i < d.length; ++i) cr = crct[cr & 255 ^ d[i]] ^ cr >>> 8;
			c = cr;
		},
		d: function() {
			return ~c;
		}
	};
};
var dopt = function(dat, opt, pre, post, st) {
	if (!st) {
		st = { l: 1 };
		if (opt.dictionary) {
			var dict = opt.dictionary.subarray(-32768);
			var newDat = new u8(dict.length + dat.length);
			newDat.set(dict);
			newDat.set(dat, dict.length);
			dat = newDat;
			st.w = dict.length;
		}
	}
	return dflt(dat, opt.level == null ? 6 : opt.level, opt.mem == null ? st.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(dat.length))) * 1.5) : 20 : 12 + opt.mem, pre, post, st);
};
var mrg = function(a, b) {
	var o = {};
	for (var k in a) o[k] = a[k];
	for (var k in b) o[k] = b[k];
	return o;
};
var b2 = function(d, b) {
	return d[b] | d[b + 1] << 8;
};
var b4 = function(d, b) {
	return (d[b] | d[b + 1] << 8 | d[b + 2] << 16 | d[b + 3] << 24) >>> 0;
};
var b8 = function(d, b) {
	return b4(d, b) + b4(d, b + 4) * 4294967296;
};
var wbytes = function(d, b, v) {
	for (; v; ++b) d[b] = v, v >>>= 8;
};
/**
* Compresses data with DEFLATE without any wrapper
* @param data The data to compress
* @param opts The compression options
* @returns The deflated version of the data
*/
function deflateSync(data, opts) {
	return dopt(data, opts || {}, 0, 0);
}
function inflateSync(data, opts) {
	return inflt(data, { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
var fltn = function(d, p, t, o) {
	for (var k in d) {
		var val = d[k], n = p + k, op = o;
		if (Array.isArray(val)) op = mrg(o, val[1]), val = val[0];
		if (ArrayBuffer.isView(val)) t[n] = [val, op];
		else {
			t[n += "/"] = [new u8(0), op];
			fltn(val, n, t, o);
		}
	}
};
var te = typeof TextEncoder != "undefined" && /*#__PURE__*/ new TextEncoder();
var td = typeof TextDecoder != "undefined" && /*#__PURE__*/ new TextDecoder();
try {
	td.decode(et, { stream: true });
} catch (e) {}
var dutf8 = function(d) {
	for (var r = "", i = 0;;) {
		var c = d[i++];
		var eb = (c > 127) + (c > 223) + (c > 239);
		if (i + eb > d.length) return {
			s: r,
			r: slc(d, i - 1)
		};
		if (!eb) r += String.fromCharCode(c);
		else if (eb == 3) c = ((c & 15) << 18 | (d[i++] & 63) << 12 | (d[i++] & 63) << 6 | d[i++] & 63) - 65536, r += String.fromCharCode(55296 | c >> 10, 56320 | c & 1023);
		else if (eb & 1) r += String.fromCharCode((c & 31) << 6 | d[i++] & 63);
		else r += String.fromCharCode((c & 15) << 12 | (d[i++] & 63) << 6 | d[i++] & 63);
	}
};
/**
* Converts a string into a Uint8Array for use with compression/decompression methods
* @param str The string to encode
* @param latin1 Whether or not to interpret the data as Latin-1. This should
*               not need to be true unless decoding a binary string.
* @returns The string encoded in UTF-8/Latin-1 binary
*/
function strToU8(str, latin1) {
	if (latin1) {
		var ar_1 = new u8(str.length);
		for (var i = 0; i < str.length; ++i) ar_1[i] = str.charCodeAt(i);
		return ar_1;
	}
	if (te) return te.encode(str);
	var l = str.length;
	var ar = new u8(str.length + (str.length >> 1));
	var ai = 0;
	var w = function(v) {
		ar[ai++] = v;
	};
	for (var i = 0; i < l; ++i) {
		if (ai + 5 > ar.length) {
			var n = new u8(ai + 8 + (l - i << 1));
			n.set(ar);
			ar = n;
		}
		var c = str.charCodeAt(i);
		if (c < 128 || latin1) w(c);
		else if (c < 2048) w(192 | c >> 6), w(128 | c & 63);
		else if (c > 55295 && c < 57344) c = 65536 + (c & 1047552) | str.charCodeAt(++i) & 1023, w(240 | c >> 18), w(128 | c >> 12 & 63), w(128 | c >> 6 & 63), w(128 | c & 63);
		else w(224 | c >> 12), w(128 | c >> 6 & 63), w(128 | c & 63);
	}
	return slc(ar, 0, ai);
}
/**
* Converts a Uint8Array to a string
* @param dat The data to decode to string
* @param latin1 Whether or not to interpret the data as Latin-1. This should
*               not need to be true unless encoding to binary string.
* @returns The original UTF-8/Latin-1 string
*/
function strFromU8(dat, latin1) {
	if (latin1) {
		var r = "";
		for (var i = 0; i < dat.length; i += 16384) r += String.fromCharCode.apply(null, dat.subarray(i, i + 16384));
		return r;
	} else if (td) return td.decode(dat);
	else {
		var _a = dutf8(dat), s = _a.s, r = _a.r;
		if (r.length) err(8);
		return s;
	}
}
var slzh = function(d, b) {
	return b + 30 + b2(d, b + 26) + b2(d, b + 28);
};
var zh = function(d, b, z) {
	var fnl = b2(d, b + 28), efl = b2(d, b + 30), fn = strFromU8(d.subarray(b + 46, b + 46 + fnl), !(b2(d, b + 8) & 2048)), es = b + 46 + fnl;
	var _a = z64hs(d, es, efl, z, b4(d, b + 20), b4(d, b + 24), b4(d, b + 42)), sc = _a[0], su = _a[1], off = _a[2];
	return [
		b2(d, b + 10),
		sc,
		su,
		fn,
		es + efl + b2(d, b + 32),
		off
	];
};
var z64hs = function(d, b, l, z, sc, su, off) {
	var nsc = sc == 4294967295, nsu = su == 4294967295, noff = off == 4294967295, e = b + l;
	var nf = nsc + nsu + noff;
	if (z && nf) {
		for (; b + 4 < e; b += 4 + b2(d, b + 2)) if (b2(d, b) == 1) return [
			nsc ? b8(d, b + 4 + 8 * nsu) : sc,
			nsu ? b8(d, b + 4) : su,
			noff ? b8(d, b + 4 + 8 * (nsu + nsc)) : off,
			1
		];
		if (z < 2) err(13);
	}
	return [
		sc,
		su,
		off,
		0
	];
};
var exfl = function(ex) {
	var le = 0;
	if (ex) for (var k in ex) {
		var l = ex[k].length;
		if (l > 65535) err(9);
		le += l + 4;
	}
	return le;
};
var wzh = function(d, b, f, fn, u, c, ce, co) {
	var fl = fn.length, ex = f.extra, col = co && co.length;
	var exl = exfl(ex);
	wbytes(d, b, ce != null ? 33639248 : 67324752), b += 4;
	if (ce != null) d[b++] = 20, d[b++] = f.os;
	d[b] = 20, b += 2;
	d[b++] = f.flag << 1 | (c < 0 && 8), d[b++] = u && 8;
	d[b++] = f.compression & 255, d[b++] = f.compression >> 8;
	var dt = new Date(f.mtime == null ? Date.now() : f.mtime), y = dt.getFullYear() - 1980;
	if (y < 0 || y > 119) err(10);
	wbytes(d, b, y << 25 | dt.getMonth() + 1 << 21 | dt.getDate() << 16 | dt.getHours() << 11 | dt.getMinutes() << 5 | dt.getSeconds() >> 1), b += 4;
	if (c != -1) {
		wbytes(d, b, f.crc);
		wbytes(d, b + 4, c < 0 ? -c - 2 : c);
		wbytes(d, b + 8, f.size);
	}
	wbytes(d, b + 12, fl);
	wbytes(d, b + 14, exl), b += 16;
	if (ce != null) {
		wbytes(d, b, col);
		wbytes(d, b + 6, f.attrs);
		wbytes(d, b + 10, ce), b += 14;
	}
	d.set(fn, b);
	b += fl;
	if (exl) for (var k in ex) {
		var exf = ex[k], l = exf.length;
		wbytes(d, b, +k);
		wbytes(d, b + 2, l);
		d.set(exf, b + 4), b += 4 + l;
	}
	if (col) d.set(co, b), b += col;
	return b;
};
var wzf = function(o, b, c, d, e) {
	wbytes(o, b, 101010256);
	wbytes(o, b + 8, c);
	wbytes(o, b + 10, c);
	wbytes(o, b + 12, d);
	wbytes(o, b + 16, e);
};
/**
* Synchronously creates a ZIP file. Prefer using `zip` for better performance
* with more than one file.
* @param data The directory structure for the ZIP archive
* @param opts The main options, merged with per-file options
* @returns The generated ZIP archive
*/
function zipSync(data, opts) {
	if (!opts) opts = {};
	var r = {};
	var files = [];
	fltn(data, "", r, opts);
	var o = 0;
	var tot = 0;
	for (var fn in r) {
		var _a = r[fn], file = _a[0], p = _a[1];
		var compression = p.level == 0 ? 0 : 8;
		var f = strToU8(fn), s = f.length;
		var com = p.comment, m = com && strToU8(com), ms = m && m.length;
		var exl = exfl(p.extra);
		if (s > 65535) err(11);
		var d = compression ? deflateSync(file, p) : file, l = d.length;
		var c = crc();
		c.p(file);
		files.push(mrg(p, {
			size: file.length,
			crc: c.d(),
			c: d,
			f,
			m,
			u: s != fn.length || m && com.length != ms,
			o,
			compression
		}));
		o += 30 + s + exl + l;
		tot += 76 + 2 * (s + exl) + (ms || 0) + l;
	}
	var out = new u8(tot + 22), oe = o, cdl = tot - o;
	for (var i = 0; i < files.length; ++i) {
		var f = files[i];
		wzh(out, f.o, f, f.f, f.u, f.c.length);
		var badd = 30 + f.f.length + exfl(f.extra);
		out.set(f.c, f.o + badd);
		wzh(out, o, f, f.f, f.u, f.c.length, f.o, f.m), o += 16 + badd + (f.m ? f.m.length : 0);
	}
	wzf(out, o, files.length, cdl, oe);
	return out;
}
/**
* Synchronously decompresses a ZIP archive. Prefer using `unzip` for better
* performance with more than one file.
* @param data The raw compressed ZIP file
* @param opts The ZIP extraction options
* @returns The decompressed files
*/
function unzipSync(data, opts) {
	var files = {};
	var e = data.length - 22;
	for (; b4(data, e) != 101010256; --e) if (!e || data.length - e > 65558) err(13);
	var c = b2(data, e + 8);
	if (!c) return {};
	var o = b4(data, e + 16);
	var z = b4(data, e - 20) == 117853008;
	if (z) {
		var ze = b4(data, e - 12);
		z = b4(data, ze) == 101075792;
		if (z) {
			c = b4(data, ze + 32);
			o = b4(data, ze + 48);
		}
	}
	var fltr = opts && opts.filter;
	for (var i = 0; i < c; ++i) {
		var _a = zh(data, o, z), c_2 = _a[0], sc = _a[1], su = _a[2], fn = _a[3], no = _a[4], off = _a[5], b = slzh(data, off);
		o = no;
		if (!fltr || fltr({
			name: fn,
			size: sc,
			originalSize: su,
			compression: c_2
		})) {
			if (!c_2) files[fn] = slc(data, b, b + sc);
			else if (c_2 == 8) files[fn] = inflateSync(data.subarray(b, b + sc), { out: new u8(su) });
			else err(14, "unknown compression type " + c_2);
		}
	}
	return files;
}
/**
* Zips and unzips packages, such as .docx files, and gives a zip file in the output types of `Packer` and
* `patchDocument`.
*
* @module
*/
/**
* The bytes of a file in a package. Bytes from another realm, such as a vm context's Buffer, are read through this
* realm's `Uint8Array`, as fflate tells a file's bytes from a folder of files by `instanceof Uint8Array`.
*/
var bytesOf$2 = (data) => typeof data === "string" ? encodeUtf8(data) : ArrayBuffer.isView(data) ? new Uint8Array(data.buffer, data.byteOffset, data.byteLength) : new Uint8Array(data);
/**
* Zips a package's files, each compressed with DEFLATE, in the order they are given. A path given twice keeps its first
* place and its last data, so a file can be replaced.
*/
var zipFiles = (files) => zipSync(Object.fromEntries([...files].map(([path, data]) => [path, bytesOf$2(data)])));
var MAX_DEFLATE_RATIO = 1032;
var wrongSize = (path) => /* @__PURE__ */ new Error(`Corrupted zip: ${path} isn't the size the zip file gives it`);
/**
* The files in a zip file by their paths, in the zip file's order. Its folders, which hold nothing, are left out, and so
* are the files `include` leaves out, which aren't inflated.
*
* A file must be as large as the zip file says, as JSZip, which docx used to unzip with, checked. fflate takes room for
* that size before inflating a file, so sizes that can't be are refused before it does: compressed data that together
* is larger than the zip file it's in, or a size more than DEFLATE can inflate a file's compressed data to. That keeps
* the room taken to what DEFLATE can give for the zip file. fflate cuts a file short at a size smaller than its data,
* which only parsing the zip file again would show.
*/
var unzipFiles = (data, include = () => true) => {
	const sizes = /* @__PURE__ */ new Map();
	let compressed = 0;
	const files = unzipSync(data, { filter: ({ name, size, originalSize }) => {
		if (name.endsWith("/") || !include(name)) return false;
		compressed += size;
		if (compressed > data.length || originalSize > size * MAX_DEFLATE_RATIO) throw wrongSize(name);
		sizes.set(name, originalSize);
		return true;
	} });
	const wrong = Object.entries(files).find(([path, file]) => file.length !== sizes.get(path));
	if (wrong !== void 0) throw wrongSize(wrong[0]);
	return new Map(Object.entries(files));
};
/** A zip file as a string with a character for each byte, as JSZip, which docx used to zip with, gave it */
var binaryStringOf = (data) => {
	let text = "";
	for (let start = 0; start < data.length; start += 32768) text += String.fromCharCode(...data.subarray(start, start + 32768));
	return text;
};
var unsupported = (type) => /* @__PURE__ */ new Error(`${type} is not supported by this platform`);
var OUTPUTS = {
	uint8array: (data) => data,
	arraybuffer: (data) => data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength),
	array: (data) => Array.from(data),
	string: binaryStringOf,
	binarystring: binaryStringOf,
	base64: (data) => btoa(binaryStringOf(data)),
	blob: (data, mimeType) => {
		if (typeof Blob === "undefined") throw unsupported("blob");
		return new Blob([data], { type: mimeType });
	},
	nodebuffer: (data) => {
		if (typeof Buffer === "undefined") throw unsupported("nodebuffer");
		return Buffer.from(data.buffer, data.byteOffset, data.byteLength);
	},
	text: () => {
		throw unsupported("text");
	}
};
/**
* A zip file in one of the output types of `Packer` and `patchDocument`. The type's case doesn't matter, as it didn't
* to JSZip.
*
* @param mimeType - The type a Blob is given
*/
var zipOutput = (data, type, mimeType) => {
	const output = Object.prototype.hasOwnProperty.call(OUTPUTS, type.toLowerCase()) ? OUTPUTS[type.toLowerCase()] : void 0;
	if (output === void 0) throw unsupported(type);
	return output(data, mimeType);
};
/**
* Reads themes: the theme of a Word document or template, of another Office file, or of a theme file, as the options of
* a document's `theme`, so a document `docx` writes can have it, and the colors of a document's theme for the patcher.
*
* @module
*/
var COLOR_NAMES = /* @__PURE__ */ new Map([
	["dk1", "dark1"],
	["lt1", "light1"],
	["dk2", "dark2"],
	["lt2", "light2"],
	["accent1", "accent1"],
	["accent2", "accent2"],
	["accent3", "accent3"],
	["accent4", "accent4"],
	["accent5", "accent5"],
	["accent6", "accent6"],
	["hlink", "hyperlink"],
	["folHlink", "followedHyperlink"]
]);
var DEFAULT_SYSTEM_COLORS = /* @__PURE__ */ new Map([["dark1", "windowText"], ["light1", "window"]]);
var THEME_TYPES = /* @__PURE__ */ new Set(["http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme", "http://purl.oclc.org/ooxml/officeDocument/relationships/theme"]);
var localName$1 = (element) => {
	var _element$name$slice, _element$name;
	return (_element$name$slice = element === null || element === void 0 || (_element$name = element.name) === null || _element$name === void 0 ? void 0 : _element$name.slice(element.name.indexOf(":") + 1)) !== null && _element$name$slice !== void 0 ? _element$name$slice : "";
};
var childElements = (element) => {
	var _element$elements$fil, _element$elements;
	return (_element$elements$fil = element === null || element === void 0 || (_element$elements = element.elements) === null || _element$elements === void 0 ? void 0 : _element$elements.filter((item) => item.type === "element")) !== null && _element$elements$fil !== void 0 ? _element$elements$fil : [];
};
var child = (element, name) => childElements(element).find((item) => localName$1(item) === name);
var attribute = (element, name) => {
	var _element$attributes;
	const value = element === null || element === void 0 || (_element$attributes = element.attributes) === null || _element$attributes === void 0 ? void 0 : _element$attributes[name];
	return value === void 0 ? void 0 : String(value);
};
var decode$1 = (bytes) => new TextDecoder(bytes[0] === 255 && bytes[1] === 254 ? "utf-16le" : bytes[0] === 254 && bytes[1] === 255 ? "utf-16be" : "utf-8").decode(bytes);
/**
* The part that a part's relationship of one of `types` refers to, such as the package's main part, which the package
* itself (`""`) refers to.
*/
var relatedPart = (files, from, types) => {
	const relationships = files.get(relationshipsPathOf(from));
	const target = attribute(relationships && childElements(child(parseXml(decode$1(relationships)), "Relationships")).find((item) => {
		var _attribute;
		return types.has((_attribute = attribute(item, "Type")) !== null && _attribute !== void 0 ? _attribute : "");
	}), "Target");
	return target === void 0 ? void 0 : resolveTarget(from, target);
};
/**
* The path of the theme a part of a package refers to, such as word/theme/theme1.xml for a Word document's
* word/document.xml.
*/
var themePathOf = (files, part) => relatedPart(files, part, THEME_TYPES);
/**
* A theme color's 6-digit hex color: an RGB color's value, or a system color's last value. Unless `withSystemColors`,
* the first dark and light colors are left out when they are the system's window text and window colors, as `docx`
* writes them then.
*/
var colorValue = (name, color, withSystemColors) => {
	const [value] = childElements(color);
	const hex = localName$1(value) === "srgbClr" ? attribute(value, "val") : localName$1(value) === "sysClr" && (withSystemColors || attribute(value, "val") !== DEFAULT_SYSTEM_COLORS.get(name)) ? attribute(value, "lastClr") : void 0;
	return hex !== void 0 && /^[0-9A-Fa-f]{6}$/.test(hex) ? hex.toUpperCase() : void 0;
};
var readColors = (scheme, withSystemColors = false) => Object.fromEntries(childElements(scheme).flatMap((color) => {
	const name = COLOR_NAMES.get(localName$1(color));
	const value = name && colorValue(name, color, withSystemColors);
	return name && value ? [[name, value]] : [];
}));
/**
* The colors of a theme's XML, each a 6-digit hex color, with the first dark and light colors as their last values when
* they are system colors. The patcher writes theme colors in patches with the hex colors they come to in them.
*/
var readThemeColorValues = (xml) => {
	const [root] = childElements(parseXml(xml));
	const scheme = localName$1(root) === "theme" ? child(child(root, "themeElements"), "clrScheme") : void 0;
	return scheme ? readColors(scheme, true) : {};
};
/**
* File module for WordprocessingML documents.
*
* The File class is the main entry point for creating DOCX documents.
* It manages all document parts including content, styles, numbering, and media.
*
* @module
*/
var COMPOUND_FILE_SIGNATURE = [
	208,
	207,
	17,
	224,
	161,
	177,
	26,
	225
];
/**
* Represents a Word document file.
*
* The File class (exported as `Document`) is the main entry point for creating DOCX documents.
* It manages all document components including content, styles, numbering, headers/footers,
* and media. Documents are organized into sections, each of which can have its own page
* settings, headers, and footers.
*
* This class handles the assembly of all OOXML parts required for a valid .docx file,
* including relationships, content types, and document properties.
*
* @publicApi
*
* @example
* ```typescript
* // Simple document with one section
* const doc = new Document({
*   sections: [{
*     children: [
*       new Paragraph("Hello World"),
*     ],
*   }],
* });
*
* // Document with multiple sections and headers/footers
* const doc = new Document({
*   creator: "John Doe",
*   sections: [
*     {
*       headers: {
*         default: new Header({
*           children: [new Paragraph("Header Text")],
*         }),
*       },
*       children: [
*         new Paragraph("Section 1 content"),
*       ],
*     },
*     {
*       children: [
*         new Paragraph("Section 2 content"),
*       ],
*     },
*   ],
* });
*
* // Document with custom styles and numbering
* const doc = new Document({
*   styles: {
*     paragraphStyles: [
*       {
*         id: "MyHeading",
*         name: "My Heading",
*         basedOn: "Heading1",
*         run: { bold: true, color: "FF0000" },
*       },
*     ],
*   },
*   numbering: {
*     config: [
*       {
*         reference: "my-numbering",
*         levels: [
*           { level: 0, format: "decimal", text: "%1.", alignment: "left" },
*         ],
*       },
*     ],
*   },
*   sections: [{
*     children: [new Paragraph("Content")],
*   }],
* });
* ```
*/
var File = class {
	constructor(options) {
		var _options$creator, _options$revision, _options$lastModified, _options$comments, _options$customProper, _this$macros, _options$features, _options$features2, _options$fonts, _options$hyphenation, _options$hyphenation2, _options$hyphenation3, _options$hyphenation4, _options$fonts2;
		_defineProperty(this, "currentRelationshipId", 1);
		_defineProperty(this, "documentWrapper", void 0);
		_defineProperty(this, "headers", []);
		_defineProperty(this, "footers", []);
		_defineProperty(this, "coreProperties", void 0);
		_defineProperty(this, "numbering", void 0);
		_defineProperty(this, "media", void 0);
		_defineProperty(this, "fileRelationships", void 0);
		_defineProperty(this, "footnotesWrapper", void 0);
		_defineProperty(this, "endnotesWrapper", void 0);
		_defineProperty(this, "settings", void 0);
		_defineProperty(this, "contentTypes", void 0);
		_defineProperty(this, "customProperties", void 0);
		_defineProperty(this, "appProperties", void 0);
		_defineProperty(this, "styles", void 0);
		_defineProperty(this, "comments", void 0);
		_defineProperty(
			this,
			/** Extended comment data for reply threading and resolved state (word/commentsExtended.xml). */
			"commentsExtended",
			void 0
		);
		_defineProperty(
			this,
			/** Durable comment id mapping (word/commentsIds.xml). */
			"commentsIds",
			void 0
		);
		_defineProperty(this, "fontWrapper", void 0);
		_defineProperty(this, "theme", void 0);
		_defineProperty(this, "packageParts", void 0);
		_defineProperty(this, "macros", void 0);
		_defineProperty(this, "bibliography", void 0);
		if (options.macros !== void 0) {
			const { project, events = [] } = options.macros;
			const bytes = project instanceof Uint8Array ? project : new Uint8Array(project);
			if (!COMPOUND_FILE_SIGNATURE.every((byte, index) => bytes[index] === byte)) throw new Error("macros.project isn't a VBA project. Use createMacros from docx/macros, or the word/vbaProject.bin in a .docm rather than the .docm itself");
			const relationships = new Relationships();
			if (events.length > 0) relationships.addRelationship(1, "http://schemas.microsoft.com/office/2006/relationships/wordVbaData", "vbaData.xml");
			this.macros = {
				project: bytes,
				events: events.length > 0 ? createMacroEvents(events) : void 0,
				relationships
			};
		}
		this.coreProperties = new CoreProperties(_objectSpread2(_objectSpread2({}, options), {}, {
			creator: (_options$creator = options.creator) !== null && _options$creator !== void 0 ? _options$creator : "Un-named",
			revision: (_options$revision = options.revision) !== null && _options$revision !== void 0 ? _options$revision : 1,
			lastModifiedBy: (_options$lastModified = options.lastModifiedBy) !== null && _options$lastModified !== void 0 ? _options$lastModified : "Un-named"
		}));
		this.numbering = new Numbering(options.numbering ? options.numbering : { config: [] });
		this.comments = new Comments((_options$comments = options.comments) !== null && _options$comments !== void 0 ? _options$comments : { children: [] });
		if (this.comments.ThreadData) this.commentsExtended = new CommentsExtended(this.comments.ThreadData);
		if (this.comments.CommentIdsData) this.commentsIds = new CommentsIds(this.comments.CommentIdsData);
		this.fileRelationships = new Relationships();
		this.customProperties = new CustomProperties((_options$customProper = options.customProperties) !== null && _options$customProper !== void 0 ? _options$customProper : []);
		this.appProperties = new AppProperties();
		this.footnotesWrapper = new FootnotesWrapper();
		this.endnotesWrapper = new EndnotesWrapper();
		this.contentTypes = new ContentTypes({ macros: this.macros !== void 0 });
		if (((_this$macros = this.macros) === null || _this$macros === void 0 ? void 0 : _this$macros.events) !== void 0) this.contentTypes.addOverride("application/vnd.ms-word.vbaData+xml", "/word/vbaData.xml");
		if (options.bibliography !== void 0) {
			const relationships = new Relationships();
			relationships.addRelationship(1, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXmlProps", "itemProps1.xml");
			this.bibliography = {
				sources: options.bibliography.sources,
				properties: createSourcesProperties(`{${uniqueUuid().toUpperCase()}}`),
				relationships
			};
			this.contentTypes.addOverride("application/vnd.openxmlformats-officedocument.customXmlProperties+xml", "/customXml/itemProps1.xml");
		}
		this.packageParts = new PackageParts(this.contentTypes);
		this.documentWrapper = new DocumentWrapper({
			background: options.background,
			pageNumbers: options.pageNumbers
		});
		this.settings = new Settings({
			compatibilityModeVersion: options.compatabilityModeVersion,
			compatibility: options.compatibility,
			evenAndOddHeaders: options.evenAndOddHeaderAndFooters ? true : false,
			trackRevisions: (_options$features = options.features) === null || _options$features === void 0 ? void 0 : _options$features.trackRevisions,
			updateFields: (_options$features2 = options.features) === null || _options$features2 === void 0 ? void 0 : _options$features2.updateFields,
			embedFonts: ((_options$fonts = options.fonts) === null || _options$fonts === void 0 ? void 0 : _options$fonts.length) ? true : void 0,
			defaultTabStop: options.defaultTabStop,
			protection: options.protection,
			hyphenation: {
				autoHyphenation: (_options$hyphenation = options.hyphenation) === null || _options$hyphenation === void 0 ? void 0 : _options$hyphenation.autoHyphenation,
				hyphenationZone: (_options$hyphenation2 = options.hyphenation) === null || _options$hyphenation2 === void 0 ? void 0 : _options$hyphenation2.hyphenationZone,
				consecutiveHyphenLimit: (_options$hyphenation3 = options.hyphenation) === null || _options$hyphenation3 === void 0 ? void 0 : _options$hyphenation3.consecutiveHyphenLimit,
				doNotHyphenateCaps: (_options$hyphenation4 = options.hyphenation) === null || _options$hyphenation4 === void 0 ? void 0 : _options$hyphenation4.doNotHyphenateCaps
			}
		});
		this.media = new Media((extension) => this.packageParts.takePath("media", "image", extension));
		if (options.externalStyles !== void 0) {
			var _options$styles$defau, _options$styles, _options$styles2, _options$styles3;
			const given = (_options$styles$defau = (_options$styles = options.styles) === null || _options$styles === void 0 ? void 0 : _options$styles.default) !== null && _options$styles$defau !== void 0 ? _options$styles$defau : {};
			const defaultStyles = Object.entries(createDefaultStyles(given));
			const isGiven = ([key]) => given[key] !== void 0;
			const externalStyles = new ExternalStylesFactory().newInstance(options.externalStyles);
			this.styles = new Styles(_objectSpread2(_objectSpread2({}, externalStyles), {}, {
				paragraphStyles: (_options$styles2 = options.styles) === null || _options$styles2 === void 0 ? void 0 : _options$styles2.paragraphStyles,
				characterStyles: (_options$styles3 = options.styles) === null || _options$styles3 === void 0 ? void 0 : _options$styles3.characterStyles,
				importedStyles: [
					...defaultStyles.filter((entry) => !isGiven(entry)).map(([, style]) => style),
					...externalStyles.importedStyles,
					...defaultStyles.filter(isGiven).map(([, style]) => style)
				]
			}));
		} else if (options.styles) {
			const defaultStyles = new DefaultStylesFactory().newInstance(options.styles.default);
			this.styles = new Styles(_objectSpread2(_objectSpread2({}, defaultStyles), options.styles));
		} else {
			const stylesFactory = new DefaultStylesFactory();
			this.styles = new Styles(stylesFactory.newInstance());
		}
		this.addDefaultRelationships();
		for (const section of options.sections) this.addSection(section);
		if (options.footnotes) for (const key in options.footnotes) this.footnotesWrapper.View.createFootNote(parseFloat(key), options.footnotes[key].children);
		if (options.endnotes) for (const key in options.endnotes) this.endnotesWrapper.View.createEndnote(parseFloat(key), options.endnotes[key].children);
		this.fontWrapper = new FontWrapper((_options$fonts2 = options.fonts) !== null && _options$fonts2 !== void 0 ? _options$fonts2 : []);
		this.theme = new Theme(options.theme);
		this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme", "theme/theme1.xml");
		if (this.macros !== void 0) this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.microsoft.com/office/2006/relationships/vbaProject", "vbaProject.bin");
		if (this.bibliography !== void 0) this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml", "../customXml/item1.xml");
	}
	addSection({ headers = {}, footers = {}, children, properties }) {
		this.documentWrapper.View.Body.addSection(_objectSpread2(_objectSpread2({}, properties), {}, {
			headerWrapperGroup: {
				default: headers.default ? this.createHeader(headers.default) : void 0,
				first: headers.first ? this.createHeader(headers.first) : void 0,
				even: headers.even ? this.createHeader(headers.even) : void 0
			},
			footerWrapperGroup: {
				default: footers.default ? this.createFooter(footers.default) : void 0,
				first: footers.first ? this.createFooter(footers.first) : void 0,
				even: footers.even ? this.createFooter(footers.even) : void 0
			}
		}));
		for (const child of children) this.documentWrapper.View.add(child);
	}
	createHeader(header) {
		const wrapper = new HeaderWrapper(this.media, this.currentRelationshipId++);
		for (const child of header.options.children) wrapper.add(child);
		this.addHeaderToDocument(wrapper);
		return wrapper;
	}
	createFooter(footer) {
		const wrapper = new FooterWrapper(this.media, this.currentRelationshipId++);
		for (const child of footer.options.children) wrapper.add(child);
		this.addFooterToDocument(wrapper);
		return wrapper;
	}
	addHeaderToDocument(header, type = HeaderFooterReferenceType.DEFAULT) {
		this.headers.push({
			header,
			type
		});
		this.documentWrapper.Relationships.addRelationship(header.View.ReferenceId, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/header", `header${this.headers.length}.xml`);
		this.contentTypes.addHeader(this.headers.length);
	}
	addFooterToDocument(footer, type = HeaderFooterReferenceType.DEFAULT) {
		this.footers.push({
			footer,
			type
		});
		this.documentWrapper.Relationships.addRelationship(footer.View.ReferenceId, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer", `footer${this.footers.length}.xml`);
		this.contentTypes.addFooter(this.footers.length);
	}
	addDefaultRelationships() {
		this.fileRelationships.addRelationship(1, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument", "word/document.xml");
		this.fileRelationships.addRelationship(2, "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties", "docProps/core.xml");
		this.fileRelationships.addRelationship(3, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties", "docProps/app.xml");
		this.fileRelationships.addRelationship(4, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties", "docProps/custom.xml");
		this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles", "styles.xml");
		this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering", "numbering.xml");
		this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes", "footnotes.xml");
		this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/endnotes", "endnotes.xml");
		this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings", "settings.xml");
		if (!this.comments.IsEmpty) {
			this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments", "comments.xml");
			this.contentTypes.addComments();
		}
		if (this.commentsExtended) {
			this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.microsoft.com/office/2011/relationships/commentsExtended", "commentsExtended.xml");
			this.contentTypes.addCommentsExtended();
		}
		if (this.commentsIds) {
			this.documentWrapper.Relationships.addRelationship(this.currentRelationshipId++, "http://schemas.microsoft.com/office/2016/09/relationships/commentsIds", "commentsIds.xml");
			this.contentTypes.addCommentsIds();
		}
	}
	get Document() {
		return this.documentWrapper;
	}
	get Styles() {
		return this.styles;
	}
	get CoreProperties() {
		return this.coreProperties;
	}
	get Numbering() {
		return this.numbering;
	}
	get Media() {
		return this.media;
	}
	get FileRelationships() {
		return this.fileRelationships;
	}
	get Headers() {
		return this.headers.map((item) => item.header);
	}
	get Footers() {
		return this.footers.map((item) => item.footer);
	}
	get ContentTypes() {
		return this.contentTypes;
	}
	get CustomProperties() {
		return this.customProperties;
	}
	get AppProperties() {
		return this.appProperties;
	}
	get FootNotes() {
		return this.footnotesWrapper;
	}
	get Endnotes() {
		return this.endnotesWrapper;
	}
	get Settings() {
		return this.settings;
	}
	get Comments() {
		return this.comments;
	}
	/** Extended comments part for reply threading. Undefined when no comment threads exist. */
	get CommentsExtended() {
		return this.commentsExtended;
	}
	/** Durable comment id part. Undefined when no comment carries a durableId. */
	get CommentsIds() {
		return this.commentsIds;
	}
	get FontTable() {
		return this.fontWrapper;
	}
	/** The document's theme (word/theme/theme1.xml). */
	get Theme() {
		return this.theme;
	}
	/** The parts that drawings, such as charts, add to the package when it is written. */
	get PackageParts() {
		return this.packageParts;
	}
	/**
	* The document's macros, when it has any: its VBA project (word/vbaProject.bin), the events of the document it
	* handles (word/vbaData.xml), and the project's relationships, to the events.
	*/
	get Macros() {
		return this.macros;
	}
	/**
	* The document's sources, when it has a bibliography: the part they're in (customXml/item1.xml), its properties
	* (customXml/itemProps1.xml), and its relationships, to its properties.
	*/
	get Bibliography() {
		return this.bibliography;
	}
};
/**
* Represents a document footer.
*
* Footers appear at the bottom of each page in a section and can contain
* paragraphs, tables, images, and other content.
*
* @publicApi
*
* @example
* ```typescript
* const footer = new Footer({
*   children: [
*     new Paragraph({ children: [new TextRun("Page "), PageNumber.CURRENT] }),
*   ],
* });
* ```
*/
var Footer = class {
	constructor(options = { children: [] }) {
		_defineProperty(this, "options", void 0);
		this.options = options;
	}
};
/**
* Font obfuscation module for embedding fonts in WordprocessingML documents.
*
* This module implements the OOXML font obfuscation algorithm used to embed
* fonts in DOCX documents. Obfuscation is required by the OOXML specification
* to prevent simple extraction of embedded font files.
*
* Reference: ECMA-376 Part 2, Section 11.1 (Font Embedding)
*
* @module
*/
/** Start offset for obfuscation in the font file */
var obfuscatedStartOffset = 0;
/** End offset for obfuscation (first 32 bytes are obfuscated) */
var obfuscatedEndOffset = 32;
/** Expected GUID size (32 hex characters without dashes) */
var guidSize = 32;
/**
* Obfuscates a TrueType font file for embedding in OOXML documents.
*
* The obfuscation algorithm XORs the first 32 bytes of the font file
* with a reversed byte sequence derived from the font's GUID key.
* This prevents simple extraction while maintaining font functionality.
*
* @param buf - The original font file as a byte array
* @param fontKey - The GUID key for the font (with or without dashes)
* @returns The obfuscated font data
* @throws Error if the fontKey is not a valid 32-character GUID
*
* @example
* ```typescript
* const fontData = readFileSync("font.ttf");
* const fontKey = "00000000-0000-0000-0000-000000000000";
* const obfuscatedData = obfuscate(fontData, fontKey);
* ```
*
* @internal
*/
var obfuscate = (buf, fontKey) => {
	const guid = fontKey.replace(/-/g, "");
	if (guid.length !== guidSize) throw new Error(`Error: Cannot extract GUID from font filename: ${fontKey}`);
	const hexNumbers = guid.replace(/(..)/g, "$1 ").trim().split(" ").map((hexString) => parseInt(hexString, 16));
	hexNumbers.reverse();
	const obfuscatedBytes = buf.slice(obfuscatedStartOffset, obfuscatedEndOffset).map((byte, i) => byte ^ hexNumbers[i % hexNumbers.length]);
	const out = new Uint8Array(obfuscatedStartOffset + obfuscatedBytes.length + Math.max(0, buf.length - obfuscatedEndOffset));
	out.set(buf.slice(0, obfuscatedStartOffset));
	out.set(obfuscatedBytes, obfuscatedStartOffset);
	out.set(buf.slice(obfuscatedEndOffset), obfuscatedStartOffset + obfuscatedBytes.length);
	return out;
};
/**
* Converts XML components into serializable objects ready for XML generation.
*
* The Formatter is responsible for preparing XML components for serialization by calling
* their prepForXml method with the appropriate context. This is a critical step in the
* export pipeline that transforms the declarative API objects into XML-compatible structures.
*
* @example
* ```typescript
* const formatter = new Formatter();
* const paragraph = new Paragraph("Hello World");
* const xmlObject = formatter.format(paragraph, context);
* ```
*/
var Formatter = class {
	/**
	* Formats an XML component into a serializable object.
	*
	* @param input - The XML component to format
	* @param context - The context containing file state and relationships
	* @returns A serializable XML object structure
	* @throws Error if the component cannot be formatted correctly
	*/
	format(input, context = { stack: [] }) {
		const output = input.prepForXml(context);
		if (output) return output;
		else throw Error("XMLComponent did not format correctly");
	}
};
/**
* Placeholder module for the `{key}` tokens docx writes before it knows an image's or a list's id.
*
* @module
*/
var PLACEHOLDER = /\{([^{}]+)\}/g;
/**
* Replaces each `{key}` in the XML whose key has a value, in one pass over the XML. Other text in braces, such as a
* font's key, is left as it is.
*
* @param xmlData - The XML string containing placeholders
* @param values - The value to write for each key
* @returns XML string with the placeholders replaced
*/
var replacePlaceholders = (xmlData, values) => values.size === 0 ? xmlData : xmlData.replace(PLACEHOLDER, (placeholder, key) => {
	var _values$get;
	return (_values$get = values.get(key)) !== null && _values$get !== void 0 ? _values$get : placeholder;
});
/**
* Finds the keys of the `{key}` placeholders in the XML, in one pass over the XML.
*
* @param xmlData - The XML string to search
* @returns The key of every placeholder in the XML
*/
var findPlaceholders = (xmlData) => new Set(Array.from(xmlData.matchAll(PLACEHOLDER), ([, key]) => key));
/**
* Replaces image placeholders with relationship IDs in XML content.
*
* During document compilation, images are referenced using placeholder tokens
* like {4bf7547c9322fd2143bd3e8dfa84109d9d3fed14.png}, the key the image was
* added to the media under. This class replaces those placeholders with the
* actual relationship IDs used in the OOXML structure.
*
* @example
* ```typescript
* const replacer = new ImageReplacer();
* const images = replacer.getMediaData(xmlString, media);
* const updatedXml = replacer.replace(xmlString, images, 1);
* ```
*/
var ImageReplacer = class {
	/**
	* Replaces image placeholder tokens with relationship IDs.
	*
	* @param xmlData - The XML string containing image placeholders
	* @param images - The images the XML refers to, in the order their relationships are numbered
	* @param offset - Starting offset for relationship IDs
	* @returns XML string with placeholders replaced by relationship IDs
	*/
	replace(xmlData, images, offset) {
		return replacePlaceholders(xmlData, new Map(images.map((image, i) => [image.key, (offset + i).toString()])));
	}
	/**
	* Finds the images referenced in the XML content.
	*
	* @param xmlData - The XML string to search for image references
	* @param media - The media collection to search within
	* @returns The images found in the XML, in the order they were added to the media
	*/
	getMediaData(xmlData, media) {
		const placeholders = findPlaceholders(xmlData);
		return media.Entries.filter(([key]) => placeholders.has(key)).map(([key, { fileName }]) => ({
			key,
			fileName
		}));
	}
};
/**
* Replaces numbering instance placeholders with actual numbering IDs in XML content.
*
* Numbering instances (for bullets and numbered lists) use placeholder tokens during
* compilation. This class replaces those placeholders with the final numbering IDs
* that reference the numbering definitions in numbering.xml.
*
* @example
* ```typescript
* const replacer = new NumberingReplacer();
* const updatedXml = replacer.replace(xmlString, concreteNumberings);
* ```
*/
var NumberingReplacer = class {
	/**
	* Replaces numbering placeholder tokens with actual numbering IDs.
	*
	* Placeholder format: {reference-instance} where reference identifies the
	* numbering definition and instance is the specific usage.
	*
	* @param xmlData - The XML string containing numbering placeholders
	* @param concreteNumberings - Array of concrete numbering instances to replace
	* @returns XML string with placeholders replaced by numbering IDs
	*/
	replace(xmlData, concreteNumberings) {
		return replacePlaceholders(xmlData, new Map(concreteNumberings.map(({ reference, instance, restartedListId, numId }) => [listKey(reference, instance, restartedListId), numId.toString()])));
	}
};
var formatter$4 = new Formatter();
/**
* Formats a part's XML, with the relationships that anything in it that refers to other parts adds to.
*/
var xmlifyPart = (file, content, prettify, relationships, standalone = true) => stringifyXmlable(formatter$4.format(content, {
	viewWrapper: {
		View: content,
		Relationships: relationships
	},
	file,
	stack: []
}), {
	indent: prettify,
	declaration: standalone ? {
		standalone: "yes",
		encoding: "UTF-8"
	} : { encoding: "UTF-8" }
});
var xmlifyPackagePart = (file, part, path, prettify) => {
	const { content } = part.options;
	if (content instanceof Uint8Array) return [{
		data: content,
		path: `word/${path}`
	}];
	if ("files" in content) return [{
		data: zipFiles(content.files.map(({ path: filePath, content: fileContent }) => [filePath, fileContent instanceof Uint8Array ? fileContent : xmlifyPart(file, fileContent, prettify, new Relationships())])),
		path: `word/${path}`
	}];
	const relationships = file.PackageParts.createRelationships(path);
	const data = xmlifyPart(file, content, prettify, relationships);
	const folder = path.slice(0, path.lastIndexOf("/"));
	const name = path.slice(path.lastIndexOf("/") + 1);
	return [{
		data,
		path: `word/${path}`
	}, ...relationships.RelationshipCount > 0 ? [{
		data: xmlifyPart(file, relationships, prettify, relationships, false),
		path: `word/${folder}/_rels/${name}.rels`
	}] : []];
};
/**
* Writes the parts added to the package while the document's parts were written, such as charts. A part's XML can add
* parts of its own, such as a chart's embedded workbook, so the parts added meanwhile are written after.
*
* @param from - How many of the parts have been written
*/
var xmlifyPackageParts = (file, prettify, from = 0) => {
	const parts = file.PackageParts.Array.slice(from);
	if (parts.length === 0) return [];
	return [...parts.flatMap(({ part, path }) => xmlifyPackagePart(file, part, path, prettify)), ...xmlifyPackageParts(file, prettify, from + parts.length)];
};
var _excluded = ["PackageParts"];
/**
* Compiles File objects into the files of OOXML-compliant packages.
*
* The Compiler is responsible for converting the internal document representation
* into the complete set of XML files required for a .docx document, managing
* relationships, images, fonts, and all other document components.
*
* @example
* ```typescript
* const compiler = new Compiler();
* const files = compiler.compile(file, PrettifyType.WITH_2_BLANKS);
* ```
*/
var Compiler = class {
	/**
	* Creates a new Compiler instance.
	*
	* Initializes the formatter and replacer utilities used during compilation.
	*/
	constructor() {
		_defineProperty(this, "formatter", void 0);
		_defineProperty(this, "imageReplacer", void 0);
		_defineProperty(this, "numberingReplacer", void 0);
		this.formatter = new Formatter();
		this.imageReplacer = new ImageReplacer();
		this.numberingReplacer = new NumberingReplacer();
	}
	/**
	* Compiles a File object into the files of the complete OOXML package, which the Packer zips.
	*
	* This method orchestrates the entire compilation process:
	* - Converts all document components to XML
	* - Manages image and numbering placeholder replacements
	* - Creates relationship files
	* - Packages fonts and media files
	*
	* @param file - The document to compile
	* @param prettifyXml - Optional XML formatting style
	* @param overrides - Optional custom XML file overrides
	* @returns The package's files by their paths, in the order they are zipped
	*/
	compile(file, prettifyXml, overrides = []) {
		const _this$xmlifyFile = this.xmlifyFile(file, prettifyXml), { PackageParts: packageParts } = _this$xmlifyFile, xmlifiedFileMapping = _objectWithoutProperties(_this$xmlifyFile, _excluded);
		const xmlifiedFiles = Object.values(xmlifiedFileMapping).flatMap((obj) => Array.isArray(obj) ? obj : [obj]);
		return new Map([
			...xmlifiedFiles.map(({ path, data }) => [path, data]),
			...packageParts.map(({ path, data }) => [path, data]),
			...overrides.map(({ path, data }) => [path, data]),
			...file.Macros === void 0 ? [] : [["word/vbaProject.bin", file.Macros.project]],
			...file.Media.Array.map((data) => [`word/media/${data.fileName}`, data.data]),
			...file.FontTable.files.map(({ data: buffer, fontKey }, i) => [`word/fonts/font${i + 1}.odttf`, obfuscate(buffer, fontKey)])
		]);
	}
	xmlifyFile(file, prettify) {
		var _file$Macros;
		const documentXmlData = stringifyXmlable(this.formatter.format(file.Document.View, {
			viewWrapper: file.Document,
			file,
			stack: []
		}), {
			indent: prettify,
			declaration: {
				standalone: "yes",
				encoding: "UTF-8"
			}
		});
		const commentXmlData = stringifyXmlable(this.formatter.format(file.Comments, {
			viewWrapper: {
				View: file.Comments,
				Relationships: file.Comments.Relationships
			},
			file,
			stack: []
		}), {
			indent: prettify,
			declaration: {
				standalone: "yes",
				encoding: "UTF-8"
			}
		});
		const footnoteXmlData = stringifyXmlable(this.formatter.format(file.FootNotes.View, {
			viewWrapper: file.FootNotes,
			file,
			stack: []
		}), {
			indent: prettify,
			declaration: {
				standalone: "yes",
				encoding: "UTF-8"
			}
		});
		const endnoteXmlData = stringifyXmlable(this.formatter.format(file.Endnotes.View, {
			viewWrapper: file.Endnotes,
			file,
			stack: []
		}), {
			indent: prettify,
			declaration: { encoding: "UTF-8" }
		});
		const documentRelationshipCount = file.Document.Relationships.RelationshipCount + 1;
		const commentRelationshipCount = file.Comments.Relationships.RelationshipCount + 1;
		const footnoteRelationshipCount = file.FootNotes.Relationships.RelationshipCount + 1;
		const endnoteRelationshipCount = file.Endnotes.Relationships.RelationshipCount + 1;
		const documentMediaDatas = this.imageReplacer.getMediaData(documentXmlData, file.Media);
		const commentMediaDatas = this.imageReplacer.getMediaData(commentXmlData, file.Media);
		const footnoteMediaDatas = this.imageReplacer.getMediaData(footnoteXmlData, file.Media);
		const endnoteMediaDatas = this.imageReplacer.getMediaData(endnoteXmlData, file.Media);
		return _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({
			Relationships: {
				data: (() => {
					const relationships = Relationships.copy(file.Document.Relationships);
					documentMediaDatas.forEach((mediaData, i) => {
						relationships.addRelationship(documentRelationshipCount + i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", `media/${mediaData.fileName}`);
					});
					relationships.addRelationship(relationships.RelationshipCount + 1, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/fontTable", "fontTable.xml");
					return stringifyXmlable(this.formatter.format(relationships, {
						viewWrapper: file.Document,
						file,
						stack: []
					}), {
						indent: prettify,
						declaration: { encoding: "UTF-8" }
					});
				})(),
				path: "word/_rels/document.xml.rels"
			},
			Document: {
				data: (() => {
					const xmlData = this.imageReplacer.replace(documentXmlData, documentMediaDatas, documentRelationshipCount);
					return this.numberingReplacer.replace(xmlData, file.Numbering.ConcreteNumbering);
				})(),
				path: "word/document.xml"
			},
			Styles: {
				data: (() => {
					const xmlStyles = stringifyXmlable(this.formatter.format(file.Styles, {
						viewWrapper: file.Document,
						file,
						stack: []
					}), {
						indent: prettify,
						declaration: {
							standalone: "yes",
							encoding: "UTF-8"
						}
					});
					return this.numberingReplacer.replace(xmlStyles, file.Numbering.ConcreteNumbering);
				})(),
				path: "word/styles.xml"
			},
			Properties: {
				data: stringifyXmlable(this.formatter.format(file.CoreProperties, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "docProps/core.xml"
			},
			FileRelationships: {
				data: stringifyXmlable(this.formatter.format(file.FileRelationships, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				}),
				path: "_rels/.rels"
			},
			HeaderRelationships: file.Headers.map((headerWrapper, index) => {
				const xmlData = stringifyXmlable(this.formatter.format(headerWrapper.View, {
					viewWrapper: headerWrapper,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				});
				const mediaDatas = this.imageReplacer.getMediaData(xmlData, file.Media);
				const relationships = Relationships.copy(headerWrapper.Relationships);
				mediaDatas.forEach((mediaData, i) => {
					relationships.addRelationship(i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", `media/${mediaData.fileName}`);
				});
				return {
					data: stringifyXmlable(this.formatter.format(relationships, {
						viewWrapper: headerWrapper,
						file,
						stack: []
					}), {
						indent: prettify,
						declaration: { encoding: "UTF-8" }
					}),
					path: `word/_rels/header${index + 1}.xml.rels`
				};
			}),
			FooterRelationships: file.Footers.map((footerWrapper, index) => {
				const xmlData = stringifyXmlable(this.formatter.format(footerWrapper.View, {
					viewWrapper: footerWrapper,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				});
				const mediaDatas = this.imageReplacer.getMediaData(xmlData, file.Media);
				const relationships = Relationships.copy(footerWrapper.Relationships);
				mediaDatas.forEach((mediaData, i) => {
					relationships.addRelationship(i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", `media/${mediaData.fileName}`);
				});
				return {
					data: stringifyXmlable(this.formatter.format(relationships, {
						viewWrapper: footerWrapper,
						file,
						stack: []
					}), {
						indent: prettify,
						declaration: { encoding: "UTF-8" }
					}),
					path: `word/_rels/footer${index + 1}.xml.rels`
				};
			}),
			Headers: file.Headers.map((headerWrapper, index) => {
				const tempXmlData = stringifyXmlable(this.formatter.format(headerWrapper.View, {
					viewWrapper: headerWrapper,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				});
				const mediaDatas = this.imageReplacer.getMediaData(tempXmlData, file.Media);
				const xmlData = this.imageReplacer.replace(tempXmlData, mediaDatas, 0);
				return {
					data: this.numberingReplacer.replace(xmlData, file.Numbering.ConcreteNumbering),
					path: `word/header${index + 1}.xml`
				};
			}),
			Footers: file.Footers.map((footerWrapper, index) => {
				const tempXmlData = stringifyXmlable(this.formatter.format(footerWrapper.View, {
					viewWrapper: footerWrapper,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				});
				const mediaDatas = this.imageReplacer.getMediaData(tempXmlData, file.Media);
				const xmlData = this.imageReplacer.replace(tempXmlData, mediaDatas, 0);
				return {
					data: this.numberingReplacer.replace(xmlData, file.Numbering.ConcreteNumbering),
					path: `word/footer${index + 1}.xml`
				};
			}),
			CustomProperties: {
				data: stringifyXmlable(this.formatter.format(file.CustomProperties, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "docProps/custom.xml"
			},
			AppProperties: {
				data: stringifyXmlable(this.formatter.format(file.AppProperties, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "docProps/app.xml"
			},
			FootNotes: {
				data: (() => {
					const xmlData = this.imageReplacer.replace(footnoteXmlData, footnoteMediaDatas, footnoteRelationshipCount);
					return this.numberingReplacer.replace(xmlData, file.Numbering.ConcreteNumbering);
				})(),
				path: "word/footnotes.xml"
			},
			FootNotesRelationships: {
				data: (() => {
					const relationships = Relationships.copy(file.FootNotes.Relationships);
					footnoteMediaDatas.forEach((mediaData, i) => {
						relationships.addRelationship(footnoteRelationshipCount + i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", `media/${mediaData.fileName}`);
					});
					return stringifyXmlable(this.formatter.format(relationships, {
						viewWrapper: file.FootNotes,
						file,
						stack: []
					}), {
						indent: prettify,
						declaration: { encoding: "UTF-8" }
					});
				})(),
				path: "word/_rels/footnotes.xml.rels"
			},
			Endnotes: {
				data: (() => {
					const xmlData = this.imageReplacer.replace(endnoteXmlData, endnoteMediaDatas, endnoteRelationshipCount);
					return this.numberingReplacer.replace(xmlData, file.Numbering.ConcreteNumbering);
				})(),
				path: "word/endnotes.xml"
			},
			EndnotesRelationships: {
				data: (() => {
					const relationships = Relationships.copy(file.Endnotes.Relationships);
					endnoteMediaDatas.forEach((mediaData, i) => {
						relationships.addRelationship(endnoteRelationshipCount + i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", `media/${mediaData.fileName}`);
					});
					return stringifyXmlable(this.formatter.format(relationships, {
						viewWrapper: file.Endnotes,
						file,
						stack: []
					}), {
						indent: prettify,
						declaration: { encoding: "UTF-8" }
					});
				})(),
				path: "word/_rels/endnotes.xml.rels"
			},
			Settings: {
				data: stringifyXmlable(this.formatter.format(file.Settings, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "word/settings.xml"
			}
		}, file.Comments.IsEmpty ? {} : {
			Comments: {
				data: (() => {
					const xmlData = this.imageReplacer.replace(commentXmlData, commentMediaDatas, commentRelationshipCount);
					return this.numberingReplacer.replace(xmlData, file.Numbering.ConcreteNumbering);
				})(),
				path: "word/comments.xml"
			},
			CommentsRelationships: {
				data: (() => {
					const relationships = Relationships.copy(file.Comments.Relationships);
					commentMediaDatas.forEach((mediaData, i) => {
						relationships.addRelationship(commentRelationshipCount + i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", `media/${mediaData.fileName}`);
					});
					return stringifyXmlable(this.formatter.format(relationships, {
						viewWrapper: {
							View: file.Comments,
							Relationships: file.Comments.Relationships
						},
						file,
						stack: []
					}), {
						indent: prettify,
						declaration: { encoding: "UTF-8" }
					});
				})(),
				path: "word/_rels/comments.xml.rels"
			}
		}), file.CommentsExtended ? { CommentsExtended: {
			data: stringifyXmlable(this.formatter.format(file.CommentsExtended, {
				viewWrapper: {
					View: file.CommentsExtended,
					Relationships: file.Comments.Relationships
				},
				file,
				stack: []
			}), {
				indent: prettify,
				declaration: {
					standalone: "yes",
					encoding: "UTF-8"
				}
			}),
			path: "word/commentsExtended.xml"
		} } : {}), file.CommentsIds ? { CommentsIds: {
			data: stringifyXmlable(this.formatter.format(file.CommentsIds, {
				viewWrapper: {
					View: file.CommentsIds,
					Relationships: file.Comments.Relationships
				},
				file,
				stack: []
			}), {
				indent: prettify,
				declaration: {
					standalone: "yes",
					encoding: "UTF-8"
				}
			}),
			path: "word/commentsIds.xml"
		} } : {}), {}, {
			FontTable: {
				data: stringifyXmlable(this.formatter.format(file.FontTable.View, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "word/fontTable.xml"
			},
			FontTableRelationships: {
				data: (() => stringifyXmlable(this.formatter.format(file.FontTable.Relationships, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				}))(),
				path: "word/_rels/fontTable.xml.rels"
			},
			Theme: {
				data: stringifyXmlable(this.formatter.format(file.Theme, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "word/theme/theme1.xml"
			}
		}, ((_file$Macros = file.Macros) === null || _file$Macros === void 0 ? void 0 : _file$Macros.events) ? {
			MacroEvents: {
				data: stringifyXmlable(this.formatter.format(file.Macros.events, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "word/vbaData.xml"
			},
			MacroRelationships: {
				data: stringifyXmlable(this.formatter.format(file.Macros.relationships, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				}),
				path: "word/_rels/vbaProject.bin.rels"
			}
		} : {}), file.Bibliography ? {
			BibliographySources: {
				data: stringifyXmlable(this.formatter.format(file.Bibliography.sources, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "customXml/item1.xml"
			},
			BibliographySourcesProperties: {
				data: stringifyXmlable(this.formatter.format(file.Bibliography.properties, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "no",
						encoding: "UTF-8"
					}
				}),
				path: "customXml/itemProps1.xml"
			},
			BibliographySourcesRelationships: {
				data: stringifyXmlable(this.formatter.format(file.Bibliography.relationships, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "customXml/_rels/item1.xml.rels"
			}
		} : {}), {}, {
			PackageParts: xmlifyPackageParts(file, prettify),
			Numbering: {
				data: stringifyXmlable(this.formatter.format(file.Numbering, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: {
						standalone: "yes",
						encoding: "UTF-8"
					}
				}),
				path: "word/numbering.xml"
			},
			ContentTypes: {
				data: stringifyXmlable(this.formatter.format(file.ContentTypes, {
					viewWrapper: file.Document,
					file,
					stack: []
				}), {
					indent: prettify,
					declaration: { encoding: "UTF-8" }
				}),
				path: "[Content_Types].xml"
			}
		});
	}
};
var import_events = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
	var R = typeof Reflect === "object" ? Reflect : null;
	var ReflectApply = R && typeof R.apply === "function" ? R.apply : function ReflectApply(target, receiver, args) {
		return Function.prototype.apply.call(target, receiver, args);
	};
	var ReflectOwnKeys;
	if (R && typeof R.ownKeys === "function") ReflectOwnKeys = R.ownKeys;
	else if (Object.getOwnPropertySymbols) ReflectOwnKeys = function ReflectOwnKeys(target) {
		return Object.getOwnPropertyNames(target).concat(Object.getOwnPropertySymbols(target));
	};
	else ReflectOwnKeys = function ReflectOwnKeys(target) {
		return Object.getOwnPropertyNames(target);
	};
	function ProcessEmitWarning(warning) {
		if (console && console.warn) console.warn(warning);
	}
	var NumberIsNaN = Number.isNaN || function NumberIsNaN(value) {
		return value !== value;
	};
	function EventEmitter() {
		EventEmitter.init.call(this);
	}
	module.exports = EventEmitter;
	module.exports.once = once;
	EventEmitter.EventEmitter = EventEmitter;
	EventEmitter.prototype._events = void 0;
	EventEmitter.prototype._eventsCount = 0;
	EventEmitter.prototype._maxListeners = void 0;
	var defaultMaxListeners = 10;
	function checkListener(listener) {
		if (typeof listener !== "function") throw new TypeError("The \"listener\" argument must be of type Function. Received type " + typeof listener);
	}
	Object.defineProperty(EventEmitter, "defaultMaxListeners", {
		enumerable: true,
		get: function() {
			return defaultMaxListeners;
		},
		set: function(arg) {
			if (typeof arg !== "number" || arg < 0 || NumberIsNaN(arg)) throw new RangeError("The value of \"defaultMaxListeners\" is out of range. It must be a non-negative number. Received " + arg + ".");
			defaultMaxListeners = arg;
		}
	});
	EventEmitter.init = function() {
		if (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) {
			this._events = Object.create(null);
			this._eventsCount = 0;
		}
		this._maxListeners = this._maxListeners || void 0;
	};
	EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
		if (typeof n !== "number" || n < 0 || NumberIsNaN(n)) throw new RangeError("The value of \"n\" is out of range. It must be a non-negative number. Received " + n + ".");
		this._maxListeners = n;
		return this;
	};
	function _getMaxListeners(that) {
		if (that._maxListeners === void 0) return EventEmitter.defaultMaxListeners;
		return that._maxListeners;
	}
	EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
		return _getMaxListeners(this);
	};
	EventEmitter.prototype.emit = function emit(type) {
		var args = [];
		for (var i = 1; i < arguments.length; i++) args.push(arguments[i]);
		var doError = type === "error";
		var events = this._events;
		if (events !== void 0) doError = doError && events.error === void 0;
		else if (!doError) return false;
		if (doError) {
			var er;
			if (args.length > 0) er = args[0];
			if (er instanceof Error) throw er;
			var err = /* @__PURE__ */ new Error("Unhandled error." + (er ? " (" + er.message + ")" : ""));
			err.context = er;
			throw err;
		}
		var handler = events[type];
		if (handler === void 0) return false;
		if (typeof handler === "function") ReflectApply(handler, this, args);
		else {
			var len = handler.length;
			var listeners = arrayClone(handler, len);
			for (var i = 0; i < len; ++i) ReflectApply(listeners[i], this, args);
		}
		return true;
	};
	function _addListener(target, type, listener, prepend) {
		var m;
		var events;
		var existing;
		checkListener(listener);
		events = target._events;
		if (events === void 0) {
			events = target._events = Object.create(null);
			target._eventsCount = 0;
		} else {
			if (events.newListener !== void 0) {
				target.emit("newListener", type, listener.listener ? listener.listener : listener);
				events = target._events;
			}
			existing = events[type];
		}
		if (existing === void 0) {
			existing = events[type] = listener;
			++target._eventsCount;
		} else {
			if (typeof existing === "function") existing = events[type] = prepend ? [listener, existing] : [existing, listener];
			else if (prepend) existing.unshift(listener);
			else existing.push(listener);
			m = _getMaxListeners(target);
			if (m > 0 && existing.length > m && !existing.warned) {
				existing.warned = true;
				var w = /* @__PURE__ */ new Error("Possible EventEmitter memory leak detected. " + existing.length + " " + String(type) + " listeners added. Use emitter.setMaxListeners() to increase limit");
				w.name = "MaxListenersExceededWarning";
				w.emitter = target;
				w.type = type;
				w.count = existing.length;
				ProcessEmitWarning(w);
			}
		}
		return target;
	}
	EventEmitter.prototype.addListener = function addListener(type, listener) {
		return _addListener(this, type, listener, false);
	};
	EventEmitter.prototype.on = EventEmitter.prototype.addListener;
	EventEmitter.prototype.prependListener = function prependListener(type, listener) {
		return _addListener(this, type, listener, true);
	};
	function onceWrapper() {
		if (!this.fired) {
			this.target.removeListener(this.type, this.wrapFn);
			this.fired = true;
			if (arguments.length === 0) return this.listener.call(this.target);
			return this.listener.apply(this.target, arguments);
		}
	}
	function _onceWrap(target, type, listener) {
		var state = {
			fired: false,
			wrapFn: void 0,
			target,
			type,
			listener
		};
		var wrapped = onceWrapper.bind(state);
		wrapped.listener = listener;
		state.wrapFn = wrapped;
		return wrapped;
	}
	EventEmitter.prototype.once = function once(type, listener) {
		checkListener(listener);
		this.on(type, _onceWrap(this, type, listener));
		return this;
	};
	EventEmitter.prototype.prependOnceListener = function prependOnceListener(type, listener) {
		checkListener(listener);
		this.prependListener(type, _onceWrap(this, type, listener));
		return this;
	};
	EventEmitter.prototype.removeListener = function removeListener(type, listener) {
		var list, events, position, i, originalListener;
		checkListener(listener);
		events = this._events;
		if (events === void 0) return this;
		list = events[type];
		if (list === void 0) return this;
		if (list === listener || list.listener === listener) {
			if (--this._eventsCount === 0) this._events = Object.create(null);
			else {
				delete events[type];
				if (events.removeListener) this.emit("removeListener", type, list.listener || listener);
			}
		} else if (typeof list !== "function") {
			position = -1;
			for (i = list.length - 1; i >= 0; i--) if (list[i] === listener || list[i].listener === listener) {
				originalListener = list[i].listener;
				position = i;
				break;
			}
			if (position < 0) return this;
			if (position === 0) list.shift();
			else spliceOne(list, position);
			if (list.length === 1) events[type] = list[0];
			if (events.removeListener !== void 0) this.emit("removeListener", type, originalListener || listener);
		}
		return this;
	};
	EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
	EventEmitter.prototype.removeAllListeners = function removeAllListeners(type) {
		var listeners, events = this._events, i;
		if (events === void 0) return this;
		if (events.removeListener === void 0) {
			if (arguments.length === 0) {
				this._events = Object.create(null);
				this._eventsCount = 0;
			} else if (events[type] !== void 0) {
				if (--this._eventsCount === 0) this._events = Object.create(null);
				else delete events[type];
			}
			return this;
		}
		if (arguments.length === 0) {
			var keys = Object.keys(events);
			var key;
			for (i = 0; i < keys.length; ++i) {
				key = keys[i];
				if (key === "removeListener") continue;
				this.removeAllListeners(key);
			}
			this.removeAllListeners("removeListener");
			this._events = Object.create(null);
			this._eventsCount = 0;
			return this;
		}
		listeners = events[type];
		if (typeof listeners === "function") this.removeListener(type, listeners);
		else if (listeners !== void 0) for (i = listeners.length - 1; i >= 0; i--) this.removeListener(type, listeners[i]);
		return this;
	};
	function _listeners(target, type, unwrap) {
		var events = target._events;
		if (events === void 0) return [];
		var evlistener = events[type];
		if (evlistener === void 0) return [];
		if (typeof evlistener === "function") return unwrap ? [evlistener.listener || evlistener] : [evlistener];
		return unwrap ? unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
	}
	EventEmitter.prototype.listeners = function listeners(type) {
		return _listeners(this, type, true);
	};
	EventEmitter.prototype.rawListeners = function rawListeners(type) {
		return _listeners(this, type, false);
	};
	EventEmitter.listenerCount = function(emitter, type) {
		if (typeof emitter.listenerCount === "function") return emitter.listenerCount(type);
		else return listenerCount.call(emitter, type);
	};
	EventEmitter.prototype.listenerCount = listenerCount;
	function listenerCount(type) {
		var events = this._events;
		if (events !== void 0) {
			var evlistener = events[type];
			if (typeof evlistener === "function") return 1;
			else if (evlistener !== void 0) return evlistener.length;
		}
		return 0;
	}
	EventEmitter.prototype.eventNames = function eventNames() {
		return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
	};
	function arrayClone(arr, n) {
		var copy = new Array(n);
		for (var i = 0; i < n; ++i) copy[i] = arr[i];
		return copy;
	}
	function spliceOne(list, index) {
		for (; index + 1 < list.length; index++) list[index] = list[index + 1];
		list.pop();
	}
	function unwrapListeners(arr) {
		var ret = new Array(arr.length);
		for (var i = 0; i < ret.length; ++i) ret[i] = arr[i].listener || arr[i];
		return ret;
	}
	function once(emitter, name) {
		return new Promise(function(resolve, reject) {
			function errorListener(err) {
				emitter.removeListener(name, resolver);
				reject(err);
			}
			function resolver() {
				if (typeof emitter.removeListener === "function") emitter.removeListener("error", errorListener);
				resolve([].slice.call(arguments));
			}
			eventTargetAgnosticAddListener(emitter, name, resolver, { once: true });
			if (name !== "error") addErrorHandlerIfEventEmitter(emitter, errorListener, { once: true });
		});
	}
	function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
		if (typeof emitter.on === "function") eventTargetAgnosticAddListener(emitter, "error", handler, flags);
	}
	function eventTargetAgnosticAddListener(emitter, name, listener, flags) {
		if (typeof emitter.on === "function") {
			if (flags.once) emitter.once(name, listener);
			else emitter.on(name, listener);
		} else if (typeof emitter.addEventListener === "function") emitter.addEventListener(name, function wrapListener(arg) {
			if (flags.once) emitter.removeEventListener(name, wrapListener);
			listener(arg);
		});
		else throw new TypeError("The \"emitter\" argument must be of type EventEmitter. Received type " + typeof emitter);
	}
})))();
/**
* @license MIT
* Adapted from stream-browserify 3.0.0's base Stream and pipe implementation (MIT).
* Copyright Joyent, Inc. and other Node contributors.
* Copyright (c) James Halliday
*
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to permit
* persons to whom the Software is furnished to do so, subject to the
* following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
* NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
* OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
* USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
/** The legacy event stream used by Packer, without unused Readable/Writable implementations. */
var Stream = class extends import_events.EventEmitter {
	pipe(destination, options) {
		const source = this;
		const dest = destination;
		const ondata = (chunk) => {
			if (dest.writable) {
				if (false === dest.write(chunk) && source.pause) source.pause();
			}
		};
		source.on("data", ondata);
		const ondrain = () => {
			if (source.readable && source.resume) source.resume();
		};
		dest.on("drain", ondrain);
		if (!dest._isStdio && (!options || options.end !== false)) {
			source.on("end", onend);
			source.on("close", onclose);
		}
		let didOnEnd = false;
		function onend() {
			if (didOnEnd) return;
			didOnEnd = true;
			dest.end();
		}
		function onclose() {
			if (didOnEnd) return;
			didOnEnd = true;
			if (typeof dest.destroy === "function") dest.destroy();
		}
		function onerror(error) {
			cleanup();
			if (import_events.EventEmitter.listenerCount(this, "error") === 0) throw error;
		}
		source.on("error", onerror);
		dest.on("error", onerror);
		function cleanup() {
			source.removeListener("data", ondata);
			dest.removeListener("drain", ondrain);
			source.removeListener("end", onend);
			source.removeListener("close", onclose);
			source.removeListener("error", onerror);
			dest.removeListener("error", onerror);
			source.removeListener("end", cleanup);
			source.removeListener("close", cleanup);
			dest.removeListener("close", cleanup);
		}
		source.on("end", cleanup);
		source.on("close", cleanup);
		dest.on("close", cleanup);
		dest.emit("pipe", source);
		return dest;
	}
};
function asyncGeneratorStep(n, t, e, r, o, a, c) {
	try {
		var i = n[a](c), u = i.value;
	} catch (n) {
		e(n);
		return;
	}
	i.done ? t(u) : Promise.resolve(u).then(r, o);
}
function _asyncToGenerator(n) {
	return function() {
		var t = this, e = arguments;
		return new Promise(function(r, o) {
			var a = n.apply(t, e);
			function _next(n) {
				asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
			}
			function _throw(n) {
				asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
			}
			_next(void 0);
		});
	};
}
/**
* Prettify options for formatting XML output.
*
* Controls the indentation style used when formatting the generated XML.
* Prettified output is more human-readable but results in larger file sizes.
*
* @publicApi
*/
var PrettifyType = {
	/** No prettification (smallest file size) */
	NONE: "",
	/** Indent with 2 spaces */
	WITH_2_BLANKS: "  ",
	/** Indent with 4 spaces */
	WITH_4_BLANKS: "    ",
	/** Indent with tab character */
	WITH_TAB: "	"
};
var convertPrettifyType = (prettify) => prettify === true ? PrettifyType.WITH_2_BLANKS : prettify === false ? void 0 : prettify;
var mimeTypeOf = (file) => file.Macros === void 0 ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : "application/vnd.ms-word.document.macroEnabled.12";
/**
* Exports documents to various output formats.
*
* The Packer class provides static methods to convert a File object into different
* output formats such as Buffer, Blob, string, or stream. It handles the compilation
* of the document structure into OOXML format and compression into a .docx ZIP archive.
*
* @publicApi
*
* @example
* ```typescript
* // Export to buffer (Node.js)
* const buffer = await Packer.toBuffer(doc);
*
* // Export to blob (browser)
* const blob = await Packer.toBlob(doc);
*
* // Export with prettified XML
* const buffer = await Packer.toBuffer(doc, PrettifyType.WITH_2_BLANKS);
* ```
*/
var Packer = class Packer {
	/**
	* Exports a document to the specified output format.
	*
	* @param file - The document to export
	* @param type - The output format type (e.g., "nodebuffer", "blob", "string")
	* @param prettify - Whether to prettify the XML output (boolean or PrettifyType)
	* @param overrides - Optional array of file overrides for custom XML content
	* @returns A promise resolving to the exported document in the specified format
	*/
	static pack(_x, _x2, _x3) {
		var _this = this;
		return _asyncToGenerator(function* (file, type, prettify, overrides = []) {
			return zipOutput(zipFiles(_this.compiler.compile(file, convertPrettifyType(prettify), overrides)), type, mimeTypeOf(file));
		}).apply(this, arguments);
	}
	/**
	* Exports a document to a string representation.
	*
	* @param file - The document to export
	* @param prettify - Whether to prettify the XML output
	* @param overrides - Optional array of file overrides
	* @returns A promise resolving to the document as a string
	*/
	static toString(file, prettify, overrides = []) {
		return Packer.pack(file, "string", prettify, overrides);
	}
	/**
	* Exports a document to a Node.js Buffer.
	*
	* @param file - The document to export
	* @param prettify - Whether to prettify the XML output
	* @param overrides - Optional array of file overrides
	* @returns A promise resolving to the document as a Buffer
	*/
	static toBuffer(file, prettify, overrides = []) {
		return Packer.pack(file, "nodebuffer", prettify, overrides);
	}
	/**
	* Exports a document to a base64-encoded string.
	*
	* @param file - The document to export
	* @param prettify - Whether to prettify the XML output
	* @param overrides - Optional array of file overrides
	* @returns A promise resolving to the document as a base64 string
	*/
	static toBase64String(file, prettify, overrides = []) {
		return Packer.pack(file, "base64", prettify, overrides);
	}
	/**
	* Exports a document to a Blob (for browser environments).
	*
	* @param file - The document to export
	* @param prettify - Whether to prettify the XML output
	* @param overrides - Optional array of file overrides
	* @returns A promise resolving to the document as a Blob
	*/
	static toBlob(file, prettify, overrides = []) {
		return Packer.pack(file, "blob", prettify, overrides);
	}
	/**
	* Exports a document to an ArrayBuffer.
	*
	* @param file - The document to export
	* @param prettify - Whether to prettify the XML output
	* @param overrides - Optional array of file overrides
	* @returns A promise resolving to the document as an ArrayBuffer
	*/
	static toArrayBuffer(file, prettify, overrides = []) {
		return Packer.pack(file, "arraybuffer", prettify, overrides);
	}
	/**
	* Exports a document to a Node.js Stream.
	*
	* The stream gives the document as one Node.js Buffer, then ends. Where there's no Buffer, as in a browser, it
	* emits an `error` event instead, so use `toBlob` there.
	*
	* @param file - The document to export
	* @param prettify - Whether to prettify the XML output
	* @param overrides - Optional array of file overrides
	* @returns A readable stream containing the document data
	*/
	static toStream(file, prettify, overrides = []) {
		const stream = new Stream();
		const files = this.compiler.compile(file, convertPrettifyType(prettify), overrides);
		new Promise((resolve) => setTimeout(resolve)).then(() => zipOutput(zipFiles(files), "nodebuffer", mimeTypeOf(file))).then((data) => {
			stream.emit("data", data);
			stream.emit("end");
		}, (error) => stream.emit("error", error));
		return stream;
	}
};
_defineProperty(Packer, "compiler", new Compiler());
var bookmarkIdOf = (element) => {
	var _element$attributes;
	if (element.name !== "w:bookmarkStart" && element.name !== "w:bookmarkEnd") return;
	const id = Number((_element$attributes = element.attributes) === null || _element$attributes === void 0 ? void 0 : _element$attributes["w:id"]);
	return Number.isInteger(id) ? id : void 0;
};
/**
* Finds the id of every bookmark in an element, at any depth.
*
* @param element - The element to search, such as a part's root
* @returns The ids, once for each bookmarkStart and bookmarkEnd
*/
var findBookmarkIds = (element) => {
	var _element$elements;
	const id = bookmarkIdOf(element);
	return [...id === void 0 ? [] : [id], ...((_element$elements = element.elements) !== null && _element$elements !== void 0 ? _element$elements : []).flatMap(findBookmarkIds)];
};
/**
* Creates a function that renumbers the bookmarks in content being inserted, so none takes an id the document
* already uses. Bookmark ids must be unique within a document, but a bookmark's id is chosen when it is created,
* without knowing which ids the template has.
*
* A bookmark keeps its id if nothing in the document uses it yet, and otherwise gets the next unused one. An id is
* renumbered the same way each time, so a bookmark's start and end still share one, even in separate patches.
*
* @param idsInDocument - The ids of the bookmarks already in the document
* @returns A function that returns the elements with their bookmarks renumbered
*/
var renumberBookmarksAvoiding = (idsInDocument) => {
	const usedIds = new Set(idsInDocument);
	const newIds = /* @__PURE__ */ new Map();
	let highestId = idsInDocument.reduce((highest, id) => Math.max(highest, id), 0);
	const newIdFor = (id) => {
		const knownId = newIds.get(id);
		if (knownId !== void 0) return knownId;
		const newId = usedIds.has(id) ? highestId + 1 : id;
		highestId = Math.max(highestId, newId);
		usedIds.add(newId);
		newIds.set(id, newId);
		return newId;
	};
	const renumber = (element) => {
		const id = bookmarkIdOf(element);
		return _objectSpread2(_objectSpread2(_objectSpread2({}, element), id === void 0 ? {} : { attributes: _objectSpread2(_objectSpread2({}, element.attributes), {}, { "w:id": String(newIdFor(id)) }) }), element.elements === void 0 ? {} : { elements: element.elements.map(renumber) });
	};
	return (elements) => elements.map(renumber);
};
/**
* Utility functions for XML manipulation in document patching.
*
* @module
*/
var formatter$3 = new Formatter();
/**
* The text of a part, which is UTF-8. A byte order mark at its start is kept, as JSZip, which docx used to unzip with,
* kept it.
*
* @param bytes - The part's bytes
* @returns The part's text
*/
var decodeUtf8 = (bytes) => new TextDecoder("utf-8", { ignoreBOM: true }).decode(bytes);
/**
* Converts XML string to JSON element structure.
*
* Parses XML text into a JavaScript object representation that can be
* manipulated programmatically. Preserves spaces between elements for
* accurate text handling.
*
* @param xmlData - The XML string to parse
* @returns Parsed XML as an Element object
*
* @example
* ```typescript
* const element = toJson('<w:p><w:r><w:t>Hello</w:t></w:r></w:p>');
* ```
*/
var toJson = (xmlData) => {
	return parseXml(xmlData, { keepWhitespaceText: true });
};
/**
* Creates text element contents from a text string.
*
* Generates the XML element structure for a text node (w:t) by formatting
* a Text component and extracting its element contents. Used when creating
* new text runs during replacement operations.
*
* @param text - The text content to wrap in element structure
* @returns Array of XML elements representing the text
*
* @example
* ```typescript
* const elements = createTextElementContents("Hello World");
* // Returns XML elements for <w:t>Hello World</w:t>
* ```
*/
var createTextElementContents = (text) => {
	var _textJson$elements$0$;
	return (_textJson$elements$0$ = toJson(stringifyXmlable(formatter$3.format(new Text({ text })))).elements[0].elements) !== null && _textJson$elements$0$ !== void 0 ? _textJson$elements$0$ : [];
};
/**
* Adds xml:space="preserve" attribute to an element.
*
* The xml:space attribute instructs XML processors to preserve whitespace
* in the element's content. This is important when text contains leading
* or trailing spaces that must be maintained.
*
* @param element - The element to patch
* @returns New element with xml:space attribute added
*
* @example
* ```typescript
* const patched = patchSpaceAttribute(textElement);
* // Adds xml:space="preserve" to maintain whitespace
* ```
*/
var patchSpaceAttribute = (element) => _objectSpread2(_objectSpread2({}, element), {}, { attributes: { "xml:space": "preserve" } });
/**
* Retrieves first-level child elements by parent element name.
*
* Finds the first element with the specified name and returns its children, which elements can be added to.
* Used to access collections like relationship elements or content type definitions.
*
* @param relationships - The parent XML element to search
* @param id - The element name to find
* @returns Array of child elements
*
* @example
* ```typescript
* const rels = getFirstLevelElements(relationshipsXml, "Relationships");
* // Returns array of Relationship elements
* ```
*/
var getFirstLevelElements = (relationships, id) => {
	var _relationships$elemen, _parent$elements;
	const parent = (_relationships$elemen = relationships.elements) === null || _relationships$elemen === void 0 ? void 0 : _relationships$elemen.find((e) => e.name === id);
	if (parent === void 0) return [];
	(_parent$elements = parent.elements) !== null && _parent$elements !== void 0 || (parent.elements = []);
	return parent.elements;
};
/**
* Checks the delimiters of a template's placeholders, which must be more than spaces.
*
* @param delimiters - The delimiters, such as `{{` and `}}`
* @throws Error if either delimiter is empty or only spaces
*/
var checkPlaceholderDelimiters = (delimiters) => {
	if (!(delimiters === null || delimiters === void 0 ? void 0 : delimiters.start.trim()) || !(delimiters === null || delimiters === void 0 ? void 0 : delimiters.end.trim())) throw new Error("Both start and end delimiters must be non-empty strings.");
};
/**
* Appends a content type definition to the [Content_Types].xml structure.
*
* The [Content_Types].xml file declares the MIME types for all file extensions
* in the OOXML package. This function adds a new content type if it doesn't
* already exist, ensuring that newly added media files are properly declared.
*
* @param element - The [Content_Types].xml root element
* @param contentType - The MIME type (e.g., "image/png")
* @param extension - The file extension (e.g., "png")
*
* @example
* ```typescript
* appendContentType(contentTypesElement, "image/png", "png");
* appendContentType(contentTypesElement, "image/jpeg", "jpg");
* ```
*/
var appendContentType = (element, contentType, extension) => {
	const relationshipElements = getFirstLevelElements(element, "Types");
	if (relationshipElements.some((el) => {
		var _el$attributes, _el$attributes2;
		return el.type === "element" && el.name === "Default" && (el === null || el === void 0 || (_el$attributes = el.attributes) === null || _el$attributes === void 0 ? void 0 : _el$attributes.ContentType) === contentType && (el === null || el === void 0 || (_el$attributes2 = el.attributes) === null || _el$attributes2 === void 0 ? void 0 : _el$attributes2.Extension) === extension;
	})) return;
	relationshipElements.push({
		attributes: {
			ContentType: contentType,
			Extension: extension
		},
		name: "Default",
		type: "element"
	});
};
/**
* Appends a content type for one part of the package to the [Content_Types].xml structure, such as a chart a patch
* adds, unless the part already has one.
*
* @param element - The [Content_Types].xml root element
* @param contentType - The part's MIME type (e.g., "application/vnd.openxmlformats-officedocument.drawingml.chart+xml")
* @param partName - The part's path in the package (e.g., "/word/charts/chart1.xml")
*/
var appendContentTypeOverride = (element, contentType, partName) => {
	const contentTypeElements = getFirstLevelElements(element, "Types");
	if (contentTypeElements.some((el) => {
		var _el$attributes3;
		return el.type === "element" && el.name === "Override" && ((_el$attributes3 = el.attributes) === null || _el$attributes3 === void 0 ? void 0 : _el$attributes3.PartName) === partName;
	})) return;
	contentTypeElements.push({
		attributes: {
			ContentType: contentType,
			PartName: partName
		},
		name: "Override",
		type: "element"
	});
};
/**
* Removes the content type of one part of the package from the [Content_Types].xml structure, such as a part a patch
* removes. Part names are compared without case.
*
* @param element - The [Content_Types].xml root element
* @param partName - The part's path in the package (e.g., "/word/embeddings/Microsoft_Excel_Worksheet1.xlsx")
*/
var removeContentTypeOverride = (element, partName) => {
	var _element$elements;
	const types = (_element$elements = element.elements) === null || _element$elements === void 0 ? void 0 : _element$elements.find((el) => el.name === "Types");
	if ((types === null || types === void 0 ? void 0 : types.elements) === void 0) return;
	types.elements = types.elements.filter((el) => {
		var _el$attributes$PartNa, _el$attributes4;
		return !(el.name === "Override" && String((_el$attributes$PartNa = (_el$attributes4 = el.attributes) === null || _el$attributes4 === void 0 ? void 0 : _el$attributes4.PartName) !== null && _el$attributes$PartNa !== void 0 ? _el$attributes$PartNa : "").toLowerCase() === partName.toLowerCase());
	});
};
/**
* Extracts the numeric ID from a relationship ID string.
*
* @param relationshipId - Relationship ID in format "rId123"
* @returns The numeric portion of the ID
*/
var getIdFromRelationshipId = (relationshipId) => {
	const output = parseInt(relationshipId.substring(3), 10);
	return isNaN(output) ? 0 : output;
};
/**
* Determines the next available relationship ID number.
*
* Scans all existing relationships and returns the next sequential ID number
* to use when adding a new relationship.
*
* @param relationships - The relationships XML element
* @returns The next available relationship ID number
*
* @example
* ```typescript
* const nextId = getNextRelationshipIndex(relationshipsElement);
* // If highest existing ID is rId5, returns 6
* ```
*/
var getNextRelationshipIndex = (relationships) => {
	return getFirstLevelElements(relationships, "Relationships").map((e) => {
		var _e$attributes$Id$toSt, _e$attributes;
		return getIdFromRelationshipId((_e$attributes$Id$toSt = (_e$attributes = e.attributes) === null || _e$attributes === void 0 || (_e$attributes = _e$attributes.Id) === null || _e$attributes === void 0 ? void 0 : _e$attributes.toString()) !== null && _e$attributes$Id$toSt !== void 0 ? _e$attributes$Id$toSt : "");
	}).reduce((acc, curr) => Math.max(acc, curr), 0) + 1;
};
/**
* Appends a new relationship to a .rels file structure.
*
* Relationships define connections between parts of an OOXML package,
* such as linking documents to images, hyperlinks, or other resources.
*
* @param relationships - The relationships XML element
* @param id - The relationship ID (number or string)
* @param type - The relationship type URI
* @param target - The target path or URI
* @param targetMode - Optional target mode (Internal or External)
* @returns The updated relationship elements array
*
* @example
* ```typescript
* appendRelationship(
*   relationshipsElement,
*   6,
*   "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
*   "media/image1.png"
* );
* ```
*/
var appendRelationship = (relationships, id, type, target, targetMode) => {
	const relationshipElements = getFirstLevelElements(relationships, "Relationships");
	relationshipElements.push({
		attributes: {
			Id: `rId${id}`,
			Type: type,
			Target: target,
			TargetMode: targetMode
		},
		name: "Relationship",
		type: "element"
	});
	return relationshipElements;
};
/**
* Creates an empty relationships part, for a part that has none.
*/
var createRelationshipFile = () => ({
	declaration: { attributes: {
		version: "1.0",
		encoding: "UTF-8",
		standalone: "yes"
	} },
	elements: [{
		type: "element",
		name: "Relationships",
		attributes: { xmlns: "http://schemas.openxmlformats.org/package/2006/relationships" },
		elements: []
	}]
});
var CORE_PROPERTIES_RELATIONSHIP_TYPE = "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties";
var CORE_PROPERTIES_CONTENT_TYPE = "application/vnd.openxmlformats-package.core-properties+xml";
var PACKAGE_RELATIONSHIPS_PATH = "_rels/.rels";
var CORE_PROPERTIES_PATH = "docProps/core.xml";
var NAMESPACES = {
	cp: "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
	dc: "http://purl.org/dc/elements/1.1/"
};
var ELEMENTS = {
	title: {
		namespace: "dc",
		name: "title"
	},
	subject: {
		namespace: "dc",
		name: "subject"
	},
	creator: {
		namespace: "dc",
		name: "creator"
	},
	keywords: {
		namespace: "cp",
		name: "keywords"
	},
	description: {
		namespace: "dc",
		name: "description"
	},
	lastModifiedBy: {
		namespace: "cp",
		name: "lastModifiedBy"
	},
	revision: {
		namespace: "cp",
		name: "revision"
	}
};
var textOf = (value) => value === "" ? [] : [{
	type: "text",
	text: String(value)
}];
var localName = (element) => {
	var _element$name;
	return (_element$name = element.name) === null || _element$name === void 0 ? void 0 : _element$name.slice(element.name.indexOf(":") + 1);
};
/**
* The prefix, with its colon, that the root gives a namespace, or none if it's the default one. A root without the
* namespace is given it with its usual prefix.
*/
var prefixOf = (root, namespace) => {
	var _Object$entries$find;
	const declaration = (_Object$entries$find = Object.entries(_objectSpread2({}, root.attributes)).find(([name, value]) => (name === "xmlns" || name.startsWith("xmlns:")) && value === NAMESPACES[namespace])) === null || _Object$entries$find === void 0 ? void 0 : _Object$entries$find[0];
	if (declaration === void 0) {
		root.attributes = _objectSpread2(_objectSpread2({}, root.attributes), {}, { [`xmlns:${namespace}`]: NAMESPACES[namespace] });
		return `${namespace}:`;
	}
	return declaration === "xmlns" ? "" : `${declaration.slice(6)}:`;
};
/**
* The text of a part, in UTF-16, from its byte order mark, or else in UTF-8.
*/
var decode = (bytes) => {
	const encoding = bytes[0] === 255 && bytes[1] === 254 ? "utf-16le" : bytes[0] === 254 && bytes[1] === 255 ? "utf-16be" : "utf-8";
	return new TextDecoder(encoding).decode(bytes);
};
/**
* The package's part at a path, if it has one. The patcher keeps a part in UTF-16, or one whose name doesn't end in
* .xml, with its other parts, as it found it, so that is read and moved to its XML parts, to be written in UTF-8 with
* them, rather than written over them as it was.
*/
var readPart = (parts, binaryParts, path) => {
	var _part$declaration;
	const bytes = binaryParts.get(path);
	if (bytes === void 0) return parts.get(path);
	const part = toJson(decode(bytes));
	if ((_part$declaration = part.declaration) === null || _part$declaration === void 0 ? void 0 : _part$declaration.attributes) part.declaration.attributes.encoding = "UTF-8";
	binaryParts.delete(path);
	parts.set(path, part);
	return part;
};
/**
* The path of the package's core properties part, found from its relationships. A package without one is given a
* relationship to docProps/core.xml.
*/
var corePropertiesPathOf = (parts) => {
	var _parts$get, _getFirstLevelElement;
	const relationships = (_parts$get = parts.get(PACKAGE_RELATIONSHIPS_PATH)) !== null && _parts$get !== void 0 ? _parts$get : createRelationshipFile();
	const target = (_getFirstLevelElement = getFirstLevelElements(relationships, "Relationships").find((relationship) => {
		var _relationship$attribu;
		return ((_relationship$attribu = relationship.attributes) === null || _relationship$attribu === void 0 ? void 0 : _relationship$attribu.Type) === CORE_PROPERTIES_RELATIONSHIP_TYPE;
	})) === null || _getFirstLevelElement === void 0 || (_getFirstLevelElement = _getFirstLevelElement.attributes) === null || _getFirstLevelElement === void 0 ? void 0 : _getFirstLevelElement.Target;
	if (typeof target === "string") return resolveTarget("", target);
	appendRelationship(relationships, getNextRelationshipIndex(relationships), CORE_PROPERTIES_RELATIONSHIP_TYPE, CORE_PROPERTIES_PATH);
	parts.set(PACKAGE_RELATIONSHIPS_PATH, relationships);
	return CORE_PROPERTIES_PATH;
};
/**
* Sets the given properties of a document in its core properties part, replacing the template's, and leaves the
* others as they are. A template without the part is given one.
*
* @param parts - The package's XML parts, by their paths, which the part is set in
* @param binaryParts - The package's other parts, by their paths, which the part is taken from if it's one of them
* @param addContentTypeOverride - Adds the content type of the part, if it's new
*/
var patchCoreProperties = (parts, binaryParts, properties, { addContentTypeOverride }) => {
	var _part$elements, _root$elements;
	const path = corePropertiesPathOf(parts);
	const existing = readPart(parts, binaryParts, path);
	const part = existing !== null && existing !== void 0 ? existing : {
		declaration: { attributes: {
			version: "1.0",
			encoding: "UTF-8",
			standalone: "yes"
		} },
		elements: [{
			type: "element",
			name: "cp:coreProperties",
			attributes: { "xmlns:cp": NAMESPACES.cp },
			elements: []
		}]
	};
	if (existing === void 0) {
		parts.set(path, part);
		addContentTypeOverride(CORE_PROPERTIES_CONTENT_TYPE, `/${path}`);
	}
	const root = (_part$elements = part.elements) === null || _part$elements === void 0 ? void 0 : _part$elements.find((element) => localName(element) === "coreProperties");
	if (root === void 0) throw new Error(`Could not find the core properties in ${path}`);
	(_root$elements = root.elements) !== null && _root$elements !== void 0 || (root.elements = []);
	for (const [key, { namespace, name }] of Object.entries(ELEMENTS)) {
		const value = properties[key];
		if (value === void 0) continue;
		const element = root.elements.find((item) => localName(item) === name);
		if (element) element.elements = textOf(value);
		else root.elements.push({
			type: "element",
			name: `${prefixOf(root, namespace)}${name}`,
			elements: textOf(value)
		});
	}
};
var DRAWINGS = /* @__PURE__ */ new Set(["wp:inline", "wp:anchor"]);
var ID_ELEMENTS = /* @__PURE__ */ new Set([
	"wp:docPr",
	"wps:cNvPr",
	"wpg:cNvPr"
]);
var REFERENCE_ELEMENTS = /* @__PURE__ */ new Set(["a:stCxn", "a:endCxn"]);
var idOf$1 = (element, names) => {
	var _element$name, _element$attributes;
	if (!names.has((_element$name = element.name) !== null && _element$name !== void 0 ? _element$name : "")) return;
	const id = Number((_element$attributes = element.attributes) === null || _element$attributes === void 0 ? void 0 : _element$attributes.id);
	return Number.isInteger(id) ? id : void 0;
};
/**
* Finds the id of every drawing in an element, at any depth, and of the shapes in them, such as in a group.
*
* @param element - The element to search, such as a part's root
* @returns The ids, once for each element that has one
*/
var findDrawingIds = (element) => {
	var _element$elements;
	const id = idOf$1(element, ID_ELEMENTS);
	return [...id === void 0 ? [] : [id], ...((_element$elements = element.elements) !== null && _element$elements !== void 0 ? _element$elements : []).flatMap(findDrawingIds)];
};
var ownIdsOf = (drawing) => {
	const idsIn = (element) => {
		var _element$elements2;
		const id = idOf$1(element, ID_ELEMENTS);
		return [...id === void 0 ? [] : [id], ...((_element$elements2 = element.elements) !== null && _element$elements2 !== void 0 ? _element$elements2 : []).flatMap((child) => {
			var _child$name;
			return DRAWINGS.has((_child$name = child.name) !== null && _child$name !== void 0 ? _child$name : "") ? [] : idsIn(child);
		})];
	};
	return idsIn(drawing);
};
/**
* Creates a function that renumbers the drawings in content being inserted, so none has an id another drawing in the
* document has. Word finds a document whose drawings share an id unreadable, even when they are in different parts,
* such as a header and the body. A drawing's id is chosen when it is created, without knowing which ids the template
* has, and content inserted more than once would have the same ids each time.
*
* A drawing keeps its ids if nothing in the document has them yet, and otherwise gets the next unused ones. The
* connectors in a drawing then still join the shapes they did.
*
* @param idsInDocument - The ids of the drawings already in the document, and of the shapes in them
* @returns A function that returns the elements with their drawings renumbered
*/
var renumberDrawingsAvoiding = (idsInDocument) => {
	const usedIds = new Set(idsInDocument);
	let highestId = idsInDocument.reduce((highest, id) => Math.max(highest, id), 0);
	const newIdFor = (id) => {
		const newId = usedIds.has(id) ? highestId + 1 : id;
		highestId = Math.max(highestId, newId);
		usedIds.add(newId);
		return newId;
	};
	const renumberDrawing = (drawing) => {
		const newIds = new Map([...new Set(ownIdsOf(drawing))].map((id) => [id, newIdFor(id)]));
		const renumberIn = (element) => {
			var _element$name2, _idOf;
			if (element !== drawing && DRAWINGS.has((_element$name2 = element.name) !== null && _element$name2 !== void 0 ? _element$name2 : "")) return renumberDrawing(element);
			const id = (_idOf = idOf$1(element, ID_ELEMENTS)) !== null && _idOf !== void 0 ? _idOf : idOf$1(element, REFERENCE_ELEMENTS);
			const newId = id === void 0 ? void 0 : newIds.get(id);
			return _objectSpread2(_objectSpread2(_objectSpread2({}, element), newId === void 0 ? {} : { attributes: _objectSpread2(_objectSpread2({}, element.attributes), {}, { id: String(newId) }) }), element.elements === void 0 ? {} : { elements: element.elements.map(renumberIn) });
		};
		return renumberIn(drawing);
	};
	const renumber = (element) => {
		var _element$name3;
		return DRAWINGS.has((_element$name3 = element.name) !== null && _element$name3 !== void 0 ? _element$name3 : "") ? renumberDrawing(element) : _objectSpread2(_objectSpread2({}, element), element.elements === void 0 ? {} : { elements: element.elements.map(renumber) });
	};
	return (elements) => elements.map(renumber);
};
/**
* The types of patch `patchDocument` applies.
*
* @module
*/
/**
* Patch type enumeration.
*
* Determines how the replacement content should be inserted into the document.
*
* @publicApi
*/
var PatchType = {
	/** Replace entire file-level elements (e.g., whole paragraphs) */
	DOCUMENT: "file",
	/** Replace content within paragraphs (inline replacement) */
	PARAGRAPH: "paragraph",
	/**
	* Repeat the rows of a table that hold the placeholder's fields, such as `{{items.name}}`, once for each row of
	* data. See {@link TableRowsPatch}
	*/
	TABLE_ROWS: "tableRows",
	/**
	* Change a drawing whose alt text holds the placeholder, and the parts it refers to, such as the data of a chart made
	* in Word. See {@link DrawingPatch}
	*/
	DRAWING: "drawing"
};
var DRAWING_PROPERTIES = /* @__PURE__ */ new Map([
	["wp:inline", "wp:docPr"],
	["wp:anchor", "wp:docPr"],
	["wpg:graphicFrame", "wpg:cNvPr"],
	["wpc:graphicFrame", "wpg:cNvPr"]
]);
/**
* Each drawing in an element, in document order, including drawings in text boxes and in both a choice and its
* fallback (`mc:AlternateContent`).
*/
var findDrawings = (element) => {
	var _element$elements;
	return ((_element$elements = element.elements) !== null && _element$elements !== void 0 ? _element$elements : []).flatMap((child) => {
		var _child$elements;
		const name = child.name === void 0 ? void 0 : DRAWING_PROPERTIES.get(child.name);
		const properties = name === void 0 ? void 0 : (_child$elements = child.elements) === null || _child$elements === void 0 ? void 0 : _child$elements.find((e) => e.name === name);
		return [...properties ? [{
			element: child,
			properties
		}] : [], ...findDrawings(child)];
	});
};
/**
* A drawing's alt text: its description, then its title.
*/
var altTextOf = (properties) => {
	var _properties$attribute, _properties$attribute2;
	return [(_properties$attribute = properties.attributes) === null || _properties$attribute === void 0 ? void 0 : _properties$attribute.descr, (_properties$attribute2 = properties.attributes) === null || _properties$attribute2 === void 0 ? void 0 : _properties$attribute2.title].flatMap((text) => text === void 0 ? [] : [String(text)]);
};
var CONTENT_TYPES$1 = "[Content_Types].xml";
/**
* A relationships part's relationships, which can be added to. A part without the `Relationships` element is given one.
*/
var relationshipsIn = (relationships) => {
	var _relationships$elemen;
	if (!((_relationships$elemen = relationships.elements) === null || _relationships$elemen === void 0 ? void 0 : _relationships$elemen.some((element) => element.name === "Relationships"))) {
		var _relationships$elemen2;
		relationships.elements = [...(_relationships$elemen2 = relationships.elements) !== null && _relationships$elemen2 !== void 0 ? _relationships$elemen2 : [], ...createRelationshipFile().elements];
	}
	return getFirstLevelElements(relationships, "Relationships");
};
var RELATIONSHIPS_NAMESPACE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
/**
* The prefixes an element and its descendants give the relationships namespace, with "r", which Word uses.
*/
var relationshipPrefixesIn = (element) => {
	var _element$attributes, _element$elements2;
	return /* @__PURE__ */ new Set([
		"r",
		...Object.entries((_element$attributes = element.attributes) !== null && _element$attributes !== void 0 ? _element$attributes : {}).flatMap(([name, value]) => name.startsWith("xmlns:") && value === RELATIONSHIPS_NAMESPACE ? [name.slice(6)] : []),
		...((_element$elements2 = element.elements) !== null && _element$elements2 !== void 0 ? _element$elements2 : []).flatMap((child) => [...relationshipPrefixesIn(child)])
	]);
};
/**
* The ids of the relationships an element and its descendants refer to, such as a picture's `r:embed`.
*
* @param prefixes - The prefixes of the relationships namespace in the element's part
*/
var relationshipIdsIn = (element, prefixes) => {
	var _element$attributes2, _element$elements3;
	return /* @__PURE__ */ new Set([...Object.entries((_element$attributes2 = element.attributes) !== null && _element$attributes2 !== void 0 ? _element$attributes2 : {}).flatMap(([name, value]) => name.includes(":") && prefixes.has(name.slice(0, name.indexOf(":"))) ? [String(value)] : []), ...((_element$elements3 = element.elements) !== null && _element$elements3 !== void 0 ? _element$elements3 : []).flatMap((child) => [...relationshipIdsIn(child, prefixes)])]);
};
/**
* Reads and changes the template's parts and the relationships between them.
*
* @param parts - The template's XML parts, parsed, by their paths, which are changed in place
* @param binaryParts - The template's other parts, by their paths
*/
var contentsOf = (parts, binaryParts) => {
	const has = (path) => parts.has(path) || binaryParts.has(path);
	const findPath = (path) => {
		if (has(path)) return path;
		const decoded = (() => {
			try {
				return decodeURI(path);
			} catch (_unused) {
				return;
			}
		})();
		if (decoded !== void 0 && has(decoded)) return decoded;
		const lower = path.toLowerCase();
		return [...parts.keys(), ...binaryParts.keys()].find((key) => key.toLowerCase() === lower);
	};
	const findRelationship = (from, id) => {
		const relationships = parts.get(relationshipsPathOf(from));
		return relationships === void 0 ? void 0 : getFirstLevelElements(relationships, "Relationships").find((relationship) => {
			var _relationship$attribu;
			return relationship.name === "Relationship" && ((_relationship$attribu = relationship.attributes) === null || _relationship$attribu === void 0 ? void 0 : _relationship$attribu.Id) === id;
		});
	};
	const pathOf = (from, relationship) => {
		var _relationship$attribu2, _relationship$attribu3;
		const target = (_relationship$attribu2 = relationship.attributes) === null || _relationship$attribu2 === void 0 ? void 0 : _relationship$attribu2.Target;
		return ((_relationship$attribu3 = relationship.attributes) === null || _relationship$attribu3 === void 0 ? void 0 : _relationship$attribu3.TargetMode) === "External" || target === void 0 ? void 0 : findPath(resolveTarget(from, String(target)));
	};
	const isReferenced = (path) => [...parts].some(([relationshipsPath, relationships]) => relationshipsPath.endsWith(".rels") && getFirstLevelElements(relationships, "Relationships").some((relationship) => pathOf(sourceOfRelationships(relationshipsPath), relationship) === path));
	const removeIfUnreferenced = (from, path) => {
		if (path === void 0 || path === from || path === CONTENT_TYPES$1 || path.endsWith(".rels") || isReferenced(path)) return;
		const relationships = parts.get(relationshipsPathOf(path));
		parts.delete(path);
		binaryParts.delete(path);
		parts.delete(relationshipsPathOf(path));
		const contentTypes = parts.get(CONTENT_TYPES$1);
		if (contentTypes !== void 0) removeContentTypeOverride(contentTypes, `/${path}`);
		for (const relationship of relationships === void 0 ? [] : getFirstLevelElements(relationships, "Relationships")) removeIfUnreferenced(path, pathOf(path, relationship));
	};
	const removeRelationships = (from, ids) => {
		var _parts$get, _relationships$elemen3;
		const relationships = (_parts$get = parts.get(relationshipsPathOf(from))) === null || _parts$get === void 0 || (_parts$get = _parts$get.elements) === null || _parts$get === void 0 ? void 0 : _parts$get.find((element) => element.name === "Relationships");
		const removed = ((_relationships$elemen3 = relationships === null || relationships === void 0 ? void 0 : relationships.elements) !== null && _relationships$elemen3 !== void 0 ? _relationships$elemen3 : []).filter((relationship) => {
			var _relationship$attribu4;
			return relationship.name === "Relationship" && ids.has(String((_relationship$attribu4 = relationship.attributes) === null || _relationship$attribu4 === void 0 ? void 0 : _relationship$attribu4.Id));
		});
		if (relationships === void 0 || removed.length === 0) return;
		relationships.elements = relationships.elements.filter((element) => !removed.includes(element));
		for (const relationship of removed) removeIfUnreferenced(from, pathOf(from, relationship));
	};
	return {
		findRelationship,
		pathOf,
		removeIfUnreferenced,
		removeRelationships
	};
};
/**
* The template's package, as a patch reads and changes it.
*
* @param parts - The template's XML parts, parsed, by their paths, which are changed in place
* @param contents - Reads and changes the template's parts and the relationships between them
* @param context - The context to format XML with
*/
var createTemplatePackage = (parts, { findRelationship, pathOf, removeIfUnreferenced }, file, context) => {
	const formatter = new Formatter();
	return {
		getRelatedPart: (from, relationshipId) => {
			const relationship = findRelationship(from.path, relationshipId);
			const path = relationship === void 0 ? void 0 : pathOf(from.path, relationship);
			return path === void 0 ? void 0 : {
				path,
				xml: parts.get(path)
			};
		},
		replaceRelatedPart: (from, relationshipId, part) => {
			const path = `word/${file.PackageParts.add(part)}`;
			const { relationshipType } = part.options;
			const target = relativeTarget(from.path, path);
			const relationship = relationshipId === void 0 ? void 0 : findRelationship(from.path, relationshipId);
			if (relationship === void 0) {
				var _parts$get2;
				const relationshipsPath = relationshipsPathOf(from.path);
				const relationships = (_parts$get2 = parts.get(relationshipsPath)) !== null && _parts$get2 !== void 0 ? _parts$get2 : createRelationshipFile();
				parts.set(relationshipsPath, relationships);
				const id = relationshipId !== null && relationshipId !== void 0 ? relationshipId : `rId${getNextRelationshipIndex(relationships)}`;
				relationshipsIn(relationships).push({
					type: "element",
					name: "Relationship",
					attributes: {
						Id: id,
						Type: relationshipType,
						Target: target
					}
				});
				return id;
			}
			const previous = pathOf(from.path, relationship);
			relationship.attributes = _objectSpread2(_objectSpread2({}, Object.fromEntries(Object.entries(relationship.attributes).filter(([name]) => name !== "TargetMode"))), {}, {
				Type: relationshipType,
				Target: target
			});
			removeIfUnreferenced(from.path, previous);
			return String(relationship.attributes.Id);
		},
		format: (content) => toJson(stringifyXmlable(formatter.format(content, context))).elements[0]
	};
};
/**
* Applies the patches for drawings whose alt text holds their placeholder, such as charts. Every drawing is found
* before any is patched, so a patch only sees the template's own alt text.
*
* @param parts - The template's XML parts, parsed, by their paths, which are changed in place
* @param binaryParts - The template's other parts, by their paths, which parts can be removed from
* @param patches - Each drawing patch, by its key
* @param createContext - Creates the context to format XML for a part with
* @throws If a drawing's alt text holds the placeholders of more than one patch, or a patch throws
*/
var patchDrawings = ({ parts, binaryParts, file, patches, delimiters }, createContext) => {
	const placeholders = patches.map(([key, patch]) => ({
		placeholder: `${delimiters.start}${key}${delimiters.end}`,
		patch
	}));
	const found = [...parts].filter(([path]) => path.startsWith("word/") && !path.endsWith(".rels")).flatMap(([path, xmlPart]) => findDrawings(xmlPart).flatMap((drawing) => {
		const altText = altTextOf(drawing.properties);
		const matches = placeholders.filter(({ placeholder }) => altText.some((text) => text.includes(placeholder)));
		if (matches.length > 1) {
			var _drawing$properties$a, _drawing$properties$a2;
			throw new Error(`The drawing "${(_drawing$properties$a = (_drawing$properties$a2 = drawing.properties.attributes) === null || _drawing$properties$a2 === void 0 ? void 0 : _drawing$properties$a2.name) !== null && _drawing$properties$a !== void 0 ? _drawing$properties$a : ""}" in ${path} has the placeholders ${matches.map(({ placeholder }) => placeholder).join(" and ")} in its alt text. A drawing can only be patched once`);
		}
		return matches.map(({ placeholder, patch }) => ({
			drawing: _objectSpread2(_objectSpread2({ placeholder }, drawing), {}, { part: {
				path,
				xml: xmlPart
			} }),
			patch
		}));
	}));
	const contents = contentsOf(parts, binaryParts);
	for (const { drawing, patch } of found) {
		const referenced = relationshipIdsIn(drawing.element, relationshipPrefixesIn(drawing.part.xml));
		patch.patch(drawing, createTemplatePackage(parts, contents, file, createContext(drawing.part.path)));
		const used = relationshipIdsIn(drawing.part.xml, relationshipPrefixesIn(drawing.part.xml));
		contents.removeRelationships(drawing.part.path, new Set([...referenced].filter((id) => !used.has(id))));
	}
};
var isStream = (data) => typeof data === "object" && data !== null && "on" in data && typeof data.on === "function";
var isZipArchive = (data) => typeof data === "object" && data !== null && "generateAsync" in data && typeof data.generateAsync === "function";
var isBlob = (data) => ["[object Blob]", "[object File]"].includes(Object.prototype.toString.call(data));
/**
* Reads a stream to its end, as a zip file lists its files at its end.
*
* It listens for the stream's events, rather than iterating it, so that a stream with no iterator also works, such
* as `Packer.toStream`'s. A chunk is usually a run of bytes, but a stream made with `Readable.from` of a `Uint8Array`
* gives each byte as a number of its own. Those are kept as numbers, not wrapped in an array each.
*/
var readStream = (stream) => new Promise((resolve, reject) => {
	const chunks = [];
	stream.on("data", (chunk) => {
		if (ArrayBuffer.isView(chunk)) chunks.push(new Uint8Array(chunk.buffer, chunk.byteOffset, chunk.byteLength));
		else if (typeof chunk === "number") chunks.push(chunk);
		else reject(/* @__PURE__ */ new TypeError(`A template stream must give bytes, but it gave a ${typeof chunk}. A stream with an encoding set gives text, so do not set one.`));
	});
	stream.on("error", reject);
	stream.on("end", () => {
		const bytes = new Uint8Array(chunks.reduce((length, chunk) => length + (typeof chunk === "number" ? 1 : chunk.length), 0));
		chunks.reduce((offset, chunk) => {
			if (typeof chunk === "number") {
				bytes[offset] = chunk;
				return offset + 1;
			}
			bytes.set(chunk, offset);
			return offset + chunk.length;
		}, 0);
		resolve(bytes);
	});
});
/** The bytes of a template's zip file, from any of the forms `patchDocument` and `patchDetector` take it in */
var bytesOf$1 = function() {
	var _ref = _asyncToGenerator(function* (data) {
		if (isZipArchive(data)) return data.generateAsync({ type: "uint8array" });
		if (isStream(data)) return readStream(data);
		if (isBlob(data)) return new Uint8Array(yield data.arrayBuffer());
		if (typeof data === "string") return Uint8Array.from({ length: data.length }, (_, index) => data.charCodeAt(index));
		if (Array.isArray(data)) return Uint8Array.from(data);
		return ArrayBuffer.isView(data) ? new Uint8Array(data.buffer, data.byteOffset, data.byteLength) : new Uint8Array(data);
	});
	return function bytesOf(_x) {
		return _ref.apply(this, arguments);
	};
}();
/**
* The files in the zip file of a template, from any of the forms `patchDocument` and `patchDetector` take it in
*
* @param include - Which files to read, by their paths. The others aren't inflated.
*/
var loadZip = function() {
	var _ref2 = _asyncToGenerator(function* (data, include) {
		return unzipFiles(yield bytesOf$1(data), include);
	});
	return function loadZip(_x2, _x3) {
		return _ref2.apply(this, arguments);
	};
}();
/**
* Footnotes and endnotes for content inserted into an existing document.
*
* @module
*/
var formatter$2 = new Formatter();
var DOCUMENT_PATH$1 = "word/document.xml";
var FOOTNOTES = {
	path: "word/footnotes.xml",
	rootName: "w:footnotes",
	noteName: "w:footnote",
	referenceName: "w:footnoteReference",
	contentType: "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml",
	relationshipType: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes",
	create: {
		part: () => new FootNotes(),
		mark: () => new FootnoteRefRun(),
		styles: () => [
			new FootnoteText({}),
			new FootnoteTextChar({}),
			new FootnoteReferenceStyle({})
		]
	}
};
var ENDNOTES = {
	path: "word/endnotes.xml",
	rootName: "w:endnotes",
	noteName: "w:endnote",
	referenceName: "w:endnoteReference",
	contentType: "application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml",
	relationshipType: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/endnotes",
	create: {
		part: () => new Endnotes(),
		mark: () => new EndnoteRefRun(),
		styles: () => [
			new EndnoteText({}),
			new EndnoteTextChar({}),
			new EndnoteReferenceStyle({})
		]
	}
};
var formatElement$1 = (component, context) => toJson(stringifyXmlable(formatter$2.format(component, context))).elements[0];
var findIds = (element, names) => {
	var _element$name, _element$attributes, _element$elements;
	const id = names.includes((_element$name = element.name) !== null && _element$name !== void 0 ? _element$name : "") ? Number((_element$attributes = element.attributes) === null || _element$attributes === void 0 ? void 0 : _element$attributes["w:id"]) : NaN;
	return [...Number.isInteger(id) ? [id] : [], ...((_element$elements = element.elements) !== null && _element$elements !== void 0 ? _element$elements : []).flatMap((child) => findIds(child, names))];
};
var withMark = (paragraph, mark) => {
	var _paragraph$elements, _elements$;
	const elements = (_paragraph$elements = paragraph.elements) !== null && _paragraph$elements !== void 0 ? _paragraph$elements : [];
	const index = ((_elements$ = elements[0]) === null || _elements$ === void 0 ? void 0 : _elements$.name) === "w:pPr" ? 1 : 0;
	return _objectSpread2(_objectSpread2({}, paragraph), {}, { elements: [
		...elements.slice(0, index),
		mark,
		...elements.slice(index)
	] });
};
var patchNotesOfKind = (kind, notes, parts, { createContext, addContentTypeOverride, renumberBookmarks, renumberDrawings, renumberLists, useStyles }) => {
	const givenNotes = new Map(Object.entries(notes).map(([id, note]) => [Number(id), note]));
	const carriedIds = /* @__PURE__ */ new Map();
	let highestGivenId = [...givenNotes.keys()].filter(Number.isFinite).reduce((highest, id) => Math.max(highest, Math.floor(id)), 0);
	const noteOfId = /* @__PURE__ */ new Map();
	let highestId;
	const renumber = (element) => {
		var _element$attributes2, _highestId;
		const note = element.name === kind.referenceName ? givenNotes.get(Number((_element$attributes2 = element.attributes) === null || _element$attributes2 === void 0 ? void 0 : _element$attributes2["w:id"])) : void 0;
		if (note === void 0) return element.elements === void 0 ? element : _objectSpread2(_objectSpread2({}, element), {}, { elements: element.elements.map(renumber) });
		highestId = ((_highestId = highestId) !== null && _highestId !== void 0 ? _highestId : [...parts.values()].flatMap((part) => findIds(part, [kind.noteName, kind.referenceName])).reduce((highest, id) => Math.max(highest, id), 0)) + 1;
		noteOfId.set(highestId, note);
		return _objectSpread2(_objectSpread2({}, element), {}, { attributes: _objectSpread2(_objectSpread2({}, element.attributes), {}, { "w:id": String(highestId) }) });
	};
	const findOrAddPart = () => {
		var _parts$get;
		const relationship = getFirstLevelElements((_parts$get = parts.get(relationshipsPathOf(DOCUMENT_PATH$1))) !== null && _parts$get !== void 0 ? _parts$get : {}, "Relationships").find((element) => {
			var _element$attributes3;
			return ((_element$attributes3 = element.attributes) === null || _element$attributes3 === void 0 ? void 0 : _element$attributes3.Type) === kind.relationshipType;
		});
		const path = relationship ? resolveTarget(DOCUMENT_PATH$1, String(relationship.attributes.Target)) : kind.path;
		if (!parts.has(path)) {
			parts.set(path, {
				declaration: { attributes: {
					version: "1.0",
					encoding: "UTF-8",
					standalone: "yes"
				} },
				elements: [formatElement$1(kind.create.part(), createContext(path))]
			});
			addContentTypeOverride(kind.contentType, `/${path}`);
		}
		if (!relationship) createContext(DOCUMENT_PATH$1).viewWrapper.Relationships.addRelationship(uniqueId(), kind.relationshipType, relativeTarget(DOCUMENT_PATH$1, path));
		return path;
	};
	const write = () => {
		if (noteOfId.size === 0) return;
		const path = findOrAddPart();
		const context = createContext(path);
		const contentOfNote = new Map([...new Set(noteOfId.values())].map((note) => {
			const mark = formatElement$1(kind.create.mark(), context);
			return [note, useStyles(renumberLists(renumberBookmarks(note.children.map((paragraph) => formatElement$1(paragraph, context)).map((paragraph, index) => index === 0 ? withMark(paragraph, mark) : paragraph))))];
		}));
		getFirstLevelElements(parts.get(path), kind.rootName).push(...[...noteOfId].map(([id, note]) => ({
			type: "element",
			name: kind.noteName,
			attributes: { "w:id": String(id) },
			elements: [...renumberDrawings(contentOfNote.get(note))]
		})));
		const stylesPart = parts.get("word/styles.xml");
		if (stylesPart) {
			const styles = getFirstLevelElements(stylesPart, "w:styles");
			const styleIds = new Set(styles.map((style) => {
				var _style$attributes;
				return (_style$attributes = style.attributes) === null || _style$attributes === void 0 ? void 0 : _style$attributes["w:styleId"];
			}));
			styles.push(...kind.create.styles().map((style) => formatElement$1(style, context)).filter((style) => {
				var _style$attributes2;
				return !styleIds.has((_style$attributes2 = style.attributes) === null || _style$attributes2 === void 0 ? void 0 : _style$attributes2["w:styleId"]);
			}));
		}
	};
	const carry = (reference, note) => {
		const existing = carriedIds.get(reference);
		if (existing !== void 0) return existing;
		highestGivenId++;
		givenNotes.set(highestGivenId, note);
		carriedIds.set(reference, highestGivenId);
		return highestGivenId;
	};
	return {
		renumber: (elements) => elements.map(renumber),
		write,
		carry
	};
};
/**
* Creates the writer of the footnotes and endnotes that patches refer to.
*
* A patch refers to a note with a reference run, such as `new FootnoteReferenceRun(1)`, whose id is the note's in
* `footnotes`, or with a run that brings its note with it, such as `new FootnoteReferenceRun({ children })`, which is
* given an id with `carry` as it is written. Only references to these notes are renumbered, and only the notes that
* are referred to are written.
*
* @param notes - The footnotes and endnotes, by the id the patches' reference runs are given
* @param parts - The document's XML parts, parsed, by their paths, which the notes are written to
* @param helpers - The patcher's helpers for what the notes refer to
*/
var patchNotes = ({ footnotes = {}, endnotes = {} }, parts, helpers) => {
	const patchers = {
		footnotes: patchNotesOfKind(FOOTNOTES, footnotes, parts, helpers),
		endnotes: patchNotesOfKind(ENDNOTES, endnotes, parts, helpers)
	};
	return {
		carry: (kind, reference, note) => patchers[kind].carry(reference, note),
		renumber: (elements) => Object.values(patchers).reduce((renumbered, patcher) => patcher.renumber(renumbered), elements),
		write: () => {
			for (const patcher of Object.values(patchers)) patcher.write();
		}
	};
};
/**
* Lists in content inserted into an existing document.
*
* @module
*/
var formatter$1 = new Formatter();
var DOCUMENT_PATH = "word/document.xml";
var NUMBERING_PATH = "word/numbering.xml";
var NUMBERING_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml";
var NUMBERING_RELATIONSHIP = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering";
var BULLET_REFERENCE = "default-bullet-numbering";
var BULLET_NUM_ID = "1";
var formatElement = (component, context) => toJson(stringifyXmlable(formatter$1.format(component, context))).elements[0];
var highestOf = (ids) => ids.reduce((highest, id) => Math.max(highest, id), 0);
/**
* Creates the writer of the lists that patches use.
*
* A paragraph in a patch is put in a list as in a Document, with `numbering: { reference, level }` for one of the
* numbering's references, or with `bullet`. It is written with a placeholder for its list's id, or for a bullet, with
* the id a Document's bullet list has, which a template's lists may have too.
*
* @param numbering - The numbering the patches' paragraphs add their lists to as they are written
* @param parts - The document's XML parts, parsed, by their paths, which the lists are written to
* @param helpers - The patcher's helpers for the numbering part
*/
var patchNumbering = (numbering, parts, { createContext, addContentTypeOverride }) => {
	const newNumIds = /* @__PURE__ */ new Map();
	let highestNumId;
	const numberingRelationship = () => {
		var _parts$get;
		return getFirstLevelElements((_parts$get = parts.get(relationshipsPathOf(DOCUMENT_PATH))) !== null && _parts$get !== void 0 ? _parts$get : {}, "Relationships").find((element) => {
			var _element$attributes;
			return ((_element$attributes = element.attributes) === null || _element$attributes === void 0 ? void 0 : _element$attributes.Type) === NUMBERING_RELATIONSHIP;
		});
	};
	const numberingPath = (relationship = numberingRelationship()) => relationship ? resolveTarget(DOCUMENT_PATH, String(relationship.attributes.Target)) : NUMBERING_PATH;
	const idsInTemplate = (name, attribute) => {
		var _parts$get2;
		return getFirstLevelElements((_parts$get2 = parts.get(numberingPath())) !== null && _parts$get2 !== void 0 ? _parts$get2 : {}, "w:numbering").filter((element) => element.name === name).map((element) => Number(element.attributes[attribute]));
	};
	const listOf = (numId) => {
		if (numId === BULLET_NUM_ID) return numbering.ConcreteNumbering.find(({ reference }) => reference === BULLET_REFERENCE);
		if (!numId.startsWith("{")) return;
		const list = numbering.ConcreteNumbering.find(({ reference, instance }) => numId === `{${reference}-${instance}}`);
		if (!list) {
			const reference = numId.slice(1, -1).replace(/-\d+$/, "");
			throw new Error(`A paragraph in a patch uses the numbering "${reference}", which isn't in the numbering option of patchDocument. Add it there with its levels, as in a Document`);
		}
		return list;
	};
	const newNumIdOf = (list) => {
		var _highestNumId;
		const knownId = newNumIds.get(list.numId);
		if (knownId !== void 0) return knownId;
		highestNumId = ((_highestNumId = highestNumId) !== null && _highestNumId !== void 0 ? _highestNumId : highestOf(idsInTemplate("w:num", "w:numId"))) + 1;
		newNumIds.set(list.numId, highestNumId);
		return highestNumId;
	};
	const renumber = (element) => {
		const list = element.name === "w:numId" ? listOf(String(element.attributes["w:val"])) : void 0;
		if (list === void 0) return element.elements === void 0 ? element : _objectSpread2(_objectSpread2({}, element), {}, { elements: element.elements.map(renumber) });
		return _objectSpread2(_objectSpread2({}, element), {}, { attributes: _objectSpread2(_objectSpread2({}, element.attributes), {}, { "w:val": String(newNumIdOf(list)) }) });
	};
	const findOrAddPart = (written) => {
		const relationship = numberingRelationship();
		const path = numberingPath(relationship);
		if (!parts.has(path)) {
			parts.set(path, {
				declaration: { attributes: {
					version: "1.0",
					encoding: "UTF-8",
					standalone: "yes"
				} },
				elements: [_objectSpread2(_objectSpread2({}, written), {}, { elements: [] })]
			});
			addContentTypeOverride(NUMBERING_CONTENT_TYPE, `/${path}`);
		}
		if (!relationship) createContext(DOCUMENT_PATH).viewWrapper.Relationships.addRelationship(uniqueId(), NUMBERING_RELATIONSHIP, relativeTarget(DOCUMENT_PATH, path));
		return path;
	};
	const write = () => {
		var _root$attributes$mcI, _root$attributes;
		if (newNumIds.size === 0) return;
		const written = formatElement(numbering, createContext(numberingPath()));
		const abstractNumIdOf = (list) => Number(list.elements.find((element) => element.name === "w:abstractNumId").attributes["w:val"]);
		const lists = written.elements.filter((element) => element.name === "w:num" && newNumIds.has(Number(element.attributes["w:numId"])));
		const highestAbstractNumId = highestOf(idsInTemplate("w:abstractNum", "w:abstractNumId"));
		const newAbstractNumIds = new Map([...new Set(lists.map(abstractNumIdOf))].map((id, index) => [id, highestAbstractNumId + index + 1]));
		const abstractLists = written.elements.flatMap((element) => {
			const newId = element.name === "w:abstractNum" ? newAbstractNumIds.get(Number(element.attributes["w:abstractNumId"])) : void 0;
			return newId === void 0 ? [] : [_objectSpread2(_objectSpread2({}, element), {}, { attributes: _objectSpread2(_objectSpread2({}, element.attributes), {}, { "w:abstractNumId": String(newId) }) })];
		});
		const path = findOrAddPart(written);
		const root = parts.get(path).elements.find((element) => element.name === "w:numbering");
		root.attributes = _objectSpread2(_objectSpread2(_objectSpread2({}, Object.fromEntries(Object.entries(written.attributes).filter(([name]) => name.startsWith("xmlns:")))), root.attributes), {}, { "mc:Ignorable": [.../* @__PURE__ */ new Set([...String((_root$attributes$mcI = (_root$attributes = root.attributes) === null || _root$attributes === void 0 ? void 0 : _root$attributes["mc:Ignorable"]) !== null && _root$attributes$mcI !== void 0 ? _root$attributes$mcI : "").split(" "), ...String(written.attributes["mc:Ignorable"]).split(" ")])].filter((prefix) => prefix !== "").join(" ") });
		const elements = getFirstLevelElements(parts.get(path), "w:numbering");
		const firstIndexOf = (names) => {
			const index = elements.findIndex((element) => names.includes(element.name));
			return index === -1 ? elements.length : index;
		};
		elements.splice(firstIndexOf(["w:num", "w:numIdMacAtCleanup"]), 0, ...abstractLists);
		elements.splice(firstIndexOf(["w:numIdMacAtCleanup"]), 0, ...lists.map((list) => _objectSpread2(_objectSpread2({}, list), {}, {
			attributes: _objectSpread2(_objectSpread2({}, list.attributes), {}, { "w:numId": String(newNumIds.get(Number(list.attributes["w:numId"]))) }),
			elements: list.elements.map((element) => element.name === "w:abstractNumId" ? _objectSpread2(_objectSpread2({}, element), {}, { attributes: { "w:val": String(newAbstractNumIds.get(abstractNumIdOf(list))) } }) : element)
		})));
	};
	return {
		renumber: (elements) => elements.map(renumber),
		write
	};
};
/**
* Page numbers written into a template's fields once `patchDocument` has patched it, from an estimate of its pages, as
* a document's are when it is written with `pageNumbers`.
*
* @module
*/
/** The elements of a template, as `parseXml` reads them */
var PARSED = {
	nameOf: (element) => element.type === "element" ? element.name : void 0,
	contentOf: (element) => element.elements,
	attributeOf: (element, attribute) => {
		var _element$attributes;
		return (_element$attributes = element.attributes) === null || _element$attributes === void 0 ? void 0 : _element$attributes[attribute];
	},
	textOf: (element) => {
		var _element$elements;
		return ((_element$elements = element.elements) !== null && _element$elements !== void 0 ? _element$elements : []).filter(({ type }) => type === "text").map(({ text }) => String(text)).join("");
	},
	textElement: (text) => ({
		type: "element",
		name: "w:t",
		attributes: { "xml:space": "preserve" },
		elements: [{
			type: "text",
			text
		}]
	}),
	writeClean: (begin, instruction) => {
		var _begin$attributes;
		if (/^\s*(PAGEREF|TOC)\b/i.test(instruction) && ((_begin$attributes = begin.attributes) === null || _begin$attributes === void 0 ? void 0 : _begin$attributes["w:dirty"]) !== void 0) begin.attributes = Object.fromEntries(Object.entries(begin.attributes).filter(([key]) => key !== "w:dirty"));
	},
	setSimpleFieldResult: (element, text) => {
		element.elements = [{
			type: "element",
			name: "w:r",
			elements: [PARSED.textElement(text)]
		}];
	}
};
var DOCUMENT = "word/document.xml";
var IMPORT = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/aFChunk";
var ZIP = [
	80,
	75,
	3,
	4
];
/** A package's parts, from a zip file: its XML parts parsed, as patchDocument parses a template's, and the rest as bytes */
var readPackage = function() {
	var _ref = _asyncToGenerator(function* (data) {
		if (!ZIP.every((byte, index) => data[index] === byte)) return;
		try {
			const parts = /* @__PURE__ */ new Map();
			const binaryParts = /* @__PURE__ */ new Map();
			for (const [path, file] of unzipFiles(data)) if (/\.(xml|rels)$/.test(path)) parts.set(path, toJson(decodeUtf8(file)));
			else binaryParts.set(path, file);
			const importedDocuments = yield readImportedDocuments(parts, binaryParts);
			return _objectSpread2({
				parts,
				binaryParts
			}, importedDocuments.size > 0 ? { importedDocuments } : {});
		} catch (_unused) {
			return;
		}
	});
	return function readPackage(_x) {
		return _ref.apply(this, arguments);
	};
}();
/**
* Each .docx the parts of a package import (`w:altChunk`), by its path: the parts the relationships of each part refer to
* as imported, which are zip files that can be read. Those in other formats, such as HTML, are left to the layout.
*/
var readImportedDocuments = function() {
	var _ref2 = _asyncToGenerator(function* (parts, binaryParts) {
		const imported = /* @__PURE__ */ new Map();
		for (const [path, relationships] of parts) {
			var _rootOf$elements, _rootOf;
			if (!path.endsWith(".rels")) continue;
			for (const { attributes = {} } of (_rootOf$elements = (_rootOf = rootOf(relationships)) === null || _rootOf === void 0 ? void 0 : _rootOf.elements) !== null && _rootOf$elements !== void 0 ? _rootOf$elements : []) {
				const target = resolveTarget(sourceOfRelationships(path), String(attributes.Target));
				const data = binaryParts.get(target);
				const read = attributes.Type === IMPORT && attributes.TargetMode !== "External" && data ? yield readPackage(data) : void 0;
				if (read) imported.set(target, read);
			}
		}
		return imported;
	});
	return function readImportedDocuments(_x2, _x3) {
		return _ref2.apply(this, arguments);
	};
}();
/** The root element of a part, such as `w:document` */
var rootOf = (part) => {
	var _part$elements;
	return part === null || part === void 0 || (_part$elements = part.elements) === null || _part$elements === void 0 ? void 0 : _part$elements.find(({ type }) => type === "element");
};
/**
* Writes the page numbers the estimator works out for a patched template into the fields of its body, headers and
* footers that show them: its PAGEREF fields, in its tables of contents and elsewhere, and its NUMPAGES and SECTIONPAGES
* fields. The results a field was written with are those of the template before it was patched, so a field whose number
* the estimator doesn't work out is left blank, as it is in a document written with `pageNumbers`. Page references and
* tables of contents are written clean, as they are in a document written with `pageNumbers`, so Word shows their numbers
* as they are and doesn't ask to update the fields.
*
* The documents it imports (`w:altChunk`) as .docx files are unzipped for the estimator to read, as Word turns them into
* paragraphs and tables of the template's own when it opens it.
*
* @param parts - The template's XML parts, parsed, by their paths, which are changed in place
* @param binaryParts - Its other parts, by their paths, for the estimator to read the fonts it embeds and the documents
* it imports
*/
var fillTemplatePageNumbers = function() {
	var _ref3 = _asyncToGenerator(function* (parts, estimator, binaryParts = /* @__PURE__ */ new Map()) {
		var _rootOf$elements2, _rootOf2;
		const document = rootOf(parts.get(DOCUMENT));
		if (!document) return;
		const importedDocuments = yield readImportedDocuments(parts, binaryParts);
		const estimate = estimator(_objectSpread2({
			parts,
			binaryParts
		}, importedDocuments.size > 0 ? { importedDocuments } : {}));
		const partPageCounts = fillBodyFields(PARSED, document, estimate, { blank: true });
		const relationships = (_rootOf$elements2 = (_rootOf2 = rootOf(parts.get(relationshipsPathOf(DOCUMENT)))) === null || _rootOf2 === void 0 ? void 0 : _rootOf2.elements) !== null && _rootOf$elements2 !== void 0 ? _rootOf$elements2 : [];
		for (const { attributes = {} } of relationships) {
			const part = /\/(header|footer)$/.test(String(attributes.Type)) ? rootOf(parts.get(resolveTarget(DOCUMENT, String(attributes.Target)))) : void 0;
			if (part) fillPartFields(PARSED, part, estimate, {
				blank: true,
				sectionPageCount: partPageCounts.get(String(attributes.Id))
			});
		}
	});
	return function fillTemplatePageNumbers(_x4, _x5) {
		return _ref3.apply(this, arguments);
	};
}();
/**
* The elements in a paragraph that hold runs of its text, so a placeholder can be in a link, a content control, a
* tracked insertion, a smart tag or a field's result. A content control holds them in its w:sdtContent. Deleted text, in
* w:del or w:moveFrom, isn't the paragraph's text, and a run's own content, such as a text box, has paragraphs of its own.
*/
var RUN_CONTAINERS = /* @__PURE__ */ new Set([
	"w:hyperlink",
	"w:sdt",
	"w:sdtContent",
	"w:ins",
	"w:moveTo",
	"w:smartTag",
	"w:customXml",
	"w:fldSimple",
	"w:dir",
	"w:bdo"
]);
/**
* The runs in an element of a paragraph, in the order they are read, with the indices from the paragraph to each.
*/
var runsIn = (element, path) => {
	var _element$elements;
	return ((_element$elements = element.elements) !== null && _element$elements !== void 0 ? _element$elements : []).flatMap((child, i) => {
		var _child$name;
		if (child.name === "w:r") return [{
			element: child,
			path: [...path, i]
		}];
		return RUN_CONTAINERS.has((_child$name = child.name) !== null && _child$name !== void 0 ? _child$name : "") ? runsIn(child, [...path, i]) : [];
	});
};
/**
* The element at the end of a path of position indices from an element, such as a run from its paragraph.
*/
var elementAtPath = (element, path) => path.reduce((parent, index) => parent.elements[index], element);
/**
* Renders a paragraph element into a structured representation with text content.
*
* Extracts all text content from a paragraph (w:p) element by processing its
* runs (w:r), including those in a link, content control or tracked insertion.
* Calculates character positions for each text fragment to enable precise text
* replacement operations.
*
* @param node - The paragraph element wrapper to render
* @returns Rendered paragraph with text content, runs, and position information
* @throws Error if the node is not a paragraph element
*
* @example
* ```typescript
* const rendered = renderParagraphNode(paragraphWrapper);
* console.log(rendered.text); // "Hello World"
* console.log(rendered.runs.length); // 2 (if text is in separate runs)
* ```
*/
var renderParagraphNode = (node) => {
	if (node.element.name !== "w:p") throw new Error(`Invalid node type: ${node.element.name}`);
	if (!node.element.elements) return {
		text: "",
		runs: [],
		index: -1,
		pathToParagraph: []
	};
	let currentRunStringLength = 0;
	const runs = runsIn(node.element, []).map(({ element, path }) => {
		const renderedRunNode = renderRunNode(element, path, currentRunStringLength);
		currentRunStringLength += renderedRunNode.text.length;
		return renderedRunNode;
	});
	return {
		text: runs.reduce((acc, curr) => acc + curr.text, ""),
		runs,
		index: node.index,
		pathToParagraph: buildNodePath(node)
	};
};
var renderRunNode = (node, path, currentRunStringIndex) => {
	if (!node.elements) return {
		text: "",
		parts: [],
		path,
		start: currentRunStringIndex,
		end: currentRunStringIndex
	};
	let currentTextStringIndex = currentRunStringIndex;
	const parts = node.elements.map((element, i) => {
		var _element$elements$0$t, _element$elements$0$t2;
		if (element.name !== "w:t" || !element.elements || element.elements.length === 0) return;
		const partText = (_element$elements$0$t = (_element$elements$0$t2 = element.elements[0].text) === null || _element$elements$0$t2 === void 0 ? void 0 : _element$elements$0$t2.toString()) !== null && _element$elements$0$t !== void 0 ? _element$elements$0$t : "";
		const start = currentTextStringIndex;
		currentTextStringIndex += partText.length;
		return {
			text: partText,
			index: i,
			start,
			end: start + partText.length - 1
		};
	}).filter((e) => !!e).map((e) => e);
	return {
		text: parts.reduce((acc, curr) => acc + curr.text, ""),
		parts,
		path,
		start: currentRunStringIndex,
		end: parts.length > 0 ? parts[parts.length - 1].end : currentRunStringIndex
	};
};
var buildNodePath = (node) => node.parent ? [...buildNodePath(node.parent), node.index] : [node.index];
var TokenNotFoundError = class extends Error {
	constructor(token) {
		super(`Token ${token} not found`);
		this.name = "TokenNotFoundError";
	}
};
/**
* Finds the run element containing a specific token.
*
* Searches through all run (w:r) elements in a paragraph, including those in a link,
* content control or tracked insertion, to find which one contains the specified
* token text. This is used to locate where new content should be injected during
* replacement operations.
*
* @param paragraphElement - The paragraph element to search
* @param token - The token text to find
* @returns The position indices from the paragraph to the run element containing the token
* @throws Error if the token is not found in any run
*
* @example
* ```typescript
* const path = findRunElementPathWithToken(paragraph, "ɵ");
* // Returns [0] for the paragraph's first run, or [2, 1] for the second run in a link that is its third element
* ```
*/
var findRunElementPathWithToken = (paragraphElement, token) => {
	const run = renderParagraphNode({
		element: paragraphElement,
		index: 0,
		parent: void 0
	}).runs.find(({ parts }) => parts.some(({ text }) => text.includes(token)));
	if (!run) throw new TokenNotFoundError(token);
	return run.path;
};
/**
* Splits a run element at a token position into left and right parts.
*
* Divides a run element at the location of a token, creating two separate
* runs. This allows new content to be injected between the split parts while
* preserving the original run's formatting properties.
*
* @param runElement - The run element to split
* @param token - The token text marking the split point
* @returns Object containing the left and right run elements
*
* @example
* ```typescript
* const { left, right } = splitRunElement(run, "ɵ");
* // If run contains "Helloɵworld", left contains "Hello" and right contains "world"
* ```
*/
var splitRunElement = (runElement, token) => {
	var _runElement$elements$, _runElement$elements;
	let splitIndex = -1;
	const splitElements = (_runElement$elements$ = (_runElement$elements = runElement.elements) === null || _runElement$elements === void 0 ? void 0 : _runElement$elements.map((e, i) => {
		if (splitIndex !== -1) return e;
		if (e.type === "element" && e.name === "w:t") {
			var _e$elements$0$text, _e$elements;
			const splitText = ((_e$elements$0$text = (_e$elements = e.elements) === null || _e$elements === void 0 || (_e$elements = _e$elements[0]) === null || _e$elements === void 0 ? void 0 : _e$elements.text) !== null && _e$elements$0$text !== void 0 ? _e$elements$0$text : "").split(token);
			const newElements = splitText.map((t) => _objectSpread2(_objectSpread2(_objectSpread2({}, e), patchSpaceAttribute(e)), {}, { elements: createTextElementContents(t) }));
			if (splitText.length > 1) splitIndex = i;
			return newElements;
		} else return e;
	}).flat()) !== null && _runElement$elements$ !== void 0 ? _runElement$elements$ : [];
	return {
		left: _objectSpread2(_objectSpread2({}, JSON.parse(JSON.stringify(runElement))), {}, { elements: splitElements.slice(0, splitIndex + 1) }),
		right: _objectSpread2(_objectSpread2({}, JSON.parse(JSON.stringify(runElement))), {}, { elements: splitElements.slice(splitIndex + 1) })
	};
};
/**
* Replacement modes for multi-run text replacement.
*/
var ReplaceMode = {
	/** Looking for the start of the replacement text */
	START: 0,
	/** Processing runs in the middle of the replacement text */
	MIDDLE: 1,
	/** Reached the end of the replacement text */
	END: 2
};
/**
* Replaces a token with replacement text within a paragraph's run elements.
*
* Handles the complex case where placeholder text may span multiple runs
* (text fragments) within a paragraph. Processes each run to replace the
* appropriate portion of the token, handling start, middle, and end sections.
*
* @param paragraphElement - The paragraph XML element to modify
* @param renderedParagraph - Pre-rendered paragraph structure with text positions
* @param originalText - The token text to replace (e.g., "{{name}}")
* @param replacementText - The text to replace it with (often a split token)
* @param fromIndex - Where in the paragraph's text to start looking for the token (default: 0)
* @returns The modified paragraph element
*
* @example
* ```typescript
* replaceTokenInParagraphElement({
*   paragraphElement,
*   renderedParagraph,
*   originalText: "{{placeholder}}",
*   replacementText: "ɵ",
* });
* ```
*/
var replaceTokenInParagraphElement = ({ paragraphElement, renderedParagraph, originalText, replacementText, fromIndex = 0 }) => {
	const startIndex = renderedParagraph.text.indexOf(originalText, fromIndex);
	const endIndex = startIndex + originalText.length - 1;
	let replaceMode = ReplaceMode.START;
	for (const run of renderedParagraph.runs) {
		const runElement = elementAtPath(paragraphElement, run.path);
		for (const { text, index, start, end } of run.parts) switch (replaceMode) {
			case ReplaceMode.START:
				if (startIndex >= start && startIndex <= end) {
					const offsetStartIndex = startIndex - start;
					const offsetEndIndex = Math.min(endIndex, end) - start;
					if (text.substring(offsetStartIndex, offsetEndIndex + 1) === "") continue;
					const firstPart = text.substring(0, offsetStartIndex) + replacementText + text.substring(offsetEndIndex + 1);
					patchTextElement(runElement.elements[index], firstPart);
					replaceMode = ReplaceMode.MIDDLE;
					continue;
				}
				break;
			case ReplaceMode.MIDDLE: if (endIndex <= end) {
				const lastPart = text.substring(endIndex - start + 1);
				patchTextElement(runElement.elements[index], lastPart);
				const currentElement = runElement.elements[index];
				runElement.elements[index] = patchSpaceAttribute(currentElement);
				replaceMode = ReplaceMode.END;
			} else patchTextElement(runElement.elements[index], "");
		}
	}
	return paragraphElement;
};
var patchTextElement = (element, text) => {
	element.elements = createTextElementContents(text);
	return element;
};
var elementsToWrapper = (wrapper) => {
	var _wrapper$element$elem, _wrapper$element$elem2;
	return (_wrapper$element$elem = (_wrapper$element$elem2 = wrapper.element.elements) === null || _wrapper$element$elem2 === void 0 ? void 0 : _wrapper$element$elem2.map((e, i) => ({
		element: e,
		index: i,
		parent: wrapper
	}))) !== null && _wrapper$element$elem !== void 0 ? _wrapper$element$elem : [];
};
/**
* Traverses an XML document tree to find and render all paragraphs.
*
* Uses breadth-first search to walk through the XML structure, identifying
* all paragraph elements (w:p) and rendering their text content along with
* positional information. The replacer relies on this order: shallower
* paragraphs come first, and at the same depth, earlier ones come first.
*
* @param node - The root XML element to traverse
* @returns Array of rendered paragraph nodes with text content and positions
*
* @example
* ```typescript
* const paragraphs = traverse(documentElement);
* paragraphs.forEach(p => console.log(p.text));
* ```
*/
var traverse = (node) => {
	const renderedParagraphs = [];
	const queue = [...elementsToWrapper({
		element: node,
		index: 0,
		parent: void 0
	})];
	for (const currentNode of queue) {
		if (currentNode.element.name === "w:p") renderedParagraphs.push(renderParagraphNode(currentNode));
		for (const child of elementsToWrapper(currentNode)) queue.push(child);
	}
	return renderedParagraphs;
};
/**
* Finds all paragraphs containing specific text.
*
* Traverses the document and filters paragraphs to find those containing
* the specified text string. Useful for locating placeholder text that
* needs to be replaced.
*
* @param node - The root XML element to search
* @param text - The text to search for
* @returns Array of paragraph nodes containing the text
*
* @example
* ```typescript
* const matches = findLocationOfText(documentElement, "{{name}}");
* // Returns all paragraphs containing "{{name}}"
* ```
*/
var findLocationOfText = (node, text) => traverse(node).filter((p) => p.text.includes(text));
var SPLIT_TOKEN = "￿";
/**
* Replaces placeholder text in XML with new content from a patch.
*
* This function locates placeholder text within the XML structure and performs
* the appropriate replacement based on the patch type (document or paragraph level).
* It handles splitting runs, preserving styles, and injecting the new content.
* Content the patch inserts is never searched, so it can contain its own placeholder.
*
* @param json - The XML element structure to search
* @param patch - The patch definition containing replacement content
* @param patchText - The placeholder text to find (e.g., "{{name}}")
* @param context - The document context for formatting
* @param keepOriginalStyles - Whether to preserve original text formatting
* @param recursive - Whether to replace every occurrence in a paragraph, rather than only the first
* @param renumberIds - Renumbers the bookmarks and note references the patch inserts, so they don't take an id the
* document uses, and records the styles it uses
* @returns Result containing the modified element and whether a replacement occurred
*/
var replacer = ({ json, patch, patchText, context, keepOriginalStyles = true, recursive = true, renumberIds = (elements) => elements }) => {
	const renderedParagraphs = findLocationOfText(json, patchText);
	if (renderedParagraphs.length === 0) return {
		element: json,
		didFindOccurrence: false
	};
	const paragraphsInPatchOrder = [...renderedParagraphs].reverse();
	const paragraphsToPatch = patch.type === PatchType.DOCUMENT ? withoutNestedParagraphs(paragraphsInPatchOrder) : paragraphsInPatchOrder;
	let highestId;
	const newTrackedChangeId = () => {
		var _highestId;
		highestId = ((_highestId = highestId) !== null && _highestId !== void 0 ? _highestId : highestIdIn(json)) + 1;
		return String(highestId);
	};
	for (const renderedParagraph of paragraphsToPatch) switch (patch.type) {
		case PatchType.DOCUMENT: {
			var _children;
			const parentElement = goToParentElementFromPath(json, renderedParagraph.pathToParagraph);
			const elementIndex = getLastElementIndexFromPath(renderedParagraph.pathToParagraph);
			const children = formatChildren(patch, context, renumberIds);
			const endParagraph = parentElement.name === "w:tc" && elementIndex === parentElement.elements.length - 1 && ((_children = children[children.length - 1]) === null || _children === void 0 ? void 0 : _children.name) !== "w:p" ? [{
				type: "element",
				name: "w:p"
			}] : [];
			parentElement.elements.splice(elementIndex, 1, ...children, ...endParagraph);
			break;
		}
		case PatchType.PARAGRAPH:
		default: {
			const paragraphElement = goToElementFromPath(json, renderedParagraph.pathToParagraph);
			let paragraph = renderedParagraph;
			let fromIndex = 0;
			do {
				fromIndex = replaceOccurrenceInParagraph({
					paragraphElement,
					renderedParagraph: paragraph,
					patchText,
					fromIndex,
					children: formatChildren(patch, context, renumberIds),
					keepOriginalStyles,
					newTrackedChangeId
				});
				paragraph = renderParagraphNode({
					element: paragraphElement,
					index: renderedParagraph.index,
					parent: void 0
				});
			} while (recursive && paragraph.text.includes(patchText, fromIndex));
			break;
		}
	}
	return {
		element: json,
		didFindOccurrence: true
	};
};
var formatChildren = (patch, context, renumberIds) => renumberIds(patch.children.flatMap((c) => {
	var _c$writtenAs;
	return (_c$writtenAs = c.writtenAs) !== null && _c$writtenAs !== void 0 ? _c$writtenAs : c;
}).flatMap((c) => {
	const formatted = c.prepForXml(context);
	return formatted ? [toJson(stringifyXmlable(formatted)).elements[0]] : [];
}));
/**
* Replaces the first occurrence of the placeholder from `fromIndex` on, splitting the run it starts in. The content goes
* where that run is, in the paragraph or in what holds the run in it, such as a link or a content control, unless that
* can't hold it.
*
* @returns Where the text after the inserted content starts in the paragraph's text
*/
var replaceOccurrenceInParagraph = ({ paragraphElement, renderedParagraph, patchText, fromIndex, children, keepOriginalStyles, newTrackedChangeId }) => {
	const start = renderedParagraph.text.indexOf(patchText, fromIndex);
	replaceTokenInParagraphElement({
		paragraphElement,
		renderedParagraph,
		originalText: patchText,
		replacementText: SPLIT_TOKEN,
		fromIndex
	});
	const runPath = findRunElementPathWithToken(paragraphElement, SPLIT_TOKEN);
	const containerPath = runPath.slice(0, -1);
	const container = elementAtPath(paragraphElement, containerPath);
	const index = runPath[runPath.length - 1];
	const contentControls = containerPath.map((_, depth) => elementAtPath(paragraphElement, containerPath.slice(0, depth + 1))).filter((e) => e.name === "w:sdt");
	const controlShowingPlaceholder = [...contentControls].reverse().find(isShowingPlaceholder);
	const runElementToBeReplaced = container.elements[index];
	const { left, right } = splitRunElement(runElementToBeReplaced, SPLIT_TOKEN);
	const runProperties = runElementToBeReplaced.elements.find((e) => e.type === "element" && e.name === "w:rPr");
	const contentRunProperties = controlShowingPlaceholder ? runPropertiesOfContentControl(controlShowingPlaceholder) : runProperties;
	const newRunElements = keepOriginalStyles && contentRunProperties ? children.map((e) => withRunPropertiesOnRuns(e, contentRunProperties)) : children;
	const patchedRightElement = runProperties ? _objectSpread2(_objectSpread2({}, right), {}, { elements: [runProperties, ...right.elements] }) : right;
	container.elements.splice(index, 1, left, ...newRunElements, patchedRightElement);
	contentControls.forEach((contentControl) => fillContentControl(contentControl, newRunElements));
	liftOutOfContainers(paragraphElement, containerPath, newTrackedChangeId);
	return start + renderParagraphNode({
		element: {
			name: "w:p",
			elements: [...newRunElements]
		},
		index: 0,
		parent: void 0
	}).text.length;
};
var propertiesOfContentControl = (contentControl) => {
	var _contentControl$eleme;
	return (_contentControl$eleme = contentControl.elements) === null || _contentControl$eleme === void 0 ? void 0 : _contentControl$eleme.find((e) => e.name === "w:sdtPr");
};
var isShowingPlaceholder = (contentControl) => {
	var _propertiesOfContentC;
	return !!((_propertiesOfContentC = propertiesOfContentControl(contentControl)) === null || _propertiesOfContentC === void 0 || (_propertiesOfContentC = _propertiesOfContentC.elements) === null || _propertiesOfContentC === void 0 ? void 0 : _propertiesOfContentC.some((e) => e.name === "w:showingPlcHdr"));
};
var runPropertiesOfContentControl = (contentControl) => {
	var _propertiesOfContentC2;
	return (_propertiesOfContentC2 = propertiesOfContentControl(contentControl)) === null || _propertiesOfContentC2 === void 0 || (_propertiesOfContentC2 = _propertiesOfContentC2.elements) === null || _propertiesOfContentC2 === void 0 ? void 0 : _propertiesOfContentC2.find((e) => e.name === "w:rPr");
};
var PLAIN_TEXT_RUN_CONTENT = /* @__PURE__ */ new Set([
	"w:rPr",
	"w:t",
	"w:tab",
	"w:br"
]);
var isPlainText = (element) => element.name === "w:bookmarkStart" || element.name === "w:bookmarkEnd" || element.name === "w:r" && childElementsOf(element).every((e) => PLAIN_TEXT_RUN_CONTENT.has(e.name));
/**
* Makes a content control show the content a patch put in it as its own. It no longer shows its placeholder text, as
* when text is typed in it, and a plain text control given more than text, such as a link or a picture, becomes a rich
* text control, as Word won't open a plain text one with it. A control bound to custom XML or a document property is
* no longer bound, as Word fills a bound control in from its data when it opens the document, which would put the
* placeholder back.
*/
var fillContentControl = (contentControl, insertedElements) => {
	const properties = propertiesOfContentControl(contentControl);
	if (!(properties === null || properties === void 0 ? void 0 : properties.elements)) return;
	const needsRichText = properties.elements.some((e) => e.name === "w:text") && !insertedElements.every(isPlainText);
	properties.elements = properties.elements.filter((e) => e.name !== "w:showingPlcHdr" && e.name !== "w:dataBinding" && !(needsRichText && e.name === "w:text"));
};
var NOT_IN_TRACKED_CHANGES = /* @__PURE__ */ new Set([
	"w:hyperlink",
	"w:fldSimple",
	"w:subDoc"
]);
/**
* The elements each container of runs can't hold. Word reads a link in a link as two links over the same text, so a
* patch's link in place of a placeholder in a link takes the place of that link there.
*/
var NOT_IN_CONTAINER = /* @__PURE__ */ new Map([
	["w:ins", NOT_IN_TRACKED_CHANGES],
	["w:moveTo", NOT_IN_TRACKED_CHANGES],
	["w:hyperlink", /* @__PURE__ */ new Set(["w:hyperlink"])]
]);
/**
* Splits each container of runs, from the placeholder's run up to the paragraph, around the content in it that it can't
* hold, such as a link a patch put in place of a placeholder typed with Track Changes on. That content then isn't
* tracked, as when Word inserts a link with Track Changes off, and the text before and after it still is. Each tracked
* change must have an id of its own, so the pieces after the first are given new ones.
*/
var liftOutOfContainers = (paragraphElement, containerPath, newTrackedChangeId) => {
	for (let depth = containerPath.length; depth > 0; depth--) {
		var _container$elements;
		const parent = elementAtPath(paragraphElement, containerPath.slice(0, depth - 1));
		const index = containerPath[depth - 1];
		const container = parent.elements[index];
		const cantHold = NOT_IN_CONTAINER.get(container.name);
		const isLifted = (element) => !!(cantHold === null || cantHold === void 0 ? void 0 : cantHold.has(element.name));
		if (!((_container$elements = container.elements) === null || _container$elements === void 0 ? void 0 : _container$elements.some(isLifted))) continue;
		const { elements } = container;
		const starts = elements.flatMap((element, i) => i === 0 || isLifted(element) || isLifted(elements[i - 1]) ? [i] : []);
		const stretches = starts.map((start, i) => elements.slice(start, starts[i + 1]));
		const isTrackedChange = cantHold === NOT_IN_TRACKED_CHANGES;
		let isFirstCopy = true;
		const pieces = stretches.map((stretch) => {
			if (isLifted(stretch[0])) return stretch[0];
			const attributes = isTrackedChange && !isFirstCopy ? _objectSpread2(_objectSpread2({}, container.attributes), {}, { "w:id": newTrackedChangeId() }) : container.attributes;
			isFirstCopy = false;
			return _objectSpread2(_objectSpread2({}, container), {}, {
				attributes,
				elements: [...stretch]
			});
		});
		parent.elements.splice(index, 1, ...pieces);
	}
};
/**
* Gives the runs of inserted content the placeholder's run properties. Content such as a hyperlink can't take run
* properties itself, so its runs take them, and its text is formatted as the text around it is. Runs inside a run, such
* as in its text box, are that content's own, and are left alone.
*/
var withRunPropertiesOnRuns = (element, originalRunProperties) => {
	if (element.name === "w:r") return withRunProperties(element, originalRunProperties);
	return element.elements ? _objectSpread2(_objectSpread2({}, element), {}, { elements: element.elements.map((e) => withRunPropertiesOnRuns(e, originalRunProperties)) }) : element;
};
/**
* Gives a run the placeholder's run properties. A run can only have one w:rPr, so properties the run
* sets itself are kept, and the placeholder's fill in the rest.
*/
var withRunProperties = (runElement, originalRunProperties) => {
	const ownRunProperties = childElementsOf(runElement).find((e) => e.type === "element" && e.name === "w:rPr");
	if (!ownRunProperties) return _objectSpread2(_objectSpread2({}, runElement), {}, { elements: [originalRunProperties, ...childElementsOf(runElement)] });
	const ownPropertyNames = new Set(childElementsOf(ownRunProperties).map((e) => e.name));
	const properties = [...childElementsOf(originalRunProperties).filter((e) => !ownPropertyNames.has(e.name)), ...childElementsOf(ownRunProperties)];
	const mergedRunProperties = _objectSpread2(_objectSpread2({}, ownRunProperties), {}, { elements: [...properties].sort((a, b) => runPropertyRank(a) - runPropertyRank(b)) });
	return _objectSpread2(_objectSpread2({}, runElement), {}, { elements: childElementsOf(runElement).map((e) => e === ownRunProperties ? mergedRunProperties : e) });
};
/**
* The order Office's schema puts a run's properties in: CT_RPr's elements, then Word 2010's text effects and
* OpenType features. ISO 29500 allows any order, but Office and the Open XML SDK validator don't.
*/
var RUN_PROPERTY_ORDER = [
	"w:rStyle",
	"w:rFonts",
	"w:b",
	"w:bCs",
	"w:i",
	"w:iCs",
	"w:caps",
	"w:smallCaps",
	"w:strike",
	"w:dstrike",
	"w:outline",
	"w:shadow",
	"w:emboss",
	"w:imprint",
	"w:noProof",
	"w:snapToGrid",
	"w:vanish",
	"w:webHidden",
	"w:color",
	"w:spacing",
	"w:w",
	"w:kern",
	"w:position",
	"w:sz",
	"w:szCs",
	"w:highlight",
	"w:u",
	"w:effect",
	"w:bdr",
	"w:shd",
	"w:fitText",
	"w:vertAlign",
	"w:rtl",
	"w:cs",
	"w:em",
	"w:lang",
	"w:eastAsianLayout",
	"w:specVanish",
	"w:oMath",
	"w14:glow",
	"w14:shadow",
	"w14:reflection",
	"w14:textOutline",
	"w14:textFill",
	"w14:scene3d",
	"w14:props3d",
	"w14:ligatures",
	"w14:numForm",
	"w14:numSpacing",
	"w14:stylisticSets",
	"w14:cntxtAlts"
];
var runPropertyRank = (element) => {
	var _element$name;
	if (element.name === "w:rPrChange") return RUN_PROPERTY_ORDER.length + 1;
	const index = RUN_PROPERTY_ORDER.indexOf((_element$name = element.name) !== null && _element$name !== void 0 ? _element$name : "");
	return index === -1 ? RUN_PROPERTY_ORDER.length : index;
};
var childElementsOf = (element) => {
	var _element$elements;
	return (_element$elements = element.elements) !== null && _element$elements !== void 0 ? _element$elements : [];
};
/**
* The highest whole number id (w:id) of an element or anything in it.
*/
var highestIdIn = (element) => {
	var _element$attributes, _element$elements2;
	const id = Number((_element$attributes = element.attributes) === null || _element$attributes === void 0 ? void 0 : _element$attributes["w:id"]);
	return ((_element$elements2 = element.elements) !== null && _element$elements2 !== void 0 ? _element$elements2 : []).reduce((highest, child) => Math.max(highest, highestIdIn(child)), Number.isInteger(id) ? id : 0);
};
var isInsideElementAtPath = (path, ancestorPath) => path.length > ancestorPath.length && ancestorPath.every((index, i) => path[i] === index);
var withoutNestedParagraphs = (paragraphs) => paragraphs.filter((paragraph) => !paragraphs.some((other) => isInsideElementAtPath(paragraph.pathToParagraph, other.pathToParagraph)));
var goToElementFromPath = (json, path) => {
	let element = json;
	for (let i = 1; i < path.length; i++) {
		const index = path[i];
		element = element.elements[index];
	}
	return element;
};
var goToParentElementFromPath = (json, path) => goToElementFromPath(json, path.slice(0, path.length - 1));
var getLastElementIndexFromPath = (path) => path[path.length - 1];
/**
* Styles of content inserted into an existing document.
*
* @module
*/
var formatter = new Formatter();
var STYLES_PATH = "word/styles.xml";
var REFERENCES = /* @__PURE__ */ new Set([
	"w:pStyle",
	"w:rStyle",
	"w:tblStyle",
	"w:basedOn",
	"w:next",
	"w:link"
]);
var idOf = (style) => {
	var _style$attributes;
	return String((_style$attributes = style.attributes) === null || _style$attributes === void 0 ? void 0 : _style$attributes["w:styleId"]);
};
var nameOf = (style) => {
	var _style$elements;
	const name = (_style$elements = style.elements) === null || _style$elements === void 0 || (_style$elements = _style$elements.find((element) => element.name === "w:name")) === null || _style$elements === void 0 || (_style$elements = _style$elements.attributes) === null || _style$elements === void 0 ? void 0 : _style$elements["w:val"];
	return name === void 0 ? void 0 : String(name).toLowerCase();
};
var childOf$1 = (element, name) => {
	var _element$elements;
	return element === null || element === void 0 || (_element$elements = element.elements) === null || _element$elements === void 0 ? void 0 : _element$elements.find((child) => child.name === name);
};
/** The size of the font that run properties give, in half points, as Word writes it */
var sizeIn = (runProperties) => {
	var _childOf;
	const size = Number((_childOf = childOf$1(runProperties, "w:sz")) === null || _childOf === void 0 || (_childOf = _childOf.attributes) === null || _childOf === void 0 ? void 0 : _childOf["w:val"]);
	return Number.isNaN(size) ? void 0 : size;
};
/**
* The size of the font of a template's Normal style, in half points: its own, or else the document's default. Word
* indents each level of a table of contents by it, so docx's TOC styles are indented by it too. Normal is the style that
* the styles added are based on: the template's with its id, or else with its name.
*/
var normalSizeOf = (elements) => {
	var _styles$find, _sizeIn;
	const styles = elements.filter((element) => element.name === "w:style");
	const normal = (_styles$find = styles.find((style) => idOf(style) === "Normal")) !== null && _styles$find !== void 0 ? _styles$find : styles.find((style) => {
		var _style$attributes2;
		return ((_style$attributes2 = style.attributes) === null || _style$attributes2 === void 0 ? void 0 : _style$attributes2["w:type"]) === "paragraph" && nameOf(style) === "normal";
	});
	const defaults = elements.find((element) => element.name === "w:docDefaults");
	return (_sizeIn = sizeIn(childOf$1(normal, "w:rPr"))) !== null && _sizeIn !== void 0 ? _sizeIn : sizeIn(childOf$1(childOf$1(defaults, "w:rPrDefault"), "w:rPr"));
};
var formatDefaultStyles = (context, normalSize) => new Map(Object.values(createDefaultStyles({ document: { run: { size: normalSize } } })).map((style) => toJson(stringifyXmlable(formatter.format(style, context))).elements[0]).filter((style) => style.name === "w:style").map((style) => [idOf(style), style]));
/**
* Creates the writer of the styles that patches use.
*
* A paragraph in a patch refers to its style by its id, such as `Heading1` for `HeadingLevel.HEADING_1`, which a
* template may not have, as Word only saves the styles that a document uses. Word shows a paragraph whose style the
* document doesn't have in the Normal style, and LibreOffice leaves out its number if it is in a list, so the styles of
* docx's that the content uses are added to the document.
*
* @param parts - The document's XML parts, parsed, by their paths, whose styles part the styles are added to
* @param createContext - Creates a context to format content for a part with
*/
var patchStyles = (parts, createContext) => {
	var _parts$get;
	const templateElements = getFirstLevelElements((_parts$get = parts.get(STYLES_PATH)) !== null && _parts$get !== void 0 ? _parts$get : {}, "w:styles");
	const templateStyles = templateElements.filter((element) => element.name === "w:style");
	const templateIds = new Set(templateStyles.map(idOf));
	let defaultStyles;
	const defaultStyleOf = (id) => {
		var _defaultStyles;
		(_defaultStyles = defaultStyles) !== null && _defaultStyles !== void 0 || (defaultStyles = formatDefaultStyles(createContext(STYLES_PATH), normalSizeOf(templateElements)));
		return defaultStyles.get(id);
	};
	const missingIds = /* @__PURE__ */ new Set();
	const idsInDocument = /* @__PURE__ */ new Map();
	const findIdInDocument = (id) => {
		const style = templateIds.has(id) ? void 0 : defaultStyleOf(id);
		if (style === void 0) return id;
		const sameStyle = templateStyles.find((templateStyle) => {
			var _templateStyle$attrib, _style$attributes3;
			return ((_templateStyle$attrib = templateStyle.attributes) === null || _templateStyle$attrib === void 0 ? void 0 : _templateStyle$attrib["w:type"]) === ((_style$attributes3 = style.attributes) === null || _style$attributes3 === void 0 ? void 0 : _style$attributes3["w:type"]) && nameOf(templateStyle) === nameOf(style);
		});
		if (sameStyle !== void 0) return idOf(sameStyle);
		missingIds.add(id);
		return id;
	};
	const idInDocument = (id) => {
		if (!idsInDocument.has(id)) idsInDocument.set(id, findIdInDocument(id));
		return idsInDocument.get(id);
	};
	const withIdsInDocument = (element) => {
		var _element$name;
		if (REFERENCES.has((_element$name = element.name) !== null && _element$name !== void 0 ? _element$name : "")) return _objectSpread2(_objectSpread2({}, element), {}, { attributes: _objectSpread2(_objectSpread2({}, element.attributes), {}, { "w:val": idInDocument(String(element.attributes["w:val"])) }) });
		return element.elements === void 0 ? element : _objectSpread2(_objectSpread2({}, element), {}, { elements: element.elements.map(withIdsInDocument) });
	};
	const write = () => {
		const stylesPart = parts.get(STYLES_PATH);
		if (!stylesPart) return;
		const styles = getFirstLevelElements(stylesPart, "w:styles");
		const ids = new Set(styles.map(idOf));
		for (const id of missingIds) if (!ids.has(id)) {
			ids.add(id);
			styles.push(withIdsInDocument(defaultStyleOf(id)));
		}
	};
	return {
		use: (elements) => elements.map(withIdsInDocument),
		write
	};
};
var EMPTY = {
	type: PatchType.PARAGRAPH,
	children: []
};
/**
* Repeats the rows of the tables in an element that hold the patch's fields, such as `{{items.name}}` for the key
* "items", once for each of the patch's rows, and patches the fields in each copy with the row's patches.
*
* @param json - The element to patch, such as a part's root
* @param key - The patch's key, such as "items"
* @param patch - The rows of data
* @param delimiters - The placeholders' delimiters
* @param patchPlaceholder - Patches a field in a copy of the rows, as `patchDocument` patches a placeholder
* @param renumberDrawings - Gives the drawings in a copy of the rows ids no other drawing in the document has
*/
var patchTableRows = ({ json, key, patch, delimiters: { start, end }, patchPlaceholder, renumberDrawings }) => {
	const fieldStart = `${start}${key}.`;
	for (const rows of findRowsToRepeat(json, fieldStart)) {
		const fields = fieldsIn(rows.elements, fieldStart, end);
		const copies = patch.rows.flatMap((row, index) => {
			const copy = {
				type: "element",
				name: "w:tbl",
				elements: [...index === 0 ? rows.elements.map(copyOf) : renumberDrawings(withoutIds(rows.elements))]
			};
			const fieldPatches = new Map(Object.entries(row).flatMap(([field, p]) => p === void 0 ? [] : [[field, p]]));
			for (const [field, fieldPatch] of fieldPatches) patchPlaceholder(copy, `${key}.${field}`, fieldPatch);
			for (const field of fields.filter((f) => !fieldPatches.has(f))) patchPlaceholder(copy, `${key}.${field}`, EMPTY);
			return copy.elements;
		});
		rows.parent.elements.splice(rows.parent.elements.indexOf(rows.elements[0]), rows.elements.length, ...copies);
		if (rows.table && !hasRows(rows.table.element)) rows.table.parent.elements.splice(rows.table.parent.elements.indexOf(rows.table.element), 1);
	}
};
/**
* The rows that hold a field, grouped into the rows next to each other in a table, which are repeated together.
*/
var findRowsToRepeat = (json, fieldStart) => {
	const found = findLocationOfText(json, fieldStart).flatMap((paragraph) => {
		const row = rowHolding(json, paragraph.pathToParagraph);
		return row ? [row] : [];
	});
	const rows = found.filter((row) => !found.some((other) => isInside(row.path, other.path))).filter((row, index, all) => all.findIndex((other) => other.row === row.row) === index);
	return [...new Set(rows.map((row) => row.parent))].flatMap((parent) => {
		const siblingRows = parent.elements.filter((e) => e.name === "w:tr");
		const positions = rows.filter((row) => row.parent === parent).map((row) => siblingRows.indexOf(row.row)).sort((a, b) => a - b);
		const { table } = rows.find((row) => row.parent === parent);
		return positions.reduce((all, position) => {
			const previous = all[all.length - 1];
			return (previous === null || previous === void 0 ? void 0 : previous[previous.length - 1]) === position - 1 ? [...all.slice(0, -1), [...previous, position]] : [...all, [position]];
		}, []).map((group) => {
			const first = parent.elements.indexOf(siblingRows[group[0]]);
			const last = parent.elements.indexOf(siblingRows[group[group.length - 1]]);
			return {
				parent,
				table,
				elements: parent.elements.slice(first, last + 1)
			};
		});
	});
};
/**
* The row nearest to the paragraph at the end of the path that holds it, if it is in a table.
*/
var rowHolding = (json, pathToParagraph) => {
	let element = json;
	let row;
	let table;
	for (let i = 1; i < pathToParagraph.length; i++) {
		const child = element.elements[pathToParagraph[i]];
		if (child.name === "w:tbl") table = {
			element: child,
			parent: element
		};
		if (child.name === "w:tr") row = {
			parent: element,
			table,
			row: child,
			path: pathToParagraph.slice(0, i + 1)
		};
		element = child;
	}
	return row;
};
var isInside = (path, ancestorPath) => path.length > ancestorPath.length && ancestorPath.every((index, i) => path[i] === index);
var hasRows = (table) => {
	var _table$elements;
	return ((_table$elements = table.elements) !== null && _table$elements !== void 0 ? _table$elements : []).some((e) => e.name === "w:tr" || e.name !== "w:tblPr" && e.name !== "w:tblGrid" && hasRows(e));
};
/**
* The names of the fields in the elements, such as "name" for `{{items.name}}`.
*/
var fieldsIn = (elements, fieldStart, end) => {
	const fields = findLocationOfText({ elements: [...elements] }, fieldStart).flatMap(({ text }) => text.split(fieldStart).slice(1).flatMap((after) => {
		const fieldEnd = after.indexOf(end);
		return fieldEnd > 0 ? [after.slice(0, fieldEnd)] : [];
	}));
	return [...new Set(fields)];
};
var copyOf = (element) => JSON.parse(JSON.stringify(element));
var ATTRIBUTES_TO_REMOVE = ["w14:paraId", "w14:textId"];
var ELEMENTS_TO_REMOVE = ["w:bookmarkStart", "w:bookmarkEnd"];
/**
* A copy of elements without what must be unique in a document, so they can be in the document more than once.
*
* @param parent - The elements' parent, as a content control's id is an element in its properties
*/
var withoutIds = (elements, parent) => elements.filter((e) => {
	var _e$name;
	return !ELEMENTS_TO_REMOVE.includes((_e$name = e.name) !== null && _e$name !== void 0 ? _e$name : "") && !((parent === null || parent === void 0 ? void 0 : parent.name) === "w:sdtPr" && e.name === "w:id");
}).map((e) => _objectSpread2(_objectSpread2(_objectSpread2({}, e), e.attributes === void 0 ? {} : { attributes: Object.fromEntries(Object.entries(e.attributes).filter(([name]) => !ATTRIBUTES_TO_REMOVE.includes(name))) }), e.elements === void 0 ? {} : { elements: [...withoutIds(e.elements, e)] }));
/**
* Reads the colors of a document's theme, so that theme colors in patches are written with the hex color they come to
* in the document's own theme.
*
* @module
*/
var isUtf16 = (bytes) => bytes[0] === 255 && bytes[1] === 254 || bytes[0] === 254 && bytes[1] === 255;
/**
* Reads the colors of the document's theme. Colors it doesn't give, or gives in a way that isn't read, are Office's.
*
* @returns The theme's colors, or `undefined` if the document has no theme that can be read
*/
var readThemeColors = (files) => {
	var _find;
	const path = themePathOf(files, "word/document.xml");
	const theme = path === void 0 ? void 0 : (_find = [...files].find(([name]) => isSamePart(name, path))) === null || _find === void 0 ? void 0 : _find[1];
	return theme === void 0 || isUtf16(theme) ? void 0 : themeColorValues(readThemeColorValues(decodeUtf8(theme)));
};
/**
* The first placeholder in a text, from an index on, with spaces inside its delimiters, whose key, without them, is
* one to patch.
*/
var findSpacedPlaceholder = (text, from, { start, end }, isKey) => {
	for (let index = text.indexOf(start, from); index !== -1; index = text.indexOf(start, index + 1)) {
		const endIndex = text.indexOf(end, index + start.length);
		if (endIndex === -1) return;
		const content = text.slice(index + start.length, endIndex);
		const key = content.trim();
		if (key !== content && isKey(key)) return {
			index,
			placeholder: text.slice(index, endIndex + end.length),
			trimmed: `${start}${key}${end}`
		};
	}
};
var trimInText = (text, delimiters, isKey) => {
	let trimmed = text;
	for (let found = findSpacedPlaceholder(trimmed, 0, delimiters, isKey); found !== void 0; found = findSpacedPlaceholder(trimmed, found.index + found.trimmed.length, delimiters, isKey)) trimmed = `${trimmed.slice(0, found.index)}${found.trimmed}${trimmed.slice(found.index + found.placeholder.length)}`;
	return trimmed;
};
var paragraphsIn = (element) => {
	var _element$elements;
	return ((_element$elements = element.elements) !== null && _element$elements !== void 0 ? _element$elements : []).flatMap((child) => [...child.name === "w:p" ? [child] : [], ...paragraphsIn(child)]);
};
/**
* Takes the spaces out of each placeholder in a paragraph whose key is one to patch, even if it is split across runs.
* The placeholder is left in its first run, as a patch would put its content there.
*/
var trimInParagraph = (paragraph, delimiters, isKey) => {
	const render = () => renderParagraphNode({
		element: paragraph,
		index: 0,
		parent: void 0
	});
	for (let rendered = render(), found = findSpacedPlaceholder(rendered.text, 0, delimiters, isKey); found !== void 0; rendered = render(), found = findSpacedPlaceholder(rendered.text, found.index + found.trimmed.length, delimiters, isKey)) replaceTokenInParagraphElement({
		paragraphElement: paragraph,
		renderedParagraph: rendered,
		originalText: found.placeholder,
		replacementText: found.trimmed,
		fromIndex: found.index
	});
};
/**
* Takes the spaces inside the delimiters out of the placeholders in a part that patches are for, such as `{{ name }}`
* for the patch `name`, so the patches find them. Other text is left as it is, even if it looks like a placeholder.
*
* @param json - The part, which is changed in place
* @param delimiters - The placeholders' delimiters
* @param textKeys - The keys of the patches for placeholders in the text
* @param tableRowsKeys - The keys of the patches that repeat the rows of a table, whose fields are `{{key.field}}`
* @param drawingKeys - The keys of the patches for drawings whose alt text holds the placeholder
*/
var trimPlaceholders = (json, { delimiters, textKeys, tableRowsKeys, drawingKeys }) => {
	const isTextKey = (key) => textKeys.has(key) || tableRowsKeys.some((tableRowsKey) => key.startsWith(`${tableRowsKey}.`));
	for (const paragraph of paragraphsIn(json)) trimInParagraph(paragraph, delimiters, isTextKey);
	const isDrawingKey = (key) => drawingKeys.has(key);
	for (const { properties } of findDrawings(json)) for (const name of ["descr", "title"]) {
		var _properties$attribute;
		const text = (_properties$attribute = properties.attributes) === null || _properties$attribute === void 0 ? void 0 : _properties$attribute[name];
		if (text !== void 0) properties.attributes[name] = trimInText(String(text), delimiters, isDrawingKey);
	}
};
var shapeTypeIdOf = (element) => {
	var _element$attributes;
	return element.name === "v:shapetype" && ((_element$attributes = element.attributes) === null || _element$attributes === void 0 ? void 0 : _element$attributes.id) !== void 0 ? String(element.attributes.id) : void 0;
};
/**
* Finds the id of every VML shape type (`v:shapetype`) in an element, at any depth.
*
* @param element - The element to search, such as a part's root
* @returns The ids, once for each shape type
*/
var findShapeTypeIds = (element) => {
	var _element$elements;
	const id = shapeTypeIdOf(element);
	return [...id === void 0 ? [] : [id], ...((_element$elements = element.elements) !== null && _element$elements !== void 0 ? _element$elements : []).flatMap(findShapeTypeIds)];
};
/**
* Creates a function that leaves out of the content inserted into a part each VML shape type (`v:shapetype`) the part
* has already, such as the picture frame (`_x0000_t75`) an embedded file or a picture watermark is drawn in. Content is
* written with the shape types its shapes use, without knowing which the template has, but a part can't have two
* elements with the same id. The shapes inserted use the part's own, which Word and LibreOffice find anywhere in the
* part, as Word writes each shape type once in a part, in its first shape.
*
* A shape type with the id of one the part has is the same shape type: docx writes Office's preset ones, whose ids, such
* as `_x0000_t75` for preset 75, name the preset.
*
* @param part - The root of the part the content is inserted into
* @returns A function that returns the elements without the shape types the part has, including those inserted before
*/
var removeShapeTypesIn = (part) => {
	const idsInPart = new Set(findShapeTypeIds(part));
	const remove = (element) => {
		const id = shapeTypeIdOf(element);
		if (id !== void 0) {
			if (idsInPart.has(id)) return [];
			idsInPart.add(id);
			return [element];
		}
		return [element.elements === void 0 ? element : _objectSpread2(_objectSpread2({}, element), {}, { elements: element.elements.flatMap(remove) })];
	};
	return (elements) => elements.flatMap(remove);
};
/**
* Throws if a patch, or a patch for a field of one of its rows, isn't one `patchDocument` can apply, such as a patch
* from JavaScript without its children.
*
* @param key - The patch's key, such as "items", or for a field of a row, such as "items.name"
* @param inTableRow - Whether the patch is for a field of a row, where a drawing patch can't be
*/
var assertValidPatch = (key, patch, { inTableRow }) => {
	if ((patch === null || patch === void 0 ? void 0 : patch.type) === PatchType.TABLE_ROWS && Array.isArray(patch.rows)) {
		for (const row of patch.rows) {
			if (typeof row !== "object" || row === null) throw new Error(`Invalid patch "${key}". Expected each of its rows to be an object of patches, by the name of their field`);
			for (const [field, fieldPatch] of Object.entries(row)) if (fieldPatch !== void 0) assertValidPatch(`${key}.${field}`, fieldPatch, { inTableRow: true });
		}
		return;
	}
	if (!((patch === null || patch === void 0 ? void 0 : patch.type) === PatchType.DRAWING ? !inTableRow && typeof patch.patch === "function" : (patch === null || patch === void 0 ? void 0 : patch.type) !== PatchType.TABLE_ROWS && Array.isArray(patch === null || patch === void 0 ? void 0 : patch.children))) throw new Error(`Invalid patch "${key}". Expected { type: PatchType.PARAGRAPH or PatchType.DOCUMENT, children: [...] }, ${inTableRow ? "or { type: PatchType.TABLE_ROWS, rows: [...] }" : "{ type: PatchType.TABLE_ROWS, rows: [...] }, or a drawing patch such as ImagePatch, or ChartDataPatch from docx/charts"}`);
};
var imageReplacer = new ImageReplacer();
var UTF16LE = new Uint8Array([255, 254]);
var UTF16BE = new Uint8Array([254, 255]);
var PATCHED_PART_ROOTS = /* @__PURE__ */ new Set([
	"w:document",
	"w:hdr",
	"w:ftr",
	"w:footnotes",
	"w:endnotes",
	"w:comments"
]);
var compareByteArrays = (a, b) => {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
	return true;
};
(function() {
	var _ref = _asyncToGenerator(function* ({ outputType, data, patches, keepOriginalStyles, placeholderDelimiters = {
		start: "{{",
		end: "}}"
	}, recursive = true, trimPlaceholders: trimPlaceholders$1 = false, footnotes, endnotes, numbering = { config: [] }, pageNumbers, properties }) {
		const zipContent = yield loadZip(data);
		const contexts = /* @__PURE__ */ new Map();
		const themeColors = readThemeColors(zipContent);
		const contentTypeOverrides = [];
		const parts = new PackageParts({ addOverride: (contentType, partName) => contentTypeOverrides.push({
			contentType,
			partName
		}) }, new Set([...zipContent.keys()].filter((path) => path.startsWith("word/")).map((path) => path.slice(5))));
		const file = {
			Media: new Media((extension) => parts.takePath("media", "image", extension)),
			Numbering: new Numbering(numbering),
			Theme: themeColors && { Colors: themeColors },
			FootNotes: { View: { idOf: (reference, note, context) => carryNote("footnotes", reference, note, context) } },
			Endnotes: { View: { idOf: (reference, note, context) => carryNote("endnotes", reference, note, context) } },
			PackageParts: parts
		};
		const map = /* @__PURE__ */ new Map();
		const imageRelationshipAdditions = [];
		const relationshipAdditions = [];
		let hasMedia = false;
		const binaryContentMap = /* @__PURE__ */ new Map();
		checkPlaceholderDelimiters(placeholderDelimiters);
		const { start, end } = placeholderDelimiters;
		for (const [key, patch] of Object.entries(patches)) assertValidPatch(key, patch, { inTableRow: false });
		for (const [key, binaryValue] of zipContent) {
			var _json$elements;
			const startBytes = binaryValue.slice(0, 2);
			if (compareByteArrays(startBytes, UTF16LE) || compareByteArrays(startBytes, UTF16BE)) {
				binaryContentMap.set(key, binaryValue);
				continue;
			}
			if (!key.endsWith(".xml") && !key.endsWith(".rels")) {
				binaryContentMap.set(key, binaryValue);
				continue;
			}
			const json = toJson(decodeUtf8(binaryValue));
			const root = (_json$elements = json.elements) === null || _json$elements === void 0 ? void 0 : _json$elements.find((i) => {
				var _i$name;
				return PATCHED_PART_ROOTS.has((_i$name = i.name) !== null && _i$name !== void 0 ? _i$name : "");
			});
			if (root && root.attributes) {
				for (const ns of [
					"mc",
					"wp",
					"r",
					"w15",
					"m",
					"v",
					"o"
				]) root.attributes[`xmlns:${ns}`] = DocumentAttributeNamespaces[ns];
				root.attributes["mc:Ignorable"] = `${root.attributes["mc:Ignorable"] || ""} w15`.trim();
			}
			map.set(key, json);
		}
		const renumberBookmarks = renumberBookmarksAvoiding([...map.values()].flatMap(findBookmarkIds));
		const renumberDrawings = renumberDrawingsAvoiding([...map.values()].flatMap(findDrawingIds));
		const viewWrappers = /* @__PURE__ */ new Map();
		const viewWrapperOf = (key) => {
			const existing = viewWrappers.get(key);
			if (existing) return existing;
			const viewWrapper = { Relationships: { addRelationship: (id, type, target, targetMode) => {
				relationshipAdditions.push({
					key,
					id,
					type,
					target,
					targetMode
				});
			} } };
			viewWrappers.set(key, viewWrapper);
			return viewWrapper;
		};
		const createContext = (key) => ({
			file,
			viewWrapper: viewWrapperOf(key),
			stack: []
		});
		const addContentTypeOverride = (contentType, partName) => {
			contentTypeOverrides.push({
				contentType,
				partName
			});
		};
		const styles = patchStyles(map, createContext);
		const lists = patchNumbering(file.Numbering, map, {
			createContext,
			addContentTypeOverride
		});
		const notes = patchNotes({
			footnotes,
			endnotes
		}, map, {
			createContext,
			addContentTypeOverride,
			renumberBookmarks,
			renumberDrawings,
			renumberLists: lists.renumber,
			useStyles: styles.use
		});
		const carryNote = (kind, reference, note, context) => context.viewWrapper === viewWrapperOf("word/document.xml") ? notes.carry(kind, reference, note) : void 0;
		if (trimPlaceholders$1) {
			const keysWhere = (test) => Object.entries(patches).flatMap(([key, patch]) => test(patch.type) ? [key] : []);
			const keys = {
				delimiters: {
					start,
					end
				},
				textKeys: new Set(keysWhere((type) => type !== PatchType.TABLE_ROWS && type !== PatchType.DRAWING)),
				tableRowsKeys: keysWhere((type) => type === PatchType.TABLE_ROWS),
				drawingKeys: new Set(keysWhere((type) => type === PatchType.DRAWING))
			};
			for (const [key, json] of map) if (key.startsWith("word/") && !key.endsWith(".rels")) trimPlaceholders(json, keys);
		}
		patchDrawings({
			parts: map,
			binaryParts: binaryContentMap,
			file,
			patches: Object.entries(patches).flatMap(([key, patch]) => patch.type === PatchType.DRAWING ? [[key, patch]] : []),
			delimiters: {
				start,
				end
			}
		}, createContext);
		const textPatches = Object.entries(patches).flatMap(([key, patch]) => patch.type === PatchType.DRAWING ? [] : [[key, patch]]);
		const patchesInOrder = [...textPatches.filter(([, patch]) => patch.type === PatchType.TABLE_ROWS), ...textPatches.filter(([, patch]) => patch.type !== PatchType.TABLE_ROWS)];
		for (const [key, json] of [...map]) {
			if (!key.startsWith("word/") || key.endsWith(".xml.rels")) continue;
			const context = createContext(key);
			contexts.set(key, context);
			const removeShapeTypes = removeShapeTypesIn(json);
			const patchPlaceholder = (element, patchKey, patchValue) => {
				if (patchValue.type === PatchType.TABLE_ROWS) {
					patchTableRows({
						json: element,
						key: patchKey,
						patch: patchValue,
						delimiters: {
							start,
							end
						},
						patchPlaceholder,
						renumberDrawings
					});
					return;
				}
				const hyperlinkRelationships = [];
				const { didFindOccurrence } = replacer({
					json: element,
					patch: _objectSpread2(_objectSpread2({}, patchValue), {}, { children: patchValue.children.flatMap((child) => child instanceof Bookmark ? child.writtenAs : [child]).map((child) => {
						if (child instanceof ExternalHyperlink) {
							const { target, anchor } = externalHyperlinkTarget(child.options.link);
							const concreteHyperlink = new ConcreteHyperlink(child.options.children, uniqueId(), anchor, child.options.link);
							hyperlinkRelationships.push({
								key,
								id: concreteHyperlink.linkId,
								type: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
								target,
								targetMode: TargetModeType.EXTERNAL
							});
							return concreteHyperlink;
						} else return child;
					}) }),
					patchText: `${start}${patchKey}${end}`,
					context,
					keepOriginalStyles,
					recursive,
					renumberIds: (elements) => styles.use(lists.renumber(notes.renumber(renumberBookmarks(renumberDrawings(removeShapeTypes(elements))))))
				});
				if (didFindOccurrence) relationshipAdditions.push(...hyperlinkRelationships);
			};
			for (const [patchKey, patchValue] of patchesInOrder) patchPlaceholder(json, patchKey, patchValue);
		}
		notes.write();
		lists.write();
		styles.write();
		for (const [key, json] of map) {
			if (!key.startsWith("word/") || key.endsWith(".xml.rels")) continue;
			const mediaDatas = imageReplacer.getMediaData(JSON.stringify(json), file.Media);
			if (mediaDatas.length > 0) {
				hasMedia = true;
				imageRelationshipAdditions.push({
					key,
					mediaDatas
				});
			}
		}
		for (const { key, mediaDatas } of imageRelationshipAdditions) {
			var _map$get;
			const relationshipKey = relationshipsPathOf(key);
			const relationshipsJson = (_map$get = map.get(relationshipKey)) !== null && _map$get !== void 0 ? _map$get : createRelationshipFile();
			map.set(relationshipKey, relationshipsJson);
			const index = getNextRelationshipIndex(relationshipsJson);
			const newJson = imageReplacer.replace(JSON.stringify(map.get(key)), mediaDatas, index);
			map.set(key, JSON.parse(newJson));
			for (let i = 0; i < mediaDatas.length; i++) {
				const { fileName } = mediaDatas[i];
				appendRelationship(relationshipsJson, index + i, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image", `media/${fileName}`);
			}
		}
		for (const { key, id, type, target, targetMode } of relationshipAdditions) {
			var _map$get2;
			const relationshipKey = relationshipsPathOf(key);
			const relationshipsJson = (_map$get2 = map.get(relationshipKey)) !== null && _map$get2 !== void 0 ? _map$get2 : createRelationshipFile();
			map.set(relationshipKey, relationshipsJson);
			appendRelationship(relationshipsJson, id, type, target, targetMode);
		}
		if (pageNumbers) yield fillTemplatePageNumbers(map, pageNumbers, binaryContentMap);
		if (properties) patchCoreProperties(map, binaryContentMap, properties, { addContentTypeOverride });
		const packageParts = xmlifyPackageParts(file, void 0);
		if (hasMedia || contentTypeOverrides.length > 0) {
			const contentTypesJson = map.get("[Content_Types].xml");
			if (!contentTypesJson) throw new Error("Could not find content types file");
			if (hasMedia) {
				appendContentType(contentTypesJson, "image/png", "png");
				appendContentType(contentTypesJson, "image/jpeg", "jpeg");
				appendContentType(contentTypesJson, "image/jpeg", "jpg");
				appendContentType(contentTypesJson, "image/bmp", "bmp");
				appendContentType(contentTypesJson, "image/gif", "gif");
				appendContentType(contentTypesJson, "image/svg+xml", "svg");
			}
			for (const { contentType, partName } of contentTypeOverrides) appendContentTypeOverride(contentTypesJson, contentType, partName);
		}
		return zipOutput(zipFiles([
			...[...map].map(([key, value]) => [key, stringifyElement(value)]),
			...binaryContentMap,
			...file.Media.Array.map(({ data: media, fileName }) => [`word/media/${fileName}`, media]),
			...packageParts.map(({ path, data: partData }) => [path, partData])
		]), outputType, "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
	});
	return function patchDocument(_x) {
		return _ref.apply(this, arguments);
	};
})();
/**
* Patch detector for discovering placeholders in document templates.
*
* @module
*/
var isSearched = (path) => path.startsWith("word/") && /\.(xml|rels)$/.test(path) && !path.endsWith(".xml.rels");
(function() {
	var _ref = _asyncToGenerator(function* ({ data, placeholderDelimiters = {
		start: "{{",
		end: "}}"
	}, trimPlaceholders = false }) {
		checkPlaceholderDelimiters(placeholderDelimiters);
		const pattern = placeholderPattern(placeholderDelimiters);
		const zipContent = yield loadZip(data, isSearched);
		const patches = /* @__PURE__ */ new Set();
		for (const [, value] of zipContent) {
			const json = toJson(decodeUtf8(value));
			[...traverse(json).map((p) => p.text), ...findDrawings(json).flatMap(({ properties }) => altTextOf(properties))].flatMap((text) => {
				var _text$match;
				return (_text$match = text.match(pattern)) !== null && _text$match !== void 0 ? _text$match : [];
			}).map((patch) => trimPlaceholders ? patch.trim() : patch).filter((patch) => patch !== "").forEach((patch) => patches.add(patch));
		}
		return Array.from(patches);
	});
	return function patchDetector(_x) {
		return _ref.apply(this, arguments);
	};
})();
var escapeRegExp = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
/**
* The pattern of the keys of placeholders: the text between the delimiters, without them. A key has no start delimiter
* in it, so a start delimiter before a placeholder, such as in `<<unfinished <<name>>` or `a < b and <name>`, doesn't
* hide it, and the search from a start delimiter with no end after it stops at the next start delimiter.
*
* @param delimiters - The delimiters, such as `{{` and `}}`
* @returns A pattern that matches every key in a text
*/
var placeholderPattern = ({ start, end }) => new RegExp(`(?<=${escapeRegExp(start)})(?:(?!${escapeRegExp(start)}).)+?(?=${escapeRegExp(end)})`, "gs");
//#endregion
export { Packer as a, ShadingType as c, TableRow as d, TextRun as f, Footer as i, Table as l, WidthType as m, BorderStyle as n, PageNumber as o, VerticalAlignTable as p, File as r, Paragraph as s, AlignmentType as t, TableCell as u };
